-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emjQK5mDJH
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AREA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text DEFAULT NULL,
  `MASTER` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint(20) DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'221','0','emjQK5mDJH',221,'','','','2026-03-20 18:29:12','2026-03-20 18:29:12','','','','','','','','','2026-03-20 18:29:12','337','337','',0,'2026-03-20 18:29:12','2026-03-20 18:29:12');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (221,NULL,NULL,NULL,'20032026','2025-04-01','2026-03-31','20032026','','20032026','21','2003202620','','','','','','','','','','','','','','',NULL,'0',NULL,NULL,'27','','','20032026@yopmail.com','','200320',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-03-20 18:29:12','2026-03-20 18:29:12',NULL,'','','20032026');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `CREATED_TS` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `BATCH_ID` int(11) DEFAULT 0,
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DISP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `DELETED` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int(11) DEFAULT 0,
  `TAX_ID` int(11) DEFAULT 0,
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','','Y','1','1'),(2,'Printpage_margin','10mm 0 0 16mm','','Y','1','1'),(3,'invoice_page_width','255','mm','Y','1','1'),(4,'invoice_page_height','100','mm','Y','1','1'),(5,'header_height','20','mm','Y','1','2'),(6,'items_height','30','mm','Y','1','2'),(7,'items_padding_top','1','mm','Y','1','3'),(8,'blank_height','2','mm','Y','1','4'),(9,'footer_height','10','mm','Y','1','4'),(10,'top_left_address_width','97','mm','Y','1','2'),(11,'top_center_address_width','100','mm','Y','1','2'),(12,'top_center_address_padding_top','23','px','Y','1','2'),(13,'top_right_width','27','mm','Y','1','2'),(14,'top_right_padding_top','5','px','Y','1','2'),(15,'top_right_margin_left','15','px','Y','1','2'),(16,'items_qty','47','mm','Y','1','3'),(17,'items_hsn','20','mm','Y','1','3'),(18,'items_mrp','35','mm','Y','1','3'),(19,'items_particular','94','mm','Y','1','3'),(20,'items_rate','23','mm','Y','1','3'),(21,'items_free','5','mm','Y','1','3'),(22,'items_sch','5','mm','Y','1','3'),(23,'items_scheme','25','mm','Y','1','3'),(24,'items_amount','25','mm','Y','1','3'),(25,'items_gst_per','15','mm','Y','1','3'),(26,'items_gst_amt','20','mm','Y','1','3'),(27,'items_net','25','mm','Y','1','3'),(28,'footer_signature','17','mm','Y','1','4'),(29,'footer_gross','25','mm','Y','1','4'),(30,'footer_schemef','21','mm','Y','1','4'),(31,'footer_discount','17','mm','Y','1','4'),(32,'footer_display','24','mm','Y','1','4'),(33,'footer_damage','21','mm','Y','1','4'),(34,'footer_gst','21','mm','Y','1','4'),(35,'footer_add','14','mm','Y','1','4'),(36,'footer_net','25','mm','Y','1','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INV_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'221',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'221',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'221',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'221',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'221',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'221',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'221',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'221',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'221',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'221',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'221',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'221',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'221',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'221',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LEDGER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `MAC_ID` int(11) DEFAULT 0,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int(11) DEFAULT 0,
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int(11) DEFAULT 0,
  `ROOT_PARENT_ID` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-03-20 18:29:08','2026-03-20 18:29:08');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text DEFAULT NULL,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `SAC_ID` int(11) NOT NULL DEFAULT 0,
  `REMOTE_ID` int(11) NOT NULL DEFAULT 0,
  `PENDING_AMT` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `PROD_ID` int(11) NOT NULL DEFAULT 0,
  `PACK` int(11) NOT NULL DEFAULT 0,
  `PROD_BATCH_ID` int(11) NOT NULL DEFAULT 0,
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_RET_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_TOTAL` int(11) NOT NULL DEFAULT 0,
  `SALE_QTY` int(11) DEFAULT 0,
  `SALE_RET_QTY` int(11) DEFAULT 0,
  `SALE_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `SALE_TOTAL` int(11) NOT NULL DEFAULT 0,
  `OP_STOCK` int(11) NOT NULL DEFAULT 0,
  `CLOSING_STOCK` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'221',NULL,NULL,'001',NULL,'','Vaporub 25gm Proma','Vaporub 25gm Proma','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(2,'221',NULL,NULL,'002',NULL,'','Vaporub 50gm Pramo','Vaporub 50gm Pramo','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(3,'221',NULL,NULL,'003',NULL,'','INHELAR KEYCHAIN','INHELAR KEYCHAIN','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','720',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','720','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(4,'221',NULL,NULL,'80711057',NULL,'','Vaporub 5gm RTM','Vaporub 5gm RTM','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','64',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(5,'221',NULL,NULL,'80711060',NULL,'','Vaporub 10gm RTM','Vaporub 10gm RTM','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','64',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(6,'221',NULL,NULL,'82323650',NULL,'','GILLETTE GUARD CARD 1 STR','GILLETTE GUARD CARD 1 STR','82122011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','240',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(7,'221',NULL,NULL,'007',NULL,'','VCD 105+5','VCD 105+5','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(8,'221',NULL,NULL,'008',NULL,'','VCD 120','VCD 120','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(9,'221',NULL,NULL,'009',NULL,'','Wilk Saloon 50s','Wilk Saloon 50s','82122019','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','160',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(10,'221',NULL,NULL,'80722178',NULL,'','Match 3 Cart 2S','Match 3 Cart 2S','82122011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(11,'221',NULL,NULL,'80711064',NULL,'','INHELAR JUMBO','INHELAR JUMBO','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','25',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(12,'221',NULL,NULL,'80720261',NULL,'','GUARD RAZOR','GUARD RAZOR','82121010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','108',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(13,'221',NULL,NULL,'80708747',NULL,'','VAPORUB 25 GM','VAPORUB 25 GM','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','320',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','320','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(14,'221',NULL,NULL,'80708750',NULL,'','VAPORUB 50GM','VAPORUB 50GM','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(15,'221',NULL,NULL,'80707588',NULL,'','OB WS SHINY M','OB WS SHINY M','96032100','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(16,'221',NULL,NULL,'82332659',NULL,'','OB CD BACF MED','OB CD BACF MED','96032100','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','240',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(17,'221',NULL,NULL,'8233884',NULL,'','VCD 1200','VCD 1200','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(18,'221',NULL,NULL,'82333273',NULL,'','H&S SBD PRE-PACK','H&S SBD PRE-PACK','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(19,'221',NULL,NULL,'80737596',NULL,'','H&S CM 9ML','H&S CM 9ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(20,'221',NULL,NULL,'80689220',NULL,'','H&S BASIC SMOOTH RS. 2','H&S BASIC SMOOTH RS. 2','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(21,'221',NULL,NULL,'80689219',NULL,'','H&S BASIC COOL RS 2','H&S BASIC COOL RS 2','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(22,'221',NULL,NULL,'80691621',NULL,'','H&S BASIC CLEAN RS 2','H&S BASIC CLEAN RS 2','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(23,'221',NULL,NULL,'80735915',NULL,'','GAURD RAZOR WILKI PRAMO','GAURD RAZOR WILKI PRAMO','82122019','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(24,'221',NULL,NULL,'80740722',NULL,'','WHISPER CH ULTRA 6S WS','WHISPER CH ULTRA 6S WS','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(25,'221',NULL,NULL,'80744472',NULL,'','WHISPER CHOICE  XL 6 WS','WHISPER CHOICE  XL 6 WS','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(26,'221',NULL,NULL,'82311187',NULL,'','WHISPER CHOICE ALOE 7','WHISPER CHOICE ALOE 7','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','120',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(27,'221',NULL,NULL,'80744303',NULL,'','WHISPER CH WING 6S WS','WHISPER CH WING 6S WS','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(28,'221',NULL,NULL,'80738734',NULL,'','TIDE SHS JR 500 C','TIDE SHS JR 500 C','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(29,'221',NULL,NULL,'80738745',NULL,'','TIDE SHS JR 1 KG C','TIDE SHS JR 1 KG C','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(30,'221',NULL,NULL,'80726156',NULL,'','RED PANTS 1S SM','RED PANTS 1S SM','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','288',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(31,'221',NULL,NULL,'80718781',NULL,'','OB SEN CARE 6+2 SW','OB SEN CARE 6+2 SW','96032100','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(32,'221',NULL,NULL,'80736762',NULL,'','Guard 1s New','Guard 1s New','82122011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','240',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(33,'221',NULL,NULL,'80740750',NULL,'','ARIEL PW BLUE 500G C','ARIEL PW BLUE 500G C','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(34,'221',NULL,NULL,'80705561',NULL,'','TIDE WHITE BAR RS 10','TIDE WHITE BAR RS 10','34011942','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(35,'221',NULL,NULL,'80712321',NULL,'','SIMPLY VENUS 3S DISP','SIMPLY VENUS 3S DISP','82121010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(36,'221',NULL,NULL,'80724023',NULL,'','TIDE NATURALS 500G','TIDE NATURALS 500G','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(37,'221',NULL,NULL,'80724024',NULL,'','TIDE NATURALS 800G+200G','TIDE NATURALS 800G+200G','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(38,'221',NULL,NULL,'80732832',NULL,'','TIDE JR RS 10','TIDE JR RS 10','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(39,'221',NULL,NULL,'80738585',NULL,'','TIDE JR 4+1 KG','TIDE JR 4+1 KG','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(40,'221',NULL,NULL,'80741267',NULL,'','ARIEL PERFECT WASH RS 10','ARIEL PERFECT WASH RS 10','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(41,'221',NULL,NULL,'80726158',NULL,'','RED PANTS 1S MD','RED PANTS 1S MD','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','280',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','280','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(42,'221',NULL,NULL,'80732255',NULL,'','WHISPER ULT CLN 30+ ON XXXL 2S','WHISPER ULT CLN 30+ ON XXXL 2S','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','18',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(43,'221',NULL,NULL,'80741318',NULL,'','CHOICE ULTRA 20S + ON XL + 2S','CHOICE ULTRA 20S + ON XL + 2S','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(44,'221',NULL,NULL,'80713796',NULL,'','BLUE PANTS REGS MD','BLUE PANTS REGS MD','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(45,'221',NULL,NULL,'80682833',NULL,'','RED PANTS 2S SM','RED PANTS 2S SM','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(46,'221',NULL,NULL,'80744296',NULL,'','WHISPER CHOICE WING 20S','WHISPER CHOICE WING 20S','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','30',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(47,'221',NULL,NULL,'80741560',NULL,'','RED PANTS 2S LG','RED PANTS 2S LG','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(48,'221',NULL,NULL,'80682837',NULL,'','RED PANTS 2S MD','RED PANTS 2S MD','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(49,'221',NULL,NULL,'80698414',NULL,'','RED PANTS SM 10S','RED PANTS SM 10S','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(50,'221',NULL,NULL,'80698416',NULL,'','RED PANTS MD 8S','RED PANTS MD 8S','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(51,'221',NULL,NULL,'80737597',NULL,'','H&S SS 9ML','H&S SS 9ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(52,'221',NULL,NULL,'80737595',NULL,'','H&S SB 9ML','H&S SB 9ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(53,'221',NULL,NULL,'80738984',NULL,'','H&S SS 90ML','H&S SS 90ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(54,'221',NULL,NULL,'80738991',NULL,'','H&S SB 90ML','H&S SB 90ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(55,'221',NULL,NULL,'80738985',NULL,'','H&S CM 90ML','H&S CM 90ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(56,'221',NULL,NULL,'80738987',NULL,'','H&S AHF 90ML','H&S AHF 90ML','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(57,'221',NULL,NULL,'80741556',NULL,'','RED PANTS 1S LG','RED PANTS 1S LG','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','280',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','280','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(58,'221',NULL,NULL,'80737593',NULL,'','H&S NEEM RS 2','H&S NEEM RS 2','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(59,'221',NULL,NULL,'80749177',NULL,'','VICKS 25GM (MRP 99)','VICKS 25GM (MRP 99)','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(60,'221',NULL,NULL,'80739759',NULL,'','OB WS SHINY','OB WS SHINY','96032100','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(61,'221',NULL,NULL,'807337256',NULL,'','RED PANTS REGS LG','RED PANTS REGS LG','96190023','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(62,'221',NULL,NULL,'80733311',NULL,'','PNTA 2IN 1 HFC RS 2','PNTA 2IN 1 HFC RS 2','33051090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(63,'221',NULL,NULL,'80727177',NULL,'','Guard Razor','Guard Razor','82121010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','108',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(64,'221',NULL,NULL,'80740716',NULL,'','WHISPER CHOICE ULTR 20S','WHISPER CHOICE ULTR 20S','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','30',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(65,'221',NULL,NULL,'80735821 A',NULL,'','RED PANTS 1S SM','RED PANTS 1S SM','96190030','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','288',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(66,'221',NULL,NULL,'80735249',NULL,'','VCD 450','VCD 450','','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','9',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','9','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(67,'221',NULL,NULL,'80735251',NULL,'','VCD 1200','VCD 1200','','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(68,'221',NULL,NULL,'80757548',NULL,'','RED PANTS 2X XL','RED PANTS 2X XL','','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(69,'221',NULL,NULL,'123456',NULL,'','OB WHOLSALE SHINY S','OB WHOLSALE SHINY S','96032100','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(70,'221',NULL,NULL,'1234567',NULL,'','WHISPER CH ULTRA 6S WS RS.50','WHISPER CH ULTRA 6S WS RS.50','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','64',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(71,'221',NULL,NULL,'80724285',NULL,'','ARIEL PW RS.3','ARIEL PW RS.3','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(72,'221',NULL,NULL,'80778560',NULL,'','Guard Cart 8s','Guard Cart 8s','82122011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','480',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(73,'221',NULL,NULL,'80787544',NULL,'','VICKS BABYRUB 10ML RTM','VICKS BABYRUB 10ML RTM','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(74,'221',NULL,NULL,'80816867',NULL,'','VICKS BABY RUB 25GM','VICKS BABY RUB 25GM','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(75,'221',NULL,NULL,'80788420',NULL,'','VCD 60+5','VCD 60+5','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(76,'221',NULL,NULL,'80814763',NULL,'','WHSPR CHOICE XL 6S','WHSPR CHOICE XL 6S','96190010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','60',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(77,'221',NULL,NULL,'80764164',NULL,'','WINNER-50S PROMO','WINNER-50S PROMO','82122019','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','160',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(78,'221',NULL,NULL,'80838236',NULL,'','TIDE JR 9 KG','TIDE JR 9 KG','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','3',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','3','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(79,'221',NULL,NULL,'80797375',NULL,'','ARIAL MAT 6KG+ LIQ','ARIAL MAT 6KG+ LIQ','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(80,'221',NULL,NULL,'80820212',NULL,'','Guard Cart 4s','Guard Cart 4s','82122011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','480',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(81,'221',NULL,NULL,'80797368',NULL,'','ARIEL LIQ RS.10 TL','ARIEL LIQ RS.10 TL','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(82,'221',NULL,NULL,'80827708',NULL,'','ARIEL PW BLUE 1KG','ARIEL PW BLUE 1KG','34022010','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(83,'221',NULL,NULL,'80787260',NULL,'','VAPORUB 105ML SW PROMO','VAPORUB 105ML SW PROMO','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(84,'221',NULL,NULL,'80839936',NULL,'','VAPORUB 50GM+20\\% EXTRA','VAPORUB 50GM+20\\% EXTRA','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(85,'221',NULL,NULL,'80814323',NULL,'','ARIEL COMPLETE 1.5KG','ARIEL COMPLETE 1.5KG','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','16',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(86,'221',NULL,NULL,'80829752',NULL,'','ARIEL LIQUID 1L TL','ARIEL LIQUID 1L TL','3402500','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(87,'221',NULL,NULL,'80769917',NULL,'','TIDE LIQ 850 ML FL','TIDE LIQ 850 ML FL','34025000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','16',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(88,'221',NULL,NULL,'80760597',NULL,'','TIDE WHITE BAR 250G','TIDE WHITE BAR 250G','34011941','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(89,'221',NULL,NULL,'80712327',NULL,'','FAT FOAMY (REG) 300GM','FAT FOAMY (REG) 300GM','33071090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(90,'221',NULL,NULL,'80787545',NULL,'','BABYRUB 10 ML','BABYRUB 10 ML','30049011','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','1080',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1080','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(91,'221',NULL,NULL,'82325380',NULL,'','EZE DEO 150 ML','EZE DEO 150 ML','33072000','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','16',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(92,'221',NULL,NULL,'80739417',NULL,'','EZE PERFUME 18ML','EZE PERFUME 18ML','33030090','1','3',NULL,'1','AAGASTI ENTERPRISES','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','AAGASTI ENTERPRISES',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'221',NULL,NULL,'AAGASTI ENTERPRISES','1',NULL,NULL,NULL,NULL,NULL,'337','337',NULL,0,'2026-03-20 18:31:28','2026-03-20 18:31:28');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'221',NULL,NULL,'1','1.75811E+12','2000-01-01','Invalid date','1','0','0','0.00','2448','0','0','1728.1','0','-1728.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(2,'221',NULL,NULL,'2','1.75811E+12','2000-01-01','2001-12-01','2','0','0','0.00','2790','1215','0','2324.76','0','-1109.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(3,'221',NULL,NULL,'3','1.75811E+12','2000-01-01','0720-01-01','3','0','0','0.00','72','0','0','46.19','0','-46.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(4,'221',NULL,NULL,'4','1.75811E+12','2000-01-01','1964-01-01','80711057','187.75','0','0.00','345','0','0','240.33','0','-240.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(5,'221',NULL,NULL,'5','1.75811E+12','2000-01-01','1964-01-01','80711060','357.62','0','0.00','675','0','0','357.62','0','-357.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(6,'221',NULL,NULL,'6','1.75811E+12','2000-01-01','0240-01-01','82323650','67.8','0','0.00','0','0','0','67.8','0','-67.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(7,'221',NULL,NULL,'7','1.75811E+12','2000-01-01','2032-01-01','7','175.74','0','0.00','205','0','0','152.74','0','-152.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(8,'221',NULL,NULL,'8','1.75811E+12','2000-01-01','2032-01-01','8','89.41','0','0.00','120','0','0','89.41','0','-89.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(9,'221',NULL,NULL,'9','1.75811E+12','2000-01-01','0160-01-01','9','79.68','0','0.00','140','0','0','79.68','0','-79.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(10,'221',NULL,NULL,'10','1.75811E+12','2000-01-01','1972-01-01','80722178','0','0','0.00','275','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(11,'221',NULL,NULL,'10','1.75811E+12','2000-01-01','1972-01-01','80722178','0','0','0.00','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(12,'221',NULL,NULL,'10','1.75811E+12','2000-01-01','1972-01-01','80722178','0','0','0.00','349','0','0','209.96','0','-209.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(13,'221',NULL,NULL,'11','1.75811E+12','2000-01-01','Invalid date','80711064','831.44','0','0.00','1240','0','0','831.44','0','-831.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(14,'221',NULL,NULL,'12','1.75811E+12','2000-01-01','0108-01-01','80720261','0','0','0.00','125','0','0','84.75','0','-84.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(15,'221',NULL,NULL,'13','1.75811E+12','2000-01-01','0320-01-01','80708747','0','0','0.00','90','0','0','67.05','0','-67.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(16,'221',NULL,NULL,'14','1.75811E+12','2000-01-01','0144-01-01','80708750','0','0','0.00','155','0','0','115.48','0','-115.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(17,'221',NULL,NULL,'15','1.75811E+12','2000-01-01','17/09/2025','80707588','2542.36','0','0.00','3600','0','0','2542.36','0','-2542.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(18,'221',NULL,NULL,'16','1.75811E+12','2000-01-01','0240-01-01','82332659','20.75','0','0.00','30','0','0','20.75','0','-20.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(19,'221',NULL,NULL,'17','1.75811E+12','2000-01-01','2001-04-01','8233884','953.62','0','0.00','1280','0','0','953.62','0','-953.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(20,'221',NULL,NULL,'18','1.75811E+12','2000-01-01','Invalid date','82333273','77.97','0','0.00','128','0','0','77.97','0','-77.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(21,'221',NULL,NULL,'19','1.75811E+12','2000-01-01','2040-01-01','80737596','58.26','0','0.00','80','0','0','58.26','0','-58.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(22,'221',NULL,NULL,'20','1.75811E+12','2000-01-01','1960-01-01','80689220','20.76','0','0.00','60','0','0','20.76','0','-20.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(23,'221',NULL,NULL,'21','1.75811E+12','2000-01-01','1960-01-01','80689219','20.76','0','0.00','32','0','0','20.76','0','-20.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(24,'221',NULL,NULL,'22','1.75811E+12','2000-01-01','1960-01-01','80691621','20.76','0','0.00','32','0','0','20.76','0','-20.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(25,'221',NULL,NULL,'23','1.75811E+12','2000-01-01','Invalid date','80735915','84.75','0','0.00','125','0','0','84.75','0','-84.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(26,'221',NULL,NULL,'24','1.75811E+12','2000-01-01','2001-01-01','80740722','4203.36','0','0.00','5184','0','0','4203.36','0','-4203.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(27,'221',NULL,NULL,'25','1.75811E+12','2000-01-01','2001-01-01','80744472','3697.4','0','0.00','4560','0','0','3697.4','0','-3697.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(28,'221',NULL,NULL,'26','1.75811E+12','2000-01-01','0120-01-01','82311187','22.52','0','0.00','25','0','0','22.52','0','-22.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(29,'221',NULL,NULL,'27','1.75811E+12','2000-01-01','2001-01-01','80744303','3113.6','0','0.00','3840','0','0','3113.6','0','-3113.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(30,'221',NULL,NULL,'28','1.75811E+12','2000-01-01','2048-01-01','80738734','54.92','0','0.00','72','0','0','54.92','0','-54.92','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(31,'221',NULL,NULL,'29','1.75811E+12','2000-01-01','Invalid date','80738745','109.86','0','0.00','144','0','0','109.86','0','-109.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(32,'221',NULL,NULL,'30','1.75811E+12','2000-01-01','0288-01-01','80726156','7.62','0','0.00','10','0','0','7.62','0','-7.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(33,'221',NULL,NULL,'31','1.75811E+12','2000-01-01','Invalid date','80718781','127.12','0','0.00','180','0','0','127.12','0','-127.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(34,'221',NULL,NULL,'32','1.75811E+12','2000-01-01','0240-01-01','80736762','81.36','0','0.00','150','0','0','81.36','0','-81.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(35,'221',NULL,NULL,'33','1.75811E+12','2000-01-01','2048-01-01','80740750','62.78','0','0.00','0','0','0','62.78','0','-62.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(36,'221',NULL,NULL,'34','1.75811E+12','2000-01-01','1972-01-01','80705561','7.85','0','0.00','10','0','0','7.85','0','-7.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(37,'221',NULL,NULL,'35','1.75811E+12','2000-01-01','0192-01-01','80712321','55.75','0','0.00','0','0','0','55.75','0','-55.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(38,'221',NULL,NULL,'36','1.75811E+12','2000-01-01','2048-01-01','80724023','32.17','0','0.00','0','0','0','32.17','0','-32.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(39,'221',NULL,NULL,'37','1.75811E+12','2000-01-01','Invalid date','80724024','54.92','0','0.00','0','0','0','61.99','0','-61.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(40,'221',NULL,NULL,'38','1.75811E+12','2000-01-01','2001-05-01','80732832','86.47','0','0.00','120','0','0','86.47','0','-86.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(41,'221',NULL,NULL,'39','1.75811E+12','2000-01-01','2001-05-01','80738585','498.28','0','0.00','675','0','0','498.28','0','-498.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(42,'221',NULL,NULL,'40','1.75811E+12','2000-01-01','2001-05-01','80741267','86.47','0','0.00','0','0','0','86.47','0','-86.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(43,'221',NULL,NULL,'41','1.75811E+12','2000-01-01','0280-01-01','80726158','9.16','0','0.00','0','0','0','9.16','0','-9.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(44,'221',NULL,NULL,'42','1.75811E+12','2000-01-01','Invalid date','80732255','139.64','0','0.00','155','0','0','307.02','0','-307.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(45,'221',NULL,NULL,'43','1.75811E+12','2000-01-01','2032-01-01','80741318','139.64','0','0.00','155','0','0','139.64','0','-139.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(46,'221',NULL,NULL,'44','1.75811E+12','2000-01-01','2032-01-01','80713796','76.87','0','0.00','99','0','0','76.87','0','-76.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(47,'221',NULL,NULL,'45','1.75811E+12','2000-01-01','0144-01-01','80682833','15.26','0','0.00','20','0','0','15.26','0','-15.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(48,'221',NULL,NULL,'46','1.75811E+12','2000-01-01','Invalid date','80744296','89.19','0','0.00','99','0','0','89.19','0','-89.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:29',NULL),(49,'221',NULL,NULL,'47','1.75811E+12','2000-01-01','0144-01-01','80741560','22.89','0','0.00','30','0','0','22.89','0','-22.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(50,'221',NULL,NULL,'48','1.75811E+12','2000-01-01','0144-01-01','80682837','18.31','0','0.00','24','0','0','18.31','0','-18.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(51,'221',NULL,NULL,'49','1.75811E+12','2000-01-01','2032-01-01','80698414','0','0','0.00','99','0','0','76.87','0','-76.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(52,'221',NULL,NULL,'50','1.75811E+12','2000-01-01','2032-01-01','80698416','0','0','0.00','99','0','0','76.87','0','-76.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(53,'221',NULL,NULL,'51','1.75811E+12','2000-01-01','2040-01-01','80737597','58.26','0','0.00','80','0','0','58.26','0','-58.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(54,'221',NULL,NULL,'52','1.75811E+12','2000-01-01','2040-01-01','80737595','58.26','0','0.00','80','0','0','58.26','0','-58.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(55,'221',NULL,NULL,'53','1.75811E+12','2000-01-01','2048-01-01','80738984','60.86','0','0.00','79','0','0','60.86','0','-60.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(56,'221',NULL,NULL,'54','1.75811E+12','2000-01-01','2048-01-01','80738991','60.86','0','0.00','79','0','0','60.86','0','-60.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(57,'221',NULL,NULL,'55','1.75811E+12','2000-01-01','2048-01-01','80738985','60.86','0','0.00','79','0','0','60.86','0','-60.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(58,'221',NULL,NULL,'56','1.75811E+12','2000-01-01','2048-01-01','80738987','60.86','0','0.00','79','0','0','60.86','0','-60.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(59,'221',NULL,NULL,'57','1.75811E+12','2000-01-01','0280-01-01','80741556','111.45','0','0.00','15','0','0','11.45','0','-11.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(60,'221',NULL,NULL,'58','1.75811E+12','2000-01-01','1960-01-01','80737593','20.76','0','0.00','32','0','0','20.76','0','-20.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(61,'221',NULL,NULL,'59','1.75811E+12','2000-01-01','2032-01-01','80749177','0','0','0.00','99','0','0','73.76','0','-73.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(62,'221',NULL,NULL,'60','1.75811E+12','2000-01-01','2001-01-01','80739759','0','0','0.00','3600','0','0','2542.36','0','-2542.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(63,'221',NULL,NULL,'61','1.75811E+12','2000-01-01','2032-01-01','807337256','0','0','0.00','99','0','0','76.87','0','-76.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(64,'221',NULL,NULL,'62','1.75811E+12','2000-01-01','1960-01-01','80733311','20.76','0','0.00','0','0','0','20.76','0','-20.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(65,'221',NULL,NULL,'63','1.75811E+12','2000-01-01','0108-01-01','80727177','83.86','0','0.00','140','0','0','83.86','0','-83.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(66,'221',NULL,NULL,'64','1.75811E+12','2000-01-01','Invalid date','80740716','139.64','0','0.00','0','0','0','139.64','0','-139.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(67,'221',NULL,NULL,'65','1.75811E+12','2000-01-01','0288-01-01','80735821 A','0','0','0.00','10','0','0','7.63','0','-7.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(68,'221',NULL,NULL,'65','1.75811E+12','2000-01-01','0288-01-01','80735821','0','0','0.00','10','0','0','7.62','0','-7.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(69,'221',NULL,NULL,'66','1.75811E+12','2000-01-01','2001-09-01','80735249','0','0','0.00','495','0','0','368.81','0','-368.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(70,'221',NULL,NULL,'67','1.75811E+12','2000-01-01','2001-04-01','80735251','0','0','0.00','1280','0','0','953.62','0','-953.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(71,'221',NULL,NULL,'68','1.75811E+12','2000-01-01','0144-01-01','80757548','0','0','0.00','36','0','0','27.47','0','-27.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(72,'221',NULL,NULL,'69','1.75811E+12','2000-01-01','Invalid date','123456','92.11','0','0.00','24','0','0','91.11','0','-91.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(73,'221',NULL,NULL,'70','1.75811E+12','2000-01-01','1964-01-01','1234567','0','0','0.00','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(74,'221',NULL,NULL,'70','1.75811E+12','2000-01-01','1964-01-01','1234567','34.65','0','0.00','48','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(75,'221',NULL,NULL,'70','1.75811E+12','2000-01-01','1964-01-01','1234567','34.65','0','0.00','48','0','0','34.65','0','-34.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(76,'221',NULL,NULL,'71','1.75811E+12','2000-01-01','2001-06-01','80724285','0','0','0.00','252','0','0','153.54','0','-153.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(77,'221',NULL,NULL,'72','1.75811E+12','2000-01-01','0480-01-01','80778560','75.67','0','0.00','98','0','0','44.49','0','-44.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(78,'221',NULL,NULL,'73','1.75811E+12','2000-01-01','0144-01-01','80787544','0','0','0.00','220','0','0','173.6','0','-173.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(79,'221',NULL,NULL,'74','1.75811E+12','2000-01-01','Invalid date','80816867','1617','0','0.00','2500','0','0','1422.96','0','-1422.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(80,'221',NULL,NULL,'75','1.75811E+12','2000-01-01','2032-01-01','80788420','40.92','0','0.00','130','0','0','73.5','0','-73.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(81,'221',NULL,NULL,'76','1.75811E+12','2000-01-01','1960-01-01','80814763','0','0','0.00','42','0','0','30','0','-30.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(82,'221',NULL,NULL,'77','1.75811E+12','2000-01-01','0160-01-01','80764164','0','0','0.00','150','0','0','69.07','0','-69.07','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(83,'221',NULL,NULL,'78','1.75811E+12','2000-01-01','2001-03-01','80838236','0','0','0.00','899','0','0','655','0','-655.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(84,'221',NULL,NULL,'79','1.75811E+12','2000-01-01','2001-02-01','80797375','0','0','0.00','1399','0','0','1122.82','0','-1122.82','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(85,'221',NULL,NULL,'80','1.75811E+12','2000-01-01','0480-01-01','80820212','0','0','0.00','52','0','0','27.11','0','-27.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(86,'221',NULL,NULL,'81','1.75811E+12','2000-01-01','Invalid date','80797368','0','0','0.00','60','0','0','74.96','0','-74.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(87,'221',NULL,NULL,'81','1.75811E+12','2000-01-01','Invalid date','80797368','0','0','0.00','60','0','0','32','0','-32.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(88,'221',NULL,NULL,'82','1.75811E+12','2000-01-01','Invalid date','80827708','0','0','0.00','179','0','0','130','0','-130.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(89,'221',NULL,NULL,'83','1.75811E+12','2000-01-01','2001-08-01','80787260','0','0','0.00','3060','0','0','964.2','0','-964.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(90,'221',NULL,NULL,'84','1.75811E+12','2000-01-01','2001-12-01','80839936','0','0','0.00','2985','0','0','1446.42','0','-1446.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(91,'221',NULL,NULL,'85','1.75811E+12','2000-01-01','Invalid date','80814323','0','0','0.00','369','0','0','211.86','0','-211.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(92,'221',NULL,NULL,'86','1.75811E+12','2000-01-01','2001-12-01','80829752','0','0','0.00','229','0','0','196.29','0','-196.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(93,'221',NULL,NULL,'87','1.75811E+12','2000-01-01','Invalid date','80769917','0','0','0.00','169','0','0','117.18','0','-117.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(94,'221',NULL,NULL,'88','1.75811E+12','2000-01-01','2048-01-01','80760597','0','0','0.00','30','0','0','20.16','0','-20.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(95,'221',NULL,NULL,'89','1.75811E+12','2000-01-01','2001-12-01','80712327','0','0','0.00','275','0','0','141.5','0','-141.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(96,'221',NULL,NULL,'90','1.75811E+12','2000-01-01','1080-01-01','80787545','0','0','0.00','55','0','0','45.9','0','-45.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(97,'221',NULL,NULL,'91','1.75811E+12','2000-01-01','Invalid date','82325380','0','0','0.00','225','0','0','180.5','0','-180.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL),(98,'221',NULL,NULL,'92','1.75811E+12','2000-01-01','Invalid date','80739417','0','0','0.00','225','0','0','155.5','0','-155.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-20 18:31:30',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int(11) DEFAULT 0,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int(11) DEFAULT 0,
  `M_ROUND_OFF` int(11) DEFAULT 0,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL,
  `LITE_ID` varchar(50) DEFAULT '',
  `WEB_ID` varchar(50) DEFAULT '',
  `PROD_ID` int(11) NOT NULL,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` varchar(50) DEFAULT NULL,
  `PUR_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT` varchar(25) DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) DEFAULT '0',
  `PUR_CESS` varchar(25) DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) DEFAULT '0',
  `PACK` varchar(25) DEFAULT '0',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(25) DEFAULT '0',
  `DISC_PERCENT` varchar(25) DEFAULT '0',
  `DISC_AMOUNT` varchar(25) DEFAULT '0',
  `RETURN_QTY` varchar(25) DEFAULT '0',
  `FREE` varchar(25) DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) DEFAULT '0',
  `AMT` varchar(25) DEFAULT '0',
  `TAX_AMT` varchar(25) DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) DEFAULT '0',
  `RETURN` varchar(25) DEFAULT '0',
  `SR_NO` varchar(50) DEFAULT '',
  `CESS_AMT` varchar(25) DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) DEFAULT '0',
  `UI_DISP_BAG` varchar(50) DEFAULT '',
  `WEIGHT` varchar(25) DEFAULT '0',
  `PRICE_PER` varchar(25) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT NULL,
  `TE_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) DEFAULT '0',
  `MRP` varchar(25) DEFAULT '0',
  `DAMAGE` varchar(25) DEFAULT '0',
  `DAMAGE_AMT` varchar(25) DEFAULT '0',
  `REPLACE` varchar(25) DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) DEFAULT '0',
  `DMG_MRP` varchar(25) DEFAULT '0',
  `PUR_INSURANCE` varchar(25) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) DEFAULT '0',
  `CLOUD_SYNC` varchar(25) DEFAULT '0',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT current_timestamp(),
  `UPDATED_TS` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `FINAL_AMT` varchar(25) DEFAULT '0',
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `TCS_TAX` varchar(100) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `BROKER_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (337,'221','0','emjQK5mDJH','20032026','emjQK5mDJH','20032026@yopmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','','337','337','',0,'2026-03-20 18:29:12','2026-03-20 18:29:12');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REMARKS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT 0,
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-03-20 18:29:07',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text DEFAULT NULL,
  `MAC_ID` int(11) DEFAULT 0,
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text DEFAULT NULL,
  `S_ADD2` text DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'221',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(2,'221',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(3,'221',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(4,'221',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(5,'221',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(6,'221',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(7,'221',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(8,'221',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(9,'221',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(10,'221',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(11,'221',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(12,'221',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(13,'221',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(14,'221',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(15,'221',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(16,'221',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(17,'221',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(18,'221',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(19,'221',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(20,'221',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(21,'221',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(22,'221',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(23,'221',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(24,'221',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(25,'221',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(26,'221',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(27,'221',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(28,'221',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(29,'221',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(30,'221',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(31,'221',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(32,'221',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(33,'221',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(34,'221',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(35,'221',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(36,'221',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(37,'221',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(38,'221',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(39,'221',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(40,'221',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(41,'221',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(42,'221',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(43,'221',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(44,'221',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(45,'221',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(46,'221',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(47,'221',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(48,'221',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(49,'221',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(50,'221',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(51,'221',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(52,'221',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(53,'221',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(54,'221',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(55,'221',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(56,'221',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(57,'221',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(58,'221',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(59,'221',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(60,'221',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(61,'221',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(62,'221',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(63,'221',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(64,'221',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(65,'221',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(66,'221',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(67,'221',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(68,'221',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(69,'221',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(70,'221',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(71,'221',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(72,'221',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(73,'221',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(74,'221',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(75,'221',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(76,'221',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(77,'221',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(78,'221',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(79,'221',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(80,'221',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(81,'221',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(82,'221',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(83,'221',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(84,'221',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(85,'221',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(86,'221',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(87,'221',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(88,'221',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(89,'221',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(90,'221',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(91,'221',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(92,'221',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(93,'221',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(94,'221',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(95,'221',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(96,'221',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(97,'221',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09'),(98,'221',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-20 18:29:09','2026-03-20 18:29:09');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int(11) NOT NULL DEFAULT 0,
  `ADDRESS1` text DEFAULT NULL,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `PG_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` int(11) DEFAULT 0,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT NULL,
  `LITE_ID` varchar(50) DEFAULT NULL,
  `WEB_ID` varchar(50) DEFAULT NULL,
  `PROD_ID` varchar(20) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) DEFAULT NULL,
  `SALES_ID` varchar(20) DEFAULT NULL,
  `SALE_UNIT` varchar(20) DEFAULT NULL,
  `SALE_RATE` varchar(20) DEFAULT NULL,
  `PUR_RATE` varchar(20) DEFAULT NULL,
  `PROD_PACK` varchar(20) DEFAULT NULL,
  `PUR_VAT` varchar(20) DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_VAT` varchar(20) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_CESS` varchar(20) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) DEFAULT NULL,
  `PACK` varchar(20) DEFAULT NULL,
  `BOX` varchar(20) DEFAULT NULL,
  `QTY` varchar(20) DEFAULT NULL,
  `DISC_PERCENT` varchar(20) DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) DEFAULT NULL,
  `RETURN_QTY` varchar(20) DEFAULT NULL,
  `FREE` varchar(20) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) DEFAULT NULL,
  `AMT` varchar(20) DEFAULT NULL,
  `PUR_AMT` varchar(20) DEFAULT NULL,
  `PROFIT` varchar(20) DEFAULT NULL,
  `TAX_AMT` varchar(20) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) DEFAULT NULL,
  `DAMAGE` varchar(20) DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) DEFAULT NULL,
  `REPLACE` varchar(25) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) DEFAULT NULL,
  `RETURN` varchar(25) DEFAULT NULL,
  `SR_NO` varchar(50) DEFAULT NULL,
  `CESS_AMT` varchar(20) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) DEFAULT NULL,
  `WEIGHT` varchar(20) DEFAULT NULL,
  `PUR_UNIT` varchar(20) DEFAULT NULL,
  `PRICE_PER` varchar(20) DEFAULT NULL,
  `TE_RATE` varchar(20) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) DEFAULT NULL,
  `DMG_MRP` varchar(20) DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) DEFAULT NULL,
  `INV_ARR` varchar(255) DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` varchar(20) DEFAULT NULL,
  `UPDATED_BY` varchar(20) DEFAULT NULL,
  `SECURITY_KEY` varchar(100) DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(20) DEFAULT NULL,
  `SALES_MAN` varchar(100) DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(20) DEFAULT NULL,
  `PARTY_CODE` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(20) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) DEFAULT NULL,
  `BATCH_NO` varchar(50) DEFAULT NULL,
  `MFG_DATE` varchar(20) DEFAULT NULL,
  `EXP_DATE` varchar(20) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int(11) DEFAULT 0,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int(11) DEFAULT 0,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int(11) DEFAULT 0,
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SMAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYNC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text DEFAULT NULL,
  `UPDATED_VALUE` text DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text DEFAULT NULL,
  `DIACM` text DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int(11) DEFAULT 0,
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int(11) DEFAULT 0,
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-03-20 18:29:07','2026-03-20 18:29:07');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UOM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT 0,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WEB_ID` int(11) NOT NULL DEFAULT 0,
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-03-20 18:29:12');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 11:00:36
