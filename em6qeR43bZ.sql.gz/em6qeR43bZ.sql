-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: em6qeR43bZ
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text DEFAULT NULL,
  `MASTER` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint(20) DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'172','0','em6qeR43bZ',172,'','','','2026-02-27 10:32:18','2026-02-27 10:32:18','','','','','','','','','2026-02-27 10:32:18','289','289','',0,'2026-02-27 10:32:18','2026-02-27 10:32:18');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (172,NULL,NULL,NULL,'mayank','2025-04-01','2026-03-31','mayank','','mayank','21','2222222222','','','','','','','','','','','','','','',NULL,'0',NULL,NULL,'27','','','mayank@yopmail.com','','222222',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-02-27 10:32:17','2026-02-27 10:32:17',NULL,'','','mayank');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `CREATED_TS` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `BATCH_ID` int(11) DEFAULT 0,
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DISP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `DELETED` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int(11) DEFAULT 0,
  `TAX_ID` int(11) DEFAULT 0,
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT 'mm',
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int(11) NOT NULL DEFAULT 0,
  `GROUP_ID` int(11) NOT NULL DEFAULT 0,
  `DISPLAY_ORDER` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','mm','Y',0,1,0),(2,'Printpage_Top_Margin','10','mm','Y',0,1,0),(3,'Printpage_Left_Margin','16','mm','Y',0,1,0),(4,'Printpage_Border','1','px','Y',0,1,0),(5,'Top_Left_Width','97','mm','Y',0,2,0),(6,'Top_Center_Width','100','mm','Y',0,2,0),(7,'Padding_Top_Right','5','px','Y',0,2,0),(8,'Item_Listing_Padding_Top','0','mm','Y',0,3,0),(9,'Items_Height','30','mm','Y',0,3,0),(10,'List_1','47','mm','Y',0,3,0),(11,'List_2','20','mm','Y',0,3,0),(12,'List_3','35','mm','Y',0,3,0),(13,'List_4','94','mm','Y',0,3,0),(14,'List_5','23','mm','Y',0,3,0),(15,'List_6','5','mm','Y',0,3,0),(16,'List_7','5','mm','Y',0,3,0),(17,'List_8','25','mm','Y',0,3,0),(18,'List_9','25','mm','Y',0,3,0),(19,'List_10','15','mm','Y',0,3,0),(20,'List_11','20','mm','Y',0,3,0),(21,'List_12','25','mm','Y',0,3,0),(22,'Blank_Space_Top_Padding','2','mm','Y',0,4,0),(23,'Footer_Padding_Top','2','mm','Y',0,4,0),(24,'Footer_1','17','mm','Y',0,4,0),(25,'Footer_2','25','mm','Y',0,4,0),(26,'Footer_3','21','mm','Y',0,4,0),(27,'Footer_4','17','mm','Y',0,4,0),(28,'Footer_5','24','mm','Y',0,4,0),(29,'Footer_6','21','mm','Y',0,4,0),(30,'Footer_7','21','mm','Y',0,4,0),(31,'Footer_8','14','mm','Y',0,4,0),(32,'Footer_9','25','mm','Y',0,4,0),(33,'Footer_10','0','mm','Y',0,4,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INV_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'172',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'172',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'172',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'172',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'172',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'172',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'172',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'172',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'172',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'172',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'172',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'172',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'172',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'172',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LEDGER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `MAC_ID` int(11) DEFAULT 0,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int(11) DEFAULT 0,
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int(11) DEFAULT 0,
  `ROOT_PARENT_ID` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text DEFAULT NULL,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `PROD_ID` int(11) NOT NULL DEFAULT 0,
  `PACK` int(11) NOT NULL DEFAULT 0,
  `PROD_BATCH_ID` int(11) NOT NULL DEFAULT 0,
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_RET_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_TOTAL` int(11) NOT NULL DEFAULT 0,
  `SALE_QTY` int(11) DEFAULT 0,
  `SALE_RET_QTY` int(11) DEFAULT 0,
  `SALE_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `SALE_TOTAL` int(11) NOT NULL DEFAULT 0,
  `OP_STOCK` int(11) NOT NULL DEFAULT 0,
  `CLOSING_STOCK` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=654 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'172',NULL,NULL,'101',NULL,'','LYNK PREMIUM MAYSORE PAK  85 GM','LYNK PREMIUM MAYSORE PAK  85 GM','21069099','85','2',NULL,'1','SSK AGENCY','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','SSK AGENCY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-27 11:27:44',NULL),(2,'172',NULL,NULL,'102',NULL,'','LYNK PREMIUM MAYSORE PAK  200 GM','LYNK PREMIUM MAYSORE PAK  200 GM','21069099','200','2',NULL,'1','SSK AGENCY','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','SSK AGENCY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-27 11:27:44',NULL),(3,'172',NULL,NULL,'111',NULL,'','LYNK PREMIUM MILK CAKE 200 GM','LYNK PREMIUM MILK CAKE 200 GM','21069099','200','2',NULL,'1','SSK AGENCY','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','SSK AGENCY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-27 11:27:44',NULL),(4,'172',NULL,NULL,'304',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(5,'172',NULL,NULL,'988A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(6,'172',NULL,NULL,'275C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(7,'172',NULL,NULL,'275E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(8,'172',NULL,NULL,'275D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(9,'172',NULL,NULL,'292',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(10,'172',NULL,NULL,'262',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(11,'172',NULL,NULL,'240',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(12,'172',NULL,NULL,'275A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(13,'172',NULL,NULL,'299',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(14,'172',NULL,NULL,'296',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(15,'172',NULL,NULL,'291',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(16,'172',NULL,NULL,'305',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(17,'172',NULL,NULL,'143',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(18,'172',NULL,NULL,'275B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(19,'172',NULL,NULL,'678B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(20,'172',NULL,NULL,'116',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(21,'172',NULL,NULL,'381',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(22,'172',NULL,NULL,'132',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(23,'172',NULL,NULL,'133',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(24,'172',NULL,NULL,'384',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(25,'172',NULL,NULL,'795',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(26,'172',NULL,NULL,'794',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(27,'172',NULL,NULL,'791',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(28,'172',NULL,NULL,'722',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(29,'172',NULL,NULL,'152',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(30,'172',NULL,NULL,'257',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(31,'172',NULL,NULL,'256',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(32,'172',NULL,NULL,'252',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(33,'172',NULL,NULL,'124',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(34,'172',NULL,NULL,'310A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(35,'172',NULL,NULL,'385',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(36,'172',NULL,NULL,'113',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(37,'172',NULL,NULL,'151',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(38,'172',NULL,NULL,'175',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(39,'172',NULL,NULL,'182',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(40,'172',NULL,NULL,'179',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(41,'172',NULL,NULL,'321',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(42,'172',NULL,NULL,'320',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(43,'172',NULL,NULL,'319',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(44,'172',NULL,NULL,'313',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(45,'172',NULL,NULL,'300',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(46,'172',NULL,NULL,'177',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(47,'172',NULL,NULL,'297',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(48,'172',NULL,NULL,'174',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(49,'172',NULL,NULL,'121',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(50,'172',NULL,NULL,'333',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(51,'172',NULL,NULL,'113A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(52,'172',NULL,NULL,'298',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(53,'172',NULL,NULL,'282',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(54,'172',NULL,NULL,'279',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(55,'172',NULL,NULL,'281',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(56,'172',NULL,NULL,'688',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(57,'172',NULL,NULL,'178',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(58,'172',NULL,NULL,'267',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(59,'172',NULL,NULL,'988',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(60,'172',NULL,NULL,'254',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(61,'172',NULL,NULL,'703',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(62,'172',NULL,NULL,'704',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(63,'172',NULL,NULL,'263',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(64,'172',NULL,NULL,'266',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(65,'172',NULL,NULL,'373',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(66,'172',NULL,NULL,'376',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(67,'172',NULL,NULL,'332',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(68,'172',NULL,NULL,'331',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(69,'172',NULL,NULL,'330',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(70,'172',NULL,NULL,'953',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(71,'172',NULL,NULL,'955',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(72,'172',NULL,NULL,'670',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(73,'172',NULL,NULL,'669',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(74,'172',NULL,NULL,'674',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(75,'172',NULL,NULL,'673',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(76,'172',NULL,NULL,'672',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(77,'172',NULL,NULL,'660',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(78,'172',NULL,NULL,'325',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(79,'172',NULL,NULL,'711',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(80,'172',NULL,NULL,'661',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(81,'172',NULL,NULL,'253',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(82,'172',NULL,NULL,'662',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(83,'172',NULL,NULL,'130A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(84,'172',NULL,NULL,'988B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(85,'172',NULL,NULL,'216B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(86,'172',NULL,NULL,'206',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(87,'172',NULL,NULL,'216E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(88,'172',NULL,NULL,'180',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(89,'172',NULL,NULL,'216A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(90,'172',NULL,NULL,'178C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(91,'172',NULL,NULL,'178D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(92,'172',NULL,NULL,'236',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(93,'172',NULL,NULL,'235',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(94,'172',NULL,NULL,'717',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(95,'172',NULL,NULL,'118',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(96,'172',NULL,NULL,'716',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(97,'172',NULL,NULL,'709',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(98,'172',NULL,NULL,'612',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(99,'172',NULL,NULL,'725',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(100,'172',NULL,NULL,'719',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(101,'172',NULL,NULL,'293',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(102,'172',NULL,NULL,'386',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(103,'172',NULL,NULL,'288',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(104,'172',NULL,NULL,'278',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(105,'172',NULL,NULL,'611',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(106,'172',NULL,NULL,'614',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(107,'172',NULL,NULL,'618',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(108,'172',NULL,NULL,'309',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(109,'172',NULL,NULL,'597',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(110,'172',NULL,NULL,'596',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(111,'172',NULL,NULL,'593',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(112,'172',NULL,NULL,'305A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(113,'172',NULL,NULL,'377',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(114,'172',NULL,NULL,'104',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(115,'172',NULL,NULL,'107',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(116,'172',NULL,NULL,'125',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(117,'172',NULL,NULL,'387',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(118,'172',NULL,NULL,'117',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(119,'172',NULL,NULL,'140',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(120,'172',NULL,NULL,'139',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(121,'172',NULL,NULL,'392',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(122,'172',NULL,NULL,'391',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(123,'172',NULL,NULL,'106',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(124,'172',NULL,NULL,'668',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(125,'172',NULL,NULL,'306',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(126,'172',NULL,NULL,'671',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(127,'172',NULL,NULL,'315',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(128,'172',NULL,NULL,'337A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(129,'172',NULL,NULL,'337',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(130,'172',NULL,NULL,'334',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(131,'172',NULL,NULL,'595',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(132,'172',NULL,NULL,'316',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(133,'172',NULL,NULL,'161',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(134,'172',NULL,NULL,'999B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(135,'172',NULL,NULL,'251',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(136,'172',NULL,NULL,'250',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(137,'172',NULL,NULL,'216D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(138,'172',NULL,NULL,'216C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(139,'172',NULL,NULL,'666B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(140,'172',NULL,NULL,'660A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(141,'172',NULL,NULL,'663A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(142,'172',NULL,NULL,'666A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(143,'172',NULL,NULL,'662A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(144,'172',NULL,NULL,'389',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(145,'172',NULL,NULL,'173',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(146,'172',NULL,NULL,'234',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(147,'172',NULL,NULL,'998L',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(148,'172',NULL,NULL,'230C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(149,'172',NULL,NULL,'230G',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(150,'172',NULL,NULL,'229E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(151,'172',NULL,NULL,'229A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(152,'172',NULL,NULL,'996',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(153,'172',NULL,NULL,'998',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(154,'172',NULL,NULL,'174A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(155,'172',NULL,NULL,'167',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(156,'172',NULL,NULL,'114',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(157,'172',NULL,NULL,'114A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(158,'172',NULL,NULL,'200',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(159,'172',NULL,NULL,'335',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(160,'172',NULL,NULL,'349',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(161,'172',NULL,NULL,'348',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(162,'172',NULL,NULL,'322',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(163,'172',NULL,NULL,'339',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(164,'172',NULL,NULL,'338',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(165,'172',NULL,NULL,'340',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(166,'172',NULL,NULL,'230A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(167,'172',NULL,NULL,'264',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(168,'172',NULL,NULL,'258',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(169,'172',NULL,NULL,'237',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(170,'172',NULL,NULL,'128',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(171,'172',NULL,NULL,'127',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(172,'172',NULL,NULL,'126',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(173,'172',NULL,NULL,'406',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(174,'172',NULL,NULL,'580',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(175,'172',NULL,NULL,'372',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(176,'172',NULL,NULL,'371',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(177,'172',NULL,NULL,'370',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(178,'172',NULL,NULL,'141',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(179,'172',NULL,NULL,'294',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(180,'172',NULL,NULL,'230E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(181,'172',NULL,NULL,'707',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(182,'172',NULL,NULL,'677',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(183,'172',NULL,NULL,'375',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(184,'172',NULL,NULL,'122',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(185,'172',NULL,NULL,'336',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(186,'172',NULL,NULL,'231D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(187,'172',NULL,NULL,'231E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(188,'172',NULL,NULL,'230F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(189,'172',NULL,NULL,'723',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(190,'172',NULL,NULL,'712',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(191,'172',NULL,NULL,'120',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(192,'172',NULL,NULL,'162',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(193,'172',NULL,NULL,'105',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(194,'172',NULL,NULL,'255',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(195,'172',NULL,NULL,'122A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(196,'172',NULL,NULL,'993',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(197,'172',NULL,NULL,'209A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(198,'172',NULL,NULL,'131L',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(199,'172',NULL,NULL,'131J',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(200,'172',NULL,NULL,'131I',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(201,'172',NULL,NULL,'131H',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(202,'172',NULL,NULL,'997',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(203,'172',NULL,NULL,'994',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(204,'172',NULL,NULL,'380',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(205,'172',NULL,NULL,'314',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(206,'172',NULL,NULL,'374',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(207,'172',NULL,NULL,'144',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(208,'172',NULL,NULL,'684',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(209,'172',NULL,NULL,'240A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(210,'172',NULL,NULL,'682',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(211,'172',NULL,NULL,'289',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(212,'172',NULL,NULL,'290',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(213,'172',NULL,NULL,'325A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(214,'172',NULL,NULL,'324',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(215,'172',NULL,NULL,'131G',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(216,'172',NULL,NULL,'180B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(217,'172',NULL,NULL,'131K',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(218,'172',NULL,NULL,'131M',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(219,'172',NULL,NULL,'233',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(220,'172',NULL,NULL,'122D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(221,'172',NULL,NULL,'351',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(222,'172',NULL,NULL,'352',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(223,'172',NULL,NULL,'130B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(224,'172',NULL,NULL,'142',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(225,'172',NULL,NULL,'993A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(226,'172',NULL,NULL,'346',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(227,'172',NULL,NULL,'992',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(228,'172',NULL,NULL,'990',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(229,'172',NULL,NULL,'991',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(230,'172',NULL,NULL,'229C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(231,'172',NULL,NULL,'230D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(232,'172',NULL,NULL,'221',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(233,'172',NULL,NULL,'224',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(234,'172',NULL,NULL,'222',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(235,'172',NULL,NULL,'223',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(236,'172',NULL,NULL,'687',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(237,'172',NULL,NULL,'680',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(238,'172',NULL,NULL,'276D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(239,'172',NULL,NULL,'383',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(240,'172',NULL,NULL,'999A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(241,'172',NULL,NULL,'382',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(242,'172',NULL,NULL,'995',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(243,'172',NULL,NULL,'988D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(244,'172',NULL,NULL,'185A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(245,'172',NULL,NULL,'185B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(246,'172',NULL,NULL,'185C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(247,'172',NULL,NULL,'999G',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(248,'172',NULL,NULL,'301',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(249,'172',NULL,NULL,'999H',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(250,'172',NULL,NULL,'999F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(251,'172',NULL,NULL,'364',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(252,'172',NULL,NULL,'365',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(253,'172',NULL,NULL,'318',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(254,'172',NULL,NULL,'366',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(255,'172',NULL,NULL,'705',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(256,'172',NULL,NULL,'225',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(257,'172',NULL,NULL,'360A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(258,'172',NULL,NULL,'102A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(259,'172',NULL,NULL,'576',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(260,'172',NULL,NULL,'388',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(261,'172',NULL,NULL,'998A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(262,'172',NULL,NULL,'582',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(263,'172',NULL,NULL,'285',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(264,'172',NULL,NULL,'323',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(265,'172',NULL,NULL,'360',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(266,'172',NULL,NULL,'940',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(267,'172',NULL,NULL,'172',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(268,'172',NULL,NULL,'939',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(269,'172',NULL,NULL,'138',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(270,'172',NULL,NULL,'170',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(271,'172',NULL,NULL,'201',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(272,'172',NULL,NULL,'202',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(273,'172',NULL,NULL,'204A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(274,'172',NULL,NULL,'659',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(275,'172',NULL,NULL,'667A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(276,'172',NULL,NULL,'658',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(277,'172',NULL,NULL,'665',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(278,'172',NULL,NULL,'667E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(279,'172',NULL,NULL,'667D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(280,'172',NULL,NULL,'664C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(281,'172',NULL,NULL,'664',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(282,'172',NULL,NULL,'666',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(283,'172',NULL,NULL,'577',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(284,'172',NULL,NULL,'343',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(285,'172',NULL,NULL,'354',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(286,'172',NULL,NULL,'350',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(287,'172',NULL,NULL,'347',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(288,'172',NULL,NULL,'149',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(289,'172',NULL,NULL,'136',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(290,'172',NULL,NULL,'410',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(291,'172',NULL,NULL,'761',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(292,'172',NULL,NULL,'205',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(293,'172',NULL,NULL,'180A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(294,'172',NULL,NULL,'769A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(295,'172',NULL,NULL,'131',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(296,'172',NULL,NULL,'131C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(297,'172',NULL,NULL,'131D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(298,'172',NULL,NULL,'720',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(299,'172',NULL,NULL,'131E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(300,'172',NULL,NULL,'131F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(301,'172',NULL,NULL,'203',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(302,'172',NULL,NULL,'988F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(303,'172',NULL,NULL,'678',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(304,'172',NULL,NULL,'150',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(305,'172',NULL,NULL,'148',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(306,'172',NULL,NULL,'168',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(307,'172',NULL,NULL,'168B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(308,'172',NULL,NULL,'178B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(309,'172',NULL,NULL,'178A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(310,'172',NULL,NULL,'678D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(311,'172',NULL,NULL,'408',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(312,'172',NULL,NULL,'663',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(313,'172',NULL,NULL,'312',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(314,'172',NULL,NULL,'188D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(315,'172',NULL,NULL,'163',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(316,'172',NULL,NULL,'147',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(317,'172',NULL,NULL,'171',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(318,'172',NULL,NULL,'155B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(319,'172',NULL,NULL,'678C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(320,'172',NULL,NULL,'155D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(321,'172',NULL,NULL,'793',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(322,'172',NULL,NULL,'661A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(323,'172',NULL,NULL,'658A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(324,'172',NULL,NULL,'103',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(325,'172',NULL,NULL,'341',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(326,'172',NULL,NULL,'342',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(327,'172',NULL,NULL,'138B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(328,'172',NULL,NULL,'204',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(329,'172',NULL,NULL,'762',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(330,'172',NULL,NULL,'150D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(331,'172',NULL,NULL,'598',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(332,'172',NULL,NULL,'287',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(333,'172',NULL,NULL,'353',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(334,'172',NULL,NULL,'159',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(335,'172',NULL,NULL,'156',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(336,'172',NULL,NULL,'277',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(337,'172',NULL,NULL,'678A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(338,'172',NULL,NULL,'677E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(339,'172',NULL,NULL,'677F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(340,'172',NULL,NULL,'667',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(341,'172',NULL,NULL,'679E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(342,'172',NULL,NULL,'675',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(343,'172',NULL,NULL,'676',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(344,'172',NULL,NULL,'150A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(345,'172',NULL,NULL,'150C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(346,'172',NULL,NULL,'169',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(347,'172',NULL,NULL,'229D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(348,'172',NULL,NULL,'229G',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(349,'172',NULL,NULL,'988H',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(350,'172',NULL,NULL,'345',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(351,'172',NULL,NULL,'229B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(352,'172',NULL,NULL,'403',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(353,'172',NULL,NULL,'998B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(354,'172',NULL,NULL,'681',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(355,'172',NULL,NULL,'763',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(356,'172',NULL,NULL,'945',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(357,'172',NULL,NULL,'344',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(358,'172',NULL,NULL,'609',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(359,'172',NULL,NULL,'618B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(360,'172',NULL,NULL,'578',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(361,'172',NULL,NULL,'765',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(362,'172',NULL,NULL,'153A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(363,'172',NULL,NULL,'146',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(364,'172',NULL,NULL,'587',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(365,'172',NULL,NULL,'581',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(366,'172',NULL,NULL,'579',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(367,'172',NULL,NULL,'230B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(368,'172',NULL,NULL,'155',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(369,'172',NULL,NULL,'158',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(370,'172',NULL,NULL,'156B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(371,'172',NULL,NULL,'327',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(372,'172',NULL,NULL,'326',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(373,'172',NULL,NULL,'101A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(374,'172',NULL,NULL,'667F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(375,'172',NULL,NULL,'689',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(376,'172',NULL,NULL,'683',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(377,'172',NULL,NULL,'115',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(378,'172',NULL,NULL,'416',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(379,'172',NULL,NULL,'145',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(380,'172',NULL,NULL,'610',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(381,'172',NULL,NULL,'618A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(382,'172',NULL,NULL,'616',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(383,'172',NULL,NULL,'308',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(384,'172',NULL,NULL,'603',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(385,'172',NULL,NULL,'419',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(386,'172',NULL,NULL,'953A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(387,'172',NULL,NULL,'415',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(388,'172',NULL,NULL,'153',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(389,'172',NULL,NULL,'583',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(390,'172',NULL,NULL,'122E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(391,'172',NULL,NULL,'122F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(392,'172',NULL,NULL,'122C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(393,'172',NULL,NULL,'286',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(394,'172',NULL,NULL,'988N',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(395,'172',NULL,NULL,'417',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(396,'172',NULL,NULL,'935',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(397,'172',NULL,NULL,'220',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(398,'172',NULL,NULL,'122G',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(399,'172',NULL,NULL,'591',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(400,'172',NULL,NULL,'404',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(401,'172',NULL,NULL,'769',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(402,'172',NULL,NULL,'588',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(403,'172',NULL,NULL,'122B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:36','2026-02-27 11:40:36'),(404,'172',NULL,NULL,'418',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:36','2026-02-27 11:40:36'),(405,'172',NULL,NULL,'138A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(406,'172',NULL,NULL,'154',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(407,'172',NULL,NULL,'242B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(408,'172',NULL,NULL,'137B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(409,'172',NULL,NULL,'242',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(410,'172',NULL,NULL,'241',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(411,'172',NULL,NULL,'767',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(412,'172',NULL,NULL,'768',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(413,'172',NULL,NULL,'229F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(414,'172',NULL,NULL,'690B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(415,'172',NULL,NULL,'988I',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(416,'172',NULL,NULL,'940B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(417,'172',NULL,NULL,'129B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(418,'172',NULL,NULL,'129D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(419,'172',NULL,NULL,'129C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(420,'172',NULL,NULL,'129',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(421,'172',NULL,NULL,'685',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(422,'172',NULL,NULL,'303',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(423,'172',NULL,NULL,'999D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(424,'172',NULL,NULL,'613',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(425,'172',NULL,NULL,'615',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(426,'172',NULL,NULL,'686',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(427,'172',NULL,NULL,'420',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:41','2026-02-27 11:40:41'),(428,'172',NULL,NULL,'421',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:41','2026-02-27 11:40:41'),(429,'172',NULL,NULL,'150B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:41','2026-02-27 11:40:41'),(430,'172',NULL,NULL,'766',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:42','2026-02-27 11:40:42'),(431,'172',NULL,NULL,'129A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:42','2026-02-27 11:40:42'),(432,'172',NULL,NULL,'933',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:43','2026-02-27 11:40:43'),(433,'172',NULL,NULL,'690',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:44','2026-02-27 11:40:44'),(434,'172',NULL,NULL,'153B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:44','2026-02-27 11:40:44'),(435,'172',NULL,NULL,'999I',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:45','2026-02-27 11:40:45'),(436,'172',NULL,NULL,'108',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:46','2026-02-27 11:40:46'),(437,'172',NULL,NULL,'110',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:46','2026-02-27 11:40:46'),(438,'172',NULL,NULL,'378',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:47','2026-02-27 11:40:47'),(439,'172',NULL,NULL,'360B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:47','2026-02-27 11:40:47'),(440,'172',NULL,NULL,'209B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:48','2026-02-27 11:40:48'),(441,'172',NULL,NULL,'936',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:49','2026-02-27 11:40:49'),(442,'172',NULL,NULL,'122H',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:49','2026-02-27 11:40:49'),(443,'172',NULL,NULL,'310',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:51','2026-02-27 11:40:51'),(444,'172',NULL,NULL,'109',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:51','2026-02-27 11:40:51'),(445,'172',NULL,NULL,'767B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:51','2026-02-27 11:40:51'),(446,'172',NULL,NULL,'405',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(447,'172',NULL,NULL,'605',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(448,'172',NULL,NULL,'606',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(449,'172',NULL,NULL,'604',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(450,'172',NULL,NULL,'422',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(451,'172',NULL,NULL,'178F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:53','2026-02-27 11:40:53'),(452,'172',NULL,NULL,'231',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:54','2026-02-27 11:40:54'),(453,'172',NULL,NULL,'137C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:55','2026-02-27 11:40:55'),(454,'172',NULL,NULL,'739',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:55','2026-02-27 11:40:55'),(455,'172',NULL,NULL,'988J',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:55','2026-02-27 11:40:55'),(456,'172',NULL,NULL,'319A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:56','2026-02-27 11:40:56'),(457,'172',NULL,NULL,'586',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:56','2026-02-27 11:40:56'),(458,'172',NULL,NULL,'304A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:56','2026-02-27 11:40:56'),(459,'172',NULL,NULL,'762A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:57','2026-02-27 11:40:57'),(460,'172',NULL,NULL,'356',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:57','2026-02-27 11:40:57'),(461,'172',NULL,NULL,'157A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:58','2026-02-27 11:40:58'),(462,'172',NULL,NULL,'155C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:59','2026-02-27 11:40:59'),(463,'172',NULL,NULL,'156A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:00','2026-02-27 11:41:00'),(464,'172',NULL,NULL,'137',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:00','2026-02-27 11:41:00'),(465,'172',NULL,NULL,'231F',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:01','2026-02-27 11:41:01'),(466,'172',NULL,NULL,'999E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:02','2026-02-27 11:41:02'),(467,'172',NULL,NULL,'367',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:03','2026-02-27 11:41:03'),(468,'172',NULL,NULL,'319B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:04','2026-02-27 11:41:04'),(469,'172',NULL,NULL,'319C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:04','2026-02-27 11:41:04'),(470,'172',NULL,NULL,'319D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:04','2026-02-27 11:41:04'),(471,'172',NULL,NULL,'426',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:05','2026-02-27 11:41:05'),(472,'172',NULL,NULL,'424',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:05','2026-02-27 11:41:05'),(473,'172',NULL,NULL,'423',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:05','2026-02-27 11:41:05'),(474,'172',NULL,NULL,'425',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:06','2026-02-27 11:41:06'),(475,'172',NULL,NULL,'279A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:07','2026-02-27 11:41:07'),(476,'172',NULL,NULL,'160',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:09','2026-02-27 11:41:09'),(477,'172',NULL,NULL,'301A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:09','2026-02-27 11:41:09'),(478,'172',NULL,NULL,'607',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:10','2026-02-27 11:41:10'),(479,'172',NULL,NULL,'594',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:13','2026-02-27 11:41:13'),(480,'172',NULL,NULL,'427',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:13','2026-02-27 11:41:13'),(481,'172',NULL,NULL,'306A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:15','2026-02-27 11:41:15'),(482,'172',NULL,NULL,'305B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:16','2026-02-27 11:41:16'),(483,'172',NULL,NULL,'137A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:17','2026-02-27 11:41:17'),(484,'172',NULL,NULL,'358',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:17','2026-02-27 11:41:17'),(485,'172',NULL,NULL,'239',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:18','2026-02-27 11:41:18'),(486,'172',NULL,NULL,'407',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:20','2026-02-27 11:41:20'),(487,'172',NULL,NULL,'407A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:20','2026-02-27 11:41:20'),(488,'172',NULL,NULL,'123A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(489,'172',NULL,NULL,'123C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(490,'172',NULL,NULL,'123B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(491,'172',NULL,NULL,'123',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(492,'172',NULL,NULL,'428',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:22','2026-02-27 11:41:22'),(493,'172',NULL,NULL,'359',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:22','2026-02-27 11:41:22'),(494,'172',NULL,NULL,'328',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:24','2026-02-27 11:41:24'),(495,'172',NULL,NULL,'690C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:25','2026-02-27 11:41:25'),(496,'172',NULL,NULL,'385A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:25','2026-02-27 11:41:25'),(497,'172',NULL,NULL,'440',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(498,'172',NULL,NULL,'439',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(499,'172',NULL,NULL,'436',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(500,'172',NULL,NULL,'438',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(501,'172',NULL,NULL,'433',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(502,'172',NULL,NULL,'431',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(503,'172',NULL,NULL,'435',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(504,'172',NULL,NULL,'188E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(505,'172',NULL,NULL,'419A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(506,'172',NULL,NULL,'437',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(507,'172',NULL,NULL,'434',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(508,'172',NULL,NULL,'432',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(509,'172',NULL,NULL,'442',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(510,'172',NULL,NULL,'441',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(511,'172',NULL,NULL,'792',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:28','2026-02-27 11:41:28'),(512,'172',NULL,NULL,'474',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(513,'172',NULL,NULL,'468',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(514,'172',NULL,NULL,'458',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(515,'172',NULL,NULL,'459',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(516,'172',NULL,NULL,'988G',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(517,'172',NULL,NULL,'482',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(518,'172',NULL,NULL,'464',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(519,'172',NULL,NULL,'475',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(520,'172',NULL,NULL,'483',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(521,'172',NULL,NULL,'455',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(522,'172',NULL,NULL,'452',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(523,'172',NULL,NULL,'451',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(524,'172',NULL,NULL,'481',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(525,'172',NULL,NULL,'466',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(526,'172',NULL,NULL,'463',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:33','2026-02-27 11:41:33'),(527,'172',NULL,NULL,'453',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:33','2026-02-27 11:41:33'),(528,'172',NULL,NULL,'454',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:34','2026-02-27 11:41:34'),(529,'172',NULL,NULL,'469',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:36','2026-02-27 11:41:36'),(530,'172',NULL,NULL,'484',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:36','2026-02-27 11:41:36'),(531,'172',NULL,NULL,'485',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:37','2026-02-27 11:41:37'),(532,'172',NULL,NULL,'988O',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:39','2026-02-27 11:41:39'),(533,'172',NULL,NULL,'362',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:41','2026-02-27 11:41:41'),(534,'172',NULL,NULL,'363',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:41','2026-02-27 11:41:41'),(535,'172',NULL,NULL,'476',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:46','2026-02-27 11:41:46'),(536,'172',NULL,NULL,'478',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:47','2026-02-27 11:41:47'),(537,'172',NULL,NULL,'477',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:47','2026-02-27 11:41:47'),(538,'172',NULL,NULL,'598A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:48','2026-02-27 11:41:48'),(539,'172',NULL,NULL,'243',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:49','2026-02-27 11:41:49'),(540,'172',NULL,NULL,'168A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:50','2026-02-27 11:41:50'),(541,'172',NULL,NULL,'280',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:50','2026-02-27 11:41:50'),(542,'172',NULL,NULL,'195A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:51','2026-02-27 11:41:51'),(543,'172',NULL,NULL,'195C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:51','2026-02-27 11:41:51'),(544,'172',NULL,NULL,'195B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:51','2026-02-27 11:41:51'),(545,'172',NULL,NULL,'244',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(546,'172',NULL,NULL,'245',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(547,'172',NULL,NULL,'246',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(548,'172',NULL,NULL,'190A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(549,'172',NULL,NULL,'187B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(550,'172',NULL,NULL,'189A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(551,'172',NULL,NULL,'186',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(552,'172',NULL,NULL,'191',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(553,'172',NULL,NULL,'189B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(554,'172',NULL,NULL,'187C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(555,'172',NULL,NULL,'207',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(556,'172',NULL,NULL,'248A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(557,'172',NULL,NULL,'249',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(558,'172',NULL,NULL,'248B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(559,'172',NULL,NULL,'190B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(560,'172',NULL,NULL,'184C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(561,'172',NULL,NULL,'187',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(562,'172',NULL,NULL,'187D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(563,'172',NULL,NULL,'184A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(564,'172',NULL,NULL,'189C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:55','2026-02-27 11:41:55'),(565,'172',NULL,NULL,'189D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:55','2026-02-27 11:41:55'),(566,'172',NULL,NULL,'184B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:56','2026-02-27 11:41:56'),(567,'172',NULL,NULL,'247',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:56','2026-02-27 11:41:56'),(568,'172',NULL,NULL,'248',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:56','2026-02-27 11:41:56'),(569,'172',NULL,NULL,'195',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:59','2026-02-27 11:41:59'),(570,'172',NULL,NULL,'189E',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:00','2026-02-27 11:42:00'),(571,'172',NULL,NULL,'495',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(572,'172',NULL,NULL,'488',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(573,'172',NULL,NULL,'490',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(574,'172',NULL,NULL,'493',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(575,'172',NULL,NULL,'491',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(576,'172',NULL,NULL,'489',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(577,'172',NULL,NULL,'487',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(578,'172',NULL,NULL,'486',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(579,'172',NULL,NULL,'494',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(580,'172',NULL,NULL,'496',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(581,'172',NULL,NULL,'492',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(582,'172',NULL,NULL,'498',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(583,'172',NULL,NULL,'937A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(584,'172',NULL,NULL,'932',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(585,'172',NULL,NULL,'511',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(586,'172',NULL,NULL,'940A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:03','2026-02-27 11:42:03'),(587,'172',NULL,NULL,'938',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:03','2026-02-27 11:42:03'),(588,'172',NULL,NULL,'131B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:04','2026-02-27 11:42:04'),(589,'172',NULL,NULL,'502',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:05','2026-02-27 11:42:05'),(590,'172',NULL,NULL,'501',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:07','2026-02-27 11:42:07'),(591,'172',NULL,NULL,'500',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:08','2026-02-27 11:42:08'),(592,'172',NULL,NULL,'690A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:08','2026-02-27 11:42:08'),(593,'172',NULL,NULL,'497',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:08','2026-02-27 11:42:08'),(594,'172',NULL,NULL,'249A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(595,'172',NULL,NULL,'504',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(596,'172',NULL,NULL,'505',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(597,'172',NULL,NULL,'503',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(598,'172',NULL,NULL,'937C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:14','2026-02-27 11:42:14'),(599,'172',NULL,NULL,'934',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:14','2026-02-27 11:42:14'),(600,'172',NULL,NULL,'931',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:14','2026-02-27 11:42:14'),(601,'172',NULL,NULL,'662C',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:15','2026-02-27 11:42:15'),(602,'172',NULL,NULL,'662D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:15','2026-02-27 11:42:15'),(603,'172',NULL,NULL,'511A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:18','2026-02-27 11:42:18'),(604,'172',NULL,NULL,'937',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:19','2026-02-27 11:42:19'),(605,'172',NULL,NULL,'512',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:20','2026-02-27 11:42:20'),(606,'172',NULL,NULL,'407B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:20','2026-02-27 11:42:20'),(607,'172',NULL,NULL,'499',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:21','2026-02-27 11:42:21'),(608,'172',NULL,NULL,'429',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:22','2026-02-27 11:42:22'),(609,'172',NULL,NULL,'830',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(610,'172',NULL,NULL,'833',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(611,'172',NULL,NULL,'832',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(612,'172',NULL,NULL,'824',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(613,'172',NULL,NULL,'856',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(614,'172',NULL,NULL,'871',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(615,'172',NULL,NULL,'853',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(616,'172',NULL,NULL,'857',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(617,'172',NULL,NULL,'852',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(618,'172',NULL,NULL,'841',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(619,'172',NULL,NULL,'837',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(620,'172',NULL,NULL,'836',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(621,'172',NULL,NULL,'842',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(622,'172',NULL,NULL,'846',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(623,'172',NULL,NULL,'805',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(624,'172',NULL,NULL,'815',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(625,'172',NULL,NULL,'811',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(626,'172',NULL,NULL,'809',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(627,'172',NULL,NULL,'807',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(628,'172',NULL,NULL,'860',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(629,'172',NULL,NULL,'858',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(630,'172',NULL,NULL,'859',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(631,'172',NULL,NULL,'195D',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(632,'172',NULL,NULL,'855',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(633,'172',NULL,NULL,'817',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(634,'172',NULL,NULL,'812',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(635,'172',NULL,NULL,'820',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(636,'172',NULL,NULL,'989A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:31','2026-02-27 11:42:31'),(637,'172',NULL,NULL,'989',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:31','2026-02-27 11:42:31'),(638,'172',NULL,NULL,'821',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:31','2026-02-27 11:42:31'),(639,'172',NULL,NULL,'831',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(640,'172',NULL,NULL,'827',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(641,'172',NULL,NULL,'828',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(642,'172',NULL,NULL,'818',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(643,'172',NULL,NULL,'822',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(644,'172',NULL,NULL,'511B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(645,'172',NULL,NULL,'813',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(646,'172',NULL,NULL,'814',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(647,'172',NULL,NULL,'128B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:35','2026-02-27 11:42:35'),(648,'172',NULL,NULL,'115B',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:37','2026-02-27 11:42:37'),(649,'172',NULL,NULL,'823',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:42','2026-02-27 11:42:42'),(650,'172',NULL,NULL,'835',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:42','2026-02-27 11:42:42'),(651,'172',NULL,NULL,'816',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:46','2026-02-27 11:42:46'),(652,'172',NULL,NULL,'806',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:46','2026-02-27 11:42:46'),(653,'172',NULL,NULL,'244A',NULL,'BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','BB BAKING SODA 100 GM','28363000','1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:46','2026-02-27 11:42:46');
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'172',NULL,NULL,'SSK AGENCY','1',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:27:44','2026-02-27 11:27:44');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=654 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'172',NULL,NULL,'1','1729515858823','2000-01-01','2032-01-01','101','0','0','0.00','70','53.3333','0','0','0','53.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-27 11:27:44',NULL),(2,'172',NULL,NULL,'2','1729515858857','2000-01-01','2036-01-01','102','0','-5','0.00','150','114.2857','0','102.83','0','11.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-27 11:27:44',NULL),(3,'172',NULL,NULL,'3','1729515858867','2000-01-01','2036-01-01','111','0','-8','0.00','160','121.9047','0','109.53','0','12.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-27 11:27:44',NULL),(4,'172',NULL,NULL,'4','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(5,'172',NULL,NULL,'5','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(6,'172',NULL,NULL,'6','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(7,'172',NULL,NULL,'7','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(8,'172',NULL,NULL,'8','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(9,'172',NULL,NULL,'9','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(10,'172',NULL,NULL,'10','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(11,'172',NULL,NULL,'11','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(12,'172',NULL,NULL,'12','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(13,'172',NULL,NULL,'13','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(14,'172',NULL,NULL,'14','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(15,'172',NULL,NULL,'15','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(16,'172',NULL,NULL,'16','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(17,'172',NULL,NULL,'17','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(18,'172',NULL,NULL,'18','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(19,'172',NULL,NULL,'19','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(20,'172',NULL,NULL,'20','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(21,'172',NULL,NULL,'21','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(22,'172',NULL,NULL,'22','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(23,'172',NULL,NULL,'23','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(24,'172',NULL,NULL,'24','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(25,'172',NULL,NULL,'25','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(26,'172',NULL,NULL,'26','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(27,'172',NULL,NULL,'27','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(28,'172',NULL,NULL,'28','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(29,'172',NULL,NULL,'29','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(30,'172',NULL,NULL,'30','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(31,'172',NULL,NULL,'31','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(32,'172',NULL,NULL,'32','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(33,'172',NULL,NULL,'33','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(34,'172',NULL,NULL,'34','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(35,'172',NULL,NULL,'35','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(36,'172',NULL,NULL,'36','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(37,'172',NULL,NULL,'37','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(38,'172',NULL,NULL,'38','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(39,'172',NULL,NULL,'39','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(40,'172',NULL,NULL,'40','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(41,'172',NULL,NULL,'41','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(42,'172',NULL,NULL,'42','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(43,'172',NULL,NULL,'43','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(44,'172',NULL,NULL,'44','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(45,'172',NULL,NULL,'45','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(46,'172',NULL,NULL,'46','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(47,'172',NULL,NULL,'47','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(48,'172',NULL,NULL,'48','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(49,'172',NULL,NULL,'49','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(50,'172',NULL,NULL,'50','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(51,'172',NULL,NULL,'51','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(52,'172',NULL,NULL,'52','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(53,'172',NULL,NULL,'53','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(54,'172',NULL,NULL,'54','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(55,'172',NULL,NULL,'55','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(56,'172',NULL,NULL,'56','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(57,'172',NULL,NULL,'57','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(58,'172',NULL,NULL,'58','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(59,'172',NULL,NULL,'59','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(60,'172',NULL,NULL,'60','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(61,'172',NULL,NULL,'61','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(62,'172',NULL,NULL,'62','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(63,'172',NULL,NULL,'63','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(64,'172',NULL,NULL,'64','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:21','2026-02-27 11:40:21'),(65,'172',NULL,NULL,'65','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(66,'172',NULL,NULL,'66','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(67,'172',NULL,NULL,'67','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(68,'172',NULL,NULL,'68','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(69,'172',NULL,NULL,'69','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(70,'172',NULL,NULL,'70','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(71,'172',NULL,NULL,'71','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(72,'172',NULL,NULL,'72','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(73,'172',NULL,NULL,'73','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(74,'172',NULL,NULL,'74','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(75,'172',NULL,NULL,'75','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(76,'172',NULL,NULL,'76','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(77,'172',NULL,NULL,'77','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(78,'172',NULL,NULL,'78','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(79,'172',NULL,NULL,'79','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(80,'172',NULL,NULL,'80','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(81,'172',NULL,NULL,'81','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(82,'172',NULL,NULL,'82','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(83,'172',NULL,NULL,'83','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(84,'172',NULL,NULL,'84','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(85,'172',NULL,NULL,'85','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(86,'172',NULL,NULL,'86','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(87,'172',NULL,NULL,'87','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(88,'172',NULL,NULL,'88','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(89,'172',NULL,NULL,'89','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(90,'172',NULL,NULL,'90','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(91,'172',NULL,NULL,'91','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(92,'172',NULL,NULL,'92','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(93,'172',NULL,NULL,'93','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(94,'172',NULL,NULL,'94','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(95,'172',NULL,NULL,'95','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(96,'172',NULL,NULL,'96','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(97,'172',NULL,NULL,'97','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(98,'172',NULL,NULL,'98','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(99,'172',NULL,NULL,'99','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(100,'172',NULL,NULL,'100','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(101,'172',NULL,NULL,'101','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(102,'172',NULL,NULL,'102','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(103,'172',NULL,NULL,'103','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(104,'172',NULL,NULL,'104','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(105,'172',NULL,NULL,'105','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(106,'172',NULL,NULL,'106','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(107,'172',NULL,NULL,'107','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(108,'172',NULL,NULL,'108','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(109,'172',NULL,NULL,'109','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(110,'172',NULL,NULL,'110','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(111,'172',NULL,NULL,'111','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(112,'172',NULL,NULL,'112','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(113,'172',NULL,NULL,'113','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(114,'172',NULL,NULL,'114','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(115,'172',NULL,NULL,'115','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(116,'172',NULL,NULL,'116','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(117,'172',NULL,NULL,'117','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(118,'172',NULL,NULL,'118','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(119,'172',NULL,NULL,'119','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(120,'172',NULL,NULL,'120','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:22','2026-02-27 11:40:22'),(121,'172',NULL,NULL,'121','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(122,'172',NULL,NULL,'122','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(123,'172',NULL,NULL,'123','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(124,'172',NULL,NULL,'124','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(125,'172',NULL,NULL,'125','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(126,'172',NULL,NULL,'126','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(127,'172',NULL,NULL,'127','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(128,'172',NULL,NULL,'128','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(129,'172',NULL,NULL,'129','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(130,'172',NULL,NULL,'130','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(131,'172',NULL,NULL,'131','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(132,'172',NULL,NULL,'132','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(133,'172',NULL,NULL,'133','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(134,'172',NULL,NULL,'134','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(135,'172',NULL,NULL,'135','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(136,'172',NULL,NULL,'136','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(137,'172',NULL,NULL,'137','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(138,'172',NULL,NULL,'138','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(139,'172',NULL,NULL,'139','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(140,'172',NULL,NULL,'140','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(141,'172',NULL,NULL,'141','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(142,'172',NULL,NULL,'142','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(143,'172',NULL,NULL,'143','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(144,'172',NULL,NULL,'144','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(145,'172',NULL,NULL,'145','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(146,'172',NULL,NULL,'146','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(147,'172',NULL,NULL,'147','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(148,'172',NULL,NULL,'148','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(149,'172',NULL,NULL,'149','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(150,'172',NULL,NULL,'150','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(151,'172',NULL,NULL,'151','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(152,'172',NULL,NULL,'152','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(153,'172',NULL,NULL,'153','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(154,'172',NULL,NULL,'154','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(155,'172',NULL,NULL,'155','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(156,'172',NULL,NULL,'156','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(157,'172',NULL,NULL,'157','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(158,'172',NULL,NULL,'158','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(159,'172',NULL,NULL,'159','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(160,'172',NULL,NULL,'160','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(161,'172',NULL,NULL,'161','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(162,'172',NULL,NULL,'162','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(163,'172',NULL,NULL,'163','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(164,'172',NULL,NULL,'164','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(165,'172',NULL,NULL,'165','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:23','2026-02-27 11:40:23'),(166,'172',NULL,NULL,'166','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(167,'172',NULL,NULL,'167','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(168,'172',NULL,NULL,'168','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(169,'172',NULL,NULL,'169','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(170,'172',NULL,NULL,'170','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(171,'172',NULL,NULL,'171','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(172,'172',NULL,NULL,'172','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(173,'172',NULL,NULL,'173','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(174,'172',NULL,NULL,'174','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(175,'172',NULL,NULL,'175','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(176,'172',NULL,NULL,'176','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(177,'172',NULL,NULL,'177','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(178,'172',NULL,NULL,'178','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(179,'172',NULL,NULL,'179','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(180,'172',NULL,NULL,'180','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(181,'172',NULL,NULL,'181','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(182,'172',NULL,NULL,'182','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(183,'172',NULL,NULL,'183','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(184,'172',NULL,NULL,'184','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(185,'172',NULL,NULL,'185','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(186,'172',NULL,NULL,'186','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(187,'172',NULL,NULL,'187','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(188,'172',NULL,NULL,'188','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(189,'172',NULL,NULL,'189','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(190,'172',NULL,NULL,'190','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(191,'172',NULL,NULL,'191','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(192,'172',NULL,NULL,'192','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(193,'172',NULL,NULL,'193','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(194,'172',NULL,NULL,'194','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(195,'172',NULL,NULL,'195','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(196,'172',NULL,NULL,'196','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(197,'172',NULL,NULL,'197','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(198,'172',NULL,NULL,'198','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(199,'172',NULL,NULL,'199','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(200,'172',NULL,NULL,'200','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(201,'172',NULL,NULL,'201','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(202,'172',NULL,NULL,'202','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(203,'172',NULL,NULL,'203','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(204,'172',NULL,NULL,'204','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(205,'172',NULL,NULL,'205','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(206,'172',NULL,NULL,'206','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(207,'172',NULL,NULL,'207','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(208,'172',NULL,NULL,'208','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(209,'172',NULL,NULL,'209','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(210,'172',NULL,NULL,'210','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(211,'172',NULL,NULL,'211','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(212,'172',NULL,NULL,'212','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:24','2026-02-27 11:40:24'),(213,'172',NULL,NULL,'213','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(214,'172',NULL,NULL,'214','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(215,'172',NULL,NULL,'215','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(216,'172',NULL,NULL,'216','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(217,'172',NULL,NULL,'217','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(218,'172',NULL,NULL,'218','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(219,'172',NULL,NULL,'219','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(220,'172',NULL,NULL,'220','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(221,'172',NULL,NULL,'221','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(222,'172',NULL,NULL,'222','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(223,'172',NULL,NULL,'223','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(224,'172',NULL,NULL,'224','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(225,'172',NULL,NULL,'225','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(226,'172',NULL,NULL,'226','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(227,'172',NULL,NULL,'227','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(228,'172',NULL,NULL,'228','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(229,'172',NULL,NULL,'229','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(230,'172',NULL,NULL,'230','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(231,'172',NULL,NULL,'231','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(232,'172',NULL,NULL,'232','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(233,'172',NULL,NULL,'233','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(234,'172',NULL,NULL,'234','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(235,'172',NULL,NULL,'235','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(236,'172',NULL,NULL,'236','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(237,'172',NULL,NULL,'237','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(238,'172',NULL,NULL,'238','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(239,'172',NULL,NULL,'239','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(240,'172',NULL,NULL,'240','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(241,'172',NULL,NULL,'241','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(242,'172',NULL,NULL,'242','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(243,'172',NULL,NULL,'243','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(244,'172',NULL,NULL,'244','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(245,'172',NULL,NULL,'245','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(246,'172',NULL,NULL,'246','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(247,'172',NULL,NULL,'247','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(248,'172',NULL,NULL,'248','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(249,'172',NULL,NULL,'249','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(250,'172',NULL,NULL,'250','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(251,'172',NULL,NULL,'251','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(252,'172',NULL,NULL,'252','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(253,'172',NULL,NULL,'253','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(254,'172',NULL,NULL,'254','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(255,'172',NULL,NULL,'255','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(256,'172',NULL,NULL,'256','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:25','2026-02-27 11:40:25'),(257,'172',NULL,NULL,'257','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(258,'172',NULL,NULL,'258','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(259,'172',NULL,NULL,'259','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(260,'172',NULL,NULL,'260','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(261,'172',NULL,NULL,'261','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(262,'172',NULL,NULL,'262','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(263,'172',NULL,NULL,'263','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(264,'172',NULL,NULL,'264','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(265,'172',NULL,NULL,'265','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(266,'172',NULL,NULL,'266','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(267,'172',NULL,NULL,'267','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(268,'172',NULL,NULL,'268','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(269,'172',NULL,NULL,'269','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(270,'172',NULL,NULL,'270','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(271,'172',NULL,NULL,'271','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(272,'172',NULL,NULL,'272','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(273,'172',NULL,NULL,'273','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(274,'172',NULL,NULL,'274','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(275,'172',NULL,NULL,'275','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(276,'172',NULL,NULL,'276','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(277,'172',NULL,NULL,'277','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(278,'172',NULL,NULL,'278','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(279,'172',NULL,NULL,'279','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(280,'172',NULL,NULL,'280','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(281,'172',NULL,NULL,'281','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(282,'172',NULL,NULL,'282','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(283,'172',NULL,NULL,'283','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(284,'172',NULL,NULL,'284','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(285,'172',NULL,NULL,'285','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(286,'172',NULL,NULL,'286','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(287,'172',NULL,NULL,'287','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(288,'172',NULL,NULL,'288','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(289,'172',NULL,NULL,'289','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(290,'172',NULL,NULL,'290','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(291,'172',NULL,NULL,'291','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(292,'172',NULL,NULL,'292','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:26','2026-02-27 11:40:26'),(293,'172',NULL,NULL,'293','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(294,'172',NULL,NULL,'294','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(295,'172',NULL,NULL,'295','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(296,'172',NULL,NULL,'296','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(297,'172',NULL,NULL,'297','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(298,'172',NULL,NULL,'298','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(299,'172',NULL,NULL,'299','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(300,'172',NULL,NULL,'300','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(301,'172',NULL,NULL,'301','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(302,'172',NULL,NULL,'302','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(303,'172',NULL,NULL,'303','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(304,'172',NULL,NULL,'304','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(305,'172',NULL,NULL,'305','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(306,'172',NULL,NULL,'306','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(307,'172',NULL,NULL,'307','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(308,'172',NULL,NULL,'308','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(309,'172',NULL,NULL,'309','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(310,'172',NULL,NULL,'310','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(311,'172',NULL,NULL,'311','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(312,'172',NULL,NULL,'312','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(313,'172',NULL,NULL,'313','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(314,'172',NULL,NULL,'314','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:27','2026-02-27 11:40:27'),(315,'172',NULL,NULL,'315','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(316,'172',NULL,NULL,'316','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(317,'172',NULL,NULL,'317','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(318,'172',NULL,NULL,'318','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(319,'172',NULL,NULL,'319','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(320,'172',NULL,NULL,'320','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(321,'172',NULL,NULL,'321','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(322,'172',NULL,NULL,'322','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(323,'172',NULL,NULL,'323','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(324,'172',NULL,NULL,'324','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(325,'172',NULL,NULL,'325','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(326,'172',NULL,NULL,'326','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(327,'172',NULL,NULL,'327','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(328,'172',NULL,NULL,'328','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(329,'172',NULL,NULL,'329','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(330,'172',NULL,NULL,'330','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(331,'172',NULL,NULL,'331','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(332,'172',NULL,NULL,'332','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(333,'172',NULL,NULL,'333','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:28','2026-02-27 11:40:28'),(334,'172',NULL,NULL,'334','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(335,'172',NULL,NULL,'335','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(336,'172',NULL,NULL,'336','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(337,'172',NULL,NULL,'337','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(338,'172',NULL,NULL,'338','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(339,'172',NULL,NULL,'339','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(340,'172',NULL,NULL,'340','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:29','2026-02-27 11:40:29'),(341,'172',NULL,NULL,'341','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(342,'172',NULL,NULL,'342','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(343,'172',NULL,NULL,'343','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(344,'172',NULL,NULL,'344','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(345,'172',NULL,NULL,'345','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(346,'172',NULL,NULL,'346','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(347,'172',NULL,NULL,'347','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(348,'172',NULL,NULL,'348','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(349,'172',NULL,NULL,'349','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:30','2026-02-27 11:40:30'),(350,'172',NULL,NULL,'350','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(351,'172',NULL,NULL,'351','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(352,'172',NULL,NULL,'352','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(353,'172',NULL,NULL,'353','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(354,'172',NULL,NULL,'354','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(355,'172',NULL,NULL,'355','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(356,'172',NULL,NULL,'356','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(357,'172',NULL,NULL,'357','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(358,'172',NULL,NULL,'358','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(359,'172',NULL,NULL,'359','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(360,'172',NULL,NULL,'360','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(361,'172',NULL,NULL,'361','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(362,'172',NULL,NULL,'362','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(363,'172',NULL,NULL,'363','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(364,'172',NULL,NULL,'364','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(365,'172',NULL,NULL,'365','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(366,'172',NULL,NULL,'366','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:31','2026-02-27 11:40:31'),(367,'172',NULL,NULL,'367','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(368,'172',NULL,NULL,'368','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(369,'172',NULL,NULL,'369','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(370,'172',NULL,NULL,'370','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(371,'172',NULL,NULL,'371','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(372,'172',NULL,NULL,'372','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(373,'172',NULL,NULL,'373','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(374,'172',NULL,NULL,'374','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(375,'172',NULL,NULL,'375','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(376,'172',NULL,NULL,'376','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(377,'172',NULL,NULL,'377','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(378,'172',NULL,NULL,'378','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(379,'172',NULL,NULL,'379','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:32','2026-02-27 11:40:32'),(380,'172',NULL,NULL,'380','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(381,'172',NULL,NULL,'381','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(382,'172',NULL,NULL,'382','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(383,'172',NULL,NULL,'383','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(384,'172',NULL,NULL,'384','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(385,'172',NULL,NULL,'385','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(386,'172',NULL,NULL,'386','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(387,'172',NULL,NULL,'387','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:33','2026-02-27 11:40:33'),(388,'172',NULL,NULL,'388','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(389,'172',NULL,NULL,'389','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(390,'172',NULL,NULL,'390','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(391,'172',NULL,NULL,'391','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(392,'172',NULL,NULL,'392','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(393,'172',NULL,NULL,'393','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(394,'172',NULL,NULL,'394','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(395,'172',NULL,NULL,'395','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(396,'172',NULL,NULL,'396','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:34','2026-02-27 11:40:34'),(397,'172',NULL,NULL,'397','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(398,'172',NULL,NULL,'398','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(399,'172',NULL,NULL,'399','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(400,'172',NULL,NULL,'400','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(401,'172',NULL,NULL,'401','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(402,'172',NULL,NULL,'402','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:35','2026-02-27 11:40:35'),(403,'172',NULL,NULL,'403','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:36','2026-02-27 11:40:36'),(404,'172',NULL,NULL,'404','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:36','2026-02-27 11:40:36'),(405,'172',NULL,NULL,'405','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(406,'172',NULL,NULL,'406','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(407,'172',NULL,NULL,'407','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(408,'172',NULL,NULL,'408','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(409,'172',NULL,NULL,'409','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(410,'172',NULL,NULL,'410','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(411,'172',NULL,NULL,'411','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(412,'172',NULL,NULL,'412','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:37','2026-02-27 11:40:37'),(413,'172',NULL,NULL,'413','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(414,'172',NULL,NULL,'414','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(415,'172',NULL,NULL,'415','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(416,'172',NULL,NULL,'416','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:38','2026-02-27 11:40:38'),(417,'172',NULL,NULL,'417','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(418,'172',NULL,NULL,'418','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(419,'172',NULL,NULL,'419','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(420,'172',NULL,NULL,'420','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:39','2026-02-27 11:40:39'),(421,'172',NULL,NULL,'421','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(422,'172',NULL,NULL,'422','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(423,'172',NULL,NULL,'423','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(424,'172',NULL,NULL,'424','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(425,'172',NULL,NULL,'425','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(426,'172',NULL,NULL,'426','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:40','2026-02-27 11:40:40'),(427,'172',NULL,NULL,'427','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:41','2026-02-27 11:40:41'),(428,'172',NULL,NULL,'428','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:41','2026-02-27 11:40:41'),(429,'172',NULL,NULL,'429','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:42','2026-02-27 11:40:42'),(430,'172',NULL,NULL,'430','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:42','2026-02-27 11:40:42'),(431,'172',NULL,NULL,'431','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:42','2026-02-27 11:40:42'),(432,'172',NULL,NULL,'432','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:43','2026-02-27 11:40:43'),(433,'172',NULL,NULL,'433','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:44','2026-02-27 11:40:44'),(434,'172',NULL,NULL,'434','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:44','2026-02-27 11:40:44'),(435,'172',NULL,NULL,'435','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:45','2026-02-27 11:40:45'),(436,'172',NULL,NULL,'436','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:46','2026-02-27 11:40:46'),(437,'172',NULL,NULL,'437','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:46','2026-02-27 11:40:46'),(438,'172',NULL,NULL,'438','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:47','2026-02-27 11:40:47'),(439,'172',NULL,NULL,'439','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:47','2026-02-27 11:40:47'),(440,'172',NULL,NULL,'440','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:48','2026-02-27 11:40:48'),(441,'172',NULL,NULL,'441','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:49','2026-02-27 11:40:49'),(442,'172',NULL,NULL,'442','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:50','2026-02-27 11:40:50'),(443,'172',NULL,NULL,'443','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:51','2026-02-27 11:40:51'),(444,'172',NULL,NULL,'444','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:51','2026-02-27 11:40:51'),(445,'172',NULL,NULL,'445','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:51','2026-02-27 11:40:51'),(446,'172',NULL,NULL,'446','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(447,'172',NULL,NULL,'447','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(448,'172',NULL,NULL,'448','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(449,'172',NULL,NULL,'449','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(450,'172',NULL,NULL,'450','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:52','2026-02-27 11:40:52'),(451,'172',NULL,NULL,'451','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:53','2026-02-27 11:40:53'),(452,'172',NULL,NULL,'452','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:54','2026-02-27 11:40:54'),(453,'172',NULL,NULL,'453','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:55','2026-02-27 11:40:55'),(454,'172',NULL,NULL,'454','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:55','2026-02-27 11:40:55'),(455,'172',NULL,NULL,'455','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:55','2026-02-27 11:40:55'),(456,'172',NULL,NULL,'456','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:56','2026-02-27 11:40:56'),(457,'172',NULL,NULL,'457','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:56','2026-02-27 11:40:56'),(458,'172',NULL,NULL,'458','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:56','2026-02-27 11:40:56'),(459,'172',NULL,NULL,'459','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:57','2026-02-27 11:40:57'),(460,'172',NULL,NULL,'460','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:57','2026-02-27 11:40:57'),(461,'172',NULL,NULL,'461','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:59','2026-02-27 11:40:59'),(462,'172',NULL,NULL,'462','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:40:59','2026-02-27 11:40:59'),(463,'172',NULL,NULL,'463','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:00','2026-02-27 11:41:00'),(464,'172',NULL,NULL,'464','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:00','2026-02-27 11:41:00'),(465,'172',NULL,NULL,'465','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:01','2026-02-27 11:41:01'),(466,'172',NULL,NULL,'466','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:02','2026-02-27 11:41:02'),(467,'172',NULL,NULL,'467','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:03','2026-02-27 11:41:03'),(468,'172',NULL,NULL,'468','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:04','2026-02-27 11:41:04'),(469,'172',NULL,NULL,'469','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:04','2026-02-27 11:41:04'),(470,'172',NULL,NULL,'470','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:04','2026-02-27 11:41:04'),(471,'172',NULL,NULL,'471','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:05','2026-02-27 11:41:05'),(472,'172',NULL,NULL,'472','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:05','2026-02-27 11:41:05'),(473,'172',NULL,NULL,'473','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:05','2026-02-27 11:41:05'),(474,'172',NULL,NULL,'474','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:06','2026-02-27 11:41:06'),(475,'172',NULL,NULL,'475','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:07','2026-02-27 11:41:07'),(476,'172',NULL,NULL,'476','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:09','2026-02-27 11:41:09'),(477,'172',NULL,NULL,'477','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:09','2026-02-27 11:41:09'),(478,'172',NULL,NULL,'478','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:10','2026-02-27 11:41:10'),(479,'172',NULL,NULL,'479','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:13','2026-02-27 11:41:13'),(480,'172',NULL,NULL,'480','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:13','2026-02-27 11:41:13'),(481,'172',NULL,NULL,'481','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:15','2026-02-27 11:41:15'),(482,'172',NULL,NULL,'482','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:16','2026-02-27 11:41:16'),(483,'172',NULL,NULL,'483','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:17','2026-02-27 11:41:17'),(484,'172',NULL,NULL,'484','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:17','2026-02-27 11:41:17'),(485,'172',NULL,NULL,'485','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:18','2026-02-27 11:41:18'),(486,'172',NULL,NULL,'486','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:20','2026-02-27 11:41:20'),(487,'172',NULL,NULL,'487','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:20','2026-02-27 11:41:20'),(488,'172',NULL,NULL,'488','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(489,'172',NULL,NULL,'489','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(490,'172',NULL,NULL,'490','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(491,'172',NULL,NULL,'491','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:21','2026-02-27 11:41:21'),(492,'172',NULL,NULL,'492','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:22','2026-02-27 11:41:22'),(493,'172',NULL,NULL,'493','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:22','2026-02-27 11:41:22'),(494,'172',NULL,NULL,'494','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:24','2026-02-27 11:41:24'),(495,'172',NULL,NULL,'495','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:25','2026-02-27 11:41:25'),(496,'172',NULL,NULL,'496','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:25','2026-02-27 11:41:25'),(497,'172',NULL,NULL,'497','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(498,'172',NULL,NULL,'498','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(499,'172',NULL,NULL,'499','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(500,'172',NULL,NULL,'500','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(501,'172',NULL,NULL,'501','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(502,'172',NULL,NULL,'502','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(503,'172',NULL,NULL,'503','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(504,'172',NULL,NULL,'504','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(505,'172',NULL,NULL,'505','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:26','2026-02-27 11:41:26'),(506,'172',NULL,NULL,'506','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(507,'172',NULL,NULL,'507','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(508,'172',NULL,NULL,'508','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(509,'172',NULL,NULL,'509','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(510,'172',NULL,NULL,'510','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:27','2026-02-27 11:41:27'),(511,'172',NULL,NULL,'511','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:28','2026-02-27 11:41:28'),(512,'172',NULL,NULL,'512','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(513,'172',NULL,NULL,'513','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(514,'172',NULL,NULL,'514','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(515,'172',NULL,NULL,'515','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:29','2026-02-27 11:41:29'),(516,'172',NULL,NULL,'516','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(517,'172',NULL,NULL,'517','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(518,'172',NULL,NULL,'518','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(519,'172',NULL,NULL,'519','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(520,'172',NULL,NULL,'520','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:31','2026-02-27 11:41:31'),(521,'172',NULL,NULL,'521','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(522,'172',NULL,NULL,'522','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(523,'172',NULL,NULL,'523','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(524,'172',NULL,NULL,'524','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(525,'172',NULL,NULL,'525','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:32','2026-02-27 11:41:32'),(526,'172',NULL,NULL,'526','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:33','2026-02-27 11:41:33'),(527,'172',NULL,NULL,'527','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:33','2026-02-27 11:41:33'),(528,'172',NULL,NULL,'528','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:34','2026-02-27 11:41:34'),(529,'172',NULL,NULL,'529','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:36','2026-02-27 11:41:36'),(530,'172',NULL,NULL,'530','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:36','2026-02-27 11:41:36'),(531,'172',NULL,NULL,'531','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:37','2026-02-27 11:41:37'),(532,'172',NULL,NULL,'532','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:39','2026-02-27 11:41:39'),(533,'172',NULL,NULL,'533','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:41','2026-02-27 11:41:41'),(534,'172',NULL,NULL,'534','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:41','2026-02-27 11:41:41'),(535,'172',NULL,NULL,'535','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:47','2026-02-27 11:41:47'),(536,'172',NULL,NULL,'536','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:47','2026-02-27 11:41:47'),(537,'172',NULL,NULL,'537','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:47','2026-02-27 11:41:47'),(538,'172',NULL,NULL,'538','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:48','2026-02-27 11:41:48'),(539,'172',NULL,NULL,'539','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:49','2026-02-27 11:41:49'),(540,'172',NULL,NULL,'540','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:50','2026-02-27 11:41:50'),(541,'172',NULL,NULL,'541','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:50','2026-02-27 11:41:50'),(542,'172',NULL,NULL,'542','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:51','2026-02-27 11:41:51'),(543,'172',NULL,NULL,'543','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:51','2026-02-27 11:41:51'),(544,'172',NULL,NULL,'544','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:51','2026-02-27 11:41:51'),(545,'172',NULL,NULL,'545','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(546,'172',NULL,NULL,'546','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(547,'172',NULL,NULL,'547','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(548,'172',NULL,NULL,'548','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(549,'172',NULL,NULL,'549','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(550,'172',NULL,NULL,'550','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(551,'172',NULL,NULL,'551','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(552,'172',NULL,NULL,'552','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(553,'172',NULL,NULL,'553','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:53','2026-02-27 11:41:53'),(554,'172',NULL,NULL,'554','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(555,'172',NULL,NULL,'555','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(556,'172',NULL,NULL,'556','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(557,'172',NULL,NULL,'557','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(558,'172',NULL,NULL,'558','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(559,'172',NULL,NULL,'559','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(560,'172',NULL,NULL,'560','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(561,'172',NULL,NULL,'561','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(562,'172',NULL,NULL,'562','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(563,'172',NULL,NULL,'563','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:54','2026-02-27 11:41:54'),(564,'172',NULL,NULL,'564','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:55','2026-02-27 11:41:55'),(565,'172',NULL,NULL,'565','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:55','2026-02-27 11:41:55'),(566,'172',NULL,NULL,'566','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:56','2026-02-27 11:41:56'),(567,'172',NULL,NULL,'567','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:56','2026-02-27 11:41:56'),(568,'172',NULL,NULL,'568','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:56','2026-02-27 11:41:56'),(569,'172',NULL,NULL,'569','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:41:59','2026-02-27 11:41:59'),(570,'172',NULL,NULL,'570','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:00','2026-02-27 11:42:00'),(571,'172',NULL,NULL,'571','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(572,'172',NULL,NULL,'572','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(573,'172',NULL,NULL,'573','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(574,'172',NULL,NULL,'574','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(575,'172',NULL,NULL,'575','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(576,'172',NULL,NULL,'576','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(577,'172',NULL,NULL,'577','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(578,'172',NULL,NULL,'578','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(579,'172',NULL,NULL,'579','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(580,'172',NULL,NULL,'580','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:01','2026-02-27 11:42:01'),(581,'172',NULL,NULL,'581','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(582,'172',NULL,NULL,'582','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(583,'172',NULL,NULL,'583','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(584,'172',NULL,NULL,'584','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(585,'172',NULL,NULL,'585','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:02','2026-02-27 11:42:02'),(586,'172',NULL,NULL,'586','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:03','2026-02-27 11:42:03'),(587,'172',NULL,NULL,'587','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:03','2026-02-27 11:42:03'),(588,'172',NULL,NULL,'588','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:04','2026-02-27 11:42:04'),(589,'172',NULL,NULL,'589','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:05','2026-02-27 11:42:05'),(590,'172',NULL,NULL,'590','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:07','2026-02-27 11:42:07'),(591,'172',NULL,NULL,'591','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:08','2026-02-27 11:42:08'),(592,'172',NULL,NULL,'592','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:08','2026-02-27 11:42:08'),(593,'172',NULL,NULL,'593','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:08','2026-02-27 11:42:08'),(594,'172',NULL,NULL,'594','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(595,'172',NULL,NULL,'595','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(596,'172',NULL,NULL,'596','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(597,'172',NULL,NULL,'597','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:12','2026-02-27 11:42:12'),(598,'172',NULL,NULL,'598','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:14','2026-02-27 11:42:14'),(599,'172',NULL,NULL,'599','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:14','2026-02-27 11:42:14'),(600,'172',NULL,NULL,'600','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:14','2026-02-27 11:42:14'),(601,'172',NULL,NULL,'601','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:15','2026-02-27 11:42:15'),(602,'172',NULL,NULL,'602','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:15','2026-02-27 11:42:15'),(603,'172',NULL,NULL,'603','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:18','2026-02-27 11:42:18'),(604,'172',NULL,NULL,'604','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:19','2026-02-27 11:42:19'),(605,'172',NULL,NULL,'605','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:20','2026-02-27 11:42:20'),(606,'172',NULL,NULL,'606','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:20','2026-02-27 11:42:20'),(607,'172',NULL,NULL,'607','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:21','2026-02-27 11:42:21'),(608,'172',NULL,NULL,'608','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:22','2026-02-27 11:42:22'),(609,'172',NULL,NULL,'609','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(610,'172',NULL,NULL,'610','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(611,'172',NULL,NULL,'611','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(612,'172',NULL,NULL,'612','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(613,'172',NULL,NULL,'613','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(614,'172',NULL,NULL,'614','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(615,'172',NULL,NULL,'615','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(616,'172',NULL,NULL,'616','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(617,'172',NULL,NULL,'617','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(618,'172',NULL,NULL,'618','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(619,'172',NULL,NULL,'619','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(620,'172',NULL,NULL,'620','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(621,'172',NULL,NULL,'621','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(622,'172',NULL,NULL,'622','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(623,'172',NULL,NULL,'623','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(624,'172',NULL,NULL,'624','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(625,'172',NULL,NULL,'625','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(626,'172',NULL,NULL,'626','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(627,'172',NULL,NULL,'627','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:28','2026-02-27 11:42:28'),(628,'172',NULL,NULL,'628','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(629,'172',NULL,NULL,'629','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(630,'172',NULL,NULL,'630','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(631,'172',NULL,NULL,'631','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(632,'172',NULL,NULL,'632','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(633,'172',NULL,NULL,'633','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(634,'172',NULL,NULL,'634','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(635,'172',NULL,NULL,'635','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:29','2026-02-27 11:42:29'),(636,'172',NULL,NULL,'636','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:31','2026-02-27 11:42:31'),(637,'172',NULL,NULL,'637','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:31','2026-02-27 11:42:31'),(638,'172',NULL,NULL,'638','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:31','2026-02-27 11:42:31'),(639,'172',NULL,NULL,'639','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(640,'172',NULL,NULL,'640','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(641,'172',NULL,NULL,'641','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(642,'172',NULL,NULL,'642','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:32','2026-02-27 11:42:32'),(643,'172',NULL,NULL,'643','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(644,'172',NULL,NULL,'644','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(645,'172',NULL,NULL,'645','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(646,'172',NULL,NULL,'646','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:33','2026-02-27 11:42:33'),(647,'172',NULL,NULL,'647','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:35','2026-02-27 11:42:35'),(648,'172',NULL,NULL,'648','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:37','2026-02-27 11:42:37'),(649,'172',NULL,NULL,'649','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:42','2026-02-27 11:42:42'),(650,'172',NULL,NULL,'650','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:42','2026-02-27 11:42:42'),(651,'172',NULL,NULL,'651','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:46','2026-02-27 11:42:46'),(652,'172',NULL,NULL,'652','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:46','2026-02-27 11:42:46'),(653,'172',NULL,NULL,'653','1703411590658',NULL,NULL,NULL,'18.38','0.00','0.00','27','18.38','0','18.38','0','0','0',NULL,NULL,NULL,NULL,NULL,'289','289',NULL,0,'2026-02-27 11:42:46','2026-02-27 11:42:46');
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int(11) DEFAULT 0,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int(11) DEFAULT 0,
  `M_ROUND_OFF` int(11) DEFAULT 0,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL,
  `LITE_ID` varchar(50) DEFAULT '',
  `WEB_ID` varchar(50) DEFAULT '',
  `PROD_ID` int(11) NOT NULL,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` varchar(50) DEFAULT NULL,
  `PUR_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT` varchar(25) DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) DEFAULT '0',
  `PUR_CESS` varchar(25) DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) DEFAULT '0',
  `PACK` varchar(25) DEFAULT '0',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(25) DEFAULT '0',
  `DISC_PERCENT` varchar(25) DEFAULT '0',
  `DISC_AMOUNT` varchar(25) DEFAULT '0',
  `RETURN_QTY` varchar(25) DEFAULT '0',
  `FREE` varchar(25) DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) DEFAULT '0',
  `AMT` varchar(25) DEFAULT '0',
  `TAX_AMT` varchar(25) DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) DEFAULT '0',
  `RETURN` varchar(25) DEFAULT '0',
  `SR_NO` varchar(50) DEFAULT '',
  `CESS_AMT` varchar(25) DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) DEFAULT '0',
  `UI_DISP_BAG` varchar(50) DEFAULT '',
  `WEIGHT` varchar(25) DEFAULT '0',
  `PRICE_PER` varchar(25) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT NULL,
  `TE_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) DEFAULT '0',
  `MRP` varchar(25) DEFAULT '0',
  `DAMAGE` varchar(25) DEFAULT '0',
  `DAMAGE_AMT` varchar(25) DEFAULT '0',
  `REPLACE` varchar(25) DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) DEFAULT '0',
  `DMG_MRP` varchar(25) DEFAULT '0',
  `PUR_INSURANCE` varchar(25) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) DEFAULT '0',
  `CLOUD_SYNC` varchar(25) DEFAULT '0',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT current_timestamp(),
  `UPDATED_TS` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `FINAL_AMT` varchar(25) DEFAULT '0',
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `TCS_TAX` varchar(100) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `BROKER_ID` int(11) DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (289,'172','0','em6qeR43bZ','mayank','em6qeR43bZ','mayank@yopmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','',NULL,NULL,'289','289','',0,'2026-02-27 10:32:18','2026-02-27 10:32:18');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REMARKS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT 0,
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-02-27 10:32:17',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text DEFAULT NULL,
  `MAC_ID` int(11) DEFAULT 0,
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text DEFAULT NULL,
  `S_ADD2` text DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int(11) NOT NULL DEFAULT 0,
  `ADDRESS1` text DEFAULT NULL,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `PG_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` int(11) DEFAULT 0,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT NULL,
  `LITE_ID` varchar(50) DEFAULT NULL,
  `WEB_ID` varchar(50) DEFAULT NULL,
  `PROD_ID` varchar(20) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) DEFAULT NULL,
  `SALES_ID` varchar(20) DEFAULT NULL,
  `SALE_UNIT` varchar(20) DEFAULT NULL,
  `SALE_RATE` varchar(20) DEFAULT NULL,
  `PUR_RATE` varchar(20) DEFAULT NULL,
  `PROD_PACK` varchar(20) DEFAULT NULL,
  `PUR_VAT` varchar(20) DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_VAT` varchar(20) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_CESS` varchar(20) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) DEFAULT NULL,
  `PACK` varchar(20) DEFAULT NULL,
  `BOX` varchar(20) DEFAULT NULL,
  `QTY` varchar(20) DEFAULT NULL,
  `DISC_PERCENT` varchar(20) DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) DEFAULT NULL,
  `RETURN_QTY` varchar(20) DEFAULT NULL,
  `FREE` varchar(20) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) DEFAULT NULL,
  `AMT` varchar(20) DEFAULT NULL,
  `PUR_AMT` varchar(20) DEFAULT NULL,
  `PROFIT` varchar(20) DEFAULT NULL,
  `TAX_AMT` varchar(20) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) DEFAULT NULL,
  `DAMAGE` varchar(20) DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) DEFAULT NULL,
  `REPLACE` varchar(25) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) DEFAULT NULL,
  `RETURN` varchar(25) DEFAULT NULL,
  `SR_NO` varchar(50) DEFAULT NULL,
  `CESS_AMT` varchar(20) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) DEFAULT NULL,
  `WEIGHT` varchar(20) DEFAULT NULL,
  `PUR_UNIT` varchar(20) DEFAULT NULL,
  `PRICE_PER` varchar(20) DEFAULT NULL,
  `TE_RATE` varchar(20) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) DEFAULT NULL,
  `DMG_MRP` varchar(20) DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) DEFAULT NULL,
  `INV_ARR` varchar(255) DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` varchar(20) DEFAULT NULL,
  `UPDATED_BY` varchar(20) DEFAULT NULL,
  `SECURITY_KEY` varchar(100) DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(20) DEFAULT NULL,
  `SALES_MAN` varchar(100) DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(20) DEFAULT NULL,
  `PARTY_CODE` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(20) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) DEFAULT NULL,
  `BATCH_NO` varchar(50) DEFAULT NULL,
  `MFG_DATE` varchar(20) DEFAULT NULL,
  `EXP_DATE` varchar(20) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int(11) DEFAULT 0,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int(11) DEFAULT 0,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int(11) DEFAULT 0,
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SMAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYNC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text DEFAULT NULL,
  `UPDATED_VALUE` text DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text DEFAULT NULL,
  `DIACM` text DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int(11) DEFAULT 0,
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int(11) DEFAULT 0,
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-02-27 10:32:17','2026-02-27 10:32:17');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UOM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT 0,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WEB_ID` int(11) NOT NULL DEFAULT 0,
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-02-27 10:32:18');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-14 18:00:02
