-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `INPUT_TYPE` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) DEFAULT NULL,
  `GROUPS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'template_name','Print Invoice','text','Y',NULL,'1'),(2,'left_margin','5','text','Y','(%)','1'),(3,'top_margin','2','text','Y','(%)','1'),(4,'top_bar_height','140','text','Y','(px)','1'),(5,'top_address_width','50','text','Y','(%)','2'),(6,'top_center_width','40','text','Y','(%)','2'),(7,'top_right_width','10','text','Y','(%)','2'),(8,'item_section_height','200','text','Y','(px)','1'),(9,'qty','8','text','Y','(%)','3'),(10,'hsn_code','9','text','Y','(%)','3'),(11,'mrp','9','text','Y','(%)','3'),(12,'particular','25','text','Y','(%)','3'),(13,'rate','9','text','Y','(%)','3'),(14,'free','1','text','Y','(%)','3'),(15,'sch_per','1','text','Y','(%)','3'),(16,'sch_amt','9','text','Y','(%)','3'),(17,'sch1_per','10','text','N','(%)','3'),(18,'sch1_amt','10','text','N','(%)','3'),(19,'sch2_per','10','text','N','(%)','3'),(20,'sch2_amt','10','text','N','(%)','3'),(21,'amt','9','text','Y','(%)','3'),(22,'gst_per','2','text','Y','(%)','3'),(23,'gst_amt','9','text','Y','(%)','3'),(24,'net_amt','9','text','Y','(%)','3'),(25,'footer_top_margin','0','text','N','(%)','4'),(26,'footer_height','90','text','N','(%)','4'),(27,'footer_left','24','text','Y','(%)','4'),(28,'footer_gross','9','text','Y','(%)','4'),(29,'footer_scheme','9','text','Y','(%)','4'),(30,'footer_discount','9','text','Y','(%)','4'),(31,'footer_display','9','text','Y','(%)','4'),(32,'footer_damage','9','text','Y','(%)','4'),(33,'footer_gst_amt','12','text','Y','(%)','4'),(34,'footer_add','7','text','Y','(%)','4'),(35,'footer_net_amt','26','text','Y','(%)','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-14 18:00:23
