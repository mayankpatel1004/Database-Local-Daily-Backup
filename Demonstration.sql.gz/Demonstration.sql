-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: Demonstration
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `record_id` int(11) NOT NULL DEFAULT 0,
  `table_name` varchar(255) DEFAULT NULL,
  `record_name` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id_pk` int(11) DEFAULT 0,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `customer_pin` int(11) NOT NULL DEFAULT 0,
  `pos_customer` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `guest_customer` varchar(1) NOT NULL DEFAULT '0',
  `access_token` varchar(255) DEFAULT NULL,
  `security_question_id` int(11) NOT NULL DEFAULT 0,
  `security_answer` varchar(191) DEFAULT NULL,
  `user_address1` varchar(191) DEFAULT NULL,
  `user_address2` varchar(191) DEFAULT NULL,
  `user_city` varchar(191) DEFAULT NULL,
  `user_state` varchar(191) DEFAULT NULL,
  `user_zipcode` varchar(191) DEFAULT NULL,
  `user_country` varchar(191) DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `web_token` varchar(255) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `item_type` varchar(25) NOT NULL DEFAULT 'users',
  `wallet_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `blocked` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section`
--

DROP TABLE IF EXISTS `item_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section` (
  `item_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_section_parent_id` int(11) NOT NULL DEFAULT 0,
  `section_title` varchar(255) DEFAULT NULL,
  `section_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `display_order` int(11) DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section`
--

LOCK TABLES `item_section` WRITE;
/*!40000 ALTER TABLE `item_section` DISABLE KEYS */;
INSERT INTO `item_section` VALUES (1,0,0,'Default Section 1','default-section-1','default',NULL,NULL,0,0,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 16:24:45'),(2,0,0,'Default Section 2','default-section-2','default',NULL,NULL,0,0,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 16:24:45'),(3,0,0,'Default Section 3','default-section-3','default',NULL,NULL,0,0,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 16:24:45'),(4,0,0,'11','11',NULL,'22','1777630795457_partyWiseSales.csv',22,22,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:15:37'),(5,0,0,'11','11-1777643157',NULL,'22','1777630795457_partyWiseSales.csv',22,22,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:15:57'),(6,0,0,'11222222222','11222222222',NULL,'22','1777630795457_partyWiseSales.csv',22,22,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:17:18'),(7,0,0,'333333','333333','default','333333',NULL,333333,333333,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:19:50'),(8,0,0,'4444','4444','default','4444','1777630269721_accountExport.csv',4444,4444,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:21:50'),(9,0,0,'222','222','default','333','1777630269721_accountExport.csv',2222,1,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:29:13'),(10,0,0,'333322222','333322222','default','333322222',NULL,333322222,333322222,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:33:04'),(11,0,0,'11','11-1777645696','default','11',NULL,11,11,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 19:58:16'),(12,0,0,'Blog1','Blog1','blog','Blog1','',0,0,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 20:06:27'),(13,0,0,'2222','2222','default','2222','1777630795457_partyWiseSales.csv',1,1,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 20:21:03'),(14,0,0,'123','123','default','11',NULL,11,11,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-01 20:29:23'),(15,0,0,'itemtitle','itemtitle','default','itemdescription','1777630269721_accountExport.csv',0,3,'Y',NULL,NULL,0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-02 13:34:03'),(16,0,0,'123','123-1777709287','default','123',NULL,123,123,'Y','123','123',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-02 13:38:07'),(17,0,0,'123123','123123','default','123',NULL,123,123,'Y','123','123',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-02 13:53:32'),(18,0,0,'123123123111111','123123123','default','123123123',NULL,123123123,123123123,'Y','123123123','123123123',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-02 13:53:46'),(19,0,0,'Blog 2','Blog 2','blog','Blog 2','',0,0,'Y','Blog 2','Blog 2',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-02 17:04:59'),(20,0,0,'123123123','123123123-1778761752','default','123123123',NULL,123123123,123123123,'Y','123123123','123123123',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-14 17:59:12'),(21,0,0,'123123123','123123123-1778762910','default','123123123',NULL,123123123,123123123,'Y','123123123','123123123',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-14 18:18:30'),(22,0,0,'123123123','123123123-1778763035','default','123123123',NULL,1,1,'Y','2111111','334444',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-14 18:20:35'),(23,0,0,'mayank','123123123-1778763098','default','123123123','1778777923_isec_2354.png',1,1,'Y','2111111','334444',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-14 18:21:38');
/*!40000 ALTER TABLE `item_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section_relation`
--

DROP TABLE IF EXISTS `item_section_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section_relation` (
  `item_section_relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_id` bigint(20) NOT NULL DEFAULT 0,
  `section_id` bigint(20) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  PRIMARY KEY (`item_section_relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section_relation`
--

LOCK TABLES `item_section_relation` WRITE;
/*!40000 ALTER TABLE `item_section_relation` DISABLE KEYS */;
INSERT INTO `item_section_relation` VALUES (1,0,5,1,'Y','N',0,NULL,NULL),(2,0,5,2,'Y','N',0,NULL,NULL),(6,0,6,6,'Y','N',0,NULL,NULL);
/*!40000 ALTER TABLE `item_section_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_parent` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) DEFAULT NULL,
  `item_sections_id` varchar(255) DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `attachment2` varchar(255) DEFAULT NULL,
  `item_shortdescription` text DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT 'index',
  `published_at` date DEFAULT NULL,
  `published_end_at` date DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,0,'Home','home',100,'page','24','description update','attachment1-1758612676875.png','attachment2-1758612676877.png','short description update',3,'controller','action','2026-04-27','2026-04-27','meta title update','meta description update',1,'Demonstration',1,1,'Y','N',0,NULL,NULL,'2026-04-27 12:06:28','2026-04-27 12:06:28'),(2,0,'About Us','about-us',0,'page',NULL,'About Us',NULL,'','',1,'','','2026-04-27','2026-04-27','About Us','About Us',1,'Demonstration',1,1,'Y','N',0,NULL,NULL,'2026-04-27 12:06:28','2026-04-27 12:06:28'),(3,0,'Terms & Conditions','terms-and-conditions',0,'page',NULL,'Terms & Conditions',NULL,'','',1,'','','2026-04-27','2026-04-27','Terms & Conditions','Terms & Conditions',1,'Demonstration',1,2,'Y','N',1,'Developer Account','2026-04-27 15:36:49','2026-04-27 12:06:28','2026-04-27 12:06:28'),(4,0,'Privacy Policy','privacy-policy',0,'page',NULL,'Privacy Policy',NULL,'','',1,'','','2026-04-27','2026-04-27','Privacy Policy','Privacy Policy',1,'Demonstration',1,3,'Y','N',0,NULL,NULL,'2026-04-27 12:06:28','2026-04-27 12:06:28'),(5,0,'1','1',0,'default','1,2','1',NULL,NULL,'1',0,NULL,'index','2026-05-01','2031-05-01','1','1',0,NULL,0,1,'Y','N',0,NULL,NULL,NULL,'2026-05-01 20:42:21'),(6,0,'mayank','2222',0,'default','1,2,3','Description','1778778135_item1_8254.png','1778778135_item2_6704.png','Short Description',0,NULL,'index','2026-05-02','2031-05-02','2111111','334444',0,NULL,0,3,'Y','N',0,NULL,NULL,NULL,'2026-05-01 20:47:08'),(7,0,'3333','3333',0,'default','','3333',NULL,NULL,'3333',0,NULL,'index','2026-05-01','2031-05-01','','',0,NULL,0,0,'Y','N',0,NULL,NULL,NULL,'2026-05-01 20:48:48'),(8,0,'3333','3333-1777648756',0,'default','1,2,3','2222',NULL,NULL,'222',0,NULL,'index','2026-05-01','2031-05-01','222','222',0,NULL,0,3,'Y','N',0,NULL,NULL,NULL,'2026-05-01 20:49:16'),(9,0,'Blog1','Blog1',0,'blog','12','Blog1',NULL,NULL,'Blog1',0,NULL,'index','2026-05-01','2031-05-01','Blog1','Blog1',0,NULL,0,1,'Y','N',0,NULL,NULL,NULL,'2026-05-01 20:50:36'),(10,0,'123123123','123123123',0,'default','1,2,3','123123123',NULL,NULL,'123123123',0,NULL,'index','2026-05-02','2031-05-02','123123123','123123123',0,NULL,0,123123123,'Y','N',0,NULL,NULL,NULL,'2026-05-02 13:54:29'),(11,0,'5555555555555','5555555555555',0,'default','','5555555555555',NULL,NULL,'5555555555555',0,NULL,'index','2026-05-02','2031-05-02','5555555555555','5555555555555',0,NULL,0,23,'Y','N',0,NULL,NULL,NULL,'2026-05-02 14:16:46'),(12,0,'444444444','444444444',0,'default','1,2,3','5555555555555',NULL,NULL,'5555555555555',0,NULL,'index','2026-05-02','2031-05-02','5555555555555','5555555555555',0,NULL,0,23,'Y','N',0,NULL,NULL,NULL,'2026-05-02 14:17:04'),(13,0,'444444444','444444444-1777712264',0,'default','2,8,16,17','5555555555555',NULL,NULL,'5555555555555',0,NULL,'index','2026-05-02','2031-05-02','5555555555555','5555555555555',0,NULL,0,23,'Y','N',0,NULL,NULL,NULL,'2026-05-02 14:27:44'),(14,0,'123444444','123444444',0,'default','1,2,3','123444444',NULL,NULL,'123444444',0,NULL,'index','2026-05-02','2031-05-02','123444444','123444444',0,NULL,0,0,'Y','N',0,NULL,NULL,NULL,'2026-05-02 17:10:04'),(15,0,'Blog2','Blog2',0,'blog','12,19','Blog2',NULL,NULL,'Blog2',0,NULL,'index','2026-05-02','2031-05-02','Blog2','Blog2',0,NULL,0,0,'Y','N',0,NULL,NULL,NULL,'2026-05-02 17:10:25'),(16,0,'123444444','123444444-1778775279',0,'default','1,2,3','123444444',NULL,NULL,'123444444',0,NULL,'index','2026-05-02','2031-05-02','123444444','123444444',0,NULL,0,0,'Y','N',0,NULL,NULL,NULL,'2026-05-14 21:44:39');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_details`
--

DROP TABLE IF EXISTS `meta_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_details` (
  `meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `end_points` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `sidebar_title` varchar(255) DEFAULT NULL,
  `sidebar_icon` varchar(255) DEFAULT NULL,
  `sidebar_order` int(11) NOT NULL DEFAULT 0,
  `params` varchar(255) DEFAULT NULL,
  `is_module` smallint(6) NOT NULL DEFAULT 0,
  `deleted_status` varchar(4) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_details`
--

LOCK TABLES `meta_details` WRITE;
/*!40000 ALTER TABLE `meta_details` DISABLE KEYS */;
INSERT INTO `meta_details` VALUES (1,0,0,'/','Dashboard1','Dashboard1','Dashboard1','Dashboard','mdi-view-dashboard',1,NULL,1,'N'),(2,0,0,'/users','Users','Users','Users','Users','mdi-account-box',104,NULL,1,'N'),(3,0,0,'/change-password','Change Password','Change Password','Change Password','Change Password','mdi mdi-server-security',105,NULL,1,'N'),(4,0,0,'/items?item_type=page','Pages','Pages','Pages','Pages','mdi-format-list-bulleted',3,NULL,1,'N'),(5,0,0,'/configurations','Configurations','Configurations Meta','Desc','Configurations','mdi-view-headline',109,NULL,1,'N'),(6,0,0,'/user_form','User Form','User Form','User Form','User Form',NULL,0,NULL,0,'N'),(7,0,0,'/item_section_form','Section Form','Section Form','Section Form','Section Form',NULL,0,NULL,0,'N'),(8,0,0,'/logout','Logout','Logout','Logout','Logout','mdi-logout-variant',201,NULL,1,'N'),(9,0,0,'/login','Login','Login','Login','Login',NULL,0,NULL,0,'N'),(10,0,0,'/metadetails','Meta Details','Meta Details','Meta Details','SEO','mdi-format-list-bulleted',108,NULL,1,'N'),(11,0,0,'/item_form','Item Form','Item Form','Item Form','Item Form',NULL,0,NULL,0,'N'),(12,0,0,'/forgot-password','Forgot Password','Forgot Password','Forgot Password','Forgot Password',NULL,0,NULL,0,'N'),(13,0,0,'/password-token','Password Token','Password Token','Password Token','Password Token',NULL,0,NULL,0,'N'),(14,0,0,'/reset-password','Reset Password','Reset Password','Reset Password','Reset Password',NULL,0,NULL,0,'N'),(15,0,0,'/roles','Roles','Roles','Roles','Roles','mdi mdi-account',103,NULL,1,'N'),(16,0,0,'/role_form','Role Form','Role Form','Role Form','Role Form',NULL,0,NULL,0,'N'),(17,0,0,'/item_form?item_type=blog','Blog Form','Blog Form','Blog Form',NULL,NULL,0,NULL,0,'N'),(18,0,0,'/item_form?item_type=page','Page Form','Page Form','Page Form',NULL,NULL,0,NULL,0,'N'),(19,0,0,'/item_section_form?item_type=default','Default Section Form','Default Section Form','Default Section Form',NULL,NULL,0,NULL,0,'N'),(20,0,0,'/item_section_form?item_type=blog','Blog Category Form','Blog Category Form','Blog Category Form',NULL,NULL,0,NULL,0,'N'),(21,0,0,'/items/default','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,'N'),(22,0,0,'/database_table','Database Tables','Database Tables','Database Tables','Database Tables','mdi mdi-view-headline',200,NULL,1,'N'),(23,0,0,'/item_section?item_type=blog','Blog Category','Blog Category','Blog Category','Blog Category','mdi mdi-view-headline',5,NULL,1,'N'),(24,0,0,'/items?item_type=blog','Blogs','Blogs','Blogs','Blogs','mdi-format-list-bulleted',5,NULL,1,'N'),(25,0,0,'/item_form?item_type=default','Default Form','Default Form','Default Form',NULL,NULL,0,NULL,0,'N'),(26,0,0,'/item_section?item_type=default','Default Section','Default Section','Default','Default Section','mdi mdi-view-headline',1,NULL,1,'N'),(27,0,0,'/items?item_type=default','Default Item','Default','Default','Default Items','mdi-format-list-bulleted',1,NULL,1,'N'),(28,0,52,'/template/mdiicons','Demonstration Company','Demonstration Company','Demonstration Company Description','MDI Icons','mdi mdi-view-headline',404,'ui-basic',1,'Y'),(29,0,52,'/template/formelement','Form Elements','Form Elements','Form Elements','Form Element','mdi mdi-view-headline',403,'ui-basic',1,'Y'),(30,0,52,'/template/gallery','Gallery','Gallery','Gallery','Gallery','mdi mdi-view-headline',402,'ui-basic',1,'Y'),(31,0,-1,'/template','Templates','Templates','Templates','Templates','ui-basic',401,NULL,1,'Y'),(32,0,0,'/items','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,'N'),(33,0,0,'/items?item_type=data','Data Details Update','Update','Update',NULL,NULL,0,NULL,0,'N'),(34,0,0,'/item_section_form?edit_id=18&item_type=default','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(35,0,0,'/item_section_form?edit_id=20&item_type=default','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(36,0,0,'/item_form?item_type=default&edit_id=14','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(37,0,0,'/role_form?item_type=role&edit_id=11','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(38,0,0,'/user_form?item_type=user&edit_id=28','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(39,0,0,'/item_section_form?edit_id=22&item_type=default','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(40,0,0,'/roles?item_type=role','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N'),(41,0,0,'/users?item_type=','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,'N');
/*!40000 ALTER TABLE `meta_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'role',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,0,'Developer','developer','role',1,'Y','Y','Y','N',0,'N',0,NULL,NULL,'2026-04-27 12:06:28','2026-04-27 12:06:28'),(2,0,'Super Admin','superadmin','role',1,'Y','Y','Y','N',0,'N',0,NULL,NULL,'2026-04-27 12:06:28','2026-04-27 12:06:28'),(3,0,'Admin','admin','role',1,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-04-27 12:06:28','2026-04-27 12:06:28'),(4,0,'HD','','role',0,'Y','Y','Y','Y',12,'N',0,NULL,NULL,'2026-05-01 17:27:45','2026-05-01 20:58:06'),(11,0,'HD22233211111','item_alias','role',0,'Y','Y','Y','Y',2,'N',0,NULL,NULL,'2026-05-02 13:55:29','2026-05-02 17:25:39');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_access`
--

DROP TABLE IF EXISTS `role_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_access` (
  `role_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_id` int(11) DEFAULT 0,
  `module_id` int(11) DEFAULT 0,
  `grant_add` varchar(1) NOT NULL DEFAULT 'N',
  `grant_edit` varchar(1) NOT NULL DEFAULT 'N',
  `grant_delete` varchar(1) NOT NULL DEFAULT 'N',
  `grant_view` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_access`
--

LOCK TABLES `role_access` WRITE;
/*!40000 ALTER TABLE `role_access` DISABLE KEYS */;
INSERT INTO `role_access` VALUES (1,0,1,1,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(2,0,1,2,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(3,0,1,3,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(4,0,1,4,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(5,0,1,5,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(6,0,1,8,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(7,0,1,10,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(8,0,1,15,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(9,0,1,22,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(10,0,1,23,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(11,0,1,24,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(12,0,1,26,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(13,0,1,27,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(14,0,1,28,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(15,0,1,29,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(16,0,1,30,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(17,0,1,31,'Y','Y','Y','Y',0,'Y','N','2026-04-27 12:06:28','2026-04-27 12:06:28'),(18,0,4,1,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(19,0,4,2,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(20,0,4,3,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(21,0,4,4,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(22,0,4,5,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(23,0,4,8,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(24,0,4,10,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(25,0,4,15,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(26,0,4,22,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(27,0,4,23,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(28,0,4,24,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(29,0,4,26,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(30,0,4,27,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(31,0,4,28,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(32,0,4,29,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(33,0,4,30,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(34,0,4,31,'N','N','N','Y',0,'Y','N','2026-05-01 17:28:06','2026-05-01 20:58:06'),(241,0,11,1,'Y','Y','Y','Y',0,'Y','N','2026-05-14 18:24:14','2026-05-14 21:54:14'),(242,0,11,2,'Y','Y','Y','Y',0,'Y','N','2026-05-14 18:24:14','2026-05-14 21:54:14');
/*!40000 ALTER TABLE `role_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `config_title` varchar(1024) DEFAULT NULL,
  `config_name` varchar(1024) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `input_type` varchar(15) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 100,
  `maxlength` int(11) NOT NULL DEFAULT 100,
  `input_type_title` varchar(100) DEFAULT NULL,
  `class` varchar(100) DEFAULT 'textbox',
  `required` varchar(1) DEFAULT 'O',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `comments` varchar(255) DEFAULT NULL,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `additional` varchar(100) DEFAULT NULL,
  `display_on_dashboard` varchar(1) NOT NULL DEFAULT 'N',
  `display_on_third_party` varchar(1) NOT NULL DEFAULT 'N',
  `site_config_parent_id` smallint(6) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `root_user_only` varchar(1) NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,0,'Application Title','FRONT_APPLICATION_TITLE','CMS','text',100,100,'Please enter your application name for display on frontend side as title','form-control','Y',1,NULL,'Y',NULL,'Y','Y',1,'N','N','2019-04-11 13:00:00','2026-01-30 09:34:40'),(2,0,'Records per page','FRONT_RECORD_PER_PAGE','16','select',100,60,'Records per page','form-control','Y',5,'8@=16@=24@=32@=40@=80','Y',NULL,'Y','Y',1,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(3,0,'Maintenance Mode','SITE_CONSTRUCTION','No','select',100,60,'Site Under Construction Status','form-control','Y',12,'Yes@=No','Y',NULL,'Y','N',1,'N','N','2019-04-11 13:00:00','2021-12-07 22:07:04'),(4,0,'Default Timezone','FRONT_DEFAULT_TIMEZONE','Asia/Kolkata','select',100,60,'Default Timezone','form-control','Y',13,'America/Chicago@=Asia/Kolkata@=Europe/London@=Australia/Perth','Y',NULL,'Y','Y',1,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(5,0,'Backend application Title','BACKEND_APPLICATION_TITLE','Cloudswift :: Administrator','text',100,60,'Application Title','form-control','Y',14,NULL,'Y',NULL,'Y','N',2,'N','N','2019-04-11 13:00:00','2019-10-14 07:08:57'),(6,0,'Meta Description','FRONT_META_DESCRIPTION','We are the leading Custom Software Solution Company in Vadodara, Gujarat, India who servered more then 50 Clients across World.\n','text',100,60,'Meta Description','form-control','Y',1,NULL,'Y',NULL,'N','N',1,'N','N','2019-04-11 13:00:00','2020-04-17 01:06:07'),(7,0,'Default Robots','FRONT_DEFAULT_ROBOTS','INDEX,FOLLOW','select',100,60,'Default Robots','form-control','Y',25,'INDEX,FOLLOW@=NOINDEX@=NOFOLLOW@=NOINDEX,NOFOLLOW','Y',NULL,'Y','Y',3,'N','N','2019-04-11 13:00:00','2019-10-17 08:06:12'),(8,0,'Company Name','COMPANY_NAME','Demonstration Project Pvt. Ltd.','text',100,60,'Company Name','form-control','Y',64,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-11-07 22:26:19'),(9,0,'Company Address','COMPANY_ADDRESS1','Sama, Near Chanikya crossing','text',100,60,'Company Address','form-control','Y',65,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(10,0,'Company Address 2','COMPANY_ADDRESS2','','text',100,60,'Company Address 2','form-control','Y',66,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-09-24 08:43:53'),(11,0,'City','COMPANY_CITY','Vadodara','text',100,60,'City','form-control','Y',67,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(12,0,'State','COMPANY_STATE','GJ','text',100,60,'State','form-control','Y',68,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(13,0,'Country','COMPANY_COUNTRY','INN','text',100,60,'Country','form-control','Y',69,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(14,0,'Zipcode','COMPANY_ZIPCODE','390009','text',100,60,'Zipcode','form-control','Y',70,'max six digits','Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(15,0,'Contact Number','COMPANY_CONTACT_NUMBER','886-630-3621','text',100,60,'Contact Number','form-control','Y',71,NULL,'Y',NULL,'N','Y',5,'N','N','2019-04-11 13:00:00','2020-04-13 11:50:21'),(16,0,'Contact us email address','COMPANY_EMAIL','connect@cloudswiftsolutions.com','email',100,60,'Contact us email address','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 13:00:00','2021-08-13 00:40:23'),(17,0,'Contact us person name','COMPANY_CONTACT_PERSON','Demonstration Project','text',100,60,'Contact us person name','form-control','Y',75,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 13:00:00','2021-08-13 01:15:54'),(18,0,'Allow Sending emails','ALLOW_SENDING_EMAIL','Yes','select',100,5,'Allow to send email throughout site? If no, not a single email will execute in this project.','form-control','Y',82,'Yes@=No','Y',NULL,'N','N',8,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(19,0,'Order email name','ORDER_CONTACT_PERSON','Cloud Swift Solutions','text',100,60,'order person name','form-control','Y',75,NULL,'Y',NULL,'N','N',8,'N','N','2019-04-11 13:00:00','2019-11-18 20:14:30'),(20,0,'From email address','FROM_EMAIL_ADDRESS','notifications@cloudswiftsolutions.com','email',100,60,'from email address','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 13:00:00','2021-06-21 21:54:54'),(21,0,'Backend Logo title display','BACKEND_LOGO_TITLE_DISPLAY','Administrator','text',100,60,'backend_logo_title_display','form-control','Y',8,'','Y',NULL,'N','Y',2,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(22,0,'Content to display before end of body tag','CONTENT_BEFORE_BODY_TAG','','textarea',100,6000,'Please enter content that will before close of body tag.','form-control','N',26,NULL,'Y',NULL,'N','Y',6,'N','N','2019-04-11 13:00:00','2019-09-24 09:24:46'),(23,0,'Script after begin head tag','AFTER_HEAD_TAG','','text',100,60,'After head tag javacript script','form-control','N',39,NULL,'Y',NULL,'N','Y',3,'N','N','2019-04-11 13:00:00','2019-09-24 08:43:53'),(24,0,'Application json script','APPLICATION_JSON_SCRIPT','','textarea',100,6000,'Application json script','form-control','N',26,NULL,'Y',NULL,'N','Y',3,'N','N','2019-04-11 13:00:00','2019-09-24 09:24:46'),(25,0,'Upload Max Size','UPLOAD_MAX_FILESIZE','2M','select',100,60,'Upload Max Size','form-control','Y',44,'2M@=8M@=16M@=24M','Y',NULL,'N','N',4,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(26,0,'Facebook','FACEBOOK_URL','https://www.facebook.com/cloudswiftsolutions/','text',100,60,'Please enter your facebook page url','form-control','N',40,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-10-14 07:58:52'),(27,0,'Twitter','TWITTER_URL','https://twitter.com/cloudswiftsolutions','text',100,60,'Please enter your twitter page url','form-control','N',40,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-10-14 07:59:00'),(28,0,'Linkedin','LINKEDIN_URL','https://www.linkedin.com/company/cloudswiftsolutions/','text',100,60,'Please enter your Linkedin page url','form-control','N',40,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-10-14 07:59:06'),(29,0,'Allow to sent email to admin for contact,feedback,etc.','ALLOW_CONTACT_EMAIL','Y','select',100,60,'Please select option','form-control','Y',5,'Y@=N','Y',NULL,'Y','N',8,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(30,0,'Application Name','FRONT_APPLICATION_NAME','Demonstration Project','text',100,100,'Please enter your application name for display on frontend side as name','form-control','Y',1,NULL,'Y',NULL,'Y','Y',1,'N','N','2019-04-11 18:30:00','2019-10-14 13:22:59'),(31,0,'Closed Store Status','CLOSED_STORE_STATUS','N','select',100,100,'This store is closed at present.','form-control','Y',1,'Y@=N','Y',NULL,'Y','Y',1,'N','N','2019-04-11 18:30:00','2021-08-02 10:54:46'),(32,0,'Closed Store Message','CLOSED_STORE_MESSAGE','Store is Under Construction','text',100,100,'Closed Store Message','form-control','Y',1,NULL,'Y',NULL,'Y','Y',1,'N','N','2019-04-11 18:30:00','2021-08-02 10:52:45'),(33,0,'BCC Email 1','BCC_EMAIL_1','bcc@yopmail.com','text',100,60,'BCC Email','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2026-01-29 15:39:46'),(34,0,'SMTP HOST','SMTP_HOST','smtp.hostinger.com','text',100,60,'SMTP HOST','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2021-08-13 06:20:26'),(35,0,'SMTP PORT','SMTP_PORT','587','text',100,60,'SMTP Port','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2023-09-16 22:32:56'),(36,0,'SMTP PASSWORD','SMTP_PASSWORD','Cloud@112018','email',100,60,'SMTP PASSWORD','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2021-08-13 06:20:26');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config_parent`
--

DROP TABLE IF EXISTS `site_config_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config_parent` (
  `site_config_parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `site_config_title` varchar(191) NOT NULL,
  `display_order` int(11) NOT NULL,
  `display_status` varchar(1) NOT NULL,
  `class` varchar(191) NOT NULL,
  `deleted_status` varchar(1) NOT NULL,
  `root_user_only` varchar(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`site_config_parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config_parent`
--

LOCK TABLES `site_config_parent` WRITE;
/*!40000 ALTER TABLE `site_config_parent` DISABLE KEYS */;
INSERT INTO `site_config_parent` VALUES (1,0,'Frontend Settings',1,'Y','collapseOne','N','N',NULL,NULL),(2,0,'Backend Settings',2,'Y','collapseTwo','N','N',NULL,NULL),(3,0,'SEO Settings',3,'Y','collapseThree','N','N',NULL,NULL),(4,0,'Security Settings',4,'Y','collapseFour','N','Y',NULL,NULL),(5,0,'Site Details',7,'Y','collapseSeven','N','N',NULL,NULL),(6,0,'Privacy Settings',9,'Y','collapseNine','N','Y',NULL,NULL),(7,0,'Follow Us',10,'Y','collapseTen','N','Y',NULL,NULL),(8,0,'Email Settings',8,'Y','collapseEight','N','N',NULL,NULL);
/*!40000 ALTER TABLE `site_config_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `site_db` varchar(255) DEFAULT NULL,
  `user_firstname` varchar(255) DEFAULT NULL,
  `user_lastname` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_token` varchar(255) DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  `user_role_id` smallint(6) NOT NULL DEFAULT 0,
  `is_developer_account` varchar(1) NOT NULL DEFAULT 'N',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `web_or_app` varchar(4) NOT NULL DEFAULT 'App',
  `active_status` varchar(25) NOT NULL DEFAULT 'N',
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `deleted_time` datetime DEFAULT NULL,
  `deleted_status` varchar(4) NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `add_1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'nodejsframework','Developer','Account','developer','developer112018@yopmail.com','11b0cbdf3e4d0c8377f4c18e200a140d','',NULL,1,'Y','N',0,NULL,0,'Web','Y','Y',NULL,'N','2026-04-27 12:06:28','2026-04-27 12:06:28',NULL),(2,1,'nodejsframework','Super','Admin','cloudswiftsolutions','cloudswiftsolutions@gmail.com','$2a$10$kJTPNZHNRH8L.YWfYLqsX.eZNpNRvzW/6ZnqD0nauEpxObP2kDw26',NULL,NULL,2,'N','N',0,NULL,0,'App','Y','Y',NULL,'N','2026-04-27 12:06:28','2026-04-27 12:06:28',NULL),(3,0,'asdfs@yopmaill.com','asdfs@yopmaill.com','asdfs@yopmaill.com',NULL,'asdfs@yopmaill.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:37:56','2026-05-02 12:09:30',NULL),(4,0,'asdf@yopmail.com','asdf@yopmail.com','asdf@yopmail.com',NULL,'asdf@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:40:09','2026-05-02 12:10:21',NULL),(5,0,'asdf@yopmail.com','asdf@yopmail.com','asdf@yopmail.com',NULL,'asdf@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:42:13','2026-05-02 12:12:21',NULL),(6,0,'ffsad','mayank','mayank',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:49:19','2026-05-02 12:55:39',NULL),(7,0,'ffsad','mayank','mayank',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:49:19','2026-05-02 13:00:34',NULL),(8,0,'ffsad','mayank','mayank',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:49:19','2026-05-02 13:01:33',NULL),(9,0,'ffsad','mayank','mayank',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 08:49:19','2026-05-02 13:04:53',NULL),(10,0,'mayankp@yopmail.com','mayankp@yopmail.com','mayankp@yopmail.com',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:36:08','2026-05-02 13:06:28',NULL),(11,0,'mayankp@yopmail.com','mayankp@yopmail.com','mayankp@yopmail.com',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:36:08','2026-05-02 13:11:42',NULL),(12,0,'mayankp@yopmail.com','mayankp@yopmail.com','mayankp@yopmail.com',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:36:08','2026-05-02 13:12:21',NULL),(13,0,'mayankp@yopmail.com','mayankp@yopmail.com','mayankp@yopmail.com',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:36:08','2026-05-02 13:13:19',NULL),(14,0,'mayankp@yopmail.com','mayankp@yopmail.com','mayankp@yopmail.com',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:36:08','2026-05-02 13:14:13',NULL),(15,0,'demon','demons','demons',NULL,'demons@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:49:21','2026-05-02 13:19:36',NULL),(16,0,'dbname12','demo1122','demo3322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 09:52:45','2026-05-02 13:23:04',NULL),(17,0,'dbname','demo1122','demo3322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:10:36',NULL),(18,0,'dbname','demo1122','demo3322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:12:18',NULL),(19,0,'dbname122233','demo11223344','demo3322322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:12:33',NULL),(20,0,'dbname12','demo1122','demo3322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:13:06',NULL),(21,0,'dbname122233','demo11223344','demo3322322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:14:00',NULL),(22,0,'dbname122233','demo11223344','demo3322322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:15:08',NULL),(23,0,'dbname122233','demo11223344','demo3322322',NULL,'demos2233@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 15:15:51',NULL),(24,0,'Demonstration','$dbname update','$dbname update',NULL,'dbnameupdate@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 13:42:06','2026-05-02 17:12:27',NULL),(25,0,'Demonstration','$dbname update 123','$dbname update 123',NULL,'dbnameupdate@yopmail.com',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 17:13:49',NULL),(26,0,'Demonstration','$dbname update 123','$dbname update 123',NULL,'dbnameupdate@yopmail.com12',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 17:14:23',NULL),(27,0,'Demonstration','dbname update 123','dbname update 123',NULL,'dbnameupdate@yopmail.com12',NULL,NULL,NULL,1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N',NULL,'2026-05-02 17:14:45',NULL),(28,0,'Demonstration','Mayank','Patel',NULL,'mayankppppp@yopmail.com',NULL,NULL,'1778777822_user_8239.png',1,'N','Y',0,NULL,0,'App','Y','Y',NULL,'N','2026-05-02 13:47:03','2026-05-02 17:17:12',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20 11:00:01
