-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: Demonstration
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `record_id` int(11) NOT NULL DEFAULT 0,
  `table_name` varchar(255) DEFAULT NULL,
  `record_name` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id_pk` int(11) DEFAULT 0,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `customer_pin` int(11) NOT NULL DEFAULT 0,
  `pos_customer` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `guest_customer` varchar(1) NOT NULL DEFAULT '0',
  `access_token` varchar(255) DEFAULT NULL,
  `security_question_id` int(11) NOT NULL DEFAULT 0,
  `security_answer` varchar(191) DEFAULT NULL,
  `user_address1` varchar(191) DEFAULT NULL,
  `user_address2` varchar(191) DEFAULT NULL,
  `user_city` varchar(191) DEFAULT NULL,
  `user_state` varchar(191) DEFAULT NULL,
  `user_zipcode` varchar(191) DEFAULT NULL,
  `user_country` varchar(191) DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `web_token` varchar(255) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `item_type` varchar(25) NOT NULL DEFAULT 'users',
  `wallet_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `blocked` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section`
--

DROP TABLE IF EXISTS `item_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section` (
  `item_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_section_parent_id` int(11) NOT NULL DEFAULT 0,
  `section_title` varchar(255) DEFAULT NULL,
  `section_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section`
--

LOCK TABLES `item_section` WRITE;
/*!40000 ALTER TABLE `item_section` DISABLE KEYS */;
INSERT INTO `item_section` VALUES (1,0,0,'Default Section 1','Default Section 1','default','Default Section 1','1779791806_isec_6630.png',0,'Default Section 1','Default Section 1',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:06:46'),(2,0,0,'Default Section 2','Default Section 2','default','Default Section 2',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:10:16'),(3,0,0,'Default Section 3','Default Section 3','default','Default Section 3',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:10:26'),(4,0,0,'Default Section 4','Default Section 4','default','Default Section 4','1779792039_isec_4052.png',0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:10:39'),(5,0,0,'Default Section 5','Default Section 5','default','Default Section 5','1779792053_isec_7540.png',0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:10:53'),(6,0,0,'Default section 6','Default section 6','default','Default section 6','1779795475_isec_6381.png',0,'Default section 6','Default section 6',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 17:07:55'),(7,0,0,'Default Section 7','default-section-7','default','Default Section 7','1779796211_isec_3952.png',0,'Default Section 7','Default Section 7',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:50:11','2026-05-26 17:20:11');
/*!40000 ALTER TABLE `item_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section_relation`
--

DROP TABLE IF EXISTS `item_section_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section_relation` (
  `item_section_relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_id` bigint(20) NOT NULL DEFAULT 0,
  `section_id` bigint(20) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section_relation`
--

LOCK TABLES `item_section_relation` WRITE;
/*!40000 ALTER TABLE `item_section_relation` DISABLE KEYS */;
INSERT INTO `item_section_relation` VALUES (1,0,10,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:48'),(2,0,10,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:48'),(3,0,10,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:48'),(4,0,10,4,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:48'),(5,0,10,5,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:48'),(6,0,11,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:30:19'),(7,0,11,4,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:30:19'),(12,0,12,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:06:06','2026-05-26 16:36:06'),(13,0,12,4,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:06:06','2026-05-26 16:36:06'),(14,0,13,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:10:45','2026-05-26 16:40:45'),(15,0,13,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:10:45','2026-05-26 16:40:45'),(16,0,14,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:16:56','2026-05-26 16:46:56'),(17,0,14,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:16:56','2026-05-26 16:46:56'),(18,0,14,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:16:56','2026-05-26 16:46:56'),(19,0,15,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:17:24','2026-05-26 16:47:24'),(20,0,15,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:17:24','2026-05-26 16:47:24'),(21,0,15,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:17:24','2026-05-26 16:47:24'),(22,0,16,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:18:28','2026-05-26 16:48:28'),(23,0,16,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:18:28','2026-05-26 16:48:28'),(24,0,16,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:18:28','2026-05-26 16:48:28'),(25,0,17,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:00','2026-05-26 16:49:00'),(26,0,17,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:00','2026-05-26 16:49:00'),(27,0,17,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:00','2026-05-26 16:49:00'),(28,0,18,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:28','2026-05-26 16:49:28'),(29,0,18,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:28','2026-05-26 16:49:28'),(30,0,18,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:28','2026-05-26 16:49:28'),(31,0,19,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:46','2026-05-26 16:49:46'),(32,0,19,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:46','2026-05-26 16:49:46'),(33,0,19,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:19:46','2026-05-26 16:49:46'),(34,0,20,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:20:13','2026-05-26 16:50:13'),(35,0,20,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:20:13','2026-05-26 16:50:13'),(36,0,20,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:20:13','2026-05-26 16:50:13'),(37,0,21,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:23:11','2026-05-26 16:53:11'),(38,0,21,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:23:11','2026-05-26 16:53:11'),(39,0,22,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:25:58','2026-05-26 16:55:58'),(40,0,22,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:25:58','2026-05-26 16:55:58'),(41,0,23,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:33:38','2026-05-26 17:03:38'),(42,0,23,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:33:38','2026-05-26 17:03:38'),(43,0,25,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:35:57','2026-05-26 17:05:57'),(44,0,25,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:35:57','2026-05-26 17:05:57'),(45,0,25,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:35:57','2026-05-26 17:05:57'),(46,0,26,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:50:40','2026-05-26 17:20:40'),(47,0,26,2,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:50:40','2026-05-26 17:20:40'),(48,0,26,3,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:50:40','2026-05-26 17:20:40');
/*!40000 ALTER TABLE `item_section_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_parent` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) DEFAULT NULL,
  `item_sections_id` varchar(255) DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `attachment2` varchar(255) DEFAULT NULL,
  `item_shortdescription` text DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT 'index',
  `published_at` date DEFAULT NULL,
  `published_end_at` date DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,0,'Home','home',100,'page','24','description update','attachment1-1758612676875.png','attachment2-1758612676877.png','short description update',3,'controller','action','2026-05-26','2026-05-26','meta title update','meta description update',1,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(2,0,'About Us','about-us',0,'page',NULL,'About Us',NULL,'','',1,'','','2026-05-26','2026-05-26','About Us','About Us',1,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(3,0,'Terms & Conditions','terms-and-conditions',0,'page',NULL,'Terms & Conditions',NULL,'','',1,'','','2026-05-26','2026-05-26','Terms & Conditions','Terms & Conditions',2,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(4,0,'Privacy Policy','privacy-policy',0,'page',NULL,'Privacy Policy',NULL,'','',1,'','','2026-05-26','2026-05-26','Privacy Policy','Privacy Policy',3,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(5,0,'Item 1','Item 1',0,'default','1','Item 1',NULL,NULL,'Item 1',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:11:13'),(6,0,'Item 2','Item 2',0,'default','1','Item 2',NULL,NULL,'Item 2',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:11:27'),(7,0,'Item 3','Item 3',0,'default','','Item 3',NULL,NULL,'Item 3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:12:18'),(8,0,'Item 3','Item 3-1779792620',0,'default','1,2,3,4,5','Item 3',NULL,NULL,'Item 3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:20:20'),(9,0,'Item 3','Item 3-1779792767',0,'default','1,2,3,4,5','Item 3',NULL,NULL,'Item 3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:22:47'),(10,0,'Item 3','Item 3-1779793188',0,'default','1,2,3,4,5','Item 3',NULL,NULL,'Item 3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:48'),(11,0,'Item 3 update','Item 3 update',0,'default','3,4','Item 3',NULL,NULL,'Item 3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:30:19'),(12,0,'Item 3 update1123','Item 3 update1',0,'default','3,4','Item 3',NULL,NULL,'Item 3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:31:06'),(13,0,'First','First',0,'default','1,2','Frst','1779793845_item1_5725.png',NULL,'first',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:40:45'),(14,0,'Seconddddddddddd','Seconddddddddddd',0,'default','1,2,3','Seconddddddddddd','1779794216_item1_4928.png','1779794216_item2_7789.png','Seconddddddddddd',0,NULL,'index','2026-05-26','2031-05-26','Seconddddddddddd','Seconddddddddddd',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:46:56'),(15,0,'Seconddddddddddd','Seconddddddddddd-1779794244',0,'default','1,2,3','Seconddddddddddd','1779794244_item1_1512.png','1779794244_item2_2361.png','Seconddddddddddd',0,NULL,'index','2026-05-26','2031-05-26','Seconddddddddddd','Seconddddddddddd',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:47:24'),(16,0,'rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr',0,'default','1,2,3','rrrrrrrrrrrrrrrr','1779794308_item1_5164.png','1779794308_item2_8700.png','rrrrrrrrrrrrrrrr',0,NULL,'index','2026-05-26','2031-05-26','rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:48:28'),(17,0,'rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr-1779794340',0,'default','1,2,3','rrrrrrrrrrrrrrrr','1779794340_item1_6393.png','1779794340_item2_7781.png','rrrrrrrrrrrrrrrr',0,NULL,'index','2026-05-26','2031-05-26','rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:49:00'),(18,0,'rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr-1779794368',0,'default','1,2,3','rrrrrrrrrrrrrrrr','1779794368_item1_7159.png','1779794368_item2_2508.png','rrrrrrrrrrrrrrrr',0,NULL,'index','2026-05-26','2031-05-26','rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:49:28'),(19,0,'rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr-1779794386',0,'default','1,2,3','rrrrrrrrrrrrrrrr','1779794386_item1_6891.png','1779794386_item2_3481.png','rrrrrrrrrrrrrrrr',0,NULL,'index','2026-05-26','2031-05-26','rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:49:46'),(20,0,'rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr-1779794413',0,'default','1,2,3','rrrrrrrrrrrrrrrr','1779794413_item1_7548.png','1779794413_item2_5000.png','rrrrrrrrrrrrrrrr',0,NULL,'index','2026-05-26','2031-05-26','rrrrrrrrrrrrrrrr','rrrrrrrrrrrrrrrr',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:50:13'),(21,0,'dddd','dddd',0,'default','2,3','12','1779794591_item1_8918.png',NULL,'32',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:53:11'),(22,0,'MMMMMM','MMMMMM',0,'default','1,2','MMMMMM','1779794758_item1_4108.png','1779794758_item2_2201.png','MMMMMM',0,NULL,'index','2026-05-26','2031-05-26','MMMMMM','MMMMMM',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:55:58'),(23,0,'LLLLLLL','LLLLLLL',0,'default','1,2','fsdf',NULL,NULL,'fas',0,NULL,'index','2026-05-26','2031-05-26','sdfs','',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 17:03:38'),(25,0,'TTTTTTTTTTTTT','TTTTTTTTTTTTT',0,'default','1,2,3','TTTTTTTTTTTTT',NULL,NULL,'TTTTTTTTTTTTT',0,NULL,'index','2026-05-26','2031-05-26','TTTTTTTTTTTTT','TTTTTTTTTTTTT',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:35:57','2026-05-26 17:05:57'),(26,0,'Item 1','item-1',0,'default','1,2,3','Item 1',NULL,NULL,'Item 1',0,NULL,'index','2026-05-26','2031-05-26','Item 1','Item 1',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 13:50:40','2026-05-26 17:20:40');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_details`
--

DROP TABLE IF EXISTS `meta_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_details` (
  `meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `end_points` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `sidebar_title` varchar(255) DEFAULT NULL,
  `sidebar_icon` varchar(255) DEFAULT NULL,
  `sidebar_order` int(11) NOT NULL DEFAULT 0,
  `params` varchar(255) DEFAULT NULL,
  `is_module` smallint(6) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_details`
--

LOCK TABLES `meta_details` WRITE;
/*!40000 ALTER TABLE `meta_details` DISABLE KEYS */;
INSERT INTO `meta_details` VALUES (1,0,0,'/','Dashboard','Dashboard','Dashboard','Dashboard','mdi-view-dashboard',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(2,0,0,'/users','Users','Users','Users','Users','mdi-account-box',104,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(3,0,0,'/change-password','Change Password','Change Password','Change Password','Change Password','mdi mdi-server-security',105,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(4,0,0,'/items?item_type=page','Pages','Pages','Pages','Pages','mdi-format-list-bulleted',3,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(5,0,0,'/configurations','Configurations','Configurations Meta','Desc','Configurations','mdi-view-headline',109,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(6,0,0,'/user_form','User Form','User Form','User Form','User Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(7,0,0,'/item_section_form','Section Form','Section Form','Section Form','Section Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(8,0,0,'/logout','Logout','Logout','Logout','Logout','mdi-logout-variant',201,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(9,0,0,'/login','Login','Login','Login','Login',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(10,0,0,'/metadetails','Meta Details','Meta Details','Meta Details','SEO','mdi-format-list-bulleted',108,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(11,0,0,'/item_form','Item Form','Item Form','Item Form','Item Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(12,0,0,'/forgot-password','Forgot Password','Forgot Password','Forgot Password','Forgot Password',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(13,0,0,'/password-token','Password Token','Password Token','Password Token','Password Token',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(14,0,0,'/reset-password','Reset Password','Reset Password','Reset Password','Reset Password',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(15,0,0,'/roles','Roles','Roles','Roles','Roles','mdi mdi-account',103,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(16,0,0,'/role_form','Role Form','Role Form','Role Form','Role Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(17,0,0,'/item_form?item_type=blog','Blog Form','Blog Form','Blog Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(18,0,0,'/item_form?item_type=page','Page Form','Page Form','Page Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(19,0,0,'/item_section_form?item_type=default','Default Section Form','Default Section Form','Default Section Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(20,0,0,'/item_section_form?item_type=blog','Blog Category Form','Blog Category Form','Blog Category Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(21,0,0,'/items/default','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(22,0,0,'/database_table','Database Tables','Database Tables','Database Tables','Database Tables','mdi mdi-view-headline',200,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(23,0,0,'/item_section?item_type=blog','Blog Category','Blog Category','Blog Category','Blog Category','mdi mdi-view-headline',5,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(24,0,0,'/items?item_type=blog','Blogs','Blogs','Blogs','Blogs','mdi-format-list-bulleted',5,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(25,0,0,'/item_form?item_type=default','Default Form','Default Form','Default Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(26,0,0,'/item_section?item_type=default','Default Section','Default Section','Default','Default Section','mdi mdi-view-headline',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(27,0,0,'/items?item_type=default','Default Item','Default','Default','Default Items','mdi-format-list-bulleted',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(28,0,52,'/template/mdiicons','Demonstration Company','Demonstration Company','Demonstration Company Description','MDI Icons','mdi mdi-view-headline',404,'ui-basic',1,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(29,0,52,'/template/formelement','Form Elements','Form Elements','Form Elements','Form Element','mdi mdi-view-headline',403,'ui-basic',1,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(30,0,52,'/template/gallery','Gallery','Gallery','Gallery','Gallery','mdi mdi-view-headline',402,'ui-basic',1,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(31,0,-1,'/template','Templates','Templates','Templates','Templates','ui-basic',401,NULL,1,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(32,0,0,'/items','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(33,0,0,'/item_form?item_type=default&edit_id=7','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:20:15'),(34,0,0,'/item_form?item_type=default&edit_id=8','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:21:44'),(35,0,0,'/item_form?item_type=default&edit_id=9','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:29:43'),(36,0,0,'/item_form?item_type=default&edit_id=10','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:30:08'),(37,0,0,'/item_form?item_type=default&edit_id=11','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:30:47'),(38,0,0,'/item_section_form?edit_id=5&item_type=default','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:31:33'),(39,0,0,'/item_form?item_type=default&edit_id=12','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 16:31:59');
/*!40000 ALTER TABLE `meta_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'role',
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,0,'Developer','developer','role','Y','Y','N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(2,0,'Super Admin','superadmin','role','Y','Y','N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(3,0,'Admin','admin','role','Y','Y','Y',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_access`
--

DROP TABLE IF EXISTS `role_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_access` (
  `role_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_id` int(11) DEFAULT 0,
  `module_id` int(11) DEFAULT 0,
  `grant_add` varchar(1) NOT NULL DEFAULT 'N',
  `grant_edit` varchar(1) NOT NULL DEFAULT 'N',
  `grant_delete` varchar(1) NOT NULL DEFAULT 'N',
  `grant_view` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_access`
--

LOCK TABLES `role_access` WRITE;
/*!40000 ALTER TABLE `role_access` DISABLE KEYS */;
INSERT INTO `role_access` VALUES (1,0,1,1,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(2,0,1,2,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(3,0,1,3,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(4,0,1,4,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(5,0,1,5,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(6,0,1,8,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(7,0,1,10,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(8,0,1,15,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(9,0,1,22,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(10,0,1,23,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(11,0,1,24,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(12,0,1,26,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(13,0,1,27,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(14,0,1,28,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(15,0,1,29,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(16,0,1,30,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18'),(17,0,1,31,'Y','Y','Y','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18');
/*!40000 ALTER TABLE `role_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `config_title` varchar(1024) DEFAULT NULL,
  `config_name` varchar(1024) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `input_type` varchar(15) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 100,
  `maxlength` int(11) NOT NULL DEFAULT 100,
  `input_type_title` varchar(100) DEFAULT NULL,
  `classname` varchar(100) DEFAULT 'textbox',
  `required` varchar(1) DEFAULT 'O',
  `comments` varchar(255) DEFAULT NULL,
  `additional` varchar(100) DEFAULT NULL,
  `display_on_dashboard` varchar(1) NOT NULL DEFAULT 'N',
  `display_on_third_party` varchar(1) NOT NULL DEFAULT 'N',
  `site_config_parent_id` smallint(6) NOT NULL DEFAULT 0,
  `root_user_only` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,0,'Application Title','FRONT_APPLICATION_TITLE','CMS123','text',100,100,'Please enter your application name for display on frontend side as title','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2026-01-30 09:34:40'),(2,0,'Records per page','FRONT_RECORD_PER_PAGE','16','select',100,60,'Records per page','form-control','Y','8@=16@=24@=32@=40@=80',NULL,'Y','Y',1,'N',5,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(3,0,'Maintenance Mode','SITE_CONSTRUCTION','No','select',100,60,'Site Under Construction Status','form-control','Y','Yes@=No',NULL,'Y','N',1,'N',12,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-12-07 22:07:04'),(4,0,'Default Timezone','FRONT_DEFAULT_TIMEZONE','Asia/Kolkata','select',100,60,'Default Timezone','form-control','Y','America/Chicago@=Asia/Kolkata@=Europe/London@=Australia/Perth',NULL,'Y','Y',1,'N',13,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(5,0,'Backend application Title','BACKEND_APPLICATION_TITLE','Cloudswift :: Administrator','text',100,60,'Application Title','form-control','Y',NULL,NULL,'Y','N',2,'N',14,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:08:57'),(6,0,'Meta Description','FRONT_META_DESCRIPTION','We are the leading Custom Software Solution Company in Vadodara, Gujarat, India who servered more then 50 Clients across World.','text',100,60,'Meta Description','form-control','Y',NULL,NULL,'N','N',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2020-04-17 01:06:07'),(7,0,'Default Robots','FRONT_DEFAULT_ROBOTS','INDEX,FOLLOW','select',100,60,'Default Robots','form-control','Y','INDEX,FOLLOW@=NOINDEX@=NOFOLLOW@=NOINDEX,NOFOLLOW',NULL,'Y','Y',3,'N',25,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-17 08:06:12'),(8,0,'Company Name','COMPANY_NAME','Demonstration Project Pvt. Ltd.','text',100,60,'Company Name','form-control','Y',NULL,NULL,'N','Y',5,'N',64,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-11-07 22:26:19'),(9,0,'Company Address','COMPANY_ADDRESS1','Sama, Near Chanikya crossing','text',100,60,'Company Address','form-control','Y',NULL,NULL,'N','Y',5,'N',65,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(10,0,'Company Address 2','COMPANY_ADDRESS2','','text',100,60,'Company Address 2','form-control','Y',NULL,NULL,'N','Y',5,'N',66,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 08:43:53'),(11,0,'City','COMPANY_CITY','Vadodara','text',100,60,'City','form-control','Y',NULL,NULL,'N','Y',5,'N',67,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(12,0,'State','COMPANY_STATE','GJ','text',100,60,'State','form-control','Y',NULL,NULL,'N','Y',5,'N',68,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(13,0,'Country','COMPANY_COUNTRY','INN','text',100,60,'Country','form-control','Y',NULL,NULL,'N','Y',5,'N',69,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(14,0,'Zipcode','COMPANY_ZIPCODE','390009','text',100,60,'Zipcode','form-control','Y','max six digits',NULL,'N','Y',5,'N',70,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(15,0,'Contact Number','COMPANY_CONTACT_NUMBER','886-630-3621','text',100,60,'Contact Number','form-control','Y',NULL,NULL,'N','Y',5,'N',71,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2020-04-13 11:50:21'),(16,0,'Contact us email address','COMPANY_EMAIL','connect@cloudswiftsolutions.com','email',100,60,'Contact us email address','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-08-13 00:40:23'),(17,0,'Contact us person name','COMPANY_CONTACT_PERSON','Demonstration Project','text',100,60,'Contact us person name','form-control','Y',NULL,NULL,'N','Y',8,'N',75,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-08-13 01:15:54'),(18,0,'Allow Sending emails','ALLOW_SENDING_EMAIL','Yes','select',100,5,'Allow to send email throughout site? If no, not a single email will execute in this project.','form-control','Y','Yes@=No',NULL,'N','N',8,'N',82,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(19,0,'Order email name','ORDER_CONTACT_PERSON','Cloud Swift Solutions','text',100,60,'order person name','form-control','Y',NULL,NULL,'N','N',8,'N',75,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-11-18 20:14:30'),(20,0,'From email address','FROM_EMAIL_ADDRESS','notifications@cloudswiftsolutions.com','email',100,60,'from email address','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-06-21 21:54:54'),(21,0,'Backend Logo title display','BACKEND_LOGO_TITLE_DISPLAY','Administrator','text',100,60,'backend_logo_title_display','form-control','Y','',NULL,'N','Y',2,'N',8,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(22,0,'Content to display before end of body tag','CONTENT_BEFORE_BODY_TAG','','textarea',100,6000,'Please enter content that will before close of body tag.','form-control','N',NULL,NULL,'N','Y',6,'N',26,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 09:24:46'),(23,0,'Script after begin head tag','AFTER_HEAD_TAG','','text',100,60,'After head tag javacript script','form-control','N',NULL,NULL,'N','Y',3,'N',39,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 08:43:53'),(24,0,'Application json script','APPLICATION_JSON_SCRIPT','','textarea',100,6000,'Application json script','form-control','N',NULL,NULL,'N','Y',3,'N',26,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 09:24:46'),(25,0,'Upload Max Size','UPLOAD_MAX_FILESIZE','2M','select',100,60,'Upload Max Size','form-control','Y','2M@=8M@=16M@=24M',NULL,'N','N',4,'N',44,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(26,0,'Facebook','FACEBOOK_URL','https://www.facebook.com/cloudswiftsolutions/','text',100,60,'Please enter your facebook page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:58:52'),(27,0,'Twitter','TWITTER_URL','https://twitter.com/cloudswiftsolutions','text',100,60,'Please enter your twitter page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:59:00'),(28,0,'Linkedin','LINKEDIN_URL','https://www.linkedin.com/company/cloudswiftsolutions/','text',100,60,'Please enter your Linkedin page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:59:06'),(29,0,'Allow to sent email to admin for contact,feedback,etc.','ALLOW_CONTACT_EMAIL','Y','select',100,60,'Please select option','form-control','Y','Y@=N',NULL,'Y','N',8,'N',5,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(30,0,'Application Name','FRONT_APPLICATION_NAME','Demonstration Project','text',100,100,'Please enter your application name for display on frontend side as name','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2019-10-14 13:22:59'),(31,0,'Closed Store Status','CLOSED_STORE_STATUS','N','select',100,100,'This store is closed at present.','form-control','Y','Y@=N',NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-02 10:54:46'),(32,0,'Closed Store Message','CLOSED_STORE_MESSAGE','Store is Under Construction','text',100,100,'Closed Store Message','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-02 10:52:45'),(33,0,'BCC Email 1','BCC_EMAIL_1','bcc@yopmail.com','email',100,60,'BCC Email','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2026-01-29 15:39:46'),(34,0,'SMTP HOST','SMTP_HOST','smtp.hostinger.com','text',100,60,'SMTP HOST','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-13 06:20:26'),(35,0,'SMTP PORT','SMTP_PORT','587','text',100,60,'SMTP Port','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2023-09-16 22:32:56'),(36,0,'SMTP PASSWORD','SMTP_PASSWORD','Cloud@112018','email',100,60,'SMTP PASSWORD','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-13 06:20:26');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config_parent`
--

DROP TABLE IF EXISTS `site_config_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config_parent` (
  `site_config_parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `site_config_title` varchar(191) NOT NULL,
  `classname` varchar(191) NOT NULL,
  `root_user_only` varchar(1) NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`site_config_parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config_parent`
--

LOCK TABLES `site_config_parent` WRITE;
/*!40000 ALTER TABLE `site_config_parent` DISABLE KEYS */;
INSERT INTO `site_config_parent` VALUES (1,0,'Frontend Settings','collapseOne','N',1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(2,0,'Backend Settings','collapseTwo','N',2,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(3,0,'SEO Settings','collapseThree','N',3,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(4,0,'Security Settings','collapseFour','Y',4,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(5,0,'Site Details','collapseSeven','N',7,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(6,0,'Privacy Settings','collapseNine','Y',9,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(7,0,'Follow Us','collapseTen','Y',10,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18'),(8,0,'Email Settings','collapseEight','N',8,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 15:57:18');
/*!40000 ALTER TABLE `site_config_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `site_db` varchar(255) DEFAULT NULL,
  `user_firstname` varchar(255) DEFAULT NULL,
  `user_lastname` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_token` varchar(255) DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  `user_role_id` smallint(6) NOT NULL DEFAULT 0,
  `is_developer_account` varchar(1) NOT NULL DEFAULT 'N',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `web_or_app` varchar(4) NOT NULL DEFAULT 'App',
  `active_status` varchar(25) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `add_1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'nodejsframework','Developer','Account','developer','developer112018@yopmail.com','$2a$10$UISTV//uhMD7OzURd9rxDOM5IrLAPAjVtb/saPfYqIjGCATQl7Tuq','',NULL,1,'Y','N','Web','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18',NULL),(2,1,'nodejsframework','Super','Admin','cloudswiftsolutions','cloudswiftsolutions@gmail.com','$2a$10$kJTPNZHNRH8L.YWfYLqsX.eZNpNRvzW/6ZnqD0nauEpxObP2kDw26',NULL,NULL,2,'N','N','App','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:27:18','2026-05-26 12:27:18',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-26 18:00:02
