-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emhLLi7twT
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AREA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text DEFAULT NULL,
  `MASTER` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint(20) DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'226','0','emhLLi7twT',226,'','','','2026-03-25 09:58:16','2026-03-25 09:58:16','','','','','','','','','2026-03-25 09:58:16','342','342','',0,'2026-03-25 09:58:16','2026-03-25 09:58:16');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (226,NULL,NULL,'0','25032026','2025-04-01','2026-03-31','25032026','','25032026','21','2503202625','','','','','','','','','','','','','','',NULL,'0',NULL,NULL,'27','','','25032026@yopmail.com','','250320',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-03-25 09:58:16','2026-03-25 10:01:29',NULL,'','','25032026','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `CREATED_TS` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `BATCH_ID` int(11) DEFAULT 0,
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DISP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `DELETED` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int(11) DEFAULT 0,
  `TAX_ID` int(11) DEFAULT 0,
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INV_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'226',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'226',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'226',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'226',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'226',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'226',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'226',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'226',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'226',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'226',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'226',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'226',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'226',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'226',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LEDGER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `MAC_ID` int(11) DEFAULT 0,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int(11) DEFAULT 0,
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int(11) DEFAULT 0,
  `ROOT_PARENT_ID` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-03-25 09:58:12','2026-03-25 09:58:12');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text DEFAULT NULL,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `SAC_ID` int(11) NOT NULL DEFAULT 0,
  `REMOTE_ID` int(11) NOT NULL DEFAULT 0,
  `PENDING_AMT` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `PROD_ID` int(11) NOT NULL DEFAULT 0,
  `PACK` int(11) NOT NULL DEFAULT 0,
  `PROD_BATCH_ID` int(11) NOT NULL DEFAULT 0,
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_RET_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_TOTAL` int(11) NOT NULL DEFAULT 0,
  `SALE_QTY` int(11) DEFAULT 0,
  `SALE_RET_QTY` int(11) DEFAULT 0,
  `SALE_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `SALE_TOTAL` int(11) NOT NULL DEFAULT 0,
  `OP_STOCK` int(11) NOT NULL DEFAULT 0,
  `CLOSING_STOCK` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=707 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'226',NULL,NULL,'001',NULL,'','ROASTED CHANA 25 GM 5/-','ROASTED CHANA 25 GM 5/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','504',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','504','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:07',NULL),(2,'226',NULL,NULL,'00110',NULL,'','MASALA PEANUT 25GM 5 /','MASALA PEANUT 25GM 5 /','21069099','1','2',NULL,'2','PAPL','7','7','504',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','504','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:08',NULL),(3,'226',NULL,NULL,'00111',NULL,'','NIMBU MASALA 25 GM 5/','NIMBU MASALA 25 GM 5/','21609099','1','2',NULL,'2','PAPL','7','7','360',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:09',NULL),(4,'226',NULL,NULL,'002',NULL,'','POPPITS 25GM 10/-','POPPITS 25GM 10/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:10',NULL),(5,'226',NULL,NULL,'003',NULL,'','CHANA CHOOR25GM  5/-','CHANA CHOOR25GM  5/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:10',NULL),(6,'226',NULL,NULL,'004',NULL,'','CHATPATA MATAR 25GM','CHATPATA MATAR 25GM','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:11',NULL),(7,'226',NULL,NULL,'005',NULL,'','CHATPATA MATAR 10/-','CHATPATA MATAR 10/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','384',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','384','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:12',NULL),(8,'226',NULL,NULL,'006',NULL,'','SPICY PEANUTS 25GM 5/-','SPICY PEANUTS 25GM 5/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:13',NULL),(9,'226',NULL,NULL,'0064',NULL,'','MAX PROTEIN 60','MAX PROTEIN 60','21069099','1','2',NULL,'2','PAPL','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:14',NULL),(10,'226',NULL,NULL,'0065',NULL,'','MAX PROTEIN 35MRP','MAX PROTEIN 35MRP','21069099','1','2',NULL,'2','PAPL','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:14',NULL),(11,'226',NULL,NULL,'0066',NULL,'','MAX PROTEIN 40MRP','MAX PROTEIN 40MRP','21069099','1','2',NULL,'2','PAPL','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:15',NULL),(12,'226',NULL,NULL,'0067',NULL,'','RAJWADI CHIWDA','RAJWADI CHIWDA','21069099','1','2',NULL,'2','PAPL','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:16',NULL),(13,'226',NULL,NULL,'0068',NULL,'','SOYA CHIPS','SOYA CHIPS','21069099','1','2',NULL,'2','PAPL','7','7','180',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:17',NULL),(14,'226',NULL,NULL,'0069',NULL,'','TEEKHA MITHA','TEEKHA MITHA','21069099','1','2',NULL,'2','PAPL','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:18',NULL),(15,'226',NULL,NULL,'007',NULL,'','H F CHILLI WAFER 5/-','H F CHILLI WAFER 5/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','160',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:19',NULL),(16,'226',NULL,NULL,'0071',NULL,'','MAX PROTEIN BAR','MAX PROTEIN BAR','21069099','1','2',NULL,'2','PAPL','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:20',NULL),(17,'226',NULL,NULL,'0072',NULL,'','MAX PROTEIN CHIPS','MAX PROTEIN CHIPS','21069099','1','2',NULL,'2','PAPL','7','7','80',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:21',NULL),(18,'226',NULL,NULL,'0074',NULL,'','MATKA JHATKA MRP10/-','MATKA JHATKA MRP10/-','04039010','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:22',NULL),(19,'226',NULL,NULL,'0075',NULL,'','KURMURA MIX','KURMURA MIX','21069099','1','2',NULL,'2','PAPL','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:23',NULL),(20,'226',NULL,NULL,'0076',NULL,'','HALDIRAM ALU SEV 10MRP','HALDIRAM ALU SEV 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','252',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','252','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:24',NULL),(21,'226',NULL,NULL,'0077',NULL,'','HALDIRAM CHATPATA DAL 10MRP','HALDIRAM CHATPATA DAL 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:25',NULL),(22,'226',NULL,NULL,'0078',NULL,'','HALDIRAM INSTANT BHEL10MRP','HALDIRAM INSTANT BHEL10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','204',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','204','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:26',NULL),(23,'226',NULL,NULL,'0079',NULL,'','HALDIRAM KHATTA MITHA 10MRP','HALDIRAM KHATTA MITHA 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:27',NULL),(24,'226',NULL,NULL,'008',NULL,'','H F TOMOTO WAFER 5/-','H F TOMOTO WAFER 5/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','160',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:29',NULL),(25,'226',NULL,NULL,'0080',NULL,'','HALDIRAM NAMKEEN PEANUT 10MRP','HALDIRAM NAMKEEN PEANUT 10MRP','20081100','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:30',NULL),(26,'226',NULL,NULL,'0081',NULL,'','PANCHRATAN MIX 10MRP','PANCHRATAN MIX 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:30',NULL),(27,'226',NULL,NULL,'0082',NULL,'','HALDIRAM SOYA STICK 10MRP','HALDIRAM SOYA STICK 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:31',NULL),(28,'226',NULL,NULL,'0083',NULL,'','HALDIRAM SEV MURMURA 10MRP','HALDIRAM SEV MURMURA 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:32',NULL),(29,'226',NULL,NULL,'0084',NULL,'','HALDIRAM TESTY NUT 10MRP','HALDIRAM TESTY NUT 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:33',NULL),(30,'226',NULL,NULL,'0085',NULL,'','HALDIRAM LEMON BHEL 10MRP','HALDIRAM LEMON BHEL 10MRP','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','216',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','216','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:34',NULL),(31,'226',NULL,NULL,'0086',NULL,'','HALDIRAM MIXTURE 10MRP','HALDIRAM MIXTURE 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:35',NULL),(32,'226',NULL,NULL,'0087',NULL,'','HALDIRAM NIMBOO MASALA 10MRP','HALDIRAM NIMBOO MASALA 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:36',NULL),(33,'226',NULL,NULL,'0088',NULL,'','YELLOW BANANA10MRP','YELLOW BANANA10MRP','20089999','1','2',NULL,'3','MOJO BAR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:37',NULL),(34,'226',NULL,NULL,'0089',NULL,'','BANANA BLACKPEPPER 10MRP','BANANA BLACKPEPPER 10MRP','20089999','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:38',NULL),(35,'226',NULL,NULL,'009',NULL,'','TAKA TAK TOMATO 5/-','TAKA TAK TOMATO 5/-','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:39',NULL),(36,'226',NULL,NULL,'0090',NULL,'','HALDIRAM BHUJIA SEV 10MRP','HALDIRAM BHUJIA SEV 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','264',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','264','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:40',NULL),(37,'226',NULL,NULL,'0091',NULL,'','HALDIRAM LITE CHIWDA 10MRP','HALDIRAM LITE CHIWDA 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:41',NULL),(38,'226',NULL,NULL,'0092',NULL,'','HALDIRAM MOONG DAL 10MRP','HALDIRAM MOONG DAL 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','336',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','336','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:42',NULL),(39,'226',NULL,NULL,'0093',NULL,'','HALDIRAM PHALHARI CHIWDA 10MRP','HALDIRAM PHALHARI CHIWDA 10MRP','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:43',NULL),(40,'226',NULL,NULL,'0094',NULL,'','HALDIRAM PUNJABI TADKA 10MRP','HALDIRAM PUNJABI TADKA 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','204',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','204','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:44',NULL),(41,'226',NULL,NULL,'0095',NULL,'','HALDIRAM RATLAMI SEV 10MRP','HALDIRAM RATLAMI SEV 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','228',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','228','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:45',NULL),(42,'226',NULL,NULL,'0096',NULL,'','SUPER TWIST 10MRP','SUPER TWIST 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','48',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:46',NULL),(43,'226',NULL,NULL,'0097',NULL,'','HALKE FULKE CHILLI 10MRP','HALKE FULKE CHILLI 10MRP','20052000','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:47',NULL),(44,'226',NULL,NULL,'0098',NULL,'','HALKE FULKE TANGY 10MRP','HALKE FULKE TANGY 10MRP','20052000','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:48',NULL),(45,'226',NULL,NULL,'0099',NULL,'','JAWARI SEV','JAWARI SEV','21069099','1','2',NULL,'2','PAPL','7','7','156',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','156','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:50',NULL),(46,'226',NULL,NULL,'01',NULL,'','SOYA CHIPS','SOYA CHIPS','21069099','1','2',NULL,'2','PAPL','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:51',NULL),(47,'226',NULL,NULL,'010',NULL,'','TAKA TAK MASALA 5/-','TAKA TAK MASALA 5/-','21069099','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:52',NULL),(48,'226',NULL,NULL,'0113',NULL,'','HALKE FULKE SALTED 10MRP','HALKE FULKE SALTED 10MRP','20052000','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:53',NULL),(49,'226',NULL,NULL,'0114',NULL,'','HALDIRAM NAVRATAN MIX 10MRP','HALDIRAM NAVRATAN MIX 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:54',NULL),(50,'226',NULL,NULL,'0115',NULL,'','HALDIRAM NAMKEEN','HALDIRAM NAMKEEN','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:55',NULL),(51,'226',NULL,NULL,'0123',NULL,'','HALDIRAM CHIKKI 10MRP','HALDIRAM CHIKKI 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','216',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','216','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:56',NULL),(52,'226',NULL,NULL,'0130',NULL,'','HALKE FULKE ONION CREAM 10MRP','HALKE FULKE ONION CREAM 10MRP','20052000','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:57',NULL),(53,'226',NULL,NULL,'0131',NULL,'','ALU SEV25GM 5/-','ALU SEV25GM 5/-','21069099','1','2',NULL,'3','MOJO BAR','7','7','384',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','384','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:58',NULL),(54,'226',NULL,NULL,'0132',NULL,'','BHUJIA SEV17GM','BHUJIA SEV17GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','480',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:02:59',NULL),(55,'226',NULL,NULL,'0133',NULL,'','KHATTA MITHA30GM','KHATTA MITHA30GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','336',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','336','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:00',NULL),(56,'226',NULL,NULL,'0134',NULL,'','MIXTURE25GM','MIXTURE25GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:01',NULL),(57,'226',NULL,NULL,'0135',NULL,'','MOONG DAL18GM','MOONG DAL18GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','576',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','576','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:02',NULL),(58,'226',NULL,NULL,'0136',NULL,'','PUNJABI TADKA22GM','PUNJABI TADKA22GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:03',NULL),(59,'226',NULL,NULL,'0137',NULL,'','SOYA STICK25GM','SOYA STICK25GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:04',NULL),(60,'226',NULL,NULL,'0138',NULL,'','SHENG BHAJIA22GM','SHENG BHAJIA22GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:05',NULL),(61,'226',NULL,NULL,'0148',NULL,'','ELAICHI TOAST 250GM','ELAICHI TOAST 250GM','19054000','1','2',NULL,'3','MOJO BAR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:06',NULL),(62,'226',NULL,NULL,'0157',NULL,'','YUMMY BITE 10MRP','YUMMY BITE 10MRP','21069099','1','2',NULL,'3','MOJO BAR','7','7','48',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:07',NULL),(63,'226',NULL,NULL,'0160',NULL,'','KHATTA MITHA175','KHATTA MITHA175','21069099','1','2',NULL,'3','MOJO BAR','7','7','80',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:08',NULL),(64,'226',NULL,NULL,'0161',NULL,'','MINI SAMOSA200GM','MINI SAMOSA200GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:09',NULL),(65,'226',NULL,NULL,'0162',NULL,'','ORANGE SOANPAPDI250G','ORANGE SOANPAPDI250G','21069099','1','2',NULL,'3','MOJO BAR','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:10',NULL),(66,'226',NULL,NULL,'0163',NULL,'','SOANPAPDI 250GM','SOANPAPDI 250GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:11',NULL),(67,'226',NULL,NULL,'0167',NULL,'','ROYAL DESIRE','ROYAL DESIRE','21069099','1','2',NULL,'3','MOJO BAR','7','7','9',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','9','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:12',NULL),(68,'226',NULL,NULL,'0168',NULL,'','ORANGE FRESH5KG','ORANGE FRESH5KG','33021010','1','2',NULL,'3','MOJO BAR','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:13',NULL),(69,'226',NULL,NULL,'0169',NULL,'','PUDINA CHUTTNEY 20KG','PUDINA CHUTTNEY 20KG','21039090','1','2',NULL,'3','MOJO BAR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:14',NULL),(70,'226',NULL,NULL,'0176',NULL,'','LITE CHIWDA25GM','LITE CHIWDA25GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','360',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:15',NULL),(71,'226',NULL,NULL,'0177',NULL,'','SEV MURMURA','SEV MURMURA','21069099','1','2',NULL,'3','MOJO BAR','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:16',NULL),(72,'226',NULL,NULL,'0178',NULL,'','ROYAL CELEBRATION 1550G','ROYAL CELEBRATION 1550G','21069099','1','2',NULL,'3','MOJO BAR','7','7','8',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:18',NULL),(73,'226',NULL,NULL,'0179',NULL,'','TULSI ORIGINAL','TULSI ORIGINAL','30049011','1','2',NULL,'3','MOJO BAR','7','7','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:18',NULL),(74,'226',NULL,NULL,'0180',NULL,'','SOYA CHIPS 25 GM','SOYA CHIPS 25 GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:19',NULL),(75,'226',NULL,NULL,'0182',NULL,'','LEMONE BHEL 27GM','LEMONE BHEL 27GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:20',NULL),(76,'226',NULL,NULL,'0184',NULL,'','BISLERI500ML','BISLERI500ML','2201','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:21',NULL),(77,'226',NULL,NULL,'0185',NULL,'','COOKICAKE','COOKICAKE','19059010','1','2',NULL,'1','HALDIRAM NAMKIN','7','7','56',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','56','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:22',NULL),(78,'226',NULL,NULL,'0186',NULL,'','MOVIECARDS','MOVIECARDS','999799','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:23',NULL),(79,'226',NULL,NULL,'0195',NULL,'','LEMON BHEL mrp 40','LEMON BHEL mrp 40','21069099','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:24',NULL),(80,'226',NULL,NULL,'0196',NULL,'','TANGY PICLE','TANGY PICLE','NULL','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:25',NULL),(81,'226',NULL,NULL,'0197',NULL,'','CHEESE JALAPENO','CHEESE JALAPENO','NULL','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:26',NULL),(82,'226',NULL,NULL,'0198',NULL,'','BARBEQUE','BARBEQUE','NULL','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:27',NULL),(83,'226',NULL,NULL,'0199',NULL,'','FIERY CHEESE','FIERY CHEESE','NULL','1','2',NULL,'3','MOJO BAR','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:28',NULL),(84,'226',NULL,NULL,'0200',NULL,'','PEPPY CHEESE','PEPPY CHEESE','NULL','1','2',NULL,'3','MOJO BAR','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:29',NULL),(85,'226',NULL,NULL,'0201',NULL,'','RATLAMI SEV','RATLAMI SEV','21069099','1','2',NULL,'3','MOJO BAR','7','7','360',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:30',NULL),(86,'226',NULL,NULL,'0202',NULL,'','NATURE VALLEY','NATURE VALLEY','19059090','1','2',NULL,'3','MOJO BAR','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:31',NULL),(87,'226',NULL,NULL,'0203',NULL,'','PASTRY CAKE','PASTRY CAKE','19059090','1','2',NULL,'3','MOJO BAR','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:32',NULL),(88,'226',NULL,NULL,'0204',NULL,'','GUJJU KHAKHRA','GUJJU KHAKHRA','NULL','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:33',NULL),(89,'226',NULL,NULL,'0205',NULL,'','GOODNESS YOGURT','GOODNESS YOGURT','4039090','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:34',NULL),(90,'226',NULL,NULL,'0206',NULL,'','GOODNESS COFFIATO','GOODNESS COFFIATO','4022990','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:35',NULL),(91,'226',NULL,NULL,'0207',NULL,'','CHEQUE BOUNCE CHARGE','CHEQUE BOUNCE CHARGE','NULL','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:36',NULL),(92,'226',NULL,NULL,'0208',NULL,'','YOGA PULP','YOGA PULP','22029020','1','2',NULL,'3','MOJO BAR','7','7','48',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:37',NULL),(93,'226',NULL,NULL,'0209',NULL,'','YOGA PULP 300ML','YOGA PULP 300ML','22029020','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:38',NULL),(94,'226',NULL,NULL,'0210',NULL,'','COOCKIECAKE MRP 5/-','COOCKIECAKE MRP 5/-','19059099','1','2',NULL,'3','MOJO BAR','7','7','576',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','576','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:39',NULL),(95,'226',NULL,NULL,'0211',NULL,'','MATKAJHATKA','MATKAJHATKA','04039010','1','2',NULL,'3','MOJO BAR','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:40',NULL),(96,'226',NULL,NULL,'0212',NULL,'','CLASSIC LASSI','CLASSIC LASSI','04039010','1','2',NULL,'3','MOJO BAR','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:41',NULL),(97,'226',NULL,NULL,'0213',NULL,'','PHALAHARI25GM','PHALAHARI25GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','360',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:42',NULL),(98,'226',NULL,NULL,'0214',NULL,'','HALDIRAM CHIPS','HALDIRAM CHIPS','21069099','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:43',NULL),(99,'226',NULL,NULL,'0215',NULL,'','REB LABEL TEA 500GM (BROOK BAND)','REB LABEL TEA 500GM (BROOK BAND)','21041010','1','2',NULL,'3','MOJO BAR','7','7','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:44',NULL),(100,'226',NULL,NULL,'0224',NULL,'','TAJ MAHAL TEA BAG2*100','TAJ MAHAL TEA BAG2*100','09023020','1','2',NULL,'3','MOJO BAR','7','7','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:45',NULL),(101,'226',NULL,NULL,'0225',NULL,'','BRU TRIPTI','BRU TRIPTI','21011120','1','2',NULL,'3','MOJO BAR','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:46',NULL),(102,'226',NULL,NULL,'0226',NULL,'','TAJ MAHAL LEMON','TAJ MAHAL LEMON','09023020','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:47',NULL),(103,'226',NULL,NULL,'0227',NULL,'','TAJ MAHAL GINGER','TAJ MAHAL GINGER','09023020','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:48',NULL),(104,'226',NULL,NULL,'0228',NULL,'','BADAM KESAR','BADAM KESAR','2202','1','2',NULL,'3','MOJO BAR','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:50',NULL),(105,'226',NULL,NULL,'0229',NULL,'','MANGO LASSI','MANGO LASSI','04039090','1','2',NULL,'3','MOJO BAR','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:51',NULL),(106,'226',NULL,NULL,'0230',NULL,'','KNORR SOUP SWEET CORN','KNORR SOUP SWEET CORN','21041010','1','2',NULL,'3','MOJO BAR','7','7','90',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:52',NULL),(107,'226',NULL,NULL,'0231',NULL,'','KNORR SOUPY NOODLE','KNORR SOUPY NOODLE','19023010','1','2',NULL,'3','MOJO BAR','7','7','96',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:53',NULL),(108,'226',NULL,NULL,'0232',NULL,'','LIPTON TEA BAG','LIPTON TEA BAG','09023020','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:54',NULL),(109,'226',NULL,NULL,'0233',NULL,'','TAAZA','TAAZA','09023020','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:55',NULL),(110,'226',NULL,NULL,'0234',NULL,'','BROWN & POLSON CORN','BROWN & POLSON CORN','11022000','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:56',NULL),(111,'226',NULL,NULL,'0235',NULL,'','BROWN & POLSON CUSTURD','BROWN & POLSON CUSTURD','210669080','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:57',NULL),(112,'226',NULL,NULL,'0236',NULL,'','KISSAN DOY PACK 1KG','KISSAN DOY PACK 1KG','21032000','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:58',NULL),(113,'226',NULL,NULL,'0237',NULL,'','KISSAN TOM 1KG','KISSAN TOM 1KG','21032000','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:03:59',NULL),(114,'226',NULL,NULL,'0238',NULL,'','KISSAN JAM 500GM','KISSAN JAM 500GM','20079990','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:00',NULL),(115,'226',NULL,NULL,'0239',NULL,'','CORNFLAKES MIX 30G','CORNFLAKES MIX 30G','20169099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:01',NULL),(116,'226',NULL,NULL,'0240',NULL,'','TAJ MAHAL MASALA*25','TAJ MAHAL MASALA*25','09023020','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:02',NULL),(117,'226',NULL,NULL,'0241',NULL,'','LIPTON GREEN TEA BAG*100','LIPTON GREEN TEA BAG*100','09023020','1','2',NULL,'3','MOJO BAR','7','7','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:03',NULL),(118,'226',NULL,NULL,'0242',NULL,'','LIPTON 100','LIPTON 100','09023020','1','2',NULL,'3','MOJO BAR','7','7','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:04',NULL),(119,'226',NULL,NULL,'0243',NULL,'','BROWNI','BROWNI','19059011','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:05',NULL),(120,'226',NULL,NULL,'0244',NULL,'','BRU MRP 1/-','BRU MRP 1/-','21011120','1','2',NULL,'3','MOJO BAR','7','7','1500',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1500','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:07',NULL),(121,'226',NULL,NULL,'0245',NULL,'','KISSAN SAUCE DIP 1KG','KISSAN SAUCE DIP 1KG','21032000','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:08',NULL),(122,'226',NULL,NULL,'0246',NULL,'','ALL IN ONE','ALL IN ONE','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:09',NULL),(123,'226',NULL,NULL,'0247',NULL,'','COCKTAIL MIX','COCKTAIL MIX','21069099','1','2',NULL,'3','MOJO BAR','7','7','276',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','276','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:10',NULL),(124,'226',NULL,NULL,'0248',NULL,'','CHANA CRACKER','CHANA CRACKER','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:11',NULL),(125,'226',NULL,NULL,'0249',NULL,'','ALOO LEHSUNIA','ALOO LEHSUNIA','21069099','1','2',NULL,'3','MOJO BAR','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:12',NULL),(126,'226',NULL,NULL,'0250',NULL,'','BRU GREEN LABEL500G','BRU GREEN LABEL500G','09019020','1','2',NULL,'3','MOJO BAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:13',NULL),(127,'226',NULL,NULL,'0251',NULL,'','BRU GREEN LABEL 200','BRU GREEN LABEL 200','09019020','1','2',NULL,'3','MOJO BAR','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:14',NULL),(128,'226',NULL,NULL,'0252',NULL,'','FATAFAT BHEL','FATAFAT BHEL','21069099','1','2',NULL,'3','MOJO BAR','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:15',NULL),(129,'226',NULL,NULL,'0253',NULL,'','BF MAYONNAISE 1KG','BF MAYONNAISE 1KG','21039030','1','2',NULL,'3','MOJO BAR','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:17',NULL),(130,'226',NULL,NULL,'0254',NULL,'','KACHORI POPS','KACHORI POPS','21069099','1','2',NULL,'3','MOJO BAR','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:18',NULL),(131,'226',NULL,NULL,'0255',NULL,'','CORNFLAKES CHIWDA 150G','CORNFLAKES CHIWDA 150G','21069099','1','2',NULL,'3','MOJO BAR','7','7','72',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:19',NULL),(132,'226',NULL,NULL,'0256',NULL,'','BHUJIA SEV 150G','BHUJIA SEV 150G','21069099','1','2',NULL,'3','MOJO BAR','7','7','72',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:20',NULL),(133,'226',NULL,NULL,'0257',NULL,'','RASSOGULLA 500GM','RASSOGULLA 500GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:21',NULL),(134,'226',NULL,NULL,'0258',NULL,'','TING RING','TING RING','19041090','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:22',NULL),(135,'226',NULL,NULL,'0259',NULL,'','AAM PANNA','AAM PANNA','2202','1','2',NULL,'3','MOJO BAR','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:23',NULL),(136,'226',NULL,NULL,'0260',NULL,'','JAL JIRA','JAL JIRA','2202','1','2',NULL,'3','MOJO BAR','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:24',NULL),(137,'226',NULL,NULL,'0261',NULL,'','KNORR TOMATO SOUP','KNORR TOMATO SOUP','21041010','1','2',NULL,'3','MOJO BAR','7','7','108',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:26',NULL),(138,'226',NULL,NULL,'0262',NULL,'','KNORR MIX VEG','KNORR MIX VEG','21041010','1','2',NULL,'3','MOJO BAR','7','7','108',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:27',NULL),(139,'226',NULL,NULL,'0263',NULL,'','MASALA MUTTER','MASALA MUTTER','21069099','1','2',NULL,'3','MOJO BAR','7','7','480',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:28',NULL),(140,'226',NULL,NULL,'0264',NULL,'','NIMBU MASALA','NIMBU MASALA','21069099','1','2',NULL,'3','MOJO BAR','7','7','360',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:29',NULL),(141,'226',NULL,NULL,'0265',NULL,'','PHALAHARI CHIWDA','PHALAHARI CHIWDA','21069099','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:30',NULL),(142,'226',NULL,NULL,'0266',NULL,'','SHENGCHANA','SHENGCHANA','21069099','1','2',NULL,'3','MOJO BAR','7','7','432',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:31',NULL),(143,'226',NULL,NULL,'0267',NULL,'','CORN STICKS','CORN STICKS','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:32',NULL),(144,'226',NULL,NULL,'0268',NULL,'','CHIKKI','CHIKKI','21069099','1','2',NULL,'3','MOJO BAR','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:34',NULL),(145,'226',NULL,NULL,'0269',NULL,'','LITE GATHIYA','LITE GATHIYA','21069099','1','2',NULL,'3','MOJO BAR','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:35',NULL),(146,'226',NULL,NULL,'0270',NULL,'','HALKE FULKE','HALKE FULKE','21069099','1','2',NULL,'3','MOJO BAR','7','7','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:36',NULL),(147,'226',NULL,NULL,'0271',NULL,'','POTATO LITE','POTATO LITE','21069099','1','2',NULL,'3','MOJO BAR','7','7','180',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:37',NULL),(148,'226',NULL,NULL,'0272',NULL,'','SUPER WHEELS','SUPER WHEELS','21069099','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:38',NULL),(149,'226',NULL,NULL,'0273',NULL,'','POTATO LITE35G','POTATO LITE35G','21069099','1','2',NULL,'3','MOJO BAR','7','7','110',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','110','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:39',NULL),(150,'226',NULL,NULL,'0274',NULL,'','NAMKEEN PEANUT','NAMKEEN PEANUT','20081100','1','2',NULL,'3','MOJO BAR','7','7','480',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:41',NULL),(151,'226',NULL,NULL,'0275',NULL,'','CHATPATA DAL','CHATPATA DAL','21069099','1','2',NULL,'3','MOJO BAR','7','7','504',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','504','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:42',NULL),(152,'226',NULL,NULL,'0276',NULL,'','HALDIRAM NAMKEEN','HALDIRAM NAMKEEN','21069099','1','2',NULL,'3','MOJO BAR','7','7','480',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:43',NULL),(153,'226',NULL,NULL,'0277',NULL,'','HALDIRAM KAJU','HALDIRAM KAJU','21069099','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:44',NULL),(154,'226',NULL,NULL,'0278',NULL,'','MASALA PEANUT','MASALA PEANUT','20081100','1','2',NULL,'3','MOJO BAR','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:45',NULL),(155,'226',NULL,NULL,'0279',NULL,'','LAHSUN SEV','LAHSUN SEV','20081100','1','2',NULL,'3','MOJO BAR','7','7','204',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','204','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:46',NULL),(156,'226',NULL,NULL,'0280',NULL,'','KURMURA','KURMURA','21069099','1','2',NULL,'3','MOJO BAR','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:48',NULL),(157,'226',NULL,NULL,'0281',NULL,'','KAJU','KAJU','20081910','1','2',NULL,'3','MOJO BAR','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:49',NULL),(158,'226',NULL,NULL,'0282',NULL,'','MUSTURD OIL SYNTHETIC','MUSTURD OIL SYNTHETIC','38241000','1','2',NULL,'3','MOJO BAR','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:50',NULL),(159,'226',NULL,NULL,'0283',NULL,'','SOANPAPDI250GM','SOANPAPDI250GM','21069099','1','2',NULL,'3','MOJO BAR','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:51',NULL),(160,'226',NULL,NULL,'0289',NULL,'','GULABJAMUN','GULABJAMUN','21069099','1','2',NULL,'2','PAPL','7','7','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:52',NULL),(161,'226',NULL,NULL,'1617776268383',NULL,'','RASSOGULLA 1KG','RASSOGULLA 1KG','21069099','1','2',NULL,'2','PAPL','7','7','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:53',NULL),(162,'226',NULL,NULL,'0291',NULL,'','YELLOW BANANA','YELLOW BANANA','21069099','1','2',NULL,'3','MOJO BAR','7','7','225',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','225','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:55',NULL),(163,'226',NULL,NULL,'0292',NULL,'','GULABJAMUN 500GM','GULABJAMUN 500GM','21069099','1','2',NULL,'2','PAPL','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:56',NULL),(164,'226',NULL,NULL,'0296',NULL,'','MULTIGRAIN CHIPS','MULTIGRAIN CHIPS','21069099','1','2',NULL,'2','PAPL','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:57',NULL),(165,'226',NULL,NULL,'0297',NULL,'','SOYA CHIPS','SOYA CHIPS','21069099','1','2',NULL,'2','PAPL','7','7','180',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:58',NULL),(166,'226',NULL,NULL,'0298',NULL,'','LAVA CAKE','LAVA CAKE','19059090','1','2',NULL,'2','PAPL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:04:59',NULL),(167,'226',NULL,NULL,'0300',NULL,'','BLUEBERRY','BLUEBERRY','19041000','1','2',NULL,'3','MOJO BAR','7','7','216',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','216','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:00',NULL),(168,'226',NULL,NULL,'0301',NULL,'','PEAN.UT BUTTER','PEAN.UT BUTTER','19041000','1','2',NULL,'3','MOJO BAR','7','7','216',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','216','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:02',NULL),(169,'226',NULL,NULL,'0302',NULL,'','STRAWBERRY','STRAWBERRY','19041000','1','2',NULL,'3','MOJO BAR','7','7','216',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','216','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:03',NULL),(170,'226',NULL,NULL,'0303',NULL,'','MIGHTY CHOCOLATE','MIGHTY CHOCOLATE','18061000','1','2',NULL,'3','MOJO BAR','7','7','216',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','216','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:04',NULL),(171,'226',NULL,NULL,'0311',NULL,'','TOMATO SEASOING','TOMATO SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:05',NULL),(172,'226',NULL,NULL,'0312',NULL,'','KURMURE SEASOING','KURMURE SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:06',NULL),(173,'226',NULL,NULL,'0313',NULL,'','MANCHURIAN SEASOING','MANCHURIAN SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:08',NULL),(174,'226',NULL,NULL,'0314',NULL,'','SHEZWAN SEASOING','SHEZWAN SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:09',NULL),(175,'226',NULL,NULL,'0315',NULL,'','MAGIC MASALA SEASOING','MAGIC MASALA SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:10',NULL),(176,'226',NULL,NULL,'0316',NULL,'','GREEN CHUTNEY','GREEN CHUTNEY','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:11',NULL),(177,'226',NULL,NULL,'0317',NULL,'','MAGGIE SEASOING','MAGGIE SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:13',NULL),(178,'226',NULL,NULL,'0318',NULL,'','MEXICAN SEASOING','MEXICAN SEASOING','21039090','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:14',NULL),(179,'226',NULL,NULL,'0430',NULL,'','LEX CREAM BISCUIT','LEX CREAM BISCUIT','19059020','1','2',NULL,'2','PAPL','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:15',NULL),(180,'226',NULL,NULL,'0431',NULL,'','AMERICAN DELIGHT','AMERICAN DELIGHT','22029990','1','2',NULL,'2','PAPL','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:16',NULL),(181,'226',NULL,NULL,'0432',NULL,'','COCONUT WATER','COCONUT WATER','22029990','1','2',NULL,'2','PAPL','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:18',NULL),(182,'226',NULL,NULL,'0433',NULL,'','DOLPHIN','DOLPHIN','22029990','1','2',NULL,'2','PAPL','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:19',NULL),(183,'226',NULL,NULL,'0434',NULL,'','UNIBIC CHOCOLATE','UNIBIC CHOCOLATE','21069099','1','2',NULL,'2','PAPL','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:20',NULL),(184,'226',NULL,NULL,'0439',NULL,'','RITEBITE CHOCO DELIGHT','RITEBITE CHOCO DELIGHT','21069099','1','2',NULL,'2','PAPL','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:21',NULL),(185,'226',NULL,NULL,'0440',NULL,'','RITEBITE YOGURT BERRY','RITEBITE YOGURT BERRY','21069099','1','2',NULL,'2','PAPL','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:22',NULL),(186,'226',NULL,NULL,'600',NULL,'','RINE BAR','RINE BAR','19041000','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:24',NULL),(187,'226',NULL,NULL,'601',NULL,'','RINE BAR CHOCOLATE','RINE BAR CHOCOLATE','NULL','1','2',NULL,'3','MOJO BAR','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:25',NULL),(188,'226',NULL,NULL,'0501',NULL,'','CHARMINAR SELECT 1KG','CHARMINAR SELECT 1KG','10062000','1','3',NULL,'4','KOHINOOR','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:26',NULL),(189,'226',NULL,NULL,'0502',NULL,'','CHARMINAR SELECT 5KG','CHARMINAR SELECT 5KG','10062000','5','3',NULL,'4','KOHINOOR','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:27',NULL),(190,'226',NULL,NULL,'0503',NULL,'','SUPERVALUE 1KG','SUPERVALUE 1KG','10063020','1','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:29',NULL),(191,'226',NULL,NULL,'0504',NULL,'','SUPERVALUE 5KG','SUPERVALUE 5KG','10063020','5','3',NULL,'4','KOHINOOR','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:30',NULL),(192,'226',NULL,NULL,'0505',NULL,'','GOLD 5KG','GOLD 5KG','10063020','5','3',NULL,'4','KOHINOOR','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:31',NULL),(193,'226',NULL,NULL,'0506',NULL,'','KOHINOOR TRADITIONAL 5KG','KOHINOOR TRADITIONAL 5KG','10063020','5','3',NULL,'4','KOHINOOR','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:32',NULL),(194,'226',NULL,NULL,'0507',NULL,'','KOHINOOR TIBAR 1KG','KOHINOOR TIBAR 1KG','10063020','1','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:33',NULL),(195,'226',NULL,NULL,'0508',NULL,'','KOHINOOR TIBAR 5KG','KOHINOOR TIBAR 5KG','10063020','5','3',NULL,'4','KOHINOOR','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:34',NULL),(196,'226',NULL,NULL,'0509',NULL,'','GOLD 1KG','GOLD 1KG','10063020','1','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:36',NULL),(197,'226',NULL,NULL,'0510',NULL,'','TRADITIONAL 1KG','TRADITIONAL 1KG','10063020','1','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:37',NULL),(198,'226',NULL,NULL,'0511',NULL,'','EASY2COOK BROWN','EASY2COOK BROWN','10062000','NULL','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:38',NULL),(199,'226',NULL,NULL,'0512',NULL,'','KOHINOOR ROYAL','KOHINOOR ROYAL','10063020','NULL','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:39',NULL),(200,'226',NULL,NULL,'0513',NULL,'','HYDERABADI MASALA','HYDERABADI MASALA','99009886','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:40',NULL),(201,'226',NULL,NULL,'0514',NULL,'','ROZANA 1KG','ROZANA 1KG','10063020','NULL','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:42',NULL),(202,'226',NULL,NULL,'0515',NULL,'','CHARMINAR BROWN 1KG','CHARMINAR BROWN 1KG','10063020','NULL','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:43',NULL),(203,'226',NULL,NULL,'0601',NULL,'','LIFEBUOY HS','LIFEBUOY HS','38089400','NULL','3',NULL,'5','HUL','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:44',NULL),(204,'226',NULL,NULL,'0602',NULL,'','DOMEX DI','DOMEX DI','38089400','NULL','3',NULL,'5','HUL','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:45',NULL),(205,'226',NULL,NULL,'0603',NULL,'','LIFEBUOY HW','LIFEBUOY HW','34013019','NULL','3',NULL,'5','HUL','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:47',NULL),(206,'226',NULL,NULL,'0516',NULL,'','BROWN','BROWN','10062000','NULL','3',NULL,'4','KOHINOOR','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:48',NULL),(207,'226',NULL,NULL,'0604',NULL,'','HANDWASH 85/-','HANDWASH 85/-','34013019','NULL','3',NULL,'5','HUL','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:49',NULL),(208,'226',NULL,NULL,'0701',NULL,'','FROOTI 160ML','FROOTI 160ML','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:51',NULL),(209,'226',NULL,NULL,'0702',NULL,'','APPY 160ML','APPY 160ML','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:52',NULL),(210,'226',NULL,NULL,'0703',NULL,'','FROOTI 300ML','FROOTI 300ML','22019920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:53',NULL),(211,'226',NULL,NULL,'0704',NULL,'','FROOTI 600ML','FROOTI 600ML','22019920','NULL','3',NULL,'6','PARLE AGRO','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:54',NULL),(212,'226',NULL,NULL,'0705',NULL,'','FROOTI 200ML','FROOTI 200ML','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:56',NULL),(213,'226',NULL,NULL,'0605',NULL,'','HAND SANITIZER','HAND SANITIZER','38089400','NULL','3',NULL,'5','HUL','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:57',NULL),(214,'226',NULL,NULL,'0706',NULL,'','DHISHOOM','DHISHOOM','38089400','NULL','3',NULL,'6','PARLE AGRO','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:05:58',NULL),(215,'226',NULL,NULL,'0517',NULL,'','KOHINOOR MASALA 20/-','KOHINOOR MASALA 20/-','99009886','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:00',NULL),(216,'226',NULL,NULL,'0518',NULL,'','JAMMU RAJMA MASALA','JAMMU RAJMA MASALA','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:01',NULL),(217,'226',NULL,NULL,'0519',NULL,'','KASHMIRI MEAT MASALA','KASHMIRI MEAT MASALA','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:02',NULL),(218,'226',NULL,NULL,'0520',NULL,'','TANDOORI CHICKEN MASALA','TANDOORI CHICKEN MASALA','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:03',NULL),(219,'226',NULL,NULL,'0521',NULL,'','DILLI CHOLEY','DILLI CHOLEY','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:05',NULL),(220,'226',NULL,NULL,'0522',NULL,'','PUNJABI BUTTER CHICKEN','PUNJABI BUTTER CHICKEN','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:06',NULL),(221,'226',NULL,NULL,'0523',NULL,'','MUMBAI PAV BHAJI','MUMBAI PAV BHAJI','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:07',NULL),(222,'226',NULL,NULL,'0524',NULL,'','PUNJABI PANEER','PUNJABI PANEER','09109100','NULL','3',NULL,'4','KOHINOOR','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:09',NULL),(223,'226',NULL,NULL,'0606',NULL,'','SAUCE DIP POUCH','SAUCE DIP POUCH','21032000','NULL','3',NULL,'5','HUL','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:10',NULL),(224,'226',NULL,NULL,'0707',NULL,'','APPY FIZZ 160','APPY FIZZ 160','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:11',NULL),(225,'226',NULL,NULL,'708',NULL,'','FM TCA 65 ML','FM TCA 65 ML','22029920','NULL','3',NULL,'2','PAPL','7','7','64',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:12',NULL),(226,'226',NULL,NULL,'0710',NULL,'','OTHER SERVICES (BUSINESS SUPPORT)','OTHER SERVICES (BUSINESS SUPPORT)','999799','NULL','3',NULL,'2','PAPL','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:14',NULL),(227,'226',NULL,NULL,'0100',NULL,'','TAKA TAK','TAKA TAK','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:15',NULL),(228,'226',NULL,NULL,'0608',NULL,'','KISAN TOM 1KG','KISAN TOM 1KG','21032000','NULL','3',NULL,'5','HUL','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:16',NULL),(229,'226',NULL,NULL,'0609',NULL,'','KISAN TOM 500G','KISAN TOM 500G','21032000','NULL','3',NULL,'5','HUL','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:18',NULL),(230,'226',NULL,NULL,'0709',NULL,'','APPY FIZZ250ML','APPY FIZZ250ML','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:19',NULL),(231,'226',NULL,NULL,'0711',NULL,'','APPY FIZZ CAN','APPY FIZZ CAN','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:20',NULL),(232,'226',NULL,NULL,'0607',NULL,'','sanitizer 500ml','sanitizer 500ml','38089400','NULL','3',NULL,'5','HUL','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:22',NULL),(233,'226',NULL,NULL,'0712',NULL,'','B FIZZ 160ML','B FIZZ 160ML','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:23',NULL),(234,'226',NULL,NULL,'0610',NULL,'','HAND SANITIZER 50ML','HAND SANITIZER 50ML','38089400','NULL','3',NULL,'5','HUL','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:24',NULL),(235,'226',NULL,NULL,'0611',NULL,'','HAND SANITIZER 150ML','HAND SANITIZER 150ML','38089400','NULL','3',NULL,'5','HUL','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:26',NULL),(236,'226',NULL,NULL,'0801',NULL,'','PEANUTS 40/-','PEANUTS 40/-','2008','NULL','3',NULL,'4','KOHINOOR','7','7','76',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','76','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:27',NULL),(237,'226',NULL,NULL,'0802',NULL,'','NACHOS 35/-','NACHOS 35/-','2106','NULL','3',NULL,'4','KOHINOOR','7','7','42',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','42','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:28',NULL),(238,'226',NULL,NULL,'0803',NULL,'','NACHOS 20/-','NACHOS 20/-','2106','NULL','3',NULL,'4','KOHINOOR','7','7','72',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:30',NULL),(239,'226',NULL,NULL,'0804',NULL,'','KHAKHRO 20/-','KHAKHRO 20/-','2106','NULL','3',NULL,'4','KOHINOOR','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:31',NULL),(240,'226',NULL,NULL,'0805',NULL,'','PEANUT 10/-','PEANUT 10/-','2008','NULL','3',NULL,'4','KOHINOOR','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:32',NULL),(241,'226',NULL,NULL,'0806',NULL,'','FOXNUT 99/-','FOXNUT 99/-','2008','NULL','3',NULL,'4','KOHINOOR','7','7','35',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','35','0','0','0','KOHINOOR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:34',NULL),(242,'226',NULL,NULL,'300',NULL,'','Appy Classic 200ml * 30pec','Appy Classic 200ml * 30pec','22029920','NULL','3',NULL,'2','PAPL','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:35',NULL),(243,'226',NULL,NULL,'1001',NULL,'','BF CN 250ML CC 30PEC','BF CN 250ML CC 30PEC','22029920','NULL','3',NULL,'2','PAPL','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:36',NULL),(244,'226',NULL,NULL,'1002',NULL,'','AF CN LIGHT 250ML CC 30','AF CN LIGHT 250ML CC 30','22029920','NULL','3',NULL,'2','PAPL','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:38',NULL),(245,'226',NULL,NULL,'1003',NULL,'','FM PET 500ML CC 24','FM PET 500ML CC 24','22029920','NULL','3',NULL,'2','PAPL','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:39',NULL),(246,'226',NULL,NULL,'1607319879707',NULL,'','B Fizz250ml','B Fizz250ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:40',NULL),(247,'226',NULL,NULL,'1004',NULL,'','B Fizz250ml','B Fizz250ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:43',NULL),(248,'226',NULL,NULL,'1005',NULL,'','Crazy Nuts 20gm','Crazy Nuts 20gm','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','480',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:44',NULL),(249,'226',NULL,NULL,'1006',NULL,'','Jarsesamechikkibar','Jarsesamechikkibar','17049090','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:48',NULL),(250,'226',NULL,NULL,'FM 2 LT * 6  MRP 99',NULL,'','FM 2 LT * 6  MRP 100','FM 2 LT * 6  MRP 100','22029920','NULL','3',NULL,'2','PAPL','7','7','6',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:50',NULL),(251,'226',NULL,NULL,'1007',NULL,'','Fm Pt250mlmrp 30','Fm Pt250mlmrp 30','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:51',NULL),(252,'226',NULL,NULL,'1008',NULL,'','Frooti Tp 150ml','Frooti Tp 150ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:52',NULL),(253,'226',NULL,NULL,'1009',NULL,'','Lite Cornflaskes 50gm','Lite Cornflaskes 50gm','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:54',NULL),(254,'226',NULL,NULL,'1010',NULL,'','Ap Pt 600ml','Ap Pt 600ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:55',NULL),(255,'226',NULL,NULL,'1012',NULL,'','Monaco 92gm','Monaco 92gm','19053100','NULL','3',NULL,'6','PARLE AGRO','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:56',NULL),(256,'226',NULL,NULL,'1013',NULL,'','Bourbon 60gm','Bourbon 60gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','140',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','140','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:58',NULL),(257,'226',NULL,NULL,'1014',NULL,'','Jam In 66gm','Jam In 66gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:06:59',NULL),(258,'226',NULL,NULL,'1015',NULL,'','Marie 90gm','Marie 90gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:00',NULL),(259,'226',NULL,NULL,'1016',NULL,'','H &S Choclate 33gm','H &S Choclate 33gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:02',NULL),(260,'226',NULL,NULL,'1017',NULL,'','Parle G 70gm','Parle G 70gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:03',NULL),(261,'226',NULL,NULL,'1018',NULL,'','Monaco 37gm','Monaco 37gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','120',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:05',NULL),(262,'226',NULL,NULL,'1011',NULL,'','Krackjack 75gm','Krackjack 75gm','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:06',NULL),(263,'226',NULL,NULL,'1020',NULL,'','Idacol Sunset Yellow','Idacol Sunset Yellow','32041981','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:07',NULL),(264,'226',NULL,NULL,'1021',NULL,'','Idacol Tartrazine 25kg','Idacol Tartrazine 25kg','32041982','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:09',NULL),(265,'226',NULL,NULL,'1022',NULL,'','Natracol Titanium Deoxide25kg','Natracol Titanium Deoxide25kg','28230010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:10',NULL),(266,'226',NULL,NULL,'1023',NULL,'','COCOA POWDER (25KGS)','COCOA POWDER (25KGS)','18050000','NULL','3',NULL,'7','FOOD PRODUCT','9','9','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:12',NULL),(267,'226',NULL,NULL,'1024',NULL,'','Ap Pt 1000ml','Ap Pt 1000ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:13',NULL),(268,'226',NULL,NULL,'1612602868207',NULL,'','FREE SAMPLE','FREE SAMPLE','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:14',NULL),(269,'226',NULL,NULL,'1025',NULL,'','BF PT 600ML','BF PT 600ML','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:16',NULL),(270,'226',NULL,NULL,'1026',NULL,'','Ap Pt 500ml','Ap Pt 500ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:17',NULL),(271,'226',NULL,NULL,'1617444188144',NULL,'','AVON MIST','AVON MIST','33021010','NULL','3',NULL,'7','FOOD PRODUCT','9','9','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:20',NULL),(272,'226',NULL,NULL,'0290',NULL,'','RASGULLA 1KG','RASGULLA 1KG','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:23',NULL),(273,'226',NULL,NULL,'1618458568058',NULL,'','RASSOGULLA 4 KG','RASSOGULLA 4 KG','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:24',NULL),(274,'226',NULL,NULL,'1027',NULL,'','RASSOGULLA 4 KG','RASSOGULLA 4 KG','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:26',NULL),(275,'226',NULL,NULL,'1028',NULL,'','KRACKJACK CLASSIC SWEET SALTY','KRACKJACK CLASSIC SWEET SALTY','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:27',NULL),(276,'226',NULL,NULL,'1029',NULL,'','SCM TP 85 ML CLUSTER PK','SCM TP 85 ML CLUSTER PK','22029930','NULL','3',NULL,'6','PARLE AGRO','7','7','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:28',NULL),(277,'226',NULL,NULL,'1030',NULL,'','STCM TP 85 ML CLUSTER PK','STCM TP 85 ML CLUSTER PK','22029930','NULL','3',NULL,'6','PARLE AGRO','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:30',NULL),(278,'226',NULL,NULL,'1031',NULL,'','PARLE RUSK ELAICHI','PARLE RUSK ELAICHI','19054000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:31',NULL),(279,'226',NULL,NULL,'1032',NULL,'','TOP CLASSIC BUTERY','TOP CLASSIC BUTERY','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:33',NULL),(280,'226',NULL,NULL,'1033',NULL,'','HAPPY HAPPY CLASSIC CHOCLATE','HAPPY HAPPY CLASSIC CHOCLATE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:34',NULL),(281,'226',NULL,NULL,'1034',NULL,'','MILK SHAKTI CLSSIC','MILK SHAKTI CLSSIC','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:35',NULL),(282,'226',NULL,NULL,'1035',NULL,'','PARLE COCONUT CLASSIC','PARLE COCONUT CLASSIC','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:37',NULL),(283,'226',NULL,NULL,'1036',NULL,'','PARLE 120 GM','PARLE 120 GM','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:38',NULL),(284,'226',NULL,NULL,'1037',NULL,'','PARLE G 250GM','PARLE G 250GM','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:40',NULL),(285,'226',NULL,NULL,'1038',NULL,'','PARLE G 800GM','PARLE G 800GM','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','14',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','14','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:41',NULL),(286,'226',NULL,NULL,'1039',NULL,'','PARLE TWENTY TWENTY BATER 40GM','PARLE TWENTY TWENTY BATER 40GM','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:43',NULL),(287,'226',NULL,NULL,'1040',NULL,'','PARLE TWENTY TWENTY KESW NUT 40GM','PARLE TWENTY TWENTY KESW NUT 40GM','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:44',NULL),(288,'226',NULL,NULL,'1041',NULL,'','GINGER ALE CN 250ML','GINGER ALE CN 250ML','22021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'5','5','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:45',NULL),(289,'226',NULL,NULL,'1042',NULL,'','TONIC WATER CN 250ML','TONIC WATER CN 250ML','22021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'5','5','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:47',NULL),(290,'226',NULL,NULL,'01043',NULL,'','HIDE AND SEEK','HIDE AND SEEK','19059020','NULL','1',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:48',NULL),(291,'226',NULL,NULL,'1044',NULL,'','Masala Moong Dal 17gm','Masala Moong Dal 17gm','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','540',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','540','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:50',NULL),(292,'226',NULL,NULL,'0751',NULL,'','HAND SANITIZER 250ML','HAND SANITIZER 250ML','38089400','NULL','3',NULL,'5','HUL','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:51',NULL),(293,'226',NULL,NULL,'1045',NULL,'','FM PET 1200ML','FM PET 1200ML','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:52',NULL),(294,'226',NULL,NULL,'1046',NULL,'','Chana Jor Garam 40 Gm','Chana Jor Garam 40 Gm','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:54',NULL),(295,'226',NULL,NULL,'1047',NULL,'','LB MAGIC SEASONING','LB MAGIC SEASONING','21039090','1','2',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:55',NULL),(296,'226',NULL,NULL,'1048',NULL,'','O R CAPSICUM','O R CAPSICUM','21039090','1','2',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:57',NULL),(297,'226',NULL,NULL,'1049',NULL,'','ONION POWDER','ONION POWDER','21039090','1','2',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:58',NULL),(298,'226',NULL,NULL,'1050',NULL,'','TOMATO SEASONING','TOMATO SEASONING','21039090','1','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:07:59',NULL),(299,'226',NULL,NULL,'1051',NULL,'','RAJWADI FALHARI CHIWDA','RAJWADI FALHARI CHIWDA','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:01',NULL),(300,'226',NULL,NULL,'1052',NULL,'','20-20gold Cashew Almond','20-20gold Cashew Almond','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:02',NULL),(301,'226',NULL,NULL,'1053',NULL,'','Idacol Carmosine 25kg','Idacol Carmosine 25kg','32041989','NULL','3',NULL,'7','FOOD PRODUCT','3','3','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:04',NULL),(302,'226',NULL,NULL,'1055',NULL,'','Idacol Choclate Brown Tas 10kg','Idacol Choclate Brown Tas 10kg','32041988','NULL','3',NULL,'7','FOOD PRODUCT','3','3','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:05',NULL),(303,'226',NULL,NULL,'1056',NULL,'','Idacol Apple Green 500g','Idacol Apple Green 500g','32041987','NULL','3',NULL,'7','FOOD PRODUCT','3','3','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:07',NULL),(304,'226',NULL,NULL,'1057',NULL,'','CHOCOLATE POWDER (COCOA)','CHOCOLATE POWDER (COCOA)','18061000','1','3',NULL,'7','FOOD PRODUCT','3','3','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:08',NULL),(305,'226',NULL,NULL,'1058',NULL,'','Boodi Bhujia 40gm','Boodi Bhujia 40gm','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:10',NULL),(306,'226',NULL,NULL,'1059',NULL,'','T B H Q','T B H Q','29147990','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:11',NULL),(307,'226',NULL,NULL,'1060',NULL,'','Vanillin','Vanillin','29124100','NULL','3',NULL,'7','FOOD PRODUCT','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:13',NULL),(308,'226',NULL,NULL,'1061',NULL,'','Sunset Yellow 15Kg','Sunset Yellow 15Kg','32041981','NULL','3',NULL,'7','FOOD PRODUCT','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:14',NULL),(309,'226',NULL,NULL,'1062',NULL,'','Natracol Titanium Dioxide 1Kg','Natracol Titanium Dioxide 1Kg','32061190','NULL','3',NULL,'7','FOOD PRODUCT','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:16',NULL),(310,'226',NULL,NULL,'1063',NULL,'','Kismi Classic Rs 0.5 Elaichi','Kismi Classic Rs 0.5 Elaichi','17049030','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:17',NULL),(311,'226',NULL,NULL,'1064',NULL,'','20-20 Nice-Classic 80PKT','20-20 Nice-Classic 80PKT','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:19',NULL),(312,'226',NULL,NULL,'1065',NULL,'','Magix Kream Chocolate 72PKT','Magix Kream Chocolate 72PKT','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:20',NULL),(313,'226',NULL,NULL,'1066',NULL,'','Magix Kream Elaichi 72PKT','Magix Kream Elaichi 72PKT','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:22',NULL),(314,'226',NULL,NULL,'1067',NULL,'','20-20 GOLD BUTTER','20-20 GOLD BUTTER','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:23',NULL),(315,'226',NULL,NULL,'1068',NULL,'','IDACOLTARTRAZINE 10KG','IDACOLTARTRAZINE 10KG','32041989','NULL','3',NULL,'7','FOOD PRODUCT','3','3','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:25',NULL),(316,'226',NULL,NULL,'1069',NULL,'','SCFM TP 85ML','SCFM TP 85ML','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','160',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:26',NULL),(317,'226',NULL,NULL,'1070',NULL,'','BADAM THANDA 200ML PET','BADAM THANDA 200ML PET','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:28',NULL),(318,'226',NULL,NULL,'1071',NULL,'','KESHARBADAM MILK 200ML PET','KESHARBADAM MILK 200ML PET','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:29',NULL),(319,'226',NULL,NULL,'1072',NULL,'','CHOCOLATE MILK 200ML PET','CHOCOLATE MILK 200ML PET','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:31',NULL),(320,'226',NULL,NULL,'1073',NULL,'','VANILLA MILK 200ML PET','VANILLA MILK 200ML PET','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:32',NULL),(321,'226',NULL,NULL,'1074',NULL,'','HAPPY HAPPY CAKE TUTY FRUITY','HAPPY HAPPY CAKE TUTY FRUITY','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:34',NULL),(322,'226',NULL,NULL,'0051',NULL,'','MANTRA 250ML','MANTRA 250ML','2201','NULL','5',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'5','5','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:35',NULL),(323,'226',NULL,NULL,'0151',NULL,'','BASIL KIWI','BASIL KIWI','22029090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:37',NULL),(324,'226',NULL,NULL,'0152',NULL,'','BASIL LITCHI','BASIL LITCHI','22029090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:38',NULL),(325,'226',NULL,NULL,'0153',NULL,'','BASIL ORANGE','BASIL ORANGE','22029090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:39',NULL),(326,'226',NULL,NULL,'0154',NULL,'','BASIL ROSE','BASIL ROSE','22029090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:41',NULL),(327,'226',NULL,NULL,'0155',NULL,'','BASIL MINT','BASIL MINT','22029090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:42',NULL),(328,'226',NULL,NULL,'0158',NULL,'','STARCH POWDER','STARCH POWDER','11081200','50','3',NULL,'7','FOOD PRODUCT','3','3','50',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:44',NULL),(329,'226',NULL,NULL,'0159',NULL,'','HALKE FULKE PLAIN 80GM','HALKE FULKE PLAIN 80GM','20052000','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','63',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','63','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:46',NULL),(330,'226',NULL,NULL,'0149',NULL,'','MANIA MANGO','MANIA MANGO','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','27',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','27','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:47',NULL),(331,'226',NULL,NULL,'0175',NULL,'','MUSTARD OIL SYNTHETIC 500 ML GLASS','MUSTARD OIL SYNTHETIC 500 ML GLASS','33019032','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:48',NULL),(332,'226',NULL,NULL,'0560',NULL,'','SANDALWOOD GIVCO','SANDALWOOD GIVCO','33021090','1','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:50',NULL),(333,'226',NULL,NULL,'0010',NULL,'','MELODY MRP 50/-','MELODY MRP 50/-','18069010','NULL','3',NULL,'2','PAPL','7','7','32',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','PAPL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:51',NULL),(334,'226',NULL,NULL,'0063',NULL,'','BADAM KESAR MRP 30/-','BADAM KESAR MRP 30/-','22029930','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:53',NULL),(335,'226',NULL,NULL,'0062',NULL,'','MELODY 800','MELODY 800','18069010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:54',NULL),(336,'226',NULL,NULL,'0061',NULL,'','classic lassi','classic lassi','04039010','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:56',NULL),(337,'226',NULL,NULL,'0059',NULL,'','kapi parle','kapi parle','17049020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','4',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:57',NULL),(338,'226',NULL,NULL,'0031',NULL,'','MAZELO','MAZELO','17049020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:08:59',NULL),(339,'226',NULL,NULL,'0713',NULL,'','APPY FIZZ 125ml','APPY FIZZ 125ml','22029920','NULL','3',NULL,'6','PARLE AGRO','7','7','40',NULL,NULL,'5','5','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:00',NULL),(340,'226',NULL,NULL,'0714',NULL,'','shcm','shcm','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:02',NULL),(341,'226',NULL,NULL,'01101',NULL,'','TWITO VANILLA MRP10/-','TWITO VANILLA MRP10/-','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:03',NULL),(342,'226',NULL,NULL,'01102',NULL,'','TWITO CHOCOLATE','TWITO CHOCOLATE','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:05',NULL),(343,'226',NULL,NULL,'01103',NULL,'','CUP CAKE','CUP CAKE','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','432',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:06',NULL),(344,'226',NULL,NULL,'1104',NULL,'','PARLE G GOLD REGULAR','PARLE G GOLD REGULAR','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:08',NULL),(345,'226',NULL,NULL,'1201',NULL,'','ALU SEV','ALU SEV','21069099','400','3',NULL,'1','HALDIRAM NAMKIN','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:10',NULL),(346,'226',NULL,NULL,'1105',NULL,'','wave chocolate','wave chocolate','19059010','NULL','3',NULL,'5','HUL','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:11',NULL),(347,'226',NULL,NULL,'1106',NULL,'','Grand Londondery Caramel','Grand Londondery Caramel','17049020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:13',NULL),(348,'226',NULL,NULL,'1107',NULL,'','Melody Classic Choclet','Melody Classic Choclet','18069010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:14',NULL),(349,'226',NULL,NULL,'01108',NULL,'','CHEESELING','CHEESELING','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:15',NULL),(350,'226',NULL,NULL,'01109',NULL,'','YOGHURT GUAVA','YOGHURT GUAVA','04032000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:17',NULL),(351,'226',NULL,NULL,'1110',NULL,'','YOGHURT BANANA','YOGHURT BANANA','04032000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:18',NULL),(352,'226',NULL,NULL,'1111',NULL,'','YOGHURT BERRIES','YOGHURT BERRIES','04032000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:20',NULL),(353,'226',NULL,NULL,'01112',NULL,'','YOGHURT GUAVA','YOGHURT GUAVA','04032000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:21',NULL),(354,'226',NULL,NULL,'01113',NULL,'','YOGHURT BANANA','YOGHURT BANANA','04032000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:23',NULL),(355,'226',NULL,NULL,'01114',NULL,'','YOGHURT BERRIES','YOGHURT BERRIES','04032000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:24',NULL),(356,'226',NULL,NULL,'1121',NULL,'','ORANGE BITE','ORANGE BITE','17049020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:26',NULL),(357,'226',NULL,NULL,'04',NULL,'','GATHIYA MRP5/-','GATHIYA MRP5/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','300',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:28',NULL),(358,'226',NULL,NULL,'05',NULL,'','KACHORI 200GM','KACHORI 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:29',NULL),(359,'226',NULL,NULL,'06',NULL,'','GD BUTTER','GD BUTTER','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','84',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','84','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:31',NULL),(360,'226',NULL,NULL,'07',NULL,'','GD CHOCO CHIP','GD CHOCO CHIP','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:32',NULL),(361,'226',NULL,NULL,'08',NULL,'','DIGESTIVE','DIGESTIVE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:34',NULL),(362,'226',NULL,NULL,'09',NULL,'','MASKA CHASKA','MASKA CHASKA','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:36',NULL),(363,'226',NULL,NULL,'10',NULL,'','GD PISTA BADAM','GD PISTA BADAM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:37',NULL),(364,'226',NULL,NULL,'11',NULL,'','NICE TIME','NICE TIME','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','75',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','75','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:39',NULL),(365,'226',NULL,NULL,'12',NULL,'','TREAT JIM JAM','TREAT JIM JAM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:40',NULL),(366,'226',NULL,NULL,'01301',NULL,'','CREAM CRACKER','CREAM CRACKER','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','64',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:42',NULL),(367,'226',NULL,NULL,'0044',NULL,'','MINI BHAKARWADI','MINI BHAKARWADI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:43',NULL),(368,'226',NULL,NULL,'0045',NULL,'','BOONDI','BOONDI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:45',NULL),(369,'226',NULL,NULL,'00332',NULL,'','THANDA FUNDA','THANDA FUNDA','1070','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:47',NULL),(370,'226',NULL,NULL,'0041',NULL,'','THANDA FUNDA MRP20/-','THANDA FUNDA MRP20/-','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:48',NULL),(371,'226',NULL,NULL,'0042',NULL,'','ROASTED CHANA','ROASTED CHANA','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:50',NULL),(372,'226',NULL,NULL,'0043',NULL,'','MANGO DRINK','MANGO DRINK','20098910','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:51',NULL),(373,'226',NULL,NULL,'0039',NULL,'','ALL IN ONE MRP 5/-','ALL IN ONE MRP 5/-','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:53',NULL),(374,'226',NULL,NULL,'0038',NULL,'','KISMI GOLD','KISMI GOLD','17049020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','36',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:54',NULL),(375,'226',NULL,NULL,'0101',NULL,'','ALL IN ONE','ALL IN ONE','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:56',NULL),(376,'226',NULL,NULL,'0102',NULL,'','ALOO BHUJIA MRP 20/-','ALOO BHUJIA MRP 20/-','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:57',NULL),(377,'226',NULL,NULL,'0103',NULL,'','BHUJIA SEV MRP 20/-','BHUJIA SEV MRP 20/-','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','112',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','112','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:09:59',NULL),(378,'226',NULL,NULL,'0104',NULL,'','KHATTA MEETHA MRP20/-','KHATTA MEETHA MRP20/-','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','112',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','112','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:00',NULL),(379,'226',NULL,NULL,'0105',NULL,'','MOONG DAL','MOONG DAL','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:02',NULL),(380,'226',NULL,NULL,'0106',NULL,'','SOYA STICKS','SOYA STICKS','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','156',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','156','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:04',NULL),(381,'226',NULL,NULL,'0107',NULL,'','TASTY NUT','TASTY NUT','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:05',NULL),(382,'226',NULL,NULL,'0108',NULL,'','PARLE MILANO MRP 10/-','PARLE MILANO MRP 10/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','128',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','128','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:07',NULL),(383,'226',NULL,NULL,'0109',NULL,'','HALKE FULKE SALTED MRP 20/-','HALKE FULKE SALTED MRP 20/-','20052000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:08',NULL),(384,'226',NULL,NULL,'0110',NULL,'','HALKE FULKE CHILLI','HALKE FULKE CHILLI','20052000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:10',NULL),(385,'226',NULL,NULL,'0111',NULL,'','TAKA TAK MRP 20/-','TAKA TAK MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:11',NULL),(386,'226',NULL,NULL,'0112',NULL,'','KACCHA AAM','KACCHA AAM','18069010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:13',NULL),(387,'226',NULL,NULL,'02001',NULL,'','MIXTURE','MIXTURE','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:14',NULL),(388,'226',NULL,NULL,'02002',NULL,'','CARDAMOM KE','CARDAMOM KE','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:16',NULL),(389,'226',NULL,NULL,'02003',NULL,'','ROASTED CRUNCHY PEANUT','ROASTED CRUNCHY PEANUT','20081100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:18',NULL),(390,'226',NULL,NULL,'02004',NULL,'','EAT ANYTIME MILLET','EAT ANYTIME MILLET','18061000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:19',NULL),(391,'226',NULL,NULL,'02005',NULL,'','MINI BHAKARWADI 200GM','MINI BHAKARWADI 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:21',NULL),(392,'226',NULL,NULL,'02006',NULL,'','ROYAL TREASURE','ROYAL TREASURE','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','6',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:22',NULL),(393,'226',NULL,NULL,'02011',NULL,'','BOURBON 100G','BOURBON 100G','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:24',NULL),(394,'226',NULL,NULL,'02012',NULL,'','GD CASHEW','GD CASHEW','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:26',NULL),(395,'226',NULL,NULL,'02013',NULL,'','LITTLE HEARTS','LITTLE HEARTS','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:27',NULL),(396,'226',NULL,NULL,'02014',NULL,'','NC DIGESTIVE','NC DIGESTIVE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:29',NULL),(397,'226',NULL,NULL,'02015',NULL,'','NC OATS MILK ALMOND','NC OATS MILK ALMOND','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:30',NULL),(398,'226',NULL,NULL,'02016',NULL,'','NICE TIME','NICE TIME','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:32',NULL),(399,'226',NULL,NULL,'02017',NULL,'','JIM JAM','JIM JAM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','75',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','75','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:33',NULL),(400,'226',NULL,NULL,'02018',NULL,'','TREAT CROISSANT MF','TREAT CROISSANT MF','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:35',NULL),(401,'226',NULL,NULL,'02019',NULL,'','VEG CAKE CHOCOLATE','VEG CAKE CHOCOLATE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:36',NULL),(402,'226',NULL,NULL,'02020',NULL,'','VEG FRUIT CAKE','VEG FRUIT CAKE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:38',NULL),(403,'226',NULL,NULL,'02021',NULL,'','PINEAPPLE CONC KE','PINEAPPLE CONC KE','33021010','NULL','3',NULL,'3','MOJO BAR','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:40',NULL),(404,'226',NULL,NULL,'02022',NULL,'','CHOCOLATE KE','CHOCOLATE KE','33021010','NULL','3',NULL,'3','MOJO BAR','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MOJO BAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:41',NULL),(405,'226',NULL,NULL,'02023',NULL,'','TREAT CROISSANT COCOA','TREAT CROISSANT COCOA','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:43',NULL),(406,'226',NULL,NULL,'02031',NULL,'','MILK TOAST 250G','MILK TOAST 250G','19054000','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:44',NULL),(407,'226',NULL,NULL,'02032',NULL,'','GRAND LONDON DAIRY','GRAND LONDON DAIRY','18069010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:46',NULL),(408,'226',NULL,NULL,'02041',NULL,'','TASTY NUT 200GM','TASTY NUT 200GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:47',NULL),(409,'226',NULL,NULL,'02042',NULL,'','NAVRATAN MIXTURE','NAVRATAN MIXTURE','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:49',NULL),(410,'226',NULL,NULL,'02051',NULL,'','LITTLE HEARTS MRP 10','LITTLE HEARTS MRP 10','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','112',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','112','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:51',NULL),(411,'226',NULL,NULL,'02052',NULL,'','SALTED PEANUTS MRP 20/-','SALTED PEANUTS MRP 20/-','20081100','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','112',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','112','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:52',NULL),(412,'226',NULL,NULL,'02054',NULL,'','HALDIRAM NAMKEEN MRP 20','HALDIRAM NAMKEEN MRP 20','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:54',NULL),(413,'226',NULL,NULL,'02055',NULL,'','20ml ROUND 22MM BOTTLES','20ml ROUND 22MM BOTTLES','70109000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','100',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:55',NULL),(414,'226',NULL,NULL,'02065',NULL,'','NUTRICRUNCH DIGESTIVE','NUTRICRUNCH DIGESTIVE','19059020','NULL','3',NULL,'6','PARLE AGRO','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE AGRO',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:57',NULL),(415,'226',NULL,NULL,'02070',NULL,'','GD CASHEW','GD CASHEW','19053100','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','84',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','84','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:10:58',NULL),(416,'226',NULL,NULL,'02080',NULL,'','VEG CAKE MRP 10/-','VEG CAKE MRP 10/-','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:00',NULL),(417,'226',NULL,NULL,'02081',NULL,'','FUDGE IT BROWNIE','FUDGE IT BROWNIE','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:02',NULL),(418,'226',NULL,NULL,'02083',NULL,'','NUTRICRUNCH GINGER MRP 20/-','NUTRICRUNCH GINGER MRP 20/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:03',NULL),(419,'226',NULL,NULL,'02101',NULL,'','DM MRP 10','DM MRP 10','17041000','NULL','3',NULL,'5','HUL','7','7','600',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','600','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:05',NULL),(420,'226',NULL,NULL,'02102',NULL,'','DM MRP 50/-','DM MRP 50/-','17049020','NULL','3',NULL,'5','HUL','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:06',NULL),(421,'226',NULL,NULL,'02103',NULL,'','DM SPR MRP 10/-','DM SPR MRP 10/-','NULL','NULL','3',NULL,'5','HUL','7','7','400',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','400','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:08',NULL),(422,'226',NULL,NULL,'02104',NULL,'','ORBIT MIXF MRP 50/-','ORBIT MIXF MRP 50/-','21069099','NULL','3',NULL,'5','HUL','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:09',NULL),(423,'226',NULL,NULL,'02105',NULL,'','ORBIT SWEETMINT MRP 50','ORBIT SWEETMINT MRP 50','21069099','NULL','3',NULL,'5','HUL','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:11',NULL),(424,'226',NULL,NULL,'02106',NULL,'','BTY MRP 30/-','BTY MRP 30/-','18069010','NULL','3',NULL,'5','HUL','7','7','180',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:12',NULL),(425,'226',NULL,NULL,'02107',NULL,'','BTY MRP 70/-','BTY MRP 70/-','18069010','NULL','3',NULL,'5','HUL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:14',NULL),(426,'226',NULL,NULL,'02108',NULL,'','SNK ALD MRP 30/-','SNK ALD MRP 30/-','18069010','NULL','3',NULL,'5','HUL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:16',NULL),(427,'226',NULL,NULL,'02109',NULL,'','GALAXY MRP 20/-','GALAXY MRP 20/-','18069010','NULL','3',NULL,'5','HUL','7','7','576',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','576','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:18',NULL),(428,'226',NULL,NULL,'02110',NULL,'','SNK BERRY MRP 30','SNK BERRY MRP 30','18069010','NULL','3',NULL,'5','HUL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:19',NULL),(429,'226',NULL,NULL,'02111',NULL,'','SNK BUTTERS MRP 30/-','SNK BUTTERS MRP 30/-','18069010','NULL','3',NULL,'5','HUL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:21',NULL),(430,'226',NULL,NULL,'02112',NULL,'','SNK BAR MRP 50/-','SNK BAR MRP 50/-','18069010','NULL','3',NULL,'5','HUL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:23',NULL),(431,'226',NULL,NULL,'02113',NULL,'','SNK MRP 20/-','SNK MRP 20/-','18069010','NULL','3',NULL,'5','HUL','7','7','384',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','384','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:24',NULL),(432,'226',NULL,NULL,'02114',NULL,'','SNK ALD MRP 60/-','SNK ALD MRP 60/-','18069010','NULL','3',NULL,'5','HUL','7','7','180',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:26',NULL),(433,'226',NULL,NULL,'02115',NULL,'','TWIX MRP 30/-','TWIX MRP 30/-','18069010','NULL','3',NULL,'5','HUL','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:27',NULL),(434,'226',NULL,NULL,'02116',NULL,'','TWIX MRP 70/-','TWIX MRP 70/-','18069010','NULL','3',NULL,'5','HUL','7','7','250',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','250','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:29',NULL),(435,'226',NULL,NULL,'02201',NULL,'','50-50 57GM','50-50 57GM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:31',NULL),(436,'226',NULL,NULL,'02202',NULL,'','BOURBON 120GM','BOURBON 120GM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:33',NULL),(437,'226',NULL,NULL,'02203',NULL,'','VEG CAKE FRUIT 37G','VEG CAKE FRUIT 37G','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:34',NULL),(438,'226',NULL,NULL,'02204',NULL,'','VEG CAKE CHOCOLATE','VEG CAKE CHOCOLATE','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:36',NULL),(439,'226',NULL,NULL,'02205',NULL,'','TREAT CHOCO 43G','TREAT CHOCO 43G','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:37',NULL),(440,'226',NULL,NULL,'02206',NULL,'','NC DIGESTIVE 100GM','NC DIGESTIVE 100GM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:39',NULL),(441,'226',NULL,NULL,'02207',NULL,'','TREAT JIMJAM POPS 70GM','TREAT JIMJAM POPS 70GM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:41',NULL),(442,'226',NULL,NULL,'02301',NULL,'','BHUJIA SEV 200GM','BHUJIA SEV 200GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:42',NULL),(443,'226',NULL,NULL,'02302',NULL,'','ALL IN ONE 400GM','ALL IN ONE 400GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:44',NULL),(444,'226',NULL,NULL,'02303',NULL,'','MIXTURE 200GM','MIXTURE 200GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:46',NULL),(445,'226',NULL,NULL,'02304',NULL,'','MIXTURE 400GM','MIXTURE 400GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:47',NULL),(446,'226',NULL,NULL,'02307',NULL,'','CARDMOM 25KG','CARDMOM 25KG','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:49',NULL),(447,'226',NULL,NULL,'2001',NULL,'','PISTA GC','PISTA GC','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:50',NULL),(448,'226',NULL,NULL,'2002',NULL,'','KEWRA AFL','KEWRA AFL','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:52',NULL),(449,'226',NULL,NULL,'2003',NULL,'','WHITE ROSE AFL','WHITE ROSE AFL','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:54',NULL),(450,'226',NULL,NULL,'2004',NULL,'','VANILLA  AFL','VANILLA  AFL','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','5',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','5','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:55',NULL),(451,'226',NULL,NULL,'2005',NULL,'','CARDAMOM AFL','CARDAMOM AFL','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:57',NULL),(452,'226',NULL,NULL,'2006',NULL,'','FLAO COMPOUND PG','FLAO COMPOUND PG','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:11:59',NULL),(453,'226',NULL,NULL,'02401',NULL,'','MOTICHOOR LADDU','MOTICHOOR LADDU','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:00',NULL),(454,'226',NULL,NULL,'02501',NULL,'','BOURBON 150GM','BOURBON 150GM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:02',NULL),(455,'226',NULL,NULL,'02502',NULL,'','TREAT JIMJAM','TREAT JIMJAM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:04',NULL),(456,'226',NULL,NULL,'02601',NULL,'','ROYAL HERITAGE','ROYAL HERITAGE','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','6',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:06',NULL),(457,'226',NULL,NULL,'02602',NULL,'','ROYAL TREASURE','ROYAL TREASURE','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:07',NULL),(458,'226',NULL,NULL,'02603',NULL,'','ROYAL DESIRE','ROYAL DESIRE','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','6',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:09',NULL),(459,'226',NULL,NULL,'02604',NULL,'','ROYAL CELEBRATION','ROYAL CELEBRATION','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:11',NULL),(460,'226',NULL,NULL,'02605',NULL,'','HEAVENLY DELIGHT','HEAVENLY DELIGHT','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','8',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:12',NULL),(461,'226',NULL,NULL,'02606',NULL,'','LAVISH DELIGHT','LAVISH DELIGHT','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','8',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:14',NULL),(462,'226',NULL,NULL,'02607',NULL,'','DIVINE DELIGHT','DIVINE DELIGHT','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:15',NULL),(463,'226',NULL,NULL,'02608',NULL,'','FESTIVE DELIGHT','FESTIVE DELIGHT','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:17',NULL),(464,'226',NULL,NULL,'02609',NULL,'','SUPREME JOY','SUPREME JOY','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:19',NULL),(465,'226',NULL,NULL,'02610',NULL,'','IMPERIAL JOY','IMPERIAL JOY','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:21',NULL),(466,'226',NULL,NULL,'02611',NULL,'','DELICIOUS JOY','DELICIOUS JOY','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:22',NULL),(467,'226',NULL,NULL,'02612',NULL,'','GD CASHEW ALMOND','GD CASHEW ALMOND','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:24',NULL),(468,'226',NULL,NULL,'02613',NULL,'','MARIE GOLD','MARIE GOLD','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:26',NULL),(469,'226',NULL,NULL,'02614',NULL,'','VITA MARIE','VITA MARIE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:27',NULL),(470,'226',NULL,NULL,'02615',NULL,'','TIGER','TIGER','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:29',NULL),(471,'226',NULL,NULL,'02616',NULL,'','VITA MARIE 10/-','VITA MARIE 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:31',NULL),(472,'226',NULL,NULL,'02617',NULL,'','MARIE GOLD','MARIE GOLD','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:32',NULL),(473,'226',NULL,NULL,'02618',NULL,'','GD BUTTER','GD BUTTER','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','180',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:34',NULL),(474,'226',NULL,NULL,'02619',NULL,'','GD BUTTER 120G','GD BUTTER 120G','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:36',NULL),(475,'226',NULL,NULL,'02620',NULL,'','MILKY BIKIS 5/-','MILKY BIKIS 5/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:38',NULL),(476,'226',NULL,NULL,'02621',NULL,'','KAJU KATLI','KAJU KATLI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:39',NULL),(477,'226',NULL,NULL,'02622',NULL,'','KAJU CHOCOLATE ROLL','KAJU CHOCOLATE ROLL','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:41',NULL),(478,'226',NULL,NULL,'02623',NULL,'','PARLE G DARK','PARLE G DARK','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:43',NULL),(479,'226',NULL,NULL,'02631',NULL,'','ALL IN ONE 200GM','ALL IN ONE 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:45',NULL),(480,'226',NULL,NULL,'02632',NULL,'','TREAT VANILLA','TREAT VANILLA','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:46',NULL),(481,'226',NULL,NULL,'02633',NULL,'','MILK BIKIS 44 GM','MILK BIKIS 44 GM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:48',NULL),(482,'226',NULL,NULL,'02634',NULL,'','50-50 GOLMAAL 57GM','50-50 GOLMAAL 57GM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','90',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:49',NULL),(483,'226',NULL,NULL,'02635',NULL,'','MILK BIKIS 100GM','MILK BIKIS 100GM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','100',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:51',NULL),(484,'226',NULL,NULL,'02636',NULL,'','NC DIGESTIVE 100G','NC DIGESTIVE 100G','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:53',NULL),(485,'226',NULL,NULL,'02637',NULL,'','TREAT JIM JAM POP','TREAT JIM JAM POP','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','100',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:55',NULL),(486,'226',NULL,NULL,'02638',NULL,'','TREAT ORANGE','TREAT ORANGE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','80',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:56',NULL),(487,'226',NULL,NULL,'02701',NULL,'','MANGO SWEET','MANGO SWEET','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:12:58',NULL),(488,'226',NULL,NULL,'02702',NULL,'','ORANGE SWEET','ORANGE SWEET','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:00',NULL),(489,'226',NULL,NULL,'02703',NULL,'','ROSE NO 1','ROSE NO 1','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:02',NULL),(490,'226',NULL,NULL,'02704',NULL,'','DOUBLE JOY','DOUBLE JOY','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:03',NULL),(491,'226',NULL,NULL,'02705',NULL,'','VEG LAYERS CAKE 12G','VEG LAYERS CAKE 12G','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','424',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','424','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:05',NULL),(492,'226',NULL,NULL,'02801',NULL,'','GRAPE 180ML','GRAPE 180ML','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:07',NULL),(493,'226',NULL,NULL,'02802',NULL,'','POMEGRANATE 180ML','POMEGRANATE 180ML','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:09',NULL),(494,'226',NULL,NULL,'02803',NULL,'','MOSAMBI 180ML','MOSAMBI 180ML','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:11',NULL),(495,'226',NULL,NULL,'02804',NULL,'','REAL JUICE MRP 20/-','REAL JUICE MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:13',NULL),(496,'226',NULL,NULL,'02901',NULL,'','PEPPY TOMATO 40GM MRP 20/-','PEPPY TOMATO 40GM MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','110',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','110','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:15',NULL),(497,'226',NULL,NULL,'02902',NULL,'','PIKNIK TOMATO 40GM MRP 20/-','PIKNIK TOMATO 40GM MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','110',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','110','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:16',NULL),(498,'226',NULL,NULL,'02903',NULL,'','PEPPY CHEESE BALL 40GM MRP20/-','PEPPY CHEESE BALL 40GM MRP20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','110',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','110','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:18',NULL),(499,'226',NULL,NULL,'02904',NULL,'','KRACKJACK 120GM','KRACKJACK 120GM','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:20',NULL),(500,'226',NULL,NULL,'02905',NULL,'','MULTIVITA PARLE MRP 20/-','MULTIVITA PARLE MRP 20/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:21',NULL),(501,'226',NULL,NULL,'02906',NULL,'','GD CASHEW MRP 20/-','GD CASHEW MRP 20/-','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:23',NULL),(502,'226',NULL,NULL,'02907',NULL,'','TREAT JIM JAM','TREAT JIM JAM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:25',NULL),(503,'226',NULL,NULL,'02805',NULL,'','MIX FRUIT MRP 20/-','MIX FRUIT MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:27',NULL),(504,'226',NULL,NULL,'02806',NULL,'','APPLE JUICE MRP 20/-','APPLE JUICE MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:29',NULL),(505,'226',NULL,NULL,'02807',NULL,'','CRANBERRY JUICE MRP 20/-','CRANBERRY JUICE MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:30',NULL),(506,'226',NULL,NULL,'02808',NULL,'','ORANGE JUICE MRP 20/-','ORANGE JUICE MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:32',NULL),(507,'226',NULL,NULL,'02908',NULL,'','PEPPY TOMATO','PEPPY TOMATO','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:34',NULL),(508,'226',NULL,NULL,'02909',NULL,'','PICNIK TOMATO','PICNIK TOMATO','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:36',NULL),(509,'226',NULL,NULL,'02910',NULL,'','PEPPY CHEESE BALL','PEPPY CHEESE BALL','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:37',NULL),(510,'226',NULL,NULL,'12001',NULL,'','MEXILLA  NACHO CLASSIC','MEXILLA  NACHO CLASSIC','21089099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:39',NULL),(511,'226',NULL,NULL,'1202',NULL,'','MAXILLA SWEET THAI CHILI','MAXILLA SWEET THAI CHILI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:41',NULL),(512,'226',NULL,NULL,'1203',NULL,'','MAXILLA CHEESE','MAXILLA CHEESE','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:43',NULL),(513,'226',NULL,NULL,'02809',NULL,'','LITCHI 180ML MRP 20/-','LITCHI 180ML MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:44',NULL),(514,'226',NULL,NULL,'02810',NULL,'','GUAVA 180ML MRP 20/-','GUAVA 180ML MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:46',NULL),(515,'226',NULL,NULL,'02811',NULL,'','PINEAPPLE 180ML MRP 20/-','PINEAPPLE 180ML MRP 20/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:48',NULL),(516,'226',NULL,NULL,'02641',NULL,'','50-50 GOLMAAL MRP 20/-','50-50 GOLMAAL MRP 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:50',NULL),(517,'226',NULL,NULL,'02642',NULL,'','JIM JAM POPS MRP 20/-','JIM JAM POPS MRP 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:51',NULL),(518,'226',NULL,NULL,'02912',NULL,'','PANGA','PANGA','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:53',NULL),(519,'226',NULL,NULL,'03001',NULL,'','solh classic coffee MRP 50/-','solh classic coffee MRP 50/-','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:55',NULL),(520,'226',NULL,NULL,'03002',NULL,'','SOLH FRAPPE MRP 50/-','SOLH FRAPPE MRP 50/-','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:57',NULL),(521,'226',NULL,NULL,'03003',NULL,'','SOLH MOCHA MRP 50/-','SOLH MOCHA MRP 50/-','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:13:58',NULL),(522,'226',NULL,NULL,'03004',NULL,'','MALKIST 144GM MRP 50/-','MALKIST 144GM MRP 50/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:00',NULL),(523,'226',NULL,NULL,'2812',NULL,'','MANGO 180 ML MRP 20','MANGO 180 ML MRP 20','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:02',NULL),(524,'226',NULL,NULL,'03005',NULL,'','MARS MRP 70/-','MARS MRP 70/-','50001595','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:04',NULL),(525,'226',NULL,NULL,'0001',NULL,'','GUD KHASTA GAJJAK 200 GM','GUD KHASTA GAJJAK 200 GM','17049090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:05',NULL),(526,'226',NULL,NULL,'03006',NULL,'','TIGER CRUNCH MRP 10/-','TIGER CRUNCH MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:07',NULL),(527,'226',NULL,NULL,'03007',NULL,'','MILKBIKIS MRP 5/-','MILKBIKIS MRP 5/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:09',NULL),(528,'226',NULL,NULL,'03008',NULL,'','TIGER GLUCOSE','TIGER GLUCOSE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:11',NULL),(529,'226',NULL,NULL,'03009',NULL,'','TIGER CRUNCH','TIGER CRUNCH','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:12',NULL),(530,'226',NULL,NULL,'03010',NULL,'','NICE','NICE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:14',NULL),(531,'226',NULL,NULL,'03011',NULL,'','ORANGE 20ML','ORANGE 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','10','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:16',NULL),(532,'226',NULL,NULL,'03012',NULL,'','CARDMOM 20ML','CARDMOM 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','10','10','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:18',NULL),(533,'226',NULL,NULL,'03013',NULL,'','VANILLA 20ML','VANILLA 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','10','10','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:20',NULL),(534,'226',NULL,NULL,'03014',NULL,'','TREAT ORANGE MRP 20/-','TREAT ORANGE MRP 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','50',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:21',NULL),(535,'226',NULL,NULL,'03015',NULL,'','GD BUTTER JEERA MRP 20/-','GD BUTTER JEERA MRP 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:23',NULL),(536,'226',NULL,NULL,'03018',NULL,'','MUNCH MRP 10/-','MUNCH MRP 10/-','18069010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','756',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','756','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:25',NULL),(537,'226',NULL,NULL,'03101',NULL,'','Soya stick 400g','Soya stick 400g','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:27',NULL),(538,'226',NULL,NULL,'03102',NULL,'','TASTY NUT 200G','TASTY NUT 200G','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:28',NULL),(539,'226',NULL,NULL,'03103',NULL,'','ALOO BHUJIA 400G','ALOO BHUJIA 400G','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','31',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','31','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:30',NULL),(540,'226',NULL,NULL,'03104',NULL,'','MOONG DAL 200G','MOONG DAL 200G','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','62',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','62','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:32',NULL),(541,'226',NULL,NULL,'03105',NULL,'','YELLOW BANANA 160G','YELLOW BANANA 160G','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:34',NULL),(542,'226',NULL,NULL,'03106',NULL,'','LITTLE HEART MRP 5/-','LITTLE HEART MRP 5/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','225',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','225','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:36',NULL),(543,'226',NULL,NULL,'03107',NULL,'','MILK BIKIS MRP10/-','MILK BIKIS MRP10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:37',NULL),(544,'226',NULL,NULL,'03108',NULL,'','KEWRA 20ML','KEWRA 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:39',NULL),(545,'226',NULL,NULL,'03109',NULL,'','VANILLIN ETHYLE ( VN)','VANILLIN ETHYLE ( VN)','29124100','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:41',NULL),(546,'226',NULL,NULL,'04001',NULL,'','CASHEW BADAM','CASHEW BADAM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:43',NULL),(547,'226',NULL,NULL,'04002',NULL,'','CHOCO RIPPLE','CHOCO RIPPLE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:45',NULL),(548,'226',NULL,NULL,'04003',NULL,'','FRUIT & NUT','FRUIT & NUT','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:47',NULL),(549,'226',NULL,NULL,'04004',NULL,'','CUMIN COOKIES','CUMIN COOKIES','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:48',NULL),(550,'226',NULL,NULL,'04005',NULL,'','CREAMY CHEESE WAFER','CREAMY CHEESE WAFER','19053219','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:50',NULL),(551,'226',NULL,NULL,'04006',NULL,'','YUMMY STRAWBERRY WAFER','YUMMY STRAWBERRY WAFER','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:52',NULL),(552,'226',NULL,NULL,'04007',NULL,'','RICH CHOCOLATE','RICH CHOCOLATE','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:54',NULL),(553,'226',NULL,NULL,'04009',NULL,'','MURUKKU 200GM','MURUKKU 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:56',NULL),(554,'226',NULL,NULL,'04010',NULL,'','FARALI CHIWDA 200GM','FARALI CHIWDA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:14:58',NULL),(555,'226',NULL,NULL,'04011',NULL,'','H & S CHOCOFILL','H & S CHOCOFILL','18069090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:00',NULL),(556,'226',NULL,NULL,'04012',NULL,'','H & S CHOCO ROLL','H & S CHOCO ROLL','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','128',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','128','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:01',NULL),(557,'226',NULL,NULL,'04101',NULL,'','BHUJIA SEV 200GM','BHUJIA SEV 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:03',NULL),(558,'226',NULL,NULL,'04102',NULL,'','BHUJIA SEV 400GM','BHUJIA SEV 400GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:05',NULL),(559,'226',NULL,NULL,'04103',NULL,'','MOONG DAL 200GM','MOONG DAL 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','62',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','62','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:07',NULL),(560,'226',NULL,NULL,'04104',NULL,'','CHATPATA DAL 200GM','CHATPATA DAL 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:09',NULL),(561,'226',NULL,NULL,'04105',NULL,'','CHANA CHOOR 200GM','CHANA CHOOR 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','54',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','54','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:11',NULL),(562,'226',NULL,NULL,'04106',NULL,'','SALTED PEANUT 200GM','SALTED PEANUT 200GM','20081100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:13',NULL),(563,'226',NULL,NULL,'04107',NULL,'','KHATTA MEETHA 220GM','KHATTA MEETHA 220GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:14',NULL),(564,'226',NULL,NULL,'04108',NULL,'','ALOO BHUJIA 220GM','ALOO BHUJIA 220GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','50',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:16',NULL),(565,'226',NULL,NULL,'04109',NULL,'','RATLAMI SEV 200GM','RATLAMI SEV 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','64',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:18',NULL),(566,'226',NULL,NULL,'04110',NULL,'','ALL IN ONE 400GM','ALL IN ONE 400GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:20',NULL),(567,'226',NULL,NULL,'04111',NULL,'','ALL IN ONE 200GM','ALL IN ONE 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:22',NULL),(568,'226',NULL,NULL,'04112',NULL,'','50-50 JEERA','50-50 JEERA','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:24',NULL),(569,'226',NULL,NULL,'04113',NULL,'','MALKIEST CHEESE MRP 30/-','MALKIEST CHEESE MRP 30/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:25',NULL),(570,'226',NULL,NULL,'04114',NULL,'','MALKIEST CHOCOLATE MRP 30/-','MALKIEST CHOCOLATE MRP 30/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:27',NULL),(571,'226',NULL,NULL,'04115',NULL,'','H & S MILANO','H & S MILANO','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:29',NULL),(572,'226',NULL,NULL,'04116',NULL,'','50-50 MRP 5/-','50-50 MRP 5/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:31',NULL),(573,'226',NULL,NULL,'04118',NULL,'','CROISSANT VANILLA 45GM','CROISSANT VANILLA 45GM','19059010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:33',NULL),(574,'226',NULL,NULL,'04119',NULL,'','MARIE GOLD MRP 20/-','MARIE GOLD MRP 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:35',NULL),(575,'226',NULL,NULL,'04120',NULL,'','MCVITTIES BUTTER 70GM','MCVITTIES BUTTER 70GM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:37',NULL),(576,'226',NULL,NULL,'04121',NULL,'','MCVITIES CASHEW 70GM','MCVITIES CASHEW 70GM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:39',NULL),(577,'226',NULL,NULL,'04122',NULL,'','MCVITIES COCONUT 70GM','MCVITIES COCONUT 70GM','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:41',NULL),(578,'226',NULL,NULL,'04123',NULL,'','MCVITIES BUTTER JEERA','MCVITIES BUTTER JEERA','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:43',NULL),(579,'226',NULL,NULL,'04124',NULL,'','GATHIYA MRP 10/-','GATHIYA MRP 10/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:44',NULL),(580,'226',NULL,NULL,'00001',NULL,'','CHAVANO PAPAD','CHAVANO PAPAD','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','132',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','132','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:46',NULL),(581,'226',NULL,NULL,'04125',NULL,'','THANDAI 400ML','THANDAI 400ML','20089919','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:48',NULL),(582,'226',NULL,NULL,'04131',NULL,'','MEETHA KEWDA 20ML','MEETHA KEWDA 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:50',NULL),(583,'226',NULL,NULL,'04132',NULL,'','VANILLA POWDER 100G','VANILLA POWDER 100G','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:52',NULL),(584,'226',NULL,NULL,'04133',NULL,'','VANILLA POWDER 500G','VANILLA POWDER 500G','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:54',NULL),(585,'226',NULL,NULL,'04013',NULL,'','CHOCO CHIP','CHOCO CHIP','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:56',NULL),(586,'226',NULL,NULL,'04014',NULL,'','DOUBLE CHOCO CHIP','DOUBLE CHOCO CHIP','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:15:58',NULL),(587,'226',NULL,NULL,'04015',NULL,'','BUTTER COOKIES','BUTTER COOKIES','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:00',NULL),(588,'226',NULL,NULL,'04016',NULL,'','LIQUID PRESERVATIVE 25KG','LIQUID PRESERVATIVE 25KG','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:01',NULL),(589,'226',NULL,NULL,'04017',NULL,'','LIQUID PRESERVATIVE 5KG','LIQUID PRESERVATIVE 5KG','33021010','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:03',NULL),(590,'226',NULL,NULL,'04018',NULL,'','THANDA FUNDA MRP 35/-','THANDA FUNDA MRP 35/-','22029930','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:05',NULL),(591,'226',NULL,NULL,'04019',NULL,'','KASHMIRI KESAR 20ML','KASHMIRI KESAR 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:07',NULL),(592,'226',NULL,NULL,'04020',NULL,'','PINEAPPLE','PINEAPPLE','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:09',NULL),(593,'226',NULL,NULL,'04021',NULL,'','CHOCOLATE 20ML','CHOCOLATE 20ML','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:11',NULL),(594,'226',NULL,NULL,'04022',NULL,'','LIQUID PRESERVATIVE 1LTR','LIQUID PRESERVATIVE 1LTR','33021010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:13',NULL),(595,'226',NULL,NULL,'04023',NULL,'','pista badam mrp 30/-','pista badam mrp 30/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:15',NULL),(596,'226',NULL,NULL,'04024',NULL,'','milk cookies mrp 20/-','milk cookies mrp 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:17',NULL),(597,'226',NULL,NULL,'04025',NULL,'','choconut cookies mrp 20/-','choconut cookies mrp 20/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:19',NULL),(598,'226',NULL,NULL,'04026',NULL,'','SANITARY NAPKINS','SANITARY NAPKINS','96190030','NULL','3',NULL,'5','HUL','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HUL',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:21',NULL),(599,'226',NULL,NULL,'04027',NULL,'','MCVITTIES MRP 10/-','MCVITTIES MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:23',NULL),(600,'226',NULL,NULL,'04028',NULL,'','UNIBIC MRP 10/-','UNIBIC MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:24',NULL),(601,'226',NULL,NULL,'04029',NULL,'','MANGO DRINK 125 ML','MANGO DRINK 125 ML','22029020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:26',NULL),(602,'226',NULL,NULL,'04030',NULL,'','BIKAJI FARSAN MRP 10/-','BIKAJI FARSAN MRP 10/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','150000',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','150000','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:28',NULL),(603,'226',NULL,NULL,'04031',NULL,'','REAL GUAVA MRP 10/-','REAL GUAVA MRP 10/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:30',NULL),(604,'226',NULL,NULL,'04032',NULL,'','REAL LITCHI MRP 10/-','REAL LITCHI MRP 10/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:32',NULL),(605,'226',NULL,NULL,'04033',NULL,'','REAL APPLE MRP 10/-','REAL APPLE MRP 10/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:34',NULL),(606,'226',NULL,NULL,'04034',NULL,'','50-50 COCONUT','50-50 COCONUT','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:36',NULL),(607,'226',NULL,NULL,'04035',NULL,'','GD BUTTER','GD BUTTER','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','180',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:38',NULL),(608,'226',NULL,NULL,'04036',NULL,'','ORANGE SPLASH COOKIES','ORANGE SPLASH COOKIES','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:40',NULL),(609,'226',NULL,NULL,'04201',NULL,'','BIKANERI BHUJIA','BIKANERI BHUJIA','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:42',NULL),(610,'226',NULL,NULL,'04202',NULL,'','SOYA STICK MASALA','SOYA STICK MASALA','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:44',NULL),(611,'226',NULL,NULL,'04203',NULL,'','SOYA STICK TOMATO','SOYA STICK TOMATO','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:46',NULL),(612,'226',NULL,NULL,'04204',NULL,'','KHATTA MITHA','KHATTA MITHA','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:48',NULL),(613,'226',NULL,NULL,'04205',NULL,'','classic peanut mrp 10/-','classic peanut mrp 10/-','20081100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:50',NULL),(614,'226',NULL,NULL,'04206',NULL,'','TIGER CREAM MRP 5','TIGER CREAM MRP 5','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:51',NULL),(615,'226',NULL,NULL,'04207',NULL,'','MCVITTIES DIGESTIVE MRP 10/-','MCVITTIES DIGESTIVE MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:53',NULL),(616,'226',NULL,NULL,'04208',NULL,'','MCVITTIES BUTTER MRP 10/-','MCVITTIES BUTTER MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:55',NULL),(617,'226',NULL,NULL,'04209',NULL,'','MCVITTIES CASHEW MRP 10/-','MCVITTIES CASHEW MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:57',NULL),(618,'226',NULL,NULL,'04210',NULL,'','POMEGRANATE MRP 10/-','POMEGRANATE MRP 10/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:16:59',NULL),(619,'226',NULL,NULL,'04211',NULL,'','MIX FRUIT MRP 10/-','MIX FRUIT MRP 10/-','22029920','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:01',NULL),(620,'226',NULL,NULL,'04212',NULL,'','BHUJIA SEV 400GM','BHUJIA SEV 400GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:03',NULL),(621,'226',NULL,NULL,'04213',NULL,'','KHATTA MEETHA 400GM','KHATTA MEETHA 400GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:05',NULL),(622,'226',NULL,NULL,'04214',NULL,'','INST MATKA JHATKA MRP 20/-','INST MATKA JHATKA MRP 20/-','04039010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:07',NULL),(623,'226',NULL,NULL,'04215',NULL,'','MCVITTIES VANILLA CREAM MRP 30/-','MCVITTIES VANILLA CREAM MRP 30/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','84',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','84','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:09',NULL),(624,'226',NULL,NULL,'04216',NULL,'','MCVITTIES HOBNOB MRP 30/-','MCVITTIES HOBNOB MRP 30/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:11',NULL),(625,'226',NULL,NULL,'04217',NULL,'','MCVITTIES BOURBON MRP 30/-','MCVITTIES BOURBON MRP 30/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:13',NULL),(626,'226',NULL,NULL,'04218',NULL,'','CADBURY CELEBRATION 110/-','CADBURY CELEBRATION 110/-','18069090','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:15',NULL),(627,'226',NULL,NULL,'04220',NULL,'','MOONG DAL 400GM','MOONG DAL 400GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:17',NULL),(628,'226',NULL,NULL,'04221',NULL,'','INSTANT BHEL 400GM','INSTANT BHEL 400GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:19',NULL),(629,'226',NULL,NULL,'04222',NULL,'','TASTY NUT 400GM','TASTY NUT 400GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:21',NULL),(630,'226',NULL,NULL,'04223',NULL,'','GARLIC MIXTURE MRP 20/-','GARLIC MIXTURE MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:23',NULL),(631,'226',NULL,NULL,'04224',NULL,'','BUTTER RIBBON MURRUKKU MRP 20/-','BUTTER RIBBON MURRUKKU MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:24',NULL),(632,'226',NULL,NULL,'04225',NULL,'','BUTTER MURRUKKU MRP 20/-','BUTTER MURRUKKU MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:26',NULL),(633,'226',NULL,NULL,'04226',NULL,'','PANCHRATNA MIXTURE MRP 85/-','PANCHRATNA MIXTURE MRP 85/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:28',NULL),(634,'226',NULL,NULL,'04227',NULL,'','CLASSIC LASSI INST','CLASSIC LASSI INST','04039010','NULL','3',NULL,'7','FOOD PRODUCT','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:30',NULL),(635,'226',NULL,NULL,'04228',NULL,'','BOUNCE ORANGE MRP 10/-','BOUNCE ORANGE MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:32',NULL),(636,'226',NULL,NULL,'04229',NULL,'','BOUNCE CHOCOLATE MRP 10/-','BOUNCE CHOCOLATE MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:34',NULL),(637,'226',NULL,NULL,'04230',NULL,'','BIKAJI ALOO BHUJIA MRP 10','BIKAJI ALOO BHUJIA MRP 10','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:36',NULL),(638,'226',NULL,NULL,'04231',NULL,'','ALL IN ONE','ALL IN ONE','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:38',NULL),(639,'226',NULL,NULL,'04232',NULL,'','NAVRATAN BIKAJI','NAVRATAN BIKAJI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:40',NULL),(640,'226',NULL,NULL,'04233',NULL,'','NUT CRACKER BIKAJI','NUT CRACKER BIKAJI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:42',NULL),(641,'226',NULL,NULL,'04234',NULL,'','TANA BANA BIKAJI','TANA BANA BIKAJI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:44',NULL),(642,'226',NULL,NULL,'04235',NULL,'','FARALI BIKAJI','FARALI BIKAJI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:46',NULL),(643,'226',NULL,NULL,'04236',NULL,'','BHUJIA MRP10','BHUJIA MRP10','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:48',NULL),(644,'226',NULL,NULL,'04237',NULL,'','SOYA STICK BIKAJI','SOYA STICK BIKAJI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','288',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:50',NULL),(645,'226',NULL,NULL,'04238',NULL,'','PANCHRATNA BIKAJI','PANCHRATNA BIKAJI','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:52',NULL),(646,'226',NULL,NULL,'04239',NULL,'','KESARI 40KG','KESARI 40KG','33203020','NULL','3',NULL,'7','FOOD PRODUCT','3','3','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:54',NULL),(647,'226',NULL,NULL,'05001',NULL,'','KESAR MODAK','KESAR MODAK','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:56',NULL),(648,'226',NULL,NULL,'05002',NULL,'','SHAHI MODAK','SHAHI MODAK','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:17:58',NULL),(649,'226',NULL,NULL,'05003',NULL,'','KAJU MODAK 230GM','KAJU MODAK 230GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:00',NULL),(650,'226',NULL,NULL,'05004',NULL,'','PARLE RUSK','PARLE RUSK','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:02',NULL),(651,'226',NULL,NULL,'05005',NULL,'','RIKRAK WAFFY MRP 10','RIKRAK WAFFY MRP 10','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:04',NULL),(652,'226',NULL,NULL,'05006',NULL,'','CHEESE TWIST MRP 5','CHEESE TWIST MRP 5','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','320',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','320','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:06',NULL),(653,'226',NULL,NULL,'05007',NULL,'','TYOHAAR','TYOHAAR','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:08',NULL),(654,'226',NULL,NULL,'05008',NULL,'','TIME PASS','TIME PASS','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:10',NULL),(655,'226',NULL,NULL,'05009',NULL,'','INSTANT BHEL MRP 20/-','INSTANT BHEL MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','75',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','75','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:12',NULL),(656,'226',NULL,NULL,'05010',NULL,'','PUNJABI TADKA MRP 20/-','PUNJABI TADKA MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:14',NULL),(657,'226',NULL,NULL,'05011',NULL,'','SOAN CAKE 200GM','SOAN CAKE 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:16',NULL),(658,'226',NULL,NULL,'05012',NULL,'','MEOW CHIPS MRP 20/-','MEOW CHIPS MRP 20/-','20052000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','70',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','70','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:18',NULL),(659,'226',NULL,NULL,'06001',NULL,'','MILK COOKIES MRP 10/-','MILK COOKIES MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:20',NULL),(660,'226',NULL,NULL,'06002',NULL,'','OATS MRP 10/-','OATS MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:22',NULL),(661,'226',NULL,NULL,'06003',NULL,'','CHOCO RIPPLE MRP 10/-','CHOCO RIPPLE MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:24',NULL),(662,'226',NULL,NULL,'06004',NULL,'','CHOCO HAZELNUT MRP 10/-','CHOCO HAZELNUT MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:26',NULL),(663,'226',NULL,NULL,'06005',NULL,'','CASHEW BADAM MRP 10/-','CASHEW BADAM MRP 10/-','19053100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:28',NULL),(664,'226',NULL,NULL,'07001',NULL,'','ALOO BHUJIA 200GM','ALOO BHUJIA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:30',NULL),(665,'226',NULL,NULL,'07002',NULL,'','CORNFLAKES MIXTURE 200GM','CORNFLAKES MIXTURE 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:32',NULL),(666,'226',NULL,NULL,'07003',NULL,'','KHARI BOONDI 200GM','KHARI BOONDI 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:34',NULL),(667,'226',NULL,NULL,'07004',NULL,'','MINI SAMOSA 200GM','MINI SAMOSA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:36',NULL),(668,'226',NULL,NULL,'07005',NULL,'','NAVRATAN MIX','NAVRATAN MIX','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:38',NULL),(669,'226',NULL,NULL,'07006',NULL,'','SOANPAPDI 500GM','SOANPAPDI 500GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:40',NULL),(670,'226',NULL,NULL,'07007',NULL,'','AGRA PETHA 200GM','AGRA PETHA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:42',NULL),(671,'226',NULL,NULL,'07008',NULL,'','BHELPURI 270GM','BHELPURI 270GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:43',NULL),(672,'226',NULL,NULL,'07009',NULL,'','CHANA JOR GARAM 200GM','CHANA JOR GARAM 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:46',NULL),(673,'226',NULL,NULL,'07010',NULL,'','GATHIYA 200GM','GATHIYA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:48',NULL),(674,'226',NULL,NULL,'07011',NULL,'','KHATTA MEETHA 200GM','KHATTA MEETHA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:50',NULL),(675,'226',NULL,NULL,'07012',NULL,'','MATHRI 200GM','MATHRI 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:52',NULL),(676,'226',NULL,NULL,'07013',NULL,'','MINI BHAKARWADI 200GM','MINI BHAKARWADI 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:54',NULL),(677,'226',NULL,NULL,'07014',NULL,'','MURUKKU 200GM','MURUKKU 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:56',NULL),(678,'226',NULL,NULL,'07015',NULL,'','MOONG DAL 200GM','MOONG DAL 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','62',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','62','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:18:58',NULL),(679,'226',NULL,NULL,'07016',NULL,'','RATLAMI SEV 200GM','RATLAMI SEV 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:01',NULL),(680,'226',NULL,NULL,'07017',NULL,'','SALTED PEANUT 200GM','SALTED PEANUT 200GM','20081100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:04',NULL),(681,'226',NULL,NULL,'07018',NULL,'','RASGULLA 1KG','RASGULLA 1KG','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:07',NULL),(682,'226',NULL,NULL,'07019',NULL,'','COCONUT SOANPAPDI 250GM','COCONUT SOANPAPDI 250GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:11',NULL),(683,'226',NULL,NULL,'07020',NULL,'','BADAM HALWA 200GM','BADAM HALWA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:15',NULL),(684,'226',NULL,NULL,'07021',NULL,'','SOANPAPDI REGULAR 250GM','SOANPAPDI REGULAR 250GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:19',NULL),(685,'226',NULL,NULL,'07031',NULL,'','CUSTARD POWDER','CUSTARD POWDER','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:24',NULL),(686,'226',NULL,NULL,'07032',NULL,'','FARALI CHIWDA MRP20/-','FARALI CHIWDA MRP20/-','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:28',NULL),(687,'226',NULL,NULL,'07040',NULL,'','GOLDEN MIXTURE 200GM','GOLDEN MIXTURE 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:31',NULL),(688,'226',NULL,NULL,'07041',NULL,'','ORANGE SOANPAPDI 250GM','ORANGE SOANPAPDI 250GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:34',NULL),(689,'226',NULL,NULL,'07042',NULL,'','SOYA STICKS 200GM','SOYA STICKS 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:38',NULL),(690,'226',NULL,NULL,'07043',NULL,'','MEOW BLACK MAGIC','MEOW BLACK MAGIC','20052000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','70',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','70','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:42',NULL),(691,'226',NULL,NULL,'07044',NULL,'','MEOW PERI PERI','MEOW PERI PERI','20052000','NULL','3',NULL,'7','FOOD PRODUCT','7','7','70',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','70','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:47',NULL),(692,'226',NULL,NULL,'07045',NULL,'','SMOOTH KESAR BADAM','SMOOTH KESAR BADAM','04029990','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:52',NULL),(693,'226',NULL,NULL,'07046',NULL,'','NUT CRACKER','NUT CRACKER','20081999','NULL','3',NULL,'7','FOOD PRODUCT','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:19:58',NULL),(694,'226',NULL,NULL,'07047',NULL,'','FABIO VANILA 50G','FABIO VANILA 50G','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:04',NULL),(695,'226',NULL,NULL,'07048',NULL,'','KRACKJACK 35/-','KRACKJACK 35/-','19059020','NULL','3',NULL,'7','FOOD PRODUCT','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:10',NULL),(696,'226',NULL,NULL,'07049',NULL,'','LITE CHIWDA MRP 20/-','LITE CHIWDA MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:14',NULL),(697,'226',NULL,NULL,'07050',NULL,'','NUT CRACKER MRP 20/-','NUT CRACKER MRP 20/-','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:20',NULL),(698,'226',NULL,NULL,'07051',NULL,'','ROASTED CRUSHED PEANUT 1KG','ROASTED CRUSHED PEANUT 1KG','20081100','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:26',NULL),(699,'226',NULL,NULL,'08001',NULL,'','KHATTA MEETHA 1KG','KHATTA MEETHA 1KG','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:31',NULL),(700,'226',NULL,NULL,'08002',NULL,'','BHUJIA SEV 1KG','BHUJIA SEV 1KG','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:37',NULL),(701,'226',NULL,NULL,'08003',NULL,'','ALOO BHUJIA 1KG','ALOO BHUJIA 1KG','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','13',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','13','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:41',NULL),(702,'226',NULL,NULL,'08004',NULL,'','BHUJIA SEV 600GM','BHUJIA SEV 600GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:44',NULL),(703,'226',NULL,NULL,'08005',NULL,'','PHALAHARI CHIWDA 200GM','PHALAHARI CHIWDA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:48',NULL),(704,'226',NULL,NULL,'08006',NULL,'','LITE CHIWDA 200GM','LITE CHIWDA 200GM','21069099','NULL','3',NULL,'7','FOOD PRODUCT','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:52',NULL),(705,'226',NULL,NULL,'08007',NULL,'','PUNJABI TADKA 200GM','PUNJABI TADKA 200GM','21069099','NULL','3',NULL,'1','HALDIRAM NAMKIN','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','HALDIRAM NAMKIN',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:56',NULL),(706,'226',NULL,NULL,'04501',NULL,'','HALDIRAM SHARBAT 750 ML','HALDIRAM SHARBAT 750 ML','20089919','NULL','3',NULL,'7','FOOD PRODUCT','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','FOOD PRODUCT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-03-25 10:20:59',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'226',NULL,NULL,'HALDIRAM NAMKIN','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06'),(2,'226',NULL,NULL,'PAPL','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06'),(3,'226',NULL,NULL,'MOJO BAR','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06'),(4,'226',NULL,NULL,'KOHINOOR','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06'),(5,'226',NULL,NULL,'HUL','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06'),(6,'226',NULL,NULL,'PARLE AGRO','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06'),(7,'226',NULL,NULL,'FOOD PRODUCT','1',NULL,NULL,NULL,NULL,NULL,'342','342',NULL,0,'2026-03-25 10:02:06','2026-03-25 10:02:06');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=712 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'226',NULL,NULL,'1','1592038391102','13-06-2020','1970-01-01','001','0','21361','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:07',NULL),(2,'226',NULL,NULL,'2','1592038391239','13-06-2020','1970-01-01','00110','0','4044','0.00','5','3.57139992713928','0','3.3482','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:08',NULL),(3,'226',NULL,NULL,'3','1592038391369','13-06-2020','1970-01-01','00111','0','336','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:09',NULL),(4,'226',NULL,NULL,'4','1592038391487','13-06-2020','1970-01-01','002','0','3600','0.00','10','7.14279985427856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:10',NULL),(5,'226',NULL,NULL,'5','1592038391633','13-06-2020','1970-01-01','003','0','22408','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:10',NULL),(6,'226',NULL,NULL,'6','1592038391837','13-06-2020','1970-01-01','004','0','18812','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:11',NULL),(7,'226',NULL,NULL,'7','1592038391943','13-06-2020','1970-01-01','005','0','24852','0.00','10','7.14279985427856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:12',NULL),(8,'226',NULL,NULL,'8','1592038392043','13-06-2020','1970-01-01','006','0','58','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:13',NULL),(9,'226',NULL,NULL,'9','1592038392142','13-06-2020','1970-01-01','0064','0','402','0.00','60','35.5932006835938','0','35.3199996948242','0','0.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:14',NULL),(10,'226',NULL,NULL,'10','1592038392250','13-06-2020','1970-01-01','0065','0','1176','0.00','35','20.7700004577637','0','20.5599994659424','0','0.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:14',NULL),(11,'226',NULL,NULL,'11','1592038392354','13-06-2020','1970-01-01','0066','0','1152','0.00','40','23.7299995422363','0','23.5599994659424','0','0.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:15',NULL),(12,'226',NULL,NULL,'12','1592038392455','13-06-2020','1970-01-01','0067','0','1776','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:16',NULL),(13,'226',NULL,NULL,'13','1592038392559','13-06-2020','1970-01-01','0068','0','11844','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:17',NULL),(14,'226',NULL,NULL,'14','1592038392652','13-06-2020','1970-01-01','0069','0','1296','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:18',NULL),(15,'226',NULL,NULL,'15','1592038392773','13-06-2020','1970-01-01','007','0','90','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:19',NULL),(16,'226',NULL,NULL,'16','1592038392892','13-06-2020','1970-01-01','0071','0','2760','0.00','65','38.560001373291','0','37.560001373291','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:20',NULL),(17,'226',NULL,NULL,'17','1592038392986','13-06-2020','1970-01-01','0072','0','1940','0.00','20','15','0','13','0','2.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:21',NULL),(18,'226',NULL,NULL,'18','1592038393094','13-06-2020','1970-01-01','0074','9.87','1185','0.00','15','10.5','0','9.87','0','0.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:22',NULL),(19,'226',NULL,NULL,'19','1592038393192','13-06-2020','1970-01-01','0075','0','2264','0.00','10','7.57999992370605','0','6.25','0','1.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:23',NULL),(20,'226',NULL,NULL,'20','1592038393308','13-06-2020','1970-01-01','0076','0','14430','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:24',NULL),(21,'226',NULL,NULL,'21','1592038393529','13-06-2020','1970-01-01','0077','0','8475','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:25',NULL),(22,'226',NULL,NULL,'22','1592038393675','13-06-2020','1970-01-01','0078','0','4570.670000000042','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:26',NULL),(23,'226',NULL,NULL,'23','1592038393824','13-06-2020','1970-01-01','0079','0','79994','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:27',NULL),(24,'226',NULL,NULL,'24','1592038393917','13-06-2020','1970-01-01','008','0','1410','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:29',NULL),(25,'226',NULL,NULL,'25','1592038394025','13-06-2020','1970-01-01','0080','0','37788','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:30',NULL),(26,'226',NULL,NULL,'26','1592038394129','13-06-2020','1970-01-01','0081','0','20125','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:30',NULL),(27,'226',NULL,NULL,'27','1592038394217','13-06-2020','1970-01-01','0082','0','25901','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:31',NULL),(28,'226',NULL,NULL,'28','1592038394335','13-06-2020','1970-01-01','0083','0','29038','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:32',NULL),(29,'226',NULL,NULL,'29','1592038394446','13-06-2020','1970-01-01','0084','0','18267','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:33',NULL),(30,'226',NULL,NULL,'30','1592038394566','13-06-2020','1970-01-01','0085','0','9257','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:34',NULL),(31,'226',NULL,NULL,'31','1592038394667','13-06-2020','1970-01-01','0086','0','15301','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:35',NULL),(32,'226',NULL,NULL,'32','1592038394751','13-06-2020','1970-01-01','0087','0','978','0.00','10','7.54699993133545','0','6.60379981994629','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:36',NULL),(33,'226',NULL,NULL,'33','1592038394833','13-06-2020','1970-01-01','0088','0','35260','0.00','10','7.54699993133545','0','6.60379981994629','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:37',NULL),(34,'226',NULL,NULL,'34','1592038394917','13-06-2020','1970-01-01','0089','0','1449','0.00','10','7.54699993133545','0','6.60379981994629','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:38',NULL),(35,'226',NULL,NULL,'35','1592038395000','13-06-2020','1970-01-01','009','0','0','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:39',NULL),(36,'226',NULL,NULL,'36','1592038395083','13-06-2020','1970-01-01','0090','0','49234','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:40',NULL),(37,'226',NULL,NULL,'37','1592038395170','13-06-2020','1970-01-01','0091','0','17229','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:41',NULL),(38,'226',NULL,NULL,'38','1592038395265','13-06-2020','1970-01-01','0092','0','39301','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:42',NULL),(39,'226',NULL,NULL,'39','1592038395367','13-06-2020','1970-01-01','0093','0','53624','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:43',NULL),(40,'226',NULL,NULL,'40','1592038395451','13-06-2020','1970-01-01','0094','0','21407','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:44',NULL),(41,'226',NULL,NULL,'41','1592038395534','13-06-2020','1970-01-01','0095','0','48630','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:45',NULL),(42,'226',NULL,NULL,'42','1592038395650','13-06-2020','1970-01-01','0096','0','3817','0.00','10','7.54699993133545','0','6.60379981994629','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:46',NULL),(43,'226',NULL,NULL,'43','1592038395734','13-06-2020','1970-01-01','0097','0','0','0.00','10','7.54699993133545','0','6.60379981994629','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:47',NULL),(44,'226',NULL,NULL,'44','1592038395819','13-06-2020','1970-01-01','0098','0','7','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:48',NULL),(45,'226',NULL,NULL,'45','1592038395903','13-06-2020','1970-01-01','0099','0','8840','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:50',NULL),(46,'226',NULL,NULL,'46','1592038395986','13-06-2020','1970-01-01','01','0','7772','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:51',NULL),(47,'226',NULL,NULL,'47','1592038396070','13-06-2020','1970-01-01','010','0','22675','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:52',NULL),(48,'226',NULL,NULL,'48','1592038396152','13-06-2020','1970-01-01','0113','0','32592','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:53',NULL),(49,'226',NULL,NULL,'49','1592038396237','13-06-2020','1970-01-01','0114','0','3551','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:54',NULL),(50,'226',NULL,NULL,'50','1592038396320','13-06-2020','1970-01-01','0115','0','9215','0.00','10','7.54699993133545','0','6.603','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:55',NULL),(51,'226',NULL,NULL,'51','1592038396406','13-06-2020','1970-01-01','0123','0','1596','0.00','10','7.54699993133545','0','6.666','0','0.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:56',NULL),(52,'226',NULL,NULL,'52','1592038396519','13-06-2020','1970-01-01','0130','0','10066','0.00','10','7.54699993133545','0','6.25','0','1.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:57',NULL),(53,'226',NULL,NULL,'53','1592038396599','13-06-2020','1970-01-01','0131','0','35676','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:58',NULL),(54,'226',NULL,NULL,'54','1592038396693','13-06-2020','1970-01-01','0132','0','13608','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:02:59',NULL),(55,'226',NULL,NULL,'55','1592038396775','13-06-2020','1970-01-01','0133','0','22249','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:00',NULL),(56,'226',NULL,NULL,'56','1592038396859','13-06-2020','1970-01-01','0134','0','7092','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:01',NULL),(57,'226',NULL,NULL,'57','1592038396942','13-06-2020','1970-01-01','0135','0','28356','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:02',NULL),(58,'226',NULL,NULL,'58','1592038397036','13-06-2020','1970-01-01','0136','0','25500','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:03',NULL),(59,'226',NULL,NULL,'59','1592038397128','13-06-2020','1970-01-01','0137','0','4392','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:04',NULL),(60,'226',NULL,NULL,'60','1592038397209','13-06-2020','1970-01-01','0138','0','17088','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:05',NULL),(61,'226',NULL,NULL,'61','1592038397292','13-06-2020','1970-01-01','0148','32.16','3460','0.00','40','34.86','0','34.86','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:06',NULL),(62,'226',NULL,NULL,'62','1592038397385','13-06-2020','1970-01-01','0157','0','0','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:07',NULL),(63,'226',NULL,NULL,'63','1592038397459','13-06-2020','1970-01-01','0160','0','0','0.00','0','23.7700004577637','0','23.7600002288818','0','0.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:08',NULL),(64,'226',NULL,NULL,'64','1592038397536','13-06-2020','1970-01-01','0161','0','520','0.00','70','39.6100006103516','0','39.6100006103516','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:09',NULL),(65,'226',NULL,NULL,'65','1592038397626','13-06-2020','1970-01-01','0162','0','960','0.00','60','48.5699996948242','0','45.4199981689453','0','3.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:10',NULL),(66,'226',NULL,NULL,'66','1592038397711','13-06-2020','1970-01-01','0163','0','1080','0.00','65','48.5699996948242','0','45.4199981689453','0','3.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:11',NULL),(67,'226',NULL,NULL,'67','1592038397787','13-06-2020','1970-01-01','0167','0','0','0.00','490','376.790008544922','0','366.160003662109','0','10.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:12',NULL),(68,'226',NULL,NULL,'68','1592038397887','13-06-2020','1970-01-01','0168','0','0','0.00','0','614','0','528','0','86.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:13',NULL),(69,'226',NULL,NULL,'69','1592038398028','13-06-2020','1970-01-01','0169','140','0','0.00','0','160','0','140','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:14',NULL),(70,'226',NULL,NULL,'70','1592038398137','13-06-2020','1970-01-01','0176','0','3818','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:15',NULL),(71,'226',NULL,NULL,'71','1592038398258','13-06-2020','1970-01-01','0177','0','3420','0.00','0','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:16',NULL),(72,'226',NULL,NULL,'72','1592038398382','13-06-2020','1970-01-01','0178','0','0','0.00','355','290.170013427734','0','269.640014648438','0','20.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:18',NULL),(73,'226',NULL,NULL,'73','1592038398522','13-06-2020','1970-01-01','0179','0','0','0.00','148','99.1100006103516','0','93.4899978637695','0','5.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:18',NULL),(74,'226',NULL,NULL,'74','1592038398642','13-06-2020','1970-01-01','0180','0','13176','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:19',NULL),(75,'226',NULL,NULL,'75','1592038398782','13-06-2020','1970-01-01','0182','0','12060','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:20',NULL),(76,'226',NULL,NULL,'76','1592038398893','13-06-2020','1970-01-01','0184','0','0','0.00','10','175','0','160','0','15.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:21',NULL),(77,'226',NULL,NULL,'77','1592038399003','13-06-2020','1970-01-01','0185','0','1608','0.00','12','6.3600001335144','0','5.72','0','0.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:22',NULL),(78,'226',NULL,NULL,'78','1592038399103','13-06-2020','1970-01-01','0186','0','0','0.00','149','113.559997558594','0','107.330001831055','0','6.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:23',NULL),(79,'226',NULL,NULL,'79','1592038399192','13-06-2020','1970-01-01','0195','0','748','0.00','40','4.11999988555908','0','3.35','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:24',NULL),(80,'226',NULL,NULL,'80','1592038399282','13-06-2020','1970-01-01','0196','0','0','0.00','30','18.75','0','18','0','0.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:25',NULL),(81,'226',NULL,NULL,'81','1592038399365','13-06-2020','1970-01-01','0197','0','0','0.00','30','18.75','0','18','0','0.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:26',NULL),(82,'226',NULL,NULL,'82','1592038399432','13-06-2020','1970-01-01','0198','0','0','0.00','30','18.75','0','18','0','0.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:27',NULL),(83,'226',NULL,NULL,'83','1592038399532','13-06-2020','1970-01-01','0199','0','0','0.00','25','15.6300001144409','0','14.5100002288818','0','1.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:28',NULL),(84,'226',NULL,NULL,'84','1592038399624','13-06-2020','1970-01-01','0200','0','0','0.00','25','15.6300001144409','0','14.5100002288818','0','1.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:29',NULL),(85,'226',NULL,NULL,'85','1592038399707','13-06-2020','1970-01-01','0201','0','15576','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:30',NULL),(86,'226',NULL,NULL,'86','1592038399793','13-06-2020','1970-01-01','0202','0','0','0.00','50','31.7800006866455','0','29.6599998474121','0','2.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:31',NULL),(87,'226',NULL,NULL,'87','1592038399909','13-06-2020','1970-01-01','0203','0','2328','0.00','10','6.3600001335144','0','5.51000022888184','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:32',NULL),(88,'226',NULL,NULL,'88','1592038400012','13-06-2020','1970-01-01','0204','0','0','0.00','20','12.5','0','12','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:33',NULL),(89,'226',NULL,NULL,'89','1592038400099','13-06-2020','1970-01-01','0205','0','0','0.00','49','32.6699981689453','0','29.7000007629395','0','2.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:34',NULL),(90,'226',NULL,NULL,'90','1592038400183','13-06-2020','1970-01-01','0206','0','0','0.00','49','32.6699981689453','0','29.7000007629395','0','2.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:35',NULL),(91,'226',NULL,NULL,'91','1592038400268','13-06-2020','1970-01-01','0207','0','0','0.00','500','500','0','0','0','500.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:36',NULL),(92,'226',NULL,NULL,'92','1592038400366','13-06-2020','1970-01-01','0208','0','0','0.00','30','18.75','0','16.0699996948242','0','2.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:37',NULL),(93,'226',NULL,NULL,'93','1592038400451','13-06-2020','1970-01-01','0209','0','0','0.00','50','22.3199996948242','0','19.6399993896484','0','2.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:38',NULL),(94,'226',NULL,NULL,'94','1592038400542','13-06-2020','1970-01-01','0210','0','1686','0.00','5','4','0','3','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:39',NULL),(95,'226',NULL,NULL,'95','1592038400633','13-06-2020','1970-01-01','0211','0','11600','0.00','15','12','0','12.2399997711182','0','-0.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:40',NULL),(96,'226',NULL,NULL,'96','1592038400724','13-06-2020','1970-01-01','0212','10','1090','0.00','20','11.24','0','10','0','1.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:41',NULL),(97,'226',NULL,NULL,'97','1592038400850','13-06-2020','1970-01-01','0213','0','13960','0.00','5','4.11999988555908','0','3.3482','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:42',NULL),(98,'226',NULL,NULL,'98','1592038400983','13-06-2020','1970-01-01','0214','0','16','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:43',NULL),(99,'226',NULL,NULL,'99','1592038401083','13-06-2020','1970-01-01','0215','0','7200','0.00','0','111.910003662109','0','109.51000213623','0','2.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:44',NULL),(100,'226',NULL,NULL,'100','1592038401190','13-06-2020','1970-01-01','0224','0','3','0.00','140','0','0','98','0','-98.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:45',NULL),(101,'226',NULL,NULL,'101','1592038401314','13-06-2020','1970-01-01','0225','0','539','0.00','610','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:46',NULL),(102,'226',NULL,NULL,'102','1592038401433','13-06-2020','1970-01-01','0226','0','0','0.00','150','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:47',NULL),(103,'226',NULL,NULL,'103','1592038401554','13-06-2020','1970-01-01','0227','0','0','0.00','150','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:48',NULL),(104,'226',NULL,NULL,'104','1592038401783','13-06-2020','1970-01-01','0228','0','8575','0.00','30','17.8600006103516','0','18.75','0','-0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:50',NULL),(105,'226',NULL,NULL,'105','1592038401899','13-06-2020','1970-01-01','0229','16.66','31102','0.00','25','19.04','0','16.67','0','2.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:51',NULL),(106,'226',NULL,NULL,'106','1592038401991','13-06-2020','1970-01-01','0230','0','0','0.00','10','7.58930015563965','0','6.55000019073486','0','1.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:52',NULL),(107,'226',NULL,NULL,'107','1592038402084','13-06-2020','1970-01-01','0231','0','14400','0.00','15','11.1599998474121','0','10.5100002288818','0','0.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:53',NULL),(108,'226',NULL,NULL,'108','1592038402174','13-06-2020','1970-01-01','0232','0','0','0.00','140','114.290000915527','0','114.290000915527','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:54',NULL),(109,'226',NULL,NULL,'109','1592038402274','13-06-2020','1970-01-01','0233','0','1080','0.00','270','180.949996948242','0','175.960006713867','0','4.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:55',NULL),(110,'226',NULL,NULL,'110','1592038402376','13-06-2020','1970-01-01','0234','0','0','0.00','0','70','0','64.7600021362305','0','5.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:56',NULL),(111,'226',NULL,NULL,'111','1592038402470','13-06-2020','1970-01-01','0235','0','0','0.00','0','84','0','69.4899978637695','0','14.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:57',NULL),(112,'226',NULL,NULL,'112','1592038402566','13-06-2020','1970-01-01','0236','0','9480','0.00','0','93.75','0','92.8600006103516','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:58',NULL),(113,'226',NULL,NULL,'113','1592038402683','13-06-2020','1970-01-01','0237','0','8968','0.00','0','95.5299987792969','0','94.6500015258789','0','0.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:03:59',NULL),(114,'226',NULL,NULL,'114','1592038402775','13-06-2020','1970-01-01','0238','0','3428','0.00','135','110.713996887207','0','110.709999084473','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:00',NULL),(115,'226',NULL,NULL,'115','1592038402874','13-06-2020','1970-01-01','0239','0','0','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:01',NULL),(116,'226',NULL,NULL,'116','1592038402976','13-06-2020','1970-01-01','0240','0','0','0.00','150','0','0','98.0999984741211','0','-98.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:02',NULL),(117,'226',NULL,NULL,'117','1592038403076','13-06-2020','1970-01-01','0241','0','11','0.00','450','0','0','357.140014648438','0','-357.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:03',NULL),(118,'226',NULL,NULL,'118','1592038403212','13-06-2020','1970-01-01','0242','0','0','0.00','0','366.670013427734','0','357.140014648438','0','9.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:04',NULL),(119,'226',NULL,NULL,'119','1592038403315','13-06-2020','1970-01-01','0243','0','0','0.00','0','6.3600001335144','0','5.07999992370605','0','1.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:05',NULL),(120,'226',NULL,NULL,'120','1592038403415','13-06-2020','1970-01-01','0244','0','0','0.00','1','0.779999971389771','0','0.740000009536743','0','0.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:07',NULL),(121,'226',NULL,NULL,'121','1592038403510','13-06-2020','1970-01-01','0245','0','0','0.00','78','60.7099990844727','0','56.25','0','4.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:08',NULL),(122,'226',NULL,NULL,'122','1592038403637','13-06-2020','1970-01-01','0246','0','25960','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:09',NULL),(123,'226',NULL,NULL,'123','1592038403752','13-06-2020','1970-01-01','0247','0','0','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:10',NULL),(124,'226',NULL,NULL,'124','1592038403862','13-06-2020','1970-01-01','0248','0','432','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:11',NULL),(125,'226',NULL,NULL,'125','1592038403959','13-06-2020','1970-01-01','0249','0','1236','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:12',NULL),(126,'226',NULL,NULL,'126','1592038404065','13-06-2020','1970-01-01','0250','0','978','0.00','165','141.559997558594','0','140.649993896484','0','0.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:13',NULL),(127,'226',NULL,NULL,'127','1592038404165','13-06-2020','1970-01-01','0251','0','645','0.00','68','60.9500007629395','0','60','0','0.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:14',NULL),(128,'226',NULL,NULL,'128','1592038404265','13-06-2020','1970-01-01','0252','0','0','0.00','45','21.4300003051758','0','20.0300006866455','0','1.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:15',NULL),(129,'226',NULL,NULL,'129','1592038404382','13-06-2020','1970-01-01','0253','0','876','0.00','137','91.0699996948242','0','83.9300003051758','0','7.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:17',NULL),(130,'226',NULL,NULL,'130','1592038404508','13-06-2020','1970-01-01','0254','0','7788','0.00','10','7.14279985427856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:18',NULL),(131,'226',NULL,NULL,'131','1592038404615','13-06-2020','1970-01-01','0255','0','0','0.00','48','36.4300003051758','0','36.4300003051758','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:19',NULL),(132,'226',NULL,NULL,'132','1592038404715','13-06-2020','1970-01-01','0256','0','0','0.00','35','26.5699996948242','0','26.5699996948242','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:20',NULL),(133,'226',NULL,NULL,'133','1592038404825','13-06-2020','1970-01-01','0257','90.48','2165','0.00','125','101.75','0','90.48','0','11.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:21',NULL),(134,'226',NULL,NULL,'134','1592038404941','13-06-2020','1970-01-01','0258','0','3636','0.00','10','7.14279985427856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:22',NULL),(135,'226',NULL,NULL,'135','1592038405050','13-06-2020','1970-01-01','0259','0','4386','0.00','15','10.7143001556396','0','9.38000011444092','0','1.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:23',NULL),(136,'226',NULL,NULL,'136','1592038405149','13-06-2020','1970-01-01','0260','0','4600','0.00','15','10.7143001556396','0','9.38000011444092','0','1.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:24',NULL),(137,'226',NULL,NULL,'137','1592038405233','13-06-2020','1970-01-01','0261','0','0','0.00','10','5.93219995498657','0','7.6399998664856','0','-1.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:26',NULL),(138,'226',NULL,NULL,'138','1592038405316','13-06-2020','1970-01-01','0262','0','0','0.00','10','5.93219995498657','0','7.6399998664856','0','-1.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:27',NULL),(139,'226',NULL,NULL,'139','1592038405407','13-06-2020','1970-01-01','0263','0','840','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:28',NULL),(140,'226',NULL,NULL,'140','1592038405500','13-06-2020','1970-01-01','0264','0','768','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:29',NULL),(141,'226',NULL,NULL,'141','1592038405607','13-06-2020','1970-01-01','0265','0','2247','0.00','5','3.57139992713928','0','3.35','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:30',NULL),(142,'226',NULL,NULL,'142','1592038405807','13-06-2020','1970-01-01','0266','0','3888','0.00','5','3.57139992713928','0','3.3482','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:31',NULL),(143,'226',NULL,NULL,'143','1592038405914','13-06-2020','1970-01-01','0267','0','480','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:32',NULL),(144,'226',NULL,NULL,'144','1592038406023','13-06-2020','1970-01-01','0268','0','6792','0.00','5','3.5699999332428','0','3.5714','0','-0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:34',NULL),(145,'226',NULL,NULL,'145','1592038406157','13-06-2020','1970-01-01','0269','0','720','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:35',NULL),(146,'226',NULL,NULL,'146','1592038406289','13-06-2020','1970-01-01','0270','0','6590','0.00','5','3.57139992713928','0','3.2467','0','0.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:36',NULL),(147,'226',NULL,NULL,'147','1592038406373','13-06-2020','1970-01-01','0271','0','3871','0.00','5','3.57139992713928','0','3.3482','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:37',NULL),(148,'226',NULL,NULL,'148','1592038406500','13-06-2020','1970-01-01','0272','0','240','0.00','5','3.57139992713928','0','3.34999990463257','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:38',NULL),(149,'226',NULL,NULL,'149','1592038406623','13-06-2020','1970-01-01','0273','0','10993','0.00','10','7.14279985427856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:39',NULL),(150,'226',NULL,NULL,'150','1592038406707','13-06-2020','1970-01-01','0274','0','74176','0.00','5','3.57139992713928','0','3.3482','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:41',NULL),(151,'226',NULL,NULL,'151','1592038406790','13-06-2020','1970-01-01','0275','0','10064','0.00','5','3.57139992713928','0','3.3482','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:42',NULL),(152,'226',NULL,NULL,'152','1592038406874','13-06-2020','1970-01-01','0276','0','70959','0.00','5','3.51999998092651','0','3.25','0','0.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:43',NULL),(153,'226',NULL,NULL,'153','1592038406974','13-06-2020','1970-01-01','0277','0','15','0.00','50','39.8199996948242','0','37.5099983215332','0','2.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:44',NULL),(154,'226',NULL,NULL,'154','1592038407074','13-06-2020','1970-01-01','0278','0','24686','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:45',NULL),(155,'226',NULL,NULL,'155','1592038407157','13-06-2020','1970-01-01','0279','0','0','0.00','10','7.1399998664856','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:46',NULL),(156,'226',NULL,NULL,'156','1592038407257','13-06-2020','1970-01-01','0280','0','924','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:48',NULL),(157,'226',NULL,NULL,'157','1592038407341','13-06-2020','1970-01-01','0281','0','0','0.00','50','40.1500015258789','0','37.5200004577637','0','2.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:49',NULL),(158,'226',NULL,NULL,'158','1592038407421','13-06-2020','1970-01-01','0282','0','0','0.00','0','212','0','200','0','12.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:50',NULL),(159,'226',NULL,NULL,'159','1592038407508','13-06-2020','1970-01-01','0283','53.33','9359','0.00','75','57.95','0','53.33','0','4.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:51',NULL),(160,'226',NULL,NULL,'160','1592038407599','13-06-2020','1970-01-01','0289','166.67','338','0.00','225','189.81','0','166.67','0','23.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:52',NULL),(161,'226',NULL,NULL,'161','1592038407715','13-06-2020','1970-01-01','1617776268384','0','0','0.00','185','153.363098144531','0','143.330001831055','0','10.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:53',NULL),(162,'226',NULL,NULL,'162','1592038407815','13-06-2020','1970-01-01','0291','0','58','0.00','5','3.57999992370605','0','3.33999991416931','0','0.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:55',NULL),(163,'226',NULL,NULL,'163','1592038407916','13-06-2020','1970-01-01','0292','0','1229','0.00','125','80.9499969482422','0','76.7300033569336','0','4.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:56',NULL),(164,'226',NULL,NULL,'164','1592038408008','13-06-2020','1970-01-01','0296','0','1032','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:57',NULL),(165,'226',NULL,NULL,'165','1592038408122','13-06-2020','1970-01-01','0297','0','768','0.00','10','7.14289999008179','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:58',NULL),(166,'226',NULL,NULL,'166','1592038408230','13-06-2020','1970-01-01','0298','0','1872','0.00','10','5.94000005722046','0','5.07999992370605','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:04:59',NULL),(167,'226',NULL,NULL,'167','1592038408344','13-06-2020','1970-01-01','0300','0','90','0.00','60','35.5999984741211','0','34.3199996948242','0','1.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:00',NULL),(168,'226',NULL,NULL,'168','1592038408466','13-06-2020','1970-01-01','0301','0','24','0.00','60','35.5999984741211','0','34.3199996948242','0','1.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:02',NULL),(169,'226',NULL,NULL,'169','1592038408583','13-06-2020','1970-01-01','0302','0','78','0.00','60','35.5999984741211','0','34.3199996948242','0','1.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:03',NULL),(170,'226',NULL,NULL,'170','1592038408700','13-06-2020','1970-01-01','0303','0','0','0.00','70','41.5200004577637','0','40.0400009155273','0','1.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:04',NULL),(171,'226',NULL,NULL,'171','1592038408800','23-08-2021','1970-01-01','0311','130','124','0.00','0','160','0','130','0','30.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:05',NULL),(172,'226',NULL,NULL,'172','1592038408914','13-06-2020','1970-01-01','0312','120','0','0.00','0','179.2','0','120','0','59.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:06',NULL),(173,'226',NULL,NULL,'173','1592038409032','13-06-2020','1970-01-01','0313','0','0','0.00','0','140','0','120','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:08',NULL),(174,'226',NULL,NULL,'174','1592038409134','13-06-2020','1970-01-01','0314','0','0','0.00','0','140','0','120','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:09',NULL),(175,'226',NULL,NULL,'175','1592038409233','13-06-2020','1970-01-01','0315','0','0','0.00','0','140','0','120','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:10',NULL),(176,'226',NULL,NULL,'176','1592038409331','13-06-2020','1970-01-01','0316','0','0','0.00','0','140','0','120','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:11',NULL),(177,'226',NULL,NULL,'177','1592038409429','13-06-2020','1970-01-01','0317','120','0','0.00','0','179.2','0','120','0','59.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:13',NULL),(178,'226',NULL,NULL,'178','1592038409528','13-06-2020','1970-01-01','0318','0','0','0.00','0','140','0','120','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:14',NULL),(179,'226',NULL,NULL,'179','1592038409634','13-06-2020','1970-01-01','0430','0','16180','0.00','30','16.5249996185303','0','15.25','0','1.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:15',NULL),(180,'226',NULL,NULL,'180','1592038409734','13-06-2020','1970-01-01','0431','0','4056','0.00','80','40.6800003051758','0','40.6800003051758','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:16',NULL),(181,'226',NULL,NULL,'181','1592038409851','13-06-2020','1970-01-01','0432','0','0','0.00','90','48.2099990844727','0','48.2099990844727','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:18',NULL),(182,'226',NULL,NULL,'182','1592038409950','13-06-2020','1970-01-01','0433','0','0','0.00','50','26.7900009155273','0','26.7900009155273','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:19',NULL),(183,'226',NULL,NULL,'183','1592038410050','13-06-2020','1970-01-01','0434','0','24','0.00','40','24.75','0','23.75','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:20',NULL),(184,'226',NULL,NULL,'184','1592038410151','13-06-2020','1970-01-01','0439','0','120','0.00','35','23.7299995422363','0','19.7099990844727','0','4.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:21',NULL),(185,'226',NULL,NULL,'185','1592038410251','13-06-2020','1970-01-01','0440','0','0','0.00','35','23.7299995422363','0','19.8700008392334','0','3.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:22',NULL),(186,'226',NULL,NULL,'186','1592038410352','13-06-2020','1970-01-01','600','0','0','0.00','60','50.8499984741211','0','45','0','5.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:24',NULL),(187,'226',NULL,NULL,'187','1592038410442','13-06-2020','1970-01-01','601','0','6','0.00','70','49','0','0','0','49.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:25',NULL),(188,'226',NULL,NULL,'188','200616165458','2026-03-25','2026-03-25','0501','76.77','834','0.00','115','82.14','0','76.77','0','5.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:26',NULL),(189,'226',NULL,NULL,'189','200616170017','2026-03-25','2026-03-25','0502','82.14','13','0.00','569','406.43','0','379.84','0','26.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:27',NULL),(190,'226',NULL,NULL,'190','200616170443','2026-03-25','1970-01-01','0503','120.72','23','0.00','169','120.72','0','112.82','0','7.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:29',NULL),(191,'226',NULL,NULL,'191','200616170642','2026-03-25','1970-01-01','0504','578.57','18','0.00','810','578.57','0','540.72','0','37.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:30',NULL),(192,'226',NULL,NULL,'192','200616170932','2026-03-25','1970-01-01','0505','683.34','1','0.00','1025','683.34','0','638.63','0','44.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:31',NULL),(193,'226',NULL,NULL,'193','200616171239','2026-03-25','1970-01-01','0506','703.34','9','0.00','1055','703.34','0','657.32','0','46.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:32',NULL),(194,'226',NULL,NULL,'194','200616172109','2026-03-25','1970-01-01','0507','96.43','27','0.00','135','96.43','0','90.12','0','6.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:33',NULL),(195,'226',NULL,NULL,'195','200617120452','2026-03-25','1970-01-01','0508','478.57','9','0.00','670','478.57','0','447.26','0','31.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:34',NULL),(196,'226',NULL,NULL,'196','200617120752','2026-03-25','1970-01-01','0509','139.34','4','0.00','209','139.34','0','130.21','0','9.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:36',NULL),(197,'226',NULL,NULL,'197','200617122154','2026-03-25','1970-01-01','0510','143.34','61','0.00','215','143.34','0','133.96','0','9.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:37',NULL),(198,'226',NULL,NULL,'198','200625130802','2026-03-25','1970-01-01','0511','112.67','210','0.00','169','112.67','0','105.3','0','7.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:38',NULL),(199,'226',NULL,NULL,'199','200625132347','2026-03-25','1970-01-01','0512','135','121','0.00','189','135','0','126.17','0','8.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:39',NULL),(200,'226',NULL,NULL,'200','200707121620','2026-03-25','1970-01-01','0513','16.05','1883','0.00','0','16.05','0','14.58','0','1.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:40',NULL),(201,'226',NULL,NULL,'201','200710120038','2026-03-25','1970-01-01','0514','80','5','0.00','105','80','0','74.76','0','5.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:42',NULL),(202,'226',NULL,NULL,'202','200717115758','2026-03-25','1970-01-01','0515','83.05','8','0.00','109','83.05','0','77.62','0','5.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:43',NULL),(203,'226',NULL,NULL,'203','200725115336','2026-03-25','1970-01-01','0601','1186.45','7','0.00','2500','1186.45','0','1101.7','0','84.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:44',NULL),(204,'226',NULL,NULL,'204','200725115629','2026-03-25','1970-01-01','0602','415.25','8','0.00','700','415.25','0','388.98','0','26.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:45',NULL),(205,'226',NULL,NULL,'205','200725115854','2026-03-25','1970-01-01','0603','533.9','4','0.00','750','533.9','0','483.06','0','50.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:47',NULL),(206,'226',NULL,NULL,'206','200808120356','2026-03-25','1970-01-01','0516','113.33','185','0.00','179','113.33','0','104.76','0','8.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:48',NULL),(207,'226',NULL,NULL,'207','200814114303','2026-03-25','2026-03-25','0604','66.53','76','0.00','85','66.53','0','65.52','0','1.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:49',NULL),(208,'226',NULL,NULL,'208','200818144639','2026-03-25','1970-01-01','0701','7.44','7385','0.00','10','7.44','0','7.086','0','0.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:51',NULL),(209,'226',NULL,NULL,'209','200818144811','2026-03-25','1970-01-01','0702','7.44','12279','0.00','10','7.44','0','7.086','0','0.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:52',NULL),(210,'226',NULL,NULL,'210','200824125311','2026-03-25','1970-01-01','0703','14.76','1020','0.00','20','14.29','0','14.1716','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:53',NULL),(211,'226',NULL,NULL,'211','200824125523','2026-03-25','1970-01-01','0704','28.04','24','0.00','38','27.14','0','26.92','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:54',NULL),(212,'226',NULL,NULL,'212','200824125708','2026-03-25','1970-01-01','0705','9.64','2820','0.00','15','10.72','0','9.8213','0','0.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:56',NULL),(213,'226',NULL,NULL,'213','200826124355','2026-03-25','1970-01-01','0605','194.07','90','0.00','250','194.07','0','190.68','0','3.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:57',NULL),(214,'226',NULL,NULL,'214','200827123905','2026-03-25','1970-01-01','0706','14','55','0.00','22','14','0','15.5887','0','-1.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:05:58',NULL),(215,'226',NULL,NULL,'215','200902124024','2026-03-25','1970-01-01','0517','15.24','909','0.00','20','15.24','0','14.14','0','1.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:00',NULL),(216,'226',NULL,NULL,'216','200903144842','2026-03-25','1970-01-01','0518','15.61','53','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:01',NULL),(217,'226',NULL,NULL,'217','200903145017','2026-03-25','1970-01-01','0519','15.61','38','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:02',NULL),(218,'226',NULL,NULL,'218','200903145144','2026-03-25','1970-01-01','0520','15.61','81','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:03',NULL),(219,'226',NULL,NULL,'219','200903145236','2026-03-25','1970-01-01','0521','15.61','38','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:05',NULL),(220,'226',NULL,NULL,'220','200903145344','2026-03-25','1970-01-01','0522','15.61','81','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:06',NULL),(221,'226',NULL,NULL,'221','200903145441','2026-03-25','1970-01-01','0523','15.61','66','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:07',NULL),(222,'226',NULL,NULL,'222','200903145531','2026-03-25','1970-01-01','0524','15.61','53','0.00','20','15.61','0','14.58','0','1.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:09',NULL),(223,'226',NULL,NULL,'223','200907162716','2026-03-25','1970-01-01','0606','58.04','180','0.00','85','58.04','0','52.03','0','6.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:10',NULL),(224,'226',NULL,NULL,'224','200911163001','2026-03-25','1970-01-01','0707','8.503','12375','0.00','12','8.93','0','8.503','0','0.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:11',NULL),(225,'226',NULL,NULL,'225','200911165424','2026-03-25','1970-01-01','708','3.54','0','0.00','5','3.54','0','3.54','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:12',NULL),(226,'226',NULL,NULL,'226','200911170044','2026-03-25','2026-03-25','709','1','4','0.00','1','1','0','1','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:14',NULL),(227,'226',NULL,NULL,'227','200921153740','2026-03-25','1970-01-01','0100','7.14','16896','0.00','10','7.14','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:15',NULL),(228,'226',NULL,NULL,'228','201006124947','2026-03-25','1970-01-01','0608','110.77','87','0.00','140','115','0','110.77','0','4.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:16',NULL),(229,'226',NULL,NULL,'229','201006125056','2026-03-25','1970-01-01','0609','78.33','39','0.00','99','80','0','78.33','0','1.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:18',NULL),(230,'226',NULL,NULL,'230','201007144548','2026-03-25','1970-01-01','0709','10.63','1949','0.00','18','10.98','0','12.7546','0','-1.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:19',NULL),(231,'226',NULL,NULL,'231','201007145807','2026-03-25','1970-01-01','0711','17.71','1','0.00','25','18','0','17.7145','0','0.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:20',NULL),(232,'226',NULL,NULL,'232','201008112655','2026-03-25','1970-01-01','0607','185.96','18','0.00','250','186','0','185.96','0','0.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:22',NULL),(233,'226',NULL,NULL,'233','201031143854','2026-03-25','1970-01-01','0712','7.09','11580','0.00','12','6.97','0','8.503','0','-1.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:23',NULL),(234,'226',NULL,NULL,'234','201031155720','2026-03-25','1970-01-01','0610','18.6','228','0.00','25','19.33','0','18.6','0','0.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:24',NULL),(235,'226',NULL,NULL,'235','201031155904','2026-03-25','1970-01-01','0611','58.48','57','0.00','75','58.48','0','58','0','0.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:26',NULL),(236,'226',NULL,NULL,'236','201102122458','2026-03-25','1970-01-01','0801','24.8','593','0.00','40','26.79','0','24.8','0','1.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:27',NULL),(237,'226',NULL,NULL,'237','201102123157','2026-03-25','1970-01-01','0802','21.7','90','0.00','35','23.43','0','21.7','0','1.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:28',NULL),(238,'226',NULL,NULL,'238','201102123337','2026-03-25','1970-01-01','0803','12.4','384','0.00','20','13.39','0','12.4','0','0.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:30',NULL),(239,'226',NULL,NULL,'239','201102123617','2026-03-25','1970-01-01','0804','13.22','318','0.00','20','14.29','0','13.22','0','1.07','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:31',NULL),(240,'226',NULL,NULL,'240','201102123745','2026-03-25','1970-01-01','0805','6.61','900','0.00','10','7.15','0','6.61','0','0.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:32',NULL),(241,'226',NULL,NULL,'241','201102124029','2026-03-25','1970-01-01','0806','61.38','128','0.00','99','66.29','0','61.38','0','4.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:34',NULL),(242,'226',NULL,NULL,'242','201121155633','2026-03-25','1970-01-01','0713','9.82','840','0.00','15','11.55','0','9.8213','0','1.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:35',NULL),(243,'226',NULL,NULL,'243','201201114241','2026-03-25','1970-01-01','1001','18.25','60','0.00','23','19.17','0','16.2976','0','2.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:36',NULL),(244,'226',NULL,NULL,'244','201201114657','2026-03-25','1970-01-01','1002','33.33','402','0.00','60','35','0','31.8879','0','3.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:38',NULL),(245,'226',NULL,NULL,'245','201201114832','2026-03-25','1970-01-01','1003','28.57','144','0.00','60','30','0','25.51','0','4.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:39',NULL),(246,'226',NULL,NULL,'246','201207110104','2026-03-25','1970-01-01','1607319879708','10.63','0','0.00','10.63','10.98','0','0','0','10.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:40',NULL),(247,'226',NULL,NULL,'246','201207111312','2026-03-25','1970-01-01','1607319879708','10.63','0','0.00','15','10.98','0','10.63','0','0.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:42',NULL),(248,'226',NULL,NULL,'247','201207111701','2026-03-25','1970-01-01','1004','10.63','360','0.00','15','10.98','0','12.7546','0','-1.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:43',NULL),(249,'226',NULL,NULL,'248','201207122213','2026-03-25','1970-01-01','1005','3.37','0','0.00','5','3.85','0','3.37','0','0.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:44',NULL),(250,'226',NULL,NULL,'248','201207123630','2026-03-25','1970-01-01','1005','3.02','2880','0.00','5','3.85','0','3.02','0','0.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:46',NULL),(251,'226',NULL,NULL,'43','201207124252','null','1970-01-01','0097','6.25','1179','0.00','10','7.14','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:47',NULL),(252,'226',NULL,NULL,'249','201210104300','2026-03-25','1970-01-01','1006','0','6480','0.00','5','3.57','0','3.57','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:48',NULL),(253,'226',NULL,NULL,'250','201215180000','2026-03-25','1970-01-01','0','70.17','0','0.00','100','82.17','0','70.8583','0','11.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:50',NULL),(254,'226',NULL,NULL,'251','201218141015','2026-03-25','1970-01-01','1007','14.03','1710','0.00','30','16.5','0','14.03','0','2.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:51',NULL),(255,'226',NULL,NULL,'252','201218141512','2026-03-25','1970-01-01','1008','7.09','440','0.00','10','8.33','0','7.086','0','1.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:52',NULL),(256,'226',NULL,NULL,'253','201230155831','2026-03-25','1970-01-01','1009','6.25','120','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:54',NULL),(257,'226',NULL,NULL,'254','210101130841','2026-03-25','1970-01-01','1010','23.38','0','0.00','33','27.5','0','23.38','0','4.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:55',NULL),(258,'226',NULL,NULL,'255','210108153718','2026-03-25','1970-01-01','1012','6.44','119428','0.00','10','7.2','0','6.3559','0','0.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:56',NULL),(259,'226',NULL,NULL,'256','210108154228','2026-03-25','1970-01-01','1013','6.44','8888','0.00','10','7.2','0','6.3559','0','0.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:58',NULL),(260,'226',NULL,NULL,'257','210108154443','2026-03-25','1970-01-01','1014','6.44','912','0.00','10','7.2','0','6.3559','0','0.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:06:59',NULL),(261,'226',NULL,NULL,'258','210108154633','2026-03-25','1970-01-01','1015','6.44','4866','0.00','10','7.2','0','6.3559','0','0.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:00',NULL),(262,'226',NULL,NULL,'259','210108154918','2026-03-25','1970-01-01','1016','6.44','2316','0.00','10','7.2','0','6.3559','0','0.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:02',NULL),(263,'226',NULL,NULL,'260','210108155213','2026-03-25','1970-01-01','1017','3.85','576','0.00','5','4.04','0','3.7288','0','0.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:03',NULL),(264,'226',NULL,NULL,'261','210108155428','2026-03-25','1970-01-01','1018','3.78','720','0.00','5','3.97','0','3.644','0','0.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:05',NULL),(265,'226',NULL,NULL,'262','210108161457','2026-03-25','1970-01-01','1011','6.44','13628','0.00','10','7.2','0','6.3559','0','0.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:06',NULL),(266,'226',NULL,NULL,'263','210109160008','2026-03-25','2026-03-25','1020','275','25','0.00','0','0','0','400','0','-400.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:07',NULL),(267,'226',NULL,NULL,'264','210109160531','2026-03-25','2026-03-25','1021','275','0','0.00','0','0','0','348','0','-348.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:09',NULL),(268,'226',NULL,NULL,'265','210109161058','2026-03-25','2026-03-25','1022','325','25','0.00','0','0','0','325','0','-325.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:10',NULL),(269,'226',NULL,NULL,'266','210109161404','2026-03-25','2026-03-25','1023','5200','2','0.00','0','0','0','5200','0','-5200.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:12',NULL),(270,'226',NULL,NULL,'267','210114135503','2026-03-25','1970-01-01','1024','42.5','24','0.00','60','48.34','0','42.5','0','5.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:13',NULL),(271,'226',NULL,NULL,'268','210206144200','2026-03-25','null','1612602868208','0','0','0.00','10','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:14',NULL),(272,'226',NULL,NULL,'269','210308132515','2026-03-25','1970-01-01','1025','23.33','45','0.00','33','27.5','0','23.33','0','4.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:16',NULL),(273,'226',NULL,NULL,'270','210313173429','2026-03-25','1970-01-01','1026','25.51','0','0.00','60','30','0','25.51','0','4.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:17',NULL),(274,'226',NULL,NULL,'104','210325153730','null','1970-01-01','0228','18.48','0','0.00','30','24','0','18.48','0','5.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:19',NULL),(275,'226',NULL,NULL,'271','210403151612','2026-03-25','1970-01-01','1617444188145','160','0','0.00','0','0','0','160','0','-160.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:20',NULL),(276,'226',NULL,NULL,'161','210407114622','null','1970-01-01','1617776268384','147.02','0','0.00','190','165.218','0','147.02','0','18.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:21',NULL),(277,'226',NULL,NULL,'272','210407115108','2026-03-25','1970-01-01','0290','150.9255','836','0.00','225','165.4095','0','150.9255','0','14.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:23',NULL),(278,'226',NULL,NULL,'273','210415091628','2026-03-25','1970-01-01','1618458568060','138.6312','0','0.00','685','151.3853','0','138.6312','0','12.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:24',NULL),(279,'226',NULL,NULL,'274','210415092118','2026-03-25','1970-01-01','1027','151.7857','2052','0.00','800','151','0','151.7857','0','-0.79','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:26',NULL),(280,'226',NULL,NULL,'275','210424121142','2026-03-25','1970-01-01','1028','3.78','30384','0.00','5','4.75','0','3.644','0','1.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:27',NULL),(281,'226',NULL,NULL,'276','210708135437','2026-03-25','1970-01-01','1029','7.0858','4218','0.00','10','0','0','7.0858','0','-7.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:28',NULL),(282,'226',NULL,NULL,'277','210708135735','2026-03-25','1970-01-01','1030','7.0858','14798','0.00','10','0','0','7.0858','0','-7.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:30',NULL),(283,'226',NULL,NULL,'278','210715181847','2026-03-25','1970-01-01','1031','7.1427','216','0.00','10','8','0','7.1427','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:31',NULL),(284,'226',NULL,NULL,'279','210715182236','2026-03-25','1970-01-01','1032','6.3558','19212','0.00','10','8','0','6.3559','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:33',NULL),(285,'226',NULL,NULL,'280','210715182515','2026-03-25','1970-01-01','1033','6.3559','15792','0.00','10','8','0','6.3559','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:34',NULL),(286,'226',NULL,NULL,'281','210715182712','2026-03-25','1970-01-01','1034','6.3559','5022','0.00','10','8','0','6.3559','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:35',NULL),(287,'226',NULL,NULL,'282','210715182937','2026-03-25','1970-01-01','1035','6.3559','2212','0.00','10','8','0','6.3559','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:37',NULL),(288,'226',NULL,NULL,'283','210716161834','2026-03-25','1970-01-01','1036','7.6977','43786','0.00','10','8','0','7.4576','0','0.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:38',NULL),(289,'226',NULL,NULL,'284','210716162612','2026-03-25','1970-01-01','1037','15.419','0','0.00','20','20','0','14.9194','0','5.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:40',NULL),(290,'226',NULL,NULL,'285','210716162805','2026-03-25','1970-01-01','1038','57.7481','0','0.00','75','72','0','558771','0','-558699.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:41',NULL),(291,'226',NULL,NULL,'286','210716163135','2026-03-25','1970-01-01','1039','3.7782','720','0.00','5','4.5','0','3.644','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:43',NULL),(292,'226',NULL,NULL,'287','210716163449','2026-03-25','1970-01-01','1040','3.7782','252','0.00','5','4.5','0','3.4306','0','1.07','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:44',NULL),(293,'226',NULL,NULL,'288','210721110612','2026-03-25','1970-01-01','1041','23.8096','45','0.00','50','32','0','23.8096','0','8.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:45',NULL),(294,'226',NULL,NULL,'289','210721110948','2026-03-25','1970-01-01','1042','23.8096','45','0.00','50','32','0','23.8096','0','8.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:47',NULL),(295,'226',NULL,NULL,'290','210721150454','2026-03-25','1970-01-01','01043','19.07','984','0.00','30','24','0','19.0693','0','4.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:48',NULL),(296,'226',NULL,NULL,'291','210811181815','2026-03-25','1970-01-01','1044','3.3482','1548','0.00','5','4','0','3.3482','0','0.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:50',NULL),(297,'226',NULL,NULL,'292','210812145019','2026-03-25','1970-01-01','0751','89.48','72','0.00','120','91','0','89.48','0','1.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:51',NULL),(298,'226',NULL,NULL,'293','210819093817','2026-03-25','1970-01-01','1045','48.1841','0','0.00','68','56.66','0','48.1841','0','8.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:52',NULL),(299,'226',NULL,NULL,'294','210819100644','2026-03-25','1970-01-01','1046','6.25','16022','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:54',NULL),(300,'226',NULL,NULL,'295','210823114146','2026-03-25','1970-01-01','1047','120','0','0.00','0','160','0','120','0','40.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:55',NULL),(301,'226',NULL,NULL,'296','210823114628','2026-03-25','1970-01-01','1048','1600','0','0.00','0','1800','0','1600','0','200.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:57',NULL),(302,'226',NULL,NULL,'297','210823114914','2026-03-25','1970-01-01','1049','0','0','0.00','0','160','0','80','0','80.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:58',NULL),(303,'226',NULL,NULL,'298','210823145137','2026-03-25','1970-01-01','1050','160','0','0.00','0','160','0','130','0','30.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:07:59',NULL),(304,'226',NULL,NULL,'299','210824091743','2026-03-25','1970-01-01','1051','6.25','240','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:01',NULL),(305,'226',NULL,NULL,'300','210824094056','2026-03-25','1970-01-01','1052','6.356','3528','0.00','10','8','0','6.356','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:02',NULL),(306,'226',NULL,NULL,'301','210824144620','2026-03-25','1970-01-01','1053','730','0','0.00','0','0','0','730','0','-730.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:04',NULL),(307,'226',NULL,NULL,'302','210824144853','2026-03-25','1970-01-01','1055','645','0','0.00','0','0','0','645','0','-645.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:05',NULL),(308,'226',NULL,NULL,'303','210824145434','2026-03-25','1970-01-01','1056','1075','0','0.00','0','0','0','1075','0','-1075.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:07',NULL),(309,'226',NULL,NULL,'304','210828133903','2026-03-25','1970-01-01','1057','163','100','0.00','0','0','0','163','0','-163.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:08',NULL),(310,'226',NULL,NULL,'305','210906165146','2026-03-25','1970-01-01','1058','6.25','480','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:10',NULL),(311,'226',NULL,NULL,'306','210908135400','2026-03-25','2026-03-25','1059','1040','2','0.00','0','0','0','1040','0','-1040.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:11',NULL),(312,'226',NULL,NULL,'307','210915103133','2026-03-25','2026-03-25','1060','1690','0','0.00','0','0','0','1675','0','-1675.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:13',NULL),(313,'226',NULL,NULL,'308','210915104916','2026-03-25','2026-03-25','1061','541','0','0.00','0','0','0','541','0','-541.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:14',NULL),(314,'226',NULL,NULL,'309','210915105118','2026-03-25','2026-03-25','1062','350','0','0.00','0','0','0','350','0','-350.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:16',NULL),(315,'226',NULL,NULL,'310','210919210710','2026-03-25','1970-01-01','1063','33.4822','40','0.00','50','0','0','33.4822','0','-33.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:17',NULL),(316,'226',NULL,NULL,'311','211005180833','2026-03-25','1970-01-01','1064','6.3558','3400','0.00','10','0','0','6.3558','0','-6.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:19',NULL),(317,'226',NULL,NULL,'312','211015132021','2026-03-25','1970-01-01','1065','6.3559','4392','0.00','10','8.5','0','6.3559','0','2.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:20',NULL),(318,'226',NULL,NULL,'313','211015132307','2026-03-25','1970-01-01','1066','6.3559','608','0.00','10','8.5','0','6.3559','0','2.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:22',NULL),(319,'226',NULL,NULL,'314','211029174803','2026-03-25','1970-01-01','1067','6.356','292','0.00','10','8.5','0','6.356','0','2.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:23',NULL),(320,'226',NULL,NULL,'315','211105114406','2026-03-25','1970-01-01','1068','275','0','0.00','0','300','0','400','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:25',NULL),(321,'226',NULL,NULL,'316','211116114938','2026-03-25','1970-01-01','1069','7.0858','7720','0.00','10','8.33','0','7.0858','0','1.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:26',NULL),(322,'226',NULL,NULL,'317','211125103337','2026-03-25','1970-01-01','1070','25.5154','277','0.00','35','28','0','21.875','0','6.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:28',NULL),(323,'226',NULL,NULL,'318','211125103617','2026-03-25','1970-01-01','1071','25.5154','372','0.00','35','28','0','21.875','0','6.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:29',NULL),(324,'226',NULL,NULL,'319','211125103837','2026-03-25','1970-01-01','1072','21.8704','222','0.00','30','24','0','18.75','0','5.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:31',NULL),(325,'226',NULL,NULL,'320','211125104024','2026-03-25','1970-01-01','1073','21.8704','96','0.00','30','24','0','18.75','0','5.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:32',NULL),(326,'226',NULL,NULL,'321','211125120402','2026-03-25','1970-01-01','1074','6.3559','0','0.00','10','8.2','0','6.3559','0','1.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:34',NULL),(327,'226',NULL,NULL,'322','220122125415','2026-03-25','1970-01-01','0051','2.7343','1020','0.00','6','3.9','0','2.73','0','1.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:35',NULL),(328,'226',NULL,NULL,'323','220223145300','2026-03-25','1970-01-01','0151','38.84','305','0.00','69','42.73','0','38.84','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:37',NULL),(329,'226',NULL,NULL,'324','220223145416','2026-03-25','1970-01-01','0152','38.84','40','0.00','69','42.73','0','38.84','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:38',NULL),(330,'226',NULL,NULL,'325','220223145509','2026-03-25','1970-01-01','0153','38.84','90','0.00','69','42.73','0','38.84','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:39',NULL),(331,'226',NULL,NULL,'326','220223145557','2026-03-25','1970-01-01','0154','38.84','90','0.00','69','42.73','0','38.84','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:41',NULL),(332,'226',NULL,NULL,'327','220223145648','2026-03-25','1970-01-01','0155','38.84','90','0.00','69','42.73','0','38.84','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:42',NULL),(333,'226',NULL,NULL,'328','220319133757','2026-03-25','1970-01-01','0157','34','1000','0.00','50','35','0','34','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:44',NULL),(334,'226',NULL,NULL,'329','220323161912','2026-03-25','1970-01-01','0159','12.5','189','0.00','20','14.2875','0','12.5','0','1.79','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:46',NULL),(335,'226',NULL,NULL,'330','220326120258','2026-03-25','1970-01-01','0149','8.9285','2403','0.00','20','10.7143','0','8.9285','0','1.79','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:47',NULL),(336,'226',NULL,NULL,'331','220411111806','2026-03-25','1970-01-01','0175','465','40','0.00','0','465','0','465','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:48',NULL),(337,'226',NULL,NULL,'332','220430105451','2026-03-25','2026-03-25','0560','9450','0','0.00','11050','9550','0','9450','0','100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:50',NULL),(338,'226',NULL,NULL,'333','0','2026-03-25','1970-01-01','0010','31.78','2992','0.00','50','31.78','0','31.78','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:52',NULL),(339,'226',NULL,NULL,'334','220726104903','2026-03-25','1970-01-01','0063','9.12','3005','0.00','30','14.73','0','9.12','0','5.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:53',NULL),(340,'226',NULL,NULL,'335','220726174728','2026-03-25','1970-01-01','0062','508.47','70','0.00','800','508.47','0','508.47','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:54',NULL),(341,'226',NULL,NULL,'336','220728111227','2026-03-25','1970-01-01','0061','14','2232','0.00','20','16','0','14','0','2.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:56',NULL),(342,'226',NULL,NULL,'337','220812141830','2026-03-25','1970-01-01','0059','418.53','30','0.00','625','423.72','0','418.53','0','5.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:57',NULL),(343,'226',NULL,NULL,'338','220915122450','2026-03-25','1970-01-01','0031','100.45','46','0.00','150','104.46','0','100.45','0','4.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:08:59',NULL),(344,'226',NULL,NULL,'339','220922161209','2026-03-25','1970-01-01','0713','10.629','2720','0.00','15','10.71','0','10.629','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:00',NULL),(345,'226',NULL,NULL,'340','221012140135','2026-03-25','1970-01-01','0714','7.086','12840','0.00','10','7.1428','0','7.086','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:02',NULL),(346,'226',NULL,NULL,'341','221123152755','2026-03-25','1970-01-01','01101','5.51','1668','0.00','10','5.932','0','5.51','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:03',NULL),(347,'226',NULL,NULL,'342','221123152931','2026-03-25','1970-01-01','01102','5.51','0','0.00','10','5.9322','0','5.51','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:05',NULL),(348,'226',NULL,NULL,'343','221123153108','2026-03-25','1970-01-01','01103','2.75','0','0.00','5','2.966','0','2.75','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:06',NULL),(349,'226',NULL,NULL,'344','221128093413','2026-03-25','1970-01-01','1104','6.61','24048','0.00','10','8','0','6.61','0','1.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:08',NULL),(350,'226',NULL,NULL,'345','221203101558','2026-03-25','1970-01-01','1201','63.8','478','0.00','90','68.75','0','63.8','0','4.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:10',NULL),(351,'226',NULL,NULL,'346','221222145753','2026-03-25','1970-01-01','1105','10.5085','864','0.00','20','11.5254','0','10.5085','0','1.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:11',NULL),(352,'226',NULL,NULL,'347','230106090941','2026-03-25','1970-01-01','1106','100.4466','0','0.00','150','120','0','100.4466','0','19.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:13',NULL),(353,'226',NULL,NULL,'348','230106092937','2026-03-25','1970-01-01','1107','95.3391','850','0.00','150','120','0','95.3391','0','24.66','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:14',NULL),(354,'226',NULL,NULL,'349','230106181207','2026-03-25','1970-01-01','01108','635.59','25','0.00','1000','661','0','635.59','0','25.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:15',NULL),(355,'226',NULL,NULL,'350','230110124053','2026-03-25','1970-01-01','01109','7.5583','480','0.00','10','7.619','0','7.5583','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:17',NULL),(356,'226',NULL,NULL,'351','230110124158','2026-03-25','1970-01-01','1110','7.5583','0','0.00','10','7.619','0','7.5583','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:18',NULL),(357,'226',NULL,NULL,'352','230110124312','2026-03-25','1970-01-01','1111','7.5583','0','0.00','10','7.619','0','7.5583','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:20',NULL),(358,'226',NULL,NULL,'353','230110124432','2026-03-25','1970-01-01','01112','11.34','120','0.00','15','11.42','0','11.34','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:21',NULL),(359,'226',NULL,NULL,'354','230110124543','2026-03-25','1970-01-01','01113','11.34','0','0.00','15','11.42','0','11.34','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:23',NULL),(360,'226',NULL,NULL,'355','230110124707','2026-03-25','1970-01-01','01114','11.34','40','0.00','15','11.42','0','11.34','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:24',NULL),(361,'226',NULL,NULL,'356','230121150437','2026-03-25','1970-01-01','1121','100.45','132','0.00','150','104.46','0','100.45','0','4.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:26',NULL),(362,'226',NULL,NULL,'357','230127124331','2026-03-25','1970-01-01','04','3.3482','900','0.00','5','3.5714','0','3.3482','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:28',NULL),(363,'226',NULL,NULL,'358','230208160242','2026-03-25','1970-01-01','05','47.46','1840','0.00','65','57.51','0','47.46','0','10.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:29',NULL),(364,'226',NULL,NULL,'359','230425150930','2026-03-25','1970-01-01','06','6.5678','59569','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:31',NULL),(365,'226',NULL,NULL,'360','230425151057','2026-03-25','1970-01-01','07','6.5678','5328','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:32',NULL),(366,'226',NULL,NULL,'361','230425151212','2026-03-25','1970-01-01','08','6.5678','4104','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:34',NULL),(367,'226',NULL,NULL,'362','230425151307','2026-03-25','1970-01-01','09','6.5678','688','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:36',NULL),(368,'226',NULL,NULL,'363','230425151405','2026-03-25','1970-01-01','10','6.5678','567','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:37',NULL),(369,'226',NULL,NULL,'364','230425151503','2026-03-25','1970-01-01','11','6.5678','3375','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:39',NULL),(370,'226',NULL,NULL,'365','230425151659','2026-03-25','1970-01-01','12','6.5678','200','0.00','10','7.0763','0','6.5678','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:40',NULL),(371,'226',NULL,NULL,'366','230701125753','2026-03-25','1970-01-01','01301','9.5338','960','0.00','15','10.17','0','9.5338','0','0.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:42',NULL),(372,'226',NULL,NULL,'367','230714101520','2026-03-25','1970-01-01','0044','6.25','20378','0.00','10','6.7','0','6.25','0','0.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:43',NULL),(373,'226',NULL,NULL,'368','230714101610','2026-03-25','1970-01-01','0045','6.25','2592','0.00','10','6.7','0','6.25','0','0.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:45',NULL),(374,'226',NULL,NULL,'369','230724155804','2026-03-25','1970-01-01','00332','14.75','756','0.00','20','15.17','0','14.75','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:47',NULL),(375,'226',NULL,NULL,'370','230814125520','2026-03-25','1970-01-01','0041','12.5','264','0.00','20','13.3928','0','12.5','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:48',NULL),(376,'226',NULL,NULL,'371','230822155454','2026-03-25','1970-01-01','0042','6.7','17300','0.00','10','7.14','0','6.7','0','0.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:50',NULL),(377,'226',NULL,NULL,'372','230824192519','2026-03-25','1970-01-01','0043','6.25','14733','0.00','10','7.1429','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:51',NULL),(378,'226',NULL,NULL,'373','230824192725','2026-03-25','1970-01-01','0039','3.3482','20304','0.00','5','3.7946','0','3.3482','0','0.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:53',NULL),(379,'226',NULL,NULL,'374','230826123538','2026-03-25','1970-01-01','0038','33.48','0','0.00','50','35.7143','0','33.48','0','2.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:54',NULL),(380,'226',NULL,NULL,'375','230831170838','2026-03-25','1970-01-01','0101','9.8214','15287','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:56',NULL),(381,'226',NULL,NULL,'376','230831170950','2026-03-25','1970-01-01','0102','9.8214','9781','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:57',NULL),(382,'226',NULL,NULL,'377','230831171045','2026-03-25','1970-01-01','0103','9.8214','25216','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:09:59',NULL),(383,'226',NULL,NULL,'378','230831171146','2026-03-25','1970-01-01','0104','9.8214','3741','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:00',NULL),(384,'226',NULL,NULL,'379','230831171251','2026-03-25','1970-01-01','0105','9.8214','12007','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:02',NULL),(385,'226',NULL,NULL,'380','230831171350','2026-03-25','1970-01-01','0106','9.8214','6743','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:04',NULL),(386,'226',NULL,NULL,'381','230831171436','2026-03-25','1970-01-01','0107','9.8214','20166','0.00','20','10.7143','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:05',NULL),(387,'226',NULL,NULL,'382','230905132120','2026-03-25','1970-01-01','0108','6.3559','3000','0.00','10','6.78','0','6.3559','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:07',NULL),(388,'226',NULL,NULL,'383','230915153814','2026-03-25','1970-01-01','0109','9.82','5856','0.00','20','10.7143','0','9.82','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:08',NULL),(389,'226',NULL,NULL,'384','230915153912','2026-03-25','1970-01-01','0110','9.82','1056','0.00','20','10.7143','0','9.82','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:10',NULL),(390,'226',NULL,NULL,'385','230915154015','2026-03-25','1970-01-01','0111','9.82','2400','0.00','20','10.7143','0','9.82','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:11',NULL),(391,'226',NULL,NULL,'386','230928151648','2026-03-25','1970-01-01','0112','31.78','192','0.00','50','33.9','0','31.78','0','2.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:13',NULL),(392,'226',NULL,NULL,'387','231017110814','2026-03-25','1970-01-01','02001','9.82','8469','0.00','20','10.71','0','9.82','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:14',NULL),(393,'226',NULL,NULL,'388','231018123339','2026-03-25','1970-01-01','02002','844','10','0.00','1200','844','0','844','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:16',NULL),(394,'226',NULL,NULL,'389','231031122053','2026-03-25','1970-01-01','02003','6.25','116672','0.00','10','7.1428','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:18',NULL),(395,'226',NULL,NULL,'390','231031141023','2026-03-25','1970-01-01','02004','20.34','0','0.00','40','23.05','0','20.34','0','2.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:19',NULL),(396,'226',NULL,NULL,'391','231104134052','2026-03-25','1970-01-01','02005','51.61','320','0.00','62','55.95','0','51.61','0','4.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:21',NULL),(397,'226',NULL,NULL,'392','231110134031','2026-03-25','1970-01-01','02006','518.3','0','0.00','645','518.3','0','518.3','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:23',NULL),(398,'226',NULL,NULL,'393','231122195139','2026-03-25','1970-01-01','02011','16.95','0','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:24',NULL),(399,'226',NULL,NULL,'394','231122195307','2026-03-25','1970-01-01','02012','16.95','108','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:26',NULL),(400,'226',NULL,NULL,'395','231122195514','2026-03-25','1970-01-01','02013','20.34','0','0.00','30','21.36','0','20.34','0','1.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:27',NULL),(401,'226',NULL,NULL,'396','231122195819','2026-03-25','1970-01-01','02014','13.56','0','0.00','20','14.24','0','13.56','0','0.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:29',NULL),(402,'226',NULL,NULL,'397','231122200034','2026-03-25','1970-01-01','02015','16.95','0','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:30',NULL),(403,'226',NULL,NULL,'398','231122200251','2026-03-25','1970-01-01','02016','16.95','0','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:32',NULL),(404,'226',NULL,NULL,'399','231122200435','2026-03-25','1970-01-01','02017','16.95','150','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:33',NULL),(405,'226',NULL,NULL,'400','231122201526','2026-03-25','1970-01-01','02018','13.56','1100','0.00','20','16.8','0','13.56','0','3.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:35',NULL),(406,'226',NULL,NULL,'401','231122202145','2026-03-25','1970-01-01','02019','16.95','0','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:36',NULL),(407,'226',NULL,NULL,'402','231122202245','2026-03-25','1970-01-01','02020','16.95','0','0.00','25','17.8','0','16.95','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:38',NULL),(408,'226',NULL,NULL,'403','231205143147','2026-03-25','1970-01-01','02021','520','3','0.00','0','550','0','520','0','30.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:40',NULL),(409,'226',NULL,NULL,'404','231205143256','2026-03-25','1970-01-01','02022','725','0','0.00','0','775','0','725','0','50.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:41',NULL),(410,'226',NULL,NULL,'405','231222114631','2026-03-25','1970-01-01','02023','13.56','0','0.00','20','14.23','0','13.56','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:43',NULL),(411,'226',NULL,NULL,'406','240117133235','2026-03-25','1970-01-01','02031','32.38','160','0.00','40','33.7','0','32.38','0','1.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:44',NULL),(412,'226',NULL,NULL,'407','240118130305','2026-03-25','1970-01-01','02032','31.78','96','0.00','50','33.05','0','31.78','0','1.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:46',NULL),(413,'226',NULL,NULL,'408','240220135628','2026-03-25','1970-01-01','02041','37','532','0.00','50','39','0','37','0','2.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:47',NULL),(414,'226',NULL,NULL,'409','240220140122','2026-03-25','1970-01-01','02042','44.9','107','0.00','60','45','0','44.9','0','0.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:49',NULL),(415,'226',NULL,NULL,'410','240224104404','2026-03-25','1970-01-01','02051','6.57','336','0.00','10','7.0763','0','6.57','0','0.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:51',NULL),(416,'226',NULL,NULL,'411','240307134941','2026-03-25','1970-01-01','02052','39.26','40','0.00','20','41.26','0','39.26','0','2.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:52',NULL),(417,'226',NULL,NULL,'412','240309092624','2026-03-25','2026-03-25','02054','9.8214','18944','0.00','20','10.7114','0','9.8214','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:54',NULL),(418,'226',NULL,NULL,'413','240312195015','2026-03-25','1970-01-01','02055','2.59','0','0.00','4','2.6','0','2.59','0','0.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:55',NULL),(419,'226',NULL,NULL,'414','240411105008','2026-03-25','1970-01-01','02065','12.71','2100','0.00','20','13.56','0','12.71','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:57',NULL),(420,'226',NULL,NULL,'415','240705140951','2026-03-25','1970-01-01','02070','6.78','6962','0.00','10','7.076','0','6.78','0','0.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:10:58',NULL),(421,'226',NULL,NULL,'416','240711102638','2026-03-25','1970-01-01','02080','6.78','576','0.00','10','7.0763','0','6.78','0','0.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:00',NULL),(422,'226',NULL,NULL,'417','240711103715','2026-03-25','1970-01-01','02081','13.56','11790','0.00','20','14.15','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:02',NULL),(423,'226',NULL,NULL,'418','240711105915','2026-03-25','1970-01-01','02083','12.71','2170','0.00','20','13.56','0','12.71','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:03',NULL),(424,'226',NULL,NULL,'419','240727143213','2026-03-25','1970-01-01','02101','7.0716','780','0.00','10','7.57','0','7.0716','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:05',NULL),(425,'226',NULL,NULL,'420','240727143521','2026-03-25','1970-01-01','02102','37.25','0','0.00','50','39.86','0','37.25','0','2.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:06',NULL),(426,'226',NULL,NULL,'421','240727143712','2026-03-25','1970-01-01','02103','7.0716','580','0.00','10','7.57','0','7.0716','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:08',NULL),(427,'226',NULL,NULL,'422','240727143929','2026-03-25','1970-01-01','02104','37.25','64','0.00','50','39.86','0','37.25','0','2.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:09',NULL),(428,'226',NULL,NULL,'423','240727144141','2026-03-25','1970-01-01','02105','37.25','96','0.00','50','39.86','0','37.25','0','2.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:11',NULL),(429,'226',NULL,NULL,'424','240727144431','2026-03-25','1970-01-01','02106','21.42','0','0.00','30','22.91','0','21.42','0','1.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:12',NULL),(430,'226',NULL,NULL,'425','240727144719','2026-03-25','1970-01-01','02107','49.97','384','0.00','70','53.47','0','49.97','0','3.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:14',NULL),(431,'226',NULL,NULL,'426','240727144907','2026-03-25','1970-01-01','02108','21.42','24','0.00','30','22.92','0','21.42','0','1.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:16',NULL),(432,'226',NULL,NULL,'427','240727145120','2026-03-25','1970-01-01','02109','14.28','1476','0.00','20','15.28','0','14.28','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:18',NULL),(433,'226',NULL,NULL,'428','240727145345','2026-03-25','1970-01-01','02110','21.42','0','0.00','30','22.91','0','21.42','0','1.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:19',NULL),(434,'226',NULL,NULL,'429','240727145515','2026-03-25','1970-01-01','02111','21.42','24','0.00','30','22.91','0','21.42','0','1.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:21',NULL),(435,'226',NULL,NULL,'430','240727145705','2026-03-25','1970-01-01','02112','35.7','24','0.00','50','38.19','0','35.7','0','2.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:23',NULL),(436,'226',NULL,NULL,'431','240727145916','2026-03-25','1970-01-01','02113','14.28','1152','0.00','20','15.17','0','14.28','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:24',NULL),(437,'226',NULL,NULL,'432','240727150113','2026-03-25','1970-01-01','02114','42.83','165','0.00','60','45.82','0','42.83','0','2.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:26',NULL),(438,'226',NULL,NULL,'433','240727150233','2026-03-25','1970-01-01','02115','21.42','288','0.00','30','22.91','0','21.42','0','1.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:27',NULL),(439,'226',NULL,NULL,'434','240727150402','2026-03-25','1970-01-01','02116','49.97','400','0.00','70','53.47','0','49.97','0','3.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:29',NULL),(440,'226',NULL,NULL,'435','240808133015','2026-03-25','1970-01-01','02201','6.78','522','0.00','10','7.0762','0','6.78','0','0.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:31',NULL),(441,'226',NULL,NULL,'436','240808133237','2026-03-25','1970-01-01','02202','16.95','0','0.00','25','20.875','0','16.95','0','3.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:33',NULL),(442,'226',NULL,NULL,'437','240808140640','2026-03-25','1970-01-01','02203','6.78','0','0.00','10','7.0762','0','6.78','0','0.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:34',NULL),(443,'226',NULL,NULL,'438','240808140740','2026-03-25','1970-01-01','02204','6.78','0','0.00','25','7.0762','0','6.78','0','0.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:36',NULL),(444,'226',NULL,NULL,'439','240808140905','2026-03-25','1970-01-01','02205','6.78','2320','0.00','10','7.0762','0','6.78','0','0.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:37',NULL),(445,'226',NULL,NULL,'440','240808141237','2026-03-25','1970-01-01','02206','13.56','0','0.00','20','14.15','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:39',NULL),(446,'226',NULL,NULL,'441','240808141841','2026-03-25','1970-01-01','02207','13.56','1440','0.00','20','14.15','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:41',NULL),(447,'226',NULL,NULL,'442','240814103411','2026-03-25','1970-01-01','02301','39.23','1800','0.00','55','40.27','0','39.23','0','1.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:42',NULL),(448,'226',NULL,NULL,'443','240814103724','2026-03-25','1970-01-01','02302','71.32','0','0.00','100','73.21','0','71.32','0','1.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:44',NULL),(449,'226',NULL,NULL,'444','240814104020','2026-03-25','1970-01-01','02303','32.09','0','0.00','45','32.94','0','32.09','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:46',NULL),(450,'226',NULL,NULL,'445','240814104316','2026-03-25','1970-01-01','02304','62.76','0','0.00','82','64.42','0','62.76','0','1.66','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:47',NULL),(451,'226',NULL,NULL,'446','240818115913','2026-03-25','2026-03-25','02307','200','9','0.00','0','300','0','200','0','100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:49',NULL),(452,'226',NULL,NULL,'447','240903113844','2026-03-25','1970-01-01','2001','400','0','0.00','2000','590','0','400','0','190.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:50',NULL),(453,'226',NULL,NULL,'448','240903114325','2026-03-25','1970-01-01','2002','180','0','0.00','1800','307','0','180','0','127.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:52',NULL),(454,'226',NULL,NULL,'449','240903114630','2026-03-25','1970-01-01','2003','200','0','0.00','0','330','0','200','0','130.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:54',NULL),(455,'226',NULL,NULL,'450','240903114844','2026-03-25','1970-01-01','2004','150','0','0.00','0','236','0','150','0','86.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:55',NULL),(456,'226',NULL,NULL,'451','240903115118','2026-03-25','1970-01-01','2005','200','0','0.00','0','354','0','200','0','154.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:57',NULL),(457,'226',NULL,NULL,'452','240903115322','2026-03-25','1970-01-01','2006','100','0','0.00','0','132','0','100','0','32.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:11:59',NULL),(458,'226',NULL,NULL,'453','240910134621','2026-03-25','2026-03-25','02401','280','184','0.00','341','300','0','280','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:00',NULL),(459,'226',NULL,NULL,'454','240927130421','2026-03-25','1970-01-01','02501','27.11','240','0.00','40','28.3','0','27.11','0','1.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:02',NULL),(460,'226',NULL,NULL,'455','240927130633','2026-03-25','1970-01-01','02502','23.73','0','0.00','35','24.77','0','23.73','0','1.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:04',NULL),(461,'226',NULL,NULL,'456','241002123924','2026-03-25','1970-01-01','02601','603.54','6','0.00','730','0','0','603.54','0','-603.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:06',NULL),(462,'226',NULL,NULL,'457','241002124045','2026-03-25','1970-01-01','02602','547.47','750','0.00','680','0','0','547.47','0','-547.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:07',NULL),(463,'226',NULL,NULL,'458','241002124205','2026-03-25','1970-01-01','02603','489.41','18','0.00','0','0','0','489.41','0','-489.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:09',NULL),(464,'226',NULL,NULL,'459','241002124319','2026-03-25','1970-01-01','02604','447.93','0','0.00','515','0','0','447.93','0','-447.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:11',NULL),(465,'226',NULL,NULL,'460','241002124436','2026-03-25','1970-01-01','02605','373.28','0','0.00','0','0','0','373.28','0','-373.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:12',NULL),(466,'226',NULL,NULL,'461','241002124600','2026-03-25','1970-01-01','02606','331.8','96','0.00','0','0','0','331.8','0','-331.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:14',NULL),(467,'226',NULL,NULL,'462','241002124748','2026-03-25','1970-01-01','02607','265.45','328','0.00','315','0','0','265.45','0','-265.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:15',NULL),(468,'226',NULL,NULL,'463','241002124906','2026-03-25','1970-01-01','02608','232.26','0','0.00','0','0','0','232.26','0','-232.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:17',NULL),(469,'226',NULL,NULL,'464','241002125013','2026-03-25','1970-01-01','02609','207.38','0','0.00','0','0','0','207.38','0','-207.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:19',NULL),(470,'226',NULL,NULL,'465','241002125139','2026-03-25','1970-01-01','02610','174.2','89','0.00','0','0','0','174.2','0','-174.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:21',NULL),(471,'226',NULL,NULL,'466','241002125239','2026-03-25','1970-01-01','02611','128.58','0','0.00','0','0','0','128.58','0','-128.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:22',NULL),(472,'226',NULL,NULL,'467','241013093550','2026-03-25','1970-01-01','02612','3.39','25020','0.00','5','3.5169','0','3.39','0','0.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:24',NULL),(473,'226',NULL,NULL,'468','241013093748','2026-03-25','1970-01-01','02613','3.39','38640','0.00','5','3.5169','0','3.39','0','0.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:26',NULL),(474,'226',NULL,NULL,'469','241013093850','2026-03-25','1970-01-01','02614','3.39','12000','0.00','5','3.5169','0','3.39','0','0.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:27',NULL),(475,'226',NULL,NULL,'470','241013094152','2026-03-25','1970-01-01','02615','6.78','0','0.00','10','6.85','0','6.78','0','0.07','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:29',NULL),(476,'226',NULL,NULL,'471','241013094335','2026-03-25','1970-01-01','02616','6.78','2080','0.00','10','7.0338','0','6.78','0','0.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:31',NULL),(477,'226',NULL,NULL,'472','241013094621','2026-03-25','1970-01-01','02617','7.68','1584','0.00','10','7.0338','0','7.68','0','-0.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:32',NULL),(478,'226',NULL,NULL,'473','241013094721','2026-03-25','1970-01-01','02618','3.39','0','0.00','5','3.5169','0','3.39','0','0.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:34',NULL),(479,'226',NULL,NULL,'474','241013095644','2026-03-25','1970-01-01','02619','16.95','0','0.00','25','17.58','0','16.95','0','0.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:36',NULL),(480,'226',NULL,NULL,'475','241013100524','2026-03-25','1970-01-01','02620','3.39','0','0.00','5','3.5169','0','3.39','0','0.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:38',NULL),(481,'226',NULL,NULL,'476','241015193650','2026-03-25','1970-01-01','02621','245','38.599999999999994','0.00','290','255','0','245','0','10.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:39',NULL),(482,'226',NULL,NULL,'477','241015193739','2026-03-25','1970-01-01','02622','245','27','0.00','290','255','0','245','0','10.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:41',NULL),(483,'226',NULL,NULL,'478','241016131017','2026-03-25','1970-01-01','02623','6.33','3576','0.00','10','6.78','0','6.33','0','0.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:43',NULL),(484,'226',NULL,NULL,'479','241017120234','2026-03-25','1970-01-01','02631','39.7','1660','0.00','55','40.7','0','39.7','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:45',NULL),(485,'226',NULL,NULL,'480','241018181023','2026-03-25','1970-01-01','02632','6.58','2800','0.00','10','6.78','0','6.58','0','0.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:46',NULL),(486,'226',NULL,NULL,'481','241018181418','2026-03-25','1970-01-01','02633','6.58','0','0.00','10','6.78','0','6.58','0','0.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:48',NULL),(487,'226',NULL,NULL,'482','241018181610','2026-03-25','1970-01-01','02634','6.58','0','0.00','10','6.78','0','6.58','0','0.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:49',NULL),(488,'226',NULL,NULL,'483','241018181941','2026-03-25','1970-01-01','02635','23.72','0','0.00','35','25.38','0','23.72','0','1.66','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:51',NULL),(489,'226',NULL,NULL,'484','241018182128','2026-03-25','1970-01-01','02636','23.72','0','0.00','35','25.36','0','23.72','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:53',NULL),(490,'226',NULL,NULL,'485','241018182304','2026-03-25','1970-01-01','02637','6.78','0','0.00','10','6.9','0','6.78','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:55',NULL),(491,'226',NULL,NULL,'486','241018182410','2026-03-25','1970-01-01','02638','6.78','0','0.00','10','6.9','0','6.78','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:56',NULL),(492,'226',NULL,NULL,'487','241023121851','2026-03-25','2026-03-25','02701','200','25','0.00','0','400','0','200','0','200.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:12:58',NULL),(493,'226',NULL,NULL,'488','241023121938','2026-03-25','2026-03-25','02702','200','0','0.00','0','400','0','200','0','200.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:00',NULL),(494,'226',NULL,NULL,'489','241023122023','2026-03-25','2026-03-25','02703','200','0','0.00','0','330','0','200','0','130.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:02',NULL),(495,'226',NULL,NULL,'490','241031145148','2026-03-25','1970-01-01','02704','110.69','172','0.00','150','117.86','0','110.69','0','7.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:03',NULL),(496,'226',NULL,NULL,'491','241105175404','2026-03-25','1970-01-01','02705','3.39','120','0.00','5','3.52','0','3.39','0','0.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:05',NULL),(497,'226',NULL,NULL,'492','241114140658','2026-03-25','1970-01-01','02801','10.2678','4200','0.00','20','11.6071','0','10.2678','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:07',NULL),(498,'226',NULL,NULL,'493','241114140819','2026-03-25','1970-01-01','02802','10.2678','3450','0.00','20','11.6071','0','10.2678','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:09',NULL),(499,'226',NULL,NULL,'494','241114140912','2026-03-25','1970-01-01','02803','10.2678','7470','0.00','20','11.6071','0','10.2678','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:11',NULL),(500,'226',NULL,NULL,'495','241120185050','2026-03-25','1970-01-01','02804','10.2678','5090','0.00','20','11.16','0','10.2678','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:13',NULL),(501,'226',NULL,NULL,'496','241121110711','2026-03-25','1970-01-01','02901','10.71','5390','0.00','20','11.61','0','10.71','0','0.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:15',NULL),(502,'226',NULL,NULL,'497','241121110822','2026-03-25','1970-01-01','02902','10.71','7590','0.00','20','11.61','0','10.71','0','0.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:16',NULL),(503,'226',NULL,NULL,'498','241121110931','2026-03-25','1970-01-01','02903','10.71','5390','0.00','20','11.61','0','10.71','0','0.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:18',NULL),(504,'226',NULL,NULL,'499','241121111621','2026-03-25','1970-01-01','02904','12.71','0','0.00','20','13.56','0','12.71','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:20',NULL),(505,'226',NULL,NULL,'500','241121111731','2026-03-25','1970-01-01','02905','12.71','0','0.00','20','13.56','0','12.71','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:21',NULL),(506,'226',NULL,NULL,'501','241121112211','2026-03-25','1970-01-01','02906','13.56','3600','0.00','20','14.15','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:23',NULL),(507,'226',NULL,NULL,'502','241121112425','2026-03-25','1970-01-01','02907','13.56','0','0.00','20','14.15','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:25',NULL),(508,'226',NULL,NULL,'503','241121212513','2026-03-25','1970-01-01','02805','10.2679','2910','0.00','20','11.61','0','10.2679','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:27',NULL),(509,'226',NULL,NULL,'504','241121212620','2026-03-25','1970-01-01','02806','10.2679','420','0.00','20','11.61','0','10.2679','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:29',NULL),(510,'226',NULL,NULL,'505','241121212717','2026-03-25','1970-01-01','02807','10.2679','4380','0.00','20','11.61','0','10.2679','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:30',NULL),(511,'226',NULL,NULL,'506','241121213017','2026-03-25','1970-01-01','02808','10.2679','3870','0.00','20','11.61','0','10.2679','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:32',NULL),(512,'226',NULL,NULL,'507','241121213219','2026-03-25','1970-01-01','02908','5.848','9360','0.00','10','6.6964','0','5.848','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:34',NULL),(513,'226',NULL,NULL,'508','241121213316','2026-03-25','1970-01-01','02909','5.848','9360','0.00','10','6.6964','0','5.848','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:36',NULL),(514,'226',NULL,NULL,'509','241121213416','2026-03-25','1970-01-01','02910','5.848','4320','0.00','10','6.6964','0','5.848','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:37',NULL),(515,'226',NULL,NULL,'510','241123175520','2026-03-25','1970-01-01','12001','6.25','15360','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:39',NULL),(516,'226',NULL,NULL,'511','241123175723','2026-03-25','1970-01-01','1202','6.25','960','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:41',NULL),(517,'226',NULL,NULL,'512','241123175940','2026-03-25','1970-01-01','1203','6.25','9450','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:43',NULL),(518,'226',NULL,NULL,'513','241125185346','2026-03-25','1970-01-01','02809','10.2678','4200','0.00','20','11.61','0','10.2678','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:44',NULL),(519,'226',NULL,NULL,'514','241125194914','2026-03-25','1970-01-01','02810','10.2678','3810','0.00','20','11.61','0','10.2678','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:46',NULL),(520,'226',NULL,NULL,'515','241125195012','2026-03-25','1970-01-01','02811','10.2678','210','0.00','20','11.61','0','10.2678','0','1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:48',NULL),(521,'226',NULL,NULL,'516','241126131921','2026-03-25','1970-01-01','02641','13.56','2400','0.00','20','14.152','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:50',NULL),(522,'226',NULL,NULL,'517','241126132119','2026-03-25','1970-01-01','02642','13.56','1440','0.00','20','14.152','0','13.56','0','0.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:51',NULL),(523,'226',NULL,NULL,'518','241129140624','2026-03-25','1970-01-01','02912','6.25','11000','0.00','10','6.69','0','6.25','0','0.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:53',NULL),(524,'226',NULL,NULL,'519','241203212712','2026-03-25','1970-01-01','03001','27.23','1344','0.00','50','29.018','0','27.23','0','1.79','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:55',NULL),(525,'226',NULL,NULL,'520','241203212815','2026-03-25','1970-01-01','03002','27.23','552','0.00','50','29.18','0','27.23','0','1.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:57',NULL),(526,'226',NULL,NULL,'521','241203212922','2026-03-25','1970-01-01','03003','27.23','576','0.00','50','29.018','0','27.23','0','1.79','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:13:58',NULL),(527,'226',NULL,NULL,'522','241203215119','2026-03-25','1970-01-01','03004','31.78','0','0.00','50','33.9','0','31.78','0','2.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:00',NULL),(528,'226',NULL,NULL,'523','241210115421','2026-03-25','1970-01-01','2812','10.2678','9360','0.00','20','14','0','10.2678','0','3.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:02',NULL),(529,'226',NULL,NULL,'524','241213151408','2026-03-25','1970-01-01','03005','60.86','72','0.00','70','42','0','60.86','0','-18.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:04',NULL),(530,'226',NULL,NULL,'525','241215105125','2026-03-25','1970-01-01','0001','76.6048','355','0.00','105','92','0','76.6048','0','15.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:05',NULL),(531,'226',NULL,NULL,'526','250104204218','2026-03-25','1970-01-01','03006','6.78','1296','0.00','10','6.82','0','6.78','0','0.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:07',NULL),(532,'226',NULL,NULL,'527','250104204423','2026-03-25','1970-01-01','03007','3.39','6720','0.00','5','3.41','0','3.39','0','0.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:09',NULL),(533,'226',NULL,NULL,'528','250106124654','2026-03-25','1970-01-01','03008','3.39','29920','0.00','5','3.82','0','3.39','0','0.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:11',NULL),(534,'226',NULL,NULL,'529','250106124742','2026-03-25','1970-01-01','03009','3.39','3648','0.00','5','3.92','0','3.39','0','0.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:12',NULL),(535,'226',NULL,NULL,'530','250106125759','2026-03-25','1970-01-01','03010','3.39','41920','0.00','5','3.42','0','3.39','0','0.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:14',NULL),(536,'226',NULL,NULL,'531','250106180512','2026-03-25','2026-03-25','03011','85','540','0.00','0','85','0','85','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:16',NULL),(537,'226',NULL,NULL,'532','250106180713','2026-03-25','2026-03-25','03012','85','410','0.00','0','85','0','85','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:18',NULL),(538,'226',NULL,NULL,'533','250106180801','2026-03-25','2026-03-25','03013','85','1160','0.00','0','85','0','85','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:20',NULL),(539,'226',NULL,NULL,'534','250107203837','2026-03-25','1970-01-01','03014','13.56','750','0.00','20','13.75','0','13.56','0','0.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:21',NULL),(540,'226',NULL,NULL,'535','250107203936','2026-03-25','1970-01-01','03015','13.56','0','0.00','20','13.72','0','13.56','0','0.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:23',NULL),(541,'226',NULL,NULL,'536','250109120904','2026-03-25','1970-01-01','03018','6.7','2440','0.00','10','7.12','0','6.7','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:25',NULL),(542,'226',NULL,NULL,'537','250115131050','2026-03-25','1970-01-01','03101','71.46','0','0.00','84','76.92','0','71.46','0','5.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:27',NULL),(543,'226',NULL,NULL,'538','250115131859','2026-03-25','1970-01-01','03102','43.93','67','0.00','55','44.51','0','43.93','0','0.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:28',NULL),(544,'226',NULL,NULL,'539','250115132237','2026-03-25','1970-01-01','03103','79.5','0','0.00','95','80','0','79.5','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:30',NULL),(545,'226',NULL,NULL,'540','250115132441','2026-03-25','1970-01-01','03104','47.92','0','0.00','60','48','0','47.92','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:32',NULL),(546,'226',NULL,NULL,'541','250115132708','2026-03-25','1970-01-01','03105','63.9','48','0.00','80','0','0','63.9','0','-63.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:34',NULL),(547,'226',NULL,NULL,'542','250117180046','2026-03-25','1970-01-01','03106','3.38','380','0.00','5','3.42','0','3.38','0','0.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:36',NULL),(548,'226',NULL,NULL,'543','250117182339','2026-03-25','1970-01-01','03107','6.78','8100','0.00','10','6.95','0','6.78','0','0.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:37',NULL),(549,'226',NULL,NULL,'544','250120151654','2026-03-25','2026-03-25','03108','85','170','0.00','0','85','0','85','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:39',NULL),(550,'226',NULL,NULL,'545','250120154532','2026-03-25','2026-03-25','03109','1600','2.990000000000002','0.00','0','1600','0','1600','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:41',NULL),(551,'226',NULL,NULL,'546','250122182032','2026-03-25','1970-01-01','04001','10.16','4512','0.00','20','10.16','0','10.16','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:43',NULL),(552,'226',NULL,NULL,'547','250122182133','2026-03-25','1970-01-01','04002','10.16','1296','0.00','20','10.16','0','10.16','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:45',NULL),(553,'226',NULL,NULL,'548','250122182223','2026-03-25','1970-01-01','04003','10.16','2688','0.00','20','10.16','0','10.16','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:47',NULL),(554,'226',NULL,NULL,'549','250122182318','2026-03-25','1970-01-01','04004','10.16','2880','0.00','20','10.16','0','10.16','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:48',NULL),(555,'226',NULL,NULL,'550','250122182429','2026-03-25','1970-01-01','04005','9','0','0.00','20','9','0','9','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:50',NULL),(556,'226',NULL,NULL,'551','250122182610','2026-03-25','1970-01-01','04006','10','0','0.00','20','10','0','10','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:52',NULL),(557,'226',NULL,NULL,'552','250122182707','2026-03-25','1970-01-01','04007','10','0','0.00','20','10','0','10','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:54',NULL),(558,'226',NULL,NULL,'553','250124125737','2026-03-25','1970-01-01','04009','51.93','1830','0.00','65','55.56','0','51.93','0','3.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:56',NULL),(559,'226',NULL,NULL,'554','250124125829','2026-03-25','1970-01-01','04010','39.93','0','0.00','50','40.17','0','39.93','0','0.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:14:58',NULL),(560,'226',NULL,NULL,'555','250126220340','2026-03-25','1970-01-01','04011','6.36','576','0.00','10','6.78','0','6.36','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:00',NULL),(561,'226',NULL,NULL,'556','250126220459','2026-03-25','1970-01-01','04012','6.36','0','0.00','10','6.78','0','6.36','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:01',NULL),(562,'226',NULL,NULL,'557','250127201659','2026-03-25','1970-01-01','04101','42.86','0','0.00','57','43','0','42.86','0','0.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:03',NULL),(563,'226',NULL,NULL,'558','250127201808','2026-03-25','1970-01-01','04102','85.71','0','0.00','120','86','0','85.71','0','0.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:05',NULL),(564,'226',NULL,NULL,'559','250127201958','2026-03-25','1970-01-01','04103','42.86','33','0.00','60','43','0','42.86','0','0.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:07',NULL),(565,'226',NULL,NULL,'560','250127202119','2026-03-25','1970-01-01','04104','35.71','199','0.00','47','36','0','35.71','0','0.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:09',NULL),(566,'226',NULL,NULL,'561','250127202227','2026-03-25','1970-01-01','04105','32.09','270','0.00','45','33','0','32.09','0','0.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:11',NULL),(567,'226',NULL,NULL,'562','250127202351','2026-03-25','1970-01-01','04106','39.29','0','0.00','55','40','0','39.29','0','0.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:13',NULL),(568,'226',NULL,NULL,'563','250127202533','2026-03-25','1970-01-01','04107','39.28','0','0.00','55','40','0','39.28','0','0.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:14',NULL),(569,'226',NULL,NULL,'564','250127202710','2026-03-25','1970-01-01','04108','39.28','0','0.00','55','40','0','39.28','0','0.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:16',NULL),(570,'226',NULL,NULL,'565','250127202926','2026-03-25','1970-01-01','04109','35.71','0','0.00','50','36','0','35.71','0','0.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:18',NULL),(571,'226',NULL,NULL,'566','250127203150','2026-03-25','1970-01-01','04110','82.1428','0','0.00','115','83','0','82.1428','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:20',NULL),(572,'226',NULL,NULL,'567','250127203305','2026-03-25','1970-01-01','04111','42.8571','0','0.00','57','43','0','42.8571','0','0.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:22',NULL),(573,'226',NULL,NULL,'568','250128181048','2026-03-25','1970-01-01','04112','7.0795','1368','0.00','10','7.1','0','7.0795','0','0.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:24',NULL),(574,'226',NULL,NULL,'569','250129122013','2026-03-25','1970-01-01','04113','16.53','3408','0.00','30','17','0','16.53','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:25',NULL),(575,'226',NULL,NULL,'570','250129122114','2026-03-25','1970-01-01','04114','16.53','0','0.00','30','17','0','16.53','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:27',NULL),(576,'226',NULL,NULL,'571','250131202243','2026-03-25','1970-01-01','04115','6.78','0','0.00','10','6.84','0','6.78','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:29',NULL),(577,'226',NULL,NULL,'572','250203195818','2026-03-25','1970-01-01','04116','3.39','560','0.00','5','3.42','0','3.39','0','0.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:31',NULL),(578,'226',NULL,NULL,'573','250210130801','2026-03-25','1970-01-01','04118','13.56','4000','0.00','20','14','0','13.56','0','0.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:33',NULL),(579,'226',NULL,NULL,'574','250210131335','2026-03-25','1970-01-01','04119','13.56','60','0.00','20','14','0','13.56','0','0.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:35',NULL),(580,'226',NULL,NULL,'575','250210131645','2026-03-25','1970-01-01','04120','8.135','7920','0.00','20','10.16','0','8.135','0','2.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:37',NULL),(581,'226',NULL,NULL,'576','250210131751','2026-03-25','1970-01-01','04121','8.135','3600','0.00','20','10.16','0','8.135','0','2.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:39',NULL),(582,'226',NULL,NULL,'577','250210131900','2026-03-25','1970-01-01','04122','8.135','4320','0.00','20','10.16','0','8.135','0','2.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:41',NULL),(583,'226',NULL,NULL,'578','250210183506','2026-03-25','1970-01-01','04123','8.135','5640','0.00','20','10.16','0','8.135','0','2.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:43',NULL),(584,'226',NULL,NULL,'579','250210213927','2026-03-25','1970-01-01','04124','6.25','6128','0.00','10','7.1428','0','6.25','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:44',NULL),(585,'226',NULL,NULL,'580','250211144749','2026-03-25','1970-01-01','00001','6.25','744','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:46',NULL),(586,'226',NULL,NULL,'581','250214143450','2026-03-25','2026-03-25','04125','144.64','797','0.00','200','145.5','0','144.64','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:48',NULL),(587,'226',NULL,NULL,'582','250220152711','2026-03-25','2026-03-25','04131','360','50','0.00','0','360','0','360','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:50',NULL),(588,'226',NULL,NULL,'583','250220152903','2026-03-25','2026-03-25','04132','220','12','0.00','0','220','0','220','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:52',NULL),(589,'226',NULL,NULL,'584','250220153016','2026-03-25','2026-03-25','04133','200','0','0.00','0','200','0','200','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:54',NULL),(590,'226',NULL,NULL,'585','250221152942','2026-03-25','1970-01-01','04013','9.15','1920','0.00','20','10','0','9.15','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:56',NULL),(591,'226',NULL,NULL,'586','250221153035','2026-03-25','1970-01-01','04014','9.15','1152','0.00','20','10','0','9.15','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:15:58',NULL),(592,'226',NULL,NULL,'587','250221153135','2026-03-25','1970-01-01','04015','9.15','0','0.00','20','10','0','9.15','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:00',NULL),(593,'226',NULL,NULL,'588','250222132413','2026-03-25','2026-03-25','04016','953.39','21','0.00','0','953.39','0','953.39','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:01',NULL),(594,'226',NULL,NULL,'589','250222132558','2026-03-25','2026-03-25','04017','228.814','46','0.00','0','228.814','0','228.814','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:03',NULL),(595,'226',NULL,NULL,'590','250306144819','2026-03-25','1970-01-01','04018','27.34','0','0.00','35','26','0','27.34','0','-1.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:05',NULL),(596,'226',NULL,NULL,'591','250310104133','2026-03-25','2026-03-25','04019','62.97','212','0.00','0','63','0','62.97','0','0.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:07',NULL),(597,'226',NULL,NULL,'592','250310104257','2026-03-25','2026-03-25','04020','62.97','152','0.00','0','63','0','62.97','0','0.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:09',NULL),(598,'226',NULL,NULL,'593','250310104350','2026-03-25','2026-03-25','04021','62.97','152','0.00','0','63','0','62.97','0','0.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:11',NULL),(599,'226',NULL,NULL,'594','250310105753','2026-03-25','2026-03-25','04022','60','400','0.00','0','61','0','60','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:13',NULL),(600,'226',NULL,NULL,'595','250311204109','2026-03-25','1970-01-01','04023','14.24','1920','0.00','30','14.4','0','14.24','0','0.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:15',NULL),(601,'226',NULL,NULL,'596','250311204231','2026-03-25','1970-01-01','04024','9.4915','0','0.00','20','9.65','0','9.4915','0','0.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:17',NULL),(602,'226',NULL,NULL,'597','250311204931','2026-03-25','1970-01-01','04025','9.4915','0','0.00','20','9.65','0','9.4915','0','0.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:19',NULL),(603,'226',NULL,NULL,'598','250320131305','2026-03-25','1970-01-01','04026','5.81','0','0.00','10','6.7','0','5.81','0','0.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:21',NULL),(604,'226',NULL,NULL,'599','250324180614','2026-03-25','1970-01-01','04027','4.66','46400','0.00','10','4.78','0','4.66','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:23',NULL),(605,'226',NULL,NULL,'600','250324180802','2026-03-25','1970-01-01','04028','4.66','36160','0.00','10','4.78','0','4.66','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:24',NULL),(606,'226',NULL,NULL,'601','250327180232','2026-03-25','1970-01-01','04029','6.25','1960','0.00','10','8','0','6.25','0','1.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:26',NULL),(607,'226',NULL,NULL,'602','250402144849','2026-03-25','1970-01-01','04030','6.25','150000','0.00','10','6.7','0','6.25','0','0.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:28',NULL),(608,'226',NULL,NULL,'603','250405122437','2026-03-25','1970-01-01','04031','5.84','800','0.00','10','6.25','0','5.84','0','0.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:30',NULL),(609,'226',NULL,NULL,'604','250405122533','2026-03-25','1970-01-01','04032','5.84','0','0.00','10','6.25','0','5.84','0','0.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:32',NULL),(610,'226',NULL,NULL,'605','250405122623','2026-03-25','1970-01-01','04033','5.84','0','0.00','10','6.25','0','5.84','0','0.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:34',NULL),(611,'226',NULL,NULL,'606','250408223428','2026-03-25','1970-01-01','04034','6.78','80000','0.00','10','7.12','0','6.78','0','0.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:36',NULL),(612,'226',NULL,NULL,'607','250408224027','2026-03-25','1970-01-01','04035','3.38','18000','0.00','5','3.56','0','3.38','0','0.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:38',NULL),(613,'226',NULL,NULL,'608','250411152841','2026-03-25','1970-01-01','04036','10.16','2880','0.00','18','10.25','0','10.16','0','0.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:40',NULL),(614,'226',NULL,NULL,'609','250411154456','2026-03-25','1970-01-01','04201','10.16','2500','0.00','20','10.25','0','10.16','0','0.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:42',NULL),(615,'226',NULL,NULL,'610','250411154559','2026-03-25','1970-01-01','04202','10.16','0','0.00','20','10.25','0','10.16','0','0.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:44',NULL),(616,'226',NULL,NULL,'611','250411154711','2026-03-25','1970-01-01','04203','10.16','0','0.00','20','10.25','0','10.16','0','0.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:46',NULL),(617,'226',NULL,NULL,'612','250411154811','2026-03-25','1970-01-01','04204','10.16','0','0.00','20','10.25','0','10.163','0','0.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:48',NULL),(618,'226',NULL,NULL,'613','250416142143','2026-03-25','1970-01-01','04205','6.25','4800','0.00','10','6.7','0','6.25','0','0.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:50',NULL),(619,'226',NULL,NULL,'614','250424110935','2026-03-25','1970-01-01','04206','3.35','14400','0.00','5','3.41','0','3.35','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:51',NULL),(620,'226',NULL,NULL,'615','250429114901','2026-03-25','1970-01-01','04207','4.661','6000','0.00','10','4.78','0','4.661','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:53',NULL),(621,'226',NULL,NULL,'616','250429115029','2026-03-25','1970-01-01','04208','4.661','0','0.00','10','4.78','0','4.661','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:55',NULL),(622,'226',NULL,NULL,'617','250429115200','2026-03-25','1970-01-01','04209','4.661','0','0.00','10','4.78','0','4.661','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:57',NULL),(623,'226',NULL,NULL,'618','250429120030','2026-03-25','1970-01-01','04210','5.58','40000','0.00','10','5.7','0','5.58','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:16:59',NULL),(624,'226',NULL,NULL,'619','250429120223','2026-03-25','1970-01-01','04211','5.58','0','0.00','10','5.7','0','5.58','0','0.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:01',NULL),(625,'226',NULL,NULL,'620','250521113716','2026-03-25','1970-01-01','04212','80.36','750','0.00','114','84.37','0','80.36','0','4.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:03',NULL),(626,'226',NULL,NULL,'621','250521113900','2026-03-25','1970-01-01','04213','63.62','0','0.00','90','64.12','0','63.62','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:05',NULL),(627,'226',NULL,NULL,'622','250522154439','2026-03-25','1970-01-01','04214','10.48','28000','0.00','20','11','0','10.48','0','0.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:07',NULL),(628,'226',NULL,NULL,'623','250524125659','2026-03-25','1970-01-01','04215','13.98','1680','0.00','30','14.25','0','13.98','0','0.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:09',NULL),(629,'226',NULL,NULL,'624','250524125918','2026-03-25','1970-01-01','04216','13.98','0','0.00','30','14.25','0','13.98','0','0.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:11',NULL),(630,'226',NULL,NULL,'625','250524130156','2026-03-25','1970-01-01','04217','13.98','0','0.00','30','14.25','0','13.98','0','0.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:13',NULL),(631,'226',NULL,NULL,'626','250524142043','2026-03-25','2026-03-25','04218','79.23','1500','0.00','110','80.23','0','79.23','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:15',NULL),(632,'226',NULL,NULL,'627','250528141920','2026-03-25','1970-01-01','04220','93','600','0.00','113','94','0','93','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:17',NULL),(633,'226',NULL,NULL,'628','250528142028','2026-03-25','1970-01-01','04221','55','0','0.00','85','56','0','55','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:19',NULL),(634,'226',NULL,NULL,'629','250528142130','2026-03-25','1970-01-01','04222','90','0','0.00','99','91','0','90','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:21',NULL),(635,'226',NULL,NULL,'630','250529115333','2026-03-25','1970-01-01','04223','9.29','3072','0.00','20','9.4','0','9.29','0','0.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:23',NULL),(636,'226',NULL,NULL,'631','250529115600','2026-03-25','1970-01-01','04224','9.29','0','0.00','20','9.4','0','9.29','0','0.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:24',NULL),(637,'226',NULL,NULL,'632','250529115709','2026-03-25','1970-01-01','04225','9.29','0','0.00','20','9.4','0','9.29','0','0.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:26',NULL),(638,'226',NULL,NULL,'633','250602122734','2026-03-25','1970-01-01','04226','73.46','60','0.00','85','78.26','0','73.46','0','4.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:28',NULL),(639,'226',NULL,NULL,'634','250614192640','2026-03-25','1970-01-01','04227','15.71','3000','0.00','30','16','0','15.71','0','0.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:30',NULL),(640,'226',NULL,NULL,'635','250617113846','2026-03-25','1970-01-01','04228','6.19','2880','0.00','10','6.61','0','6.19','0','0.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:32',NULL),(641,'226',NULL,NULL,'636','250623103438','2026-03-25','1970-01-01','04229','6.19','2880','0.00','10','6.25','0','6.19','0','0.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:34',NULL),(642,'226',NULL,NULL,'637','250721164909','2026-03-25','1970-01-01','04230','6.027','1920','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:36',NULL),(643,'226',NULL,NULL,'638','250721165013','2026-03-25','1970-01-01','04231','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:38',NULL),(644,'226',NULL,NULL,'639','250721165112','2026-03-25','1970-01-01','04232','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:40',NULL),(645,'226',NULL,NULL,'640','250721165211','2026-03-25','1970-01-01','04233','6.02','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:42',NULL),(646,'226',NULL,NULL,'641','250721165311','2026-03-25','1970-01-01','04234','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:44',NULL),(647,'226',NULL,NULL,'642','250721165412','2026-03-25','1970-01-01','04235','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:46',NULL),(648,'226',NULL,NULL,'643','250721165541','2026-03-25','1970-01-01','04236','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:48',NULL),(649,'226',NULL,NULL,'644','250721165645','2026-03-25','1970-01-01','04237','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:50',NULL),(650,'226',NULL,NULL,'645','250721165745','2026-03-25','1970-01-01','04238','6.027','0','0.00','10','6.7','0','6.027','0','0.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:52',NULL),(651,'226',NULL,NULL,'646','250722144317','2026-03-25','2026-03-25','04239','160','200','0.00','0','160','0','160','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:54',NULL),(652,'226',NULL,NULL,'647','250830145632','2026-03-25','1970-01-01','05001','151.19','432','0.00','210','171.42','0','151.19','0','20.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:56',NULL),(653,'226',NULL,NULL,'648','250830145745','2026-03-25','1970-01-01','05002','151.19','0','0.00','210','171.42','0','151.19','0','20.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:17:58',NULL),(654,'226',NULL,NULL,'649','250904235549','2026-03-25','1970-01-01','05003','233.97','384','0.00','325','258.09','0','233.97','0','24.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:00',NULL),(655,'226',NULL,NULL,'650','250929162801','2026-03-25','1970-01-01','05004','7.1428','1080','0.00','10','7.34','0','7.1428','0','0.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:02',NULL),(656,'226',NULL,NULL,'651','251005114355','2026-03-25','1970-01-01','05005','7.1428','3000','0.00','10','7.62','0','7.1428','0','0.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:04',NULL),(657,'226',NULL,NULL,'652','251005114722','2026-03-25','1970-01-01','05006','3.35','0','0.00','5','3.82','0','3.35','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:06',NULL),(658,'226',NULL,NULL,'653','251006163443','2026-03-25','2026-03-25','05007','391.88','35','0.00','450','409.09','0','391.88','0','17.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:08',NULL),(659,'226',NULL,NULL,'654','251016012946','2026-03-25','1970-01-01','05008','6.86','1440','0.00','10','7.2','0','6.86','0','0.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:10',NULL),(660,'226',NULL,NULL,'655','251106150211','2026-03-25','1970-01-01','05009','10.78','225','0.00','20','11','0','10.78','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:12',NULL),(661,'226',NULL,NULL,'656','251106150324','2026-03-25','1970-01-01','05010','10.78','0','0.00','20','11','0','10.78','0','0.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:14',NULL),(662,'226',NULL,NULL,'657','251117041133','2026-03-25','1970-01-01','05011','57.14','576','0.00','80','60.95','0','57.14','0','3.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:16',NULL),(663,'226',NULL,NULL,'658','251117162700','2026-03-25','1970-01-01','05012','11.81','4200','0.00','20','12.9523','0','11.81','0','1.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:18',NULL),(664,'226',NULL,NULL,'659','251203123035','2026-03-25','1970-01-01','06001','7.0476','6000','0.00','10','7.4285','0','7.0476','0','0.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:20',NULL),(665,'226',NULL,NULL,'660','251203123136','2026-03-25','1970-01-01','06002','7.0476','0','0.00','10','7.4285','0','7.0476','0','0.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:22',NULL),(666,'226',NULL,NULL,'661','251203123233','2026-03-25','1970-01-01','06003','7.0476','0','0.00','10','7.4285','0','7.0476','0','0.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:24',NULL),(667,'226',NULL,NULL,'662','251203123332','2026-03-25','1970-01-01','06004','7.0476','0','0.00','10','7.4285','0','7.0476','0','0.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:26',NULL),(668,'226',NULL,NULL,'663','251203123445','2026-03-25','1970-01-01','06005','7.0476','0','0.00','10','7.4285','0','7.0476','0','0.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:28',NULL),(669,'226',NULL,NULL,'664','251215113656','2026-03-25','1970-01-01','07001','39.56','0','0.00','52','40.6','0','39.56','0','1.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:30',NULL),(670,'226',NULL,NULL,'665','251215113831','2026-03-25','1970-01-01','07002','57.06','0','0.00','75','58.01','0','57.06','0','0.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:32',NULL),(671,'226',NULL,NULL,'666','251215113948','2026-03-25','1970-01-01','07003','39.56','0','0.00','52','40.6','0','39.56','0','1.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:34',NULL),(672,'226',NULL,NULL,'667','251215114228','2026-03-25','1970-01-01','07004','47.17','0','0.00','62','48.27','0','47.17','0','1.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:36',NULL),(673,'226',NULL,NULL,'668','251215114334','2026-03-25','1970-01-01','07005','43.36','0','0.00','57','44.46','0','43.36','0','1.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:38',NULL),(674,'226',NULL,NULL,'669','251215114503','2026-03-25','1970-01-01','07006','102.7','0','0.00','135','103.8','0','102.7','0','1.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:40',NULL),(675,'226',NULL,NULL,'670','251215114622','2026-03-25','1970-01-01','07007','49.45','0','0.00','65','50.45','0','49.45','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:42',NULL),(676,'226',NULL,NULL,'671','251215114748','2026-03-25','1970-01-01','07008','53.25','0','0.00','67','54.35','0','53.25','0','1.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:43',NULL),(677,'226',NULL,NULL,'672','251215114914','2026-03-25','1970-01-01','07009','32.71','0','0.00','43','33.34','0','32.71','0','0.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:46',NULL),(678,'226',NULL,NULL,'673','251215115027','2026-03-25','1970-01-01','07010','31.95','0','0.00','42','32.96','0','31.95','0','1.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:48',NULL),(679,'226',NULL,NULL,'674','251215115242','2026-03-25','1970-01-01','07011','38.04','0','0.00','50','39.15','0','38.04','0','1.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:50',NULL),(680,'226',NULL,NULL,'675','251215115345','2026-03-25','1970-01-01','07012','49.45','0','0.00','62','50.6','0','49.45','0','1.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:52',NULL),(681,'226',NULL,NULL,'676','251215115452','2026-03-25','1970-01-01','07013','47.17','0','0.00','62','49.27','0','47.17','0','2.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:54',NULL),(682,'226',NULL,NULL,'677','251215115629','2026-03-25','1970-01-01','07014','47','0','0.00','62','49','0','47','0','2.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:56',NULL),(683,'226',NULL,NULL,'678','251215115744','2026-03-25','1970-01-01','07015','43.36','0','0.00','57','44.45','0','43.36','0','1.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:18:58',NULL),(684,'226',NULL,NULL,'679','251215115854','2026-03-25','1970-01-01','07016','35.76','0','0.00','47','37.15','0','35.76','0','1.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:01',NULL),(685,'226',NULL,NULL,'680','251215120015','2026-03-25','1970-01-01','07017','39.56','0','0.00','52','40.6','0','39.56','0','1.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:04',NULL),(686,'226',NULL,NULL,'681','251215120121','2026-03-25','1970-01-01','07018','174.15','0','0.00','225','176','0','174.15','0','1.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:07',NULL),(687,'226',NULL,NULL,'682','251215120246','2026-03-25','1970-01-01','07019','60.86','0','0.00','80','62','0','60.86','0','1.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:11',NULL),(688,'226',NULL,NULL,'683','251215120402','2026-03-25','1970-01-01','07020','38.04','0','0.00','50','39.5','0','38.04','0','1.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:15',NULL),(689,'226',NULL,NULL,'684','251215120533','2026-03-25','1970-01-01','07021','57.06','0','0.00','75','59','0','57.06','0','1.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:19',NULL),(690,'226',NULL,NULL,'685','251227115622','2026-03-25','2026-03-25','07031','159','150','0.00','0','160','0','159','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:24',NULL),(691,'226',NULL,NULL,'686','260108160411','2026-03-25','1970-01-01','07032','9.84','0','0.00','20','9.84','0','10.63','0','-0.79','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:28',NULL),(692,'226',NULL,NULL,'687','260114141935','2026-03-25','1970-01-01','07040','35.76','360','0.00','47','36','0','35.76','0','0.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:31',NULL),(693,'226',NULL,NULL,'688','260114142102','2026-03-25','1970-01-01','07041','57.06','0','0.00','75','58','0','57.06','0','0.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:35',NULL),(694,'226',NULL,NULL,'689','260114142506','2026-03-25','1970-01-01','07042','31.95','900','0.00','42','32','0','31.95','0','0.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:38',NULL),(695,'226',NULL,NULL,'690','260120104522','2026-03-25','1970-01-01','07043','11.92','5250','0.00','20','12','0','11.92','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:42',NULL),(696,'226',NULL,NULL,'691','260120104658','2026-03-25','1970-01-01','07044','11.92','0','0.00','20','12','0','11.92','0','0.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:47',NULL),(697,'226',NULL,NULL,'692','260202121120','2026-03-25','1970-01-01','07045','7.1428','2800','0.00','10','7.67','0','7.1428','0','0.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:52',NULL),(698,'226',NULL,NULL,'693','260205125419','2026-03-25','1970-01-01','07046','6.67','30000','0.00','10','7.5238','0','6.67','0','0.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:19:58',NULL),(699,'226',NULL,NULL,'694','260210151312','2026-03-25','1970-01-01','07047','6.43','1200','0.00','10','6.53','0','6.43','0','0.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:04',NULL),(700,'226',NULL,NULL,'695','260211102518','2026-03-25','1970-01-01','07048','25','400','0.00','35','25.2','0','25','0','0.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:10',NULL),(701,'226',NULL,NULL,'696','260212153857','2026-03-25','1970-01-01','07049','9.84','60','0.00','20','10.28','0','9.84','0','0.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:14',NULL),(702,'226',NULL,NULL,'697','260214113008','2026-03-25','1970-01-01','07050','9.84','1200','0.00','20','10.8','0','9.84','0','0.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:20',NULL),(703,'226',NULL,NULL,'698','260217154747','2026-03-25','1970-01-01','07051','169.52','8000','0.00','0','185.7142','0','169.52','0','16.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:26',NULL),(704,'226',NULL,NULL,'699','260218192539','2026-03-25','1970-01-01','08001','153.57','0','0.00','215','154','0','153.57','0','0.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:31',NULL),(705,'226',NULL,NULL,'700','260218192735','2026-03-25','1970-01-01','08002','196.43','0','0.00','275','197','0','196.43','0','0.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:37',NULL),(706,'226',NULL,NULL,'701','260218192900','2026-03-25','1970-01-01','08003','157.14','0','0.00','220','158','0','157.14','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:41',NULL),(707,'226',NULL,NULL,'702','260218193225','2026-03-25','1970-01-01','08004','117.86','0','0.00','165','118','0','117.86','0','0.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:44',NULL),(708,'226',NULL,NULL,'703','260218193735','2026-03-25','1970-01-01','08005','33.57','120','0.00','47','34','0','33.57','0','0.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:48',NULL),(709,'226',NULL,NULL,'704','260218194335','2026-03-25','1970-01-01','08006','30','0','0.00','42','31','0','30','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:52',NULL),(710,'226',NULL,NULL,'705','260218200335','2026-03-25','1970-01-01','08007','37.14','0','0.00','52','38','0','37.14','0','0.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:56',NULL),(711,'226',NULL,NULL,'706','260312142911','2026-03-25','1970-01-01','04501','120','600','0.00','175','131.25','0','120','0','11.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-03-25 10:20:59',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=712 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int(11) DEFAULT 0,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int(11) DEFAULT 0,
  `M_ROUND_OFF` int(11) DEFAULT 0,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL,
  `LITE_ID` varchar(50) DEFAULT '',
  `WEB_ID` varchar(50) DEFAULT '',
  `PROD_ID` int(11) NOT NULL,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` varchar(50) DEFAULT NULL,
  `PUR_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT` varchar(25) DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) DEFAULT '0',
  `PUR_CESS` varchar(25) DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) DEFAULT '0',
  `PACK` varchar(25) DEFAULT '0',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(25) DEFAULT '0',
  `DISC_PERCENT` varchar(25) DEFAULT '0',
  `DISC_AMOUNT` varchar(25) DEFAULT '0',
  `RETURN_QTY` varchar(25) DEFAULT '0',
  `FREE` varchar(25) DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) DEFAULT '0',
  `AMT` varchar(25) DEFAULT '0',
  `TAX_AMT` varchar(25) DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) DEFAULT '0',
  `RETURN` varchar(25) DEFAULT '0',
  `SR_NO` varchar(50) DEFAULT '',
  `CESS_AMT` varchar(25) DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) DEFAULT '0',
  `UI_DISP_BAG` varchar(50) DEFAULT '',
  `WEIGHT` varchar(25) DEFAULT '0',
  `PRICE_PER` varchar(25) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT NULL,
  `TE_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) DEFAULT '0',
  `MRP` varchar(25) DEFAULT '0',
  `DAMAGE` varchar(25) DEFAULT '0',
  `DAMAGE_AMT` varchar(25) DEFAULT '0',
  `REPLACE` varchar(25) DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) DEFAULT '0',
  `DMG_MRP` varchar(25) DEFAULT '0',
  `PUR_INSURANCE` varchar(25) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) DEFAULT '0',
  `CLOUD_SYNC` varchar(25) DEFAULT '0',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT current_timestamp(),
  `UPDATED_TS` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `FINAL_AMT` varchar(25) DEFAULT '0',
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `TCS_TAX` varchar(100) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `BROKER_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (342,'226','0','emhLLi7twT','25032026','emhLLi7twT','25032026@yopmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','','342','1','',0,'2026-03-25 09:58:16','2026-03-25 10:01:29');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REMARKS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT 0,
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-03-25 09:58:11',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text DEFAULT NULL,
  `MAC_ID` int(11) DEFAULT 0,
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text DEFAULT NULL,
  `S_ADD2` text DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'226',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(2,'226',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(3,'226',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(4,'226',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(5,'226',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(6,'226',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(7,'226',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(8,'226',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(9,'226',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(10,'226',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(11,'226',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(12,'226',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(13,'226',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(14,'226',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(15,'226',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(16,'226',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(17,'226',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(18,'226',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(19,'226',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(20,'226',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(21,'226',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(22,'226',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(23,'226',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(24,'226',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(25,'226',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(26,'226',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(27,'226',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(28,'226',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(29,'226',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(30,'226',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(31,'226',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(32,'226',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(33,'226',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(34,'226',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(35,'226',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(36,'226',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(37,'226',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(38,'226',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(39,'226',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(40,'226',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(41,'226',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(42,'226',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(43,'226',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(44,'226',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(45,'226',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(46,'226',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(47,'226',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(48,'226',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(49,'226',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(50,'226',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(51,'226',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(52,'226',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(53,'226',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(54,'226',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(55,'226',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(56,'226',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(57,'226',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(58,'226',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(59,'226',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(60,'226',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(61,'226',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(62,'226',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(63,'226',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(64,'226',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(65,'226',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(66,'226',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(67,'226',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(68,'226',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(69,'226',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(70,'226',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(71,'226',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(72,'226',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(73,'226',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(74,'226',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(75,'226',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(76,'226',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(77,'226',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(78,'226',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(79,'226',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(80,'226',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(81,'226',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(82,'226',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(83,'226',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(84,'226',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(85,'226',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(86,'226',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(87,'226',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(88,'226',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(89,'226',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(90,'226',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(91,'226',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(92,'226',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(93,'226',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(94,'226',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(95,'226',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(96,'226',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(97,'226',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13'),(98,'226',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-03-25 09:58:13','2026-03-25 09:58:13');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int(11) NOT NULL DEFAULT 0,
  `ADDRESS1` text DEFAULT NULL,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `PG_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` int(11) DEFAULT 0,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT NULL,
  `LITE_ID` varchar(50) DEFAULT NULL,
  `WEB_ID` varchar(50) DEFAULT NULL,
  `PROD_ID` varchar(20) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) DEFAULT NULL,
  `SALES_ID` varchar(20) DEFAULT NULL,
  `SALE_UNIT` varchar(20) DEFAULT NULL,
  `SALE_RATE` varchar(20) DEFAULT NULL,
  `PUR_RATE` varchar(20) DEFAULT NULL,
  `PROD_PACK` varchar(20) DEFAULT NULL,
  `PUR_VAT` varchar(20) DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_VAT` varchar(20) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_CESS` varchar(20) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) DEFAULT NULL,
  `PACK` varchar(20) DEFAULT NULL,
  `BOX` varchar(20) DEFAULT NULL,
  `QTY` varchar(20) DEFAULT NULL,
  `DISC_PERCENT` varchar(20) DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) DEFAULT NULL,
  `RETURN_QTY` varchar(20) DEFAULT NULL,
  `FREE` varchar(20) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) DEFAULT NULL,
  `AMT` varchar(20) DEFAULT NULL,
  `PUR_AMT` varchar(20) DEFAULT NULL,
  `PROFIT` varchar(20) DEFAULT NULL,
  `TAX_AMT` varchar(20) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) DEFAULT NULL,
  `DAMAGE` varchar(20) DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) DEFAULT NULL,
  `REPLACE` varchar(25) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) DEFAULT NULL,
  `RETURN` varchar(25) DEFAULT NULL,
  `SR_NO` varchar(50) DEFAULT NULL,
  `CESS_AMT` varchar(20) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) DEFAULT NULL,
  `WEIGHT` varchar(20) DEFAULT NULL,
  `PUR_UNIT` varchar(20) DEFAULT NULL,
  `PRICE_PER` varchar(20) DEFAULT NULL,
  `TE_RATE` varchar(20) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) DEFAULT NULL,
  `DMG_MRP` varchar(20) DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) DEFAULT NULL,
  `INV_ARR` varchar(255) DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` varchar(20) DEFAULT NULL,
  `UPDATED_BY` varchar(20) DEFAULT NULL,
  `SECURITY_KEY` varchar(100) DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(20) DEFAULT NULL,
  `SALES_MAN` varchar(100) DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(20) DEFAULT NULL,
  `PARTY_CODE` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(20) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) DEFAULT NULL,
  `BATCH_NO` varchar(50) DEFAULT NULL,
  `MFG_DATE` varchar(20) DEFAULT NULL,
  `EXP_DATE` varchar(20) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int(11) DEFAULT 0,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int(11) DEFAULT 0,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int(11) DEFAULT 0,
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SMAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYNC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text DEFAULT NULL,
  `UPDATED_VALUE` text DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text DEFAULT NULL,
  `DIACM` text DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int(11) DEFAULT 0,
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int(11) DEFAULT 0,
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-03-25 09:58:11','2026-03-25 09:58:11');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UOM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT 0,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WEB_ID` int(11) NOT NULL DEFAULT 0,
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-03-25 09:58:16');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-09 18:01:06
