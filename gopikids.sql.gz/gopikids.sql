-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: gopikids
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `record_id` int(11) NOT NULL DEFAULT 0,
  `table_name` varchar(255) DEFAULT NULL,
  `record_name` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admissions`
--

DROP TABLE IF EXISTS `admissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admissions` (
  `admission_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_id` int(11) NOT NULL DEFAULT 0,
  `enrollment_no` varchar(255) DEFAULT NULL,
  `admission_date` varchar(255) DEFAULT NULL,
  `enroll_for` varchar(255) DEFAULT NULL,
  `child_photo` varchar(255) DEFAULT NULL,
  `child_pancard` varchar(255) DEFAULT NULL,
  `child_aadhar` varchar(255) DEFAULT NULL,
  `child_extra_document_1` varchar(255) DEFAULT NULL,
  `child_extra_document_2` varchar(255) DEFAULT NULL,
  `child_first_name` varchar(255) DEFAULT NULL,
  `child_middle_name` varchar(255) DEFAULT NULL,
  `child_last_name` varchar(255) DEFAULT NULL,
  `child_gender` varchar(255) DEFAULT NULL,
  `child_birth_date` varchar(255) DEFAULT NULL,
  `child_birth_place` varchar(255) DEFAULT NULL,
  `child_height` varchar(255) DEFAULT NULL,
  `child_weight` varchar(255) DEFAULT NULL,
  `child_blood_group` varchar(255) DEFAULT NULL,
  `child_regular_uniform_size` varchar(255) DEFAULT NULL,
  `child_winter_uniform_size` varchar(255) DEFAULT NULL,
  `child_birth_certificate` varchar(255) DEFAULT NULL,
  `home_spoken_language` varchar(255) DEFAULT NULL,
  `child_address` varchar(255) DEFAULT NULL,
  `child_contact` varchar(255) DEFAULT NULL,
  `children_stay_with` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `mother_photo` varchar(255) DEFAULT NULL,
  `mother_document_1` varchar(255) DEFAULT NULL,
  `mother_document_2` varchar(255) DEFAULT NULL,
  `mother_document_3` varchar(255) DEFAULT NULL,
  `mother_qualification` varchar(255) DEFAULT NULL,
  `mother_profession` varchar(255) DEFAULT NULL,
  `mother_birth_date` varchar(255) DEFAULT NULL,
  `mother_contact` varchar(255) DEFAULT NULL,
  `mother_email` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `father_photo` varchar(255) DEFAULT NULL,
  `father_document_1` varchar(255) DEFAULT NULL,
  `father_document_2` varchar(255) DEFAULT NULL,
  `father_document_3` varchar(255) DEFAULT NULL,
  `father_qualification` varchar(255) DEFAULT NULL,
  `father_professional` varchar(255) DEFAULT NULL,
  `father_birth_date` varchar(255) DEFAULT NULL,
  `father_contact` varchar(255) DEFAULT NULL,
  `father_email` varchar(255) DEFAULT NULL,
  `admission_status` varchar(255) DEFAULT NULL,
  `cancelled_status` varchar(10) NOT NULL DEFAULT 'N',
  `cancelled_reason` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(5) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `branch` varchar(255) DEFAULT NULL,
  `playgroup_fees` varchar(255) DEFAULT NULL,
  `nursary_fees` varchar(255) DEFAULT NULL,
  `jrkg_fees` varchar(255) DEFAULT NULL,
  `srkg_fees` varchar(255) DEFAULT NULL,
  `daycare_fees` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`admission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admissions`
--

LOCK TABLES `admissions` WRITE;
/*!40000 ALTER TABLE `admissions` DISABLE KEYS */;
INSERT INTO `admissions` VALUES (1,0,'E101','2026-08-04','Play Group',NULL,NULL,NULL,NULL,NULL,'Child Name','Child Middle','Child Last','Male','2022-01-01','Ajwa Road','23','34','Unknown','20','20',NULL,'Gujarati','Ajwa','09090909090','Both','Mothername',NULL,NULL,NULL,NULL,'BE','Teacher','1987-01-01','93939393993','mother@yopmail.com','Fathername',NULL,NULL,NULL,NULL,'B.ED','Lacturer','1987-01-01','93939393993','father@yopmail.com','inquiry','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-04 07:35:58','2026-08-09 17:55:13','Ankhol','20000','20000','20000','20000','20000'),(2,0,'E191','2026-08-04','Play Group','1785822820_child_photo_4506.png','1785822820_child_pancard_4163.png','1785822820_child_aadhar_8825.png','1785822820_child_extra_document_1_9813.png','1785822820_child_extra_document_2_2538.png','Child Name Update 123','Child Middle','Child Last','Male','2022-01-01','Ajwa Road','23','34','Unknown','20','20','1785822820_child_birth_certificate_4252.png','Gujarati','Ajwa','09090909090','Both','Mothername','1785823094_mother_photo_3402.png','1785823094_mother_document_1_7901.png','1785823094_mother_document_2_6817.png','1785823094_mother_document_3_8345.png','BE','Teacher','1987-01-01','93939393993','mother@yopmail.com','Fathername','1785823187_father_photo_5547.png','1785823187_father_document_1_1964.png','1785823187_father_document_2_4520.png','1785823187_father_document_3_5668.png','B.ED','Lacturer','1987-01-01','93939393993','father@yopmail.com','confirmed','N',NULL,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-04 07:37:29','2026-08-09 17:54:59','GayatriMandir','3000','3000','3000','3000','3000'),(3,0,'E394','2026-08-04','Day Care','1785824964_child_photo_5038.png',NULL,NULL,NULL,NULL,'Harshil','Dinesh','Patel','Male','2026-08-04','Waghodia Road','39','39','A-','20','20','1785824964_child_birth_certificate_2127.png','Gujarati','43 New Banks','93939399393','Both','Kokila','1785824964_mother_photo_8112.png','1785824964_mother_document_1_5651.png',NULL,NULL,'BE','Professor','2026-08-03','9393939393','fsafs@yopmail.com','Suresh',NULL,NULL,NULL,NULL,'BA','Journalist','2026-08-18','93939393','dsfasfs@yopmail.com','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-04 08:27:28','2026-08-09 17:53:45','GayatriMandir','20000','21000','22000','23000','24000'),(4,0,'1020261','2026-08-09','Jr.KG',NULL,NULL,NULL,NULL,NULL,'BHARGAVI SOLANKI','MAHENDRABHAI','SOLANKI','Female','2021-07-23','Vadodara ','','','Unknown','24','26',NULL,'Gujarati','A/56 BALAJINANDAN SOC.OPP MUNJAL AUTO,WAGHODIA','7405478566','Both','JAGRUTIBEN',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','6353144986','','MAHENDRABHAI',NULL,NULL,NULL,NULL,'','','','7405478566','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:57:04','2026-08-09 20:03:12','Waghodia','NA','NA','24500','NA','NA'),(5,0,'1020262','2026-08-09','Nursary',NULL,NULL,NULL,NULL,NULL,'SHAURYA RAVAL','DINESHKUMAR','RAVAL','Male','2022-07-16','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','36/2 MEGHDHANUSH SOC.MADODHAR ROAD WAGHODIA','9574736390','Both','BHUMIBEN',NULL,NULL,NULL,NULL,'','','','7990602700','','DINESHKUMAR',NULL,NULL,NULL,NULL,'','','','9574736390','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 19:20:03','2026-08-09 20:06:08','Waghodia','NA','23500','NA','NA','NA'),(6,0,'1020263','2026-08-09','Nursary',NULL,NULL,NULL,NULL,NULL,'HIYA HARIJAN','PRAVINBHAI','HARIJAN','Female','2022-04-11','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','NAVI NAGARI LIMDA','8200754690','Both','MONIKABEN',NULL,NULL,NULL,NULL,'','','','8849429807','','PRAVINBHAI',NULL,NULL,NULL,NULL,'','','','8200754690','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 19:37:39','2026-08-09 20:05:53','Waghodia','NA','23500','NA','NA','NA'),(7,0,'1020264','2026-08-09','Play Group',NULL,NULL,NULL,NULL,NULL,'JIYANSHI PATEL','PRATIKKUMAR','PATEL','Female','2023-07-04','','','','Unknown','20','20',NULL,'Gujarati','C/61 GALAXY SOC,MADODHAR WAGHODIA','9904856757','Both','JAYNISHA',NULL,NULL,NULL,NULL,'','','','9714381454','','PRATIKKUMAR',NULL,NULL,NULL,NULL,'','','','9904856757','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 19:42:03','2026-08-09 20:05:29','Waghodia','22000','NA','NA','NA','NA'),(8,0,'1020265','2026-08-09','Play Group',NULL,NULL,NULL,NULL,NULL,'HET MAKWANA','MAYANKBHAI','MAKWANA','Male','2023-12-30','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','5 AKSHAR PARK SOC,VAGHODIA','9537038520','Both','PALAK',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','9978974143','','MAYANKBHAI',NULL,NULL,NULL,NULL,'','','','9537038520','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 19:46:38','2026-08-09 20:05:07','Waghodia','22000','NA','NA','NA','NA'),(9,0,'1020266','2026-08-09','Sr.KG',NULL,NULL,NULL,NULL,NULL,'RISHV PANCHAL','VAIBHAVKUMAR','PANCHAL','Male','2021-04-26','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','KALP CHANDRA UNIC SOC,MADODHAR ROAD WAGHODIA','7043203052','Both','VISHAKHABEN',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','7043203052','','VAIBHAVKUMAR',NULL,NULL,NULL,NULL,'','','','7043203052','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 19:51:46','2026-08-09 20:03:57','Waghodia','NA','NA','NA','24000','NA'),(10,0,'1020267','2026-08-09','Nursary',NULL,NULL,NULL,NULL,NULL,'NAVYA ROHIT','RAKESHKUMAR','ROHIT','Female','2022-09-03','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','27 AKSHAR TOWNSHIP,WAGHODIA ','9773441740','Both','MINAXIBEN',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','9979500561','','RAKESHKUMAR',NULL,NULL,NULL,NULL,'','','','9773441740','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 19:56:54','2026-08-09 20:03:38','Waghodia','NA','23000','NA','NA','NA'),(11,0,'1020268','2026-08-09','Nursary',NULL,NULL,NULL,NULL,NULL,'SAMARTHSINH PARMAR','MILANSINH','PARMAR','Male','2022-10-08','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','R NO 1 BLOCK NO1 NEW POLICE LINE,NR WAGHODIA POLICE STATION','9106323252','Both','MANISHABEN',NULL,NULL,NULL,NULL,'','','','','','MILANSINH',NULL,NULL,NULL,NULL,'JOB','POLICE','','9106323252','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 20:08:01','2026-08-10 07:05:26','Waghodia','NA','23500','NA','NA','NA'),(12,0,'1020269','2026-08-10','Nursary',NULL,NULL,NULL,NULL,NULL,'KIAAN PATEL','SAGARBHAI','PATEL','Male','2022-10-17','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','H NO 80 SHRAMSHRADHANA SOC,VAGHODIA','8469231242','Both','AVANIBEN',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','8469231242','','SAGARBHAI',NULL,NULL,NULL,NULL,'','','','8469231242','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:06:54','2026-08-10 07:09:56','Waghodia','NA','23000','NA','NA','NA'),(13,0,'10202610','2026-08-10','Nursary',NULL,NULL,NULL,NULL,NULL,'YUG MAKWANA','PARESHKUMAR','MAKWANA','Male','2022-12-22','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','C/76 AKSHAR TOWNSHIP,WAGHODIA ','9725041964','Both','NAYNABEN',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','9722227824','','PARESHKUMAR',NULL,NULL,NULL,NULL,'JOB','','','9725041964','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:10:21','2026-08-10 10:12:36','Waghodia','NA','23000','NA','NA','NA'),(14,0,'10202611','2026-08-10','Nursary',NULL,NULL,NULL,NULL,NULL,'MALHARSINH','SHAILENDRASINH','SINH','Male','2022-11-17','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','H NO 3 KALP CHANDRA UNIC SOC,MADODHAR ROAD WAGHODIA','9773063761','Both','JYOTSNABEN',NULL,NULL,NULL,NULL,'','','','9773063761','','SHAILENDRASINH',NULL,NULL,NULL,NULL,'','','','9773063761','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:13:30','2026-08-10 10:12:58','Waghodia','NA','23000','NA','NA','NA'),(15,0,'10202612','2026-08-10','Sr.KG',NULL,NULL,NULL,NULL,NULL,'JIYANSHIBEN MAKWANA','SHAILENDRASINH','SINH','Female','2020-08-28','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','H NO 3 KALP CHANDRA UNIC SOC,MADODHAR ROAD WAGHODIA','9773063761','Both','JYOTSNABEN',NULL,NULL,NULL,NULL,'','','','9773063761','','SHAILENDRASINH',NULL,NULL,NULL,NULL,'','','','9773063761','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:16:19','2026-08-10 10:13:18','Waghodia','NA','NA','NA','24000','NA'),(16,0,'10202613','2026-08-10','Nursary',NULL,NULL,NULL,NULL,NULL,'JAINIL PARMAR','JAYDIPSINH','PARMAR','Male','2022-08-10','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','H NO 29 KALP CHANDRA UNIC SOC,MADODHAR ROAD WAGHODIA','9558537356','Both','KAJALBEN',NULL,NULL,NULL,NULL,'','','','9624569538','','JAYDIPSINH',NULL,NULL,NULL,NULL,'','','','9558537356','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:21:03','2026-08-10 10:13:40','Waghodia','NA','23000','NA','NA','NA'),(17,0,'10202614','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'MANAN PATEL','VRUSHANTKUMAR','PATEL','Male','2023-09-13','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','H NO 2 SIDDKUTIR SCO,MADODHAR ROAD WAGHODIA','9725563624','Both','KHUSHBU',NULL,NULL,NULL,NULL,'','HOUSE WIFE','','8401008793','','9725563624',NULL,NULL,NULL,NULL,'','','','9725563624','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:27:49','2026-08-10 10:14:07','Waghodia','22000','NA','NA','NA','NA'),(18,0,'10202615','2026-08-10','Nursary',NULL,NULL,NULL,NULL,NULL,'HETRAJSINH','PRAVINSINH','SINH','Male','2023-04-24','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','NEW POLICE LINE','9723534445','Both','SONALBEN',NULL,NULL,NULL,NULL,'','','','9723534445','','PRAVINSINH',NULL,NULL,NULL,NULL,'','','','9723534445','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:30:13','2026-08-10 10:14:28','Waghodia','NA','23000','NA','NA','NA'),(19,0,'10202616','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'NAKSHRAJSINH SOLANKI','MAHAVIRSINH','SOLANKI','Male','2023-11-14','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','R NO 4 BLOCK NO1 NEW POLICE LINE,NR WAGHODIA POLICE STATION, WAGHODIA ','9712920909','Both','RAXABEN',NULL,NULL,NULL,NULL,'','','','9898014019','','MAHAVIRSINH',NULL,NULL,NULL,NULL,'','','','9712920909','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 07:32:40','2026-08-10 10:14:48','Waghodia','22000','NA','NA','NA','NA'),(20,0,'10202617','2026-08-10','Jr.KG',NULL,NULL,NULL,NULL,NULL,'YASH PARMAR','CHANDRAKANTBHAI','PARMAR','Male','2022-02-23','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','','','Both','RAVINABEN',NULL,NULL,NULL,NULL,'','','','6351089377','','CHANDRAKANTBHAI',NULL,NULL,NULL,NULL,'','','','9327969254','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 09:45:32','2026-08-10 10:15:04','Waghodia','NA','NA','24500','NA','NA'),(21,0,'10202618','2026-08-10','Jr.KG',NULL,NULL,NULL,NULL,NULL,'MAHIR ROHIT','NARESHBHAI','ROHIT','Male','2022-04-13','','','','Unknown','20','20',NULL,'Gujarati','NAVI NAGARI LIMDA','9712175323','Both','JAGRUTIBEN',NULL,NULL,NULL,NULL,'','','','9601553330','','NARESHBHAI',NULL,NULL,NULL,NULL,'','','','9712175323','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 10:03:39','2026-08-10 10:15:24','Waghodia','24000','NA','24000','NA','NA'),(22,0,'10202619','2026-08-10','Nursary',NULL,NULL,NULL,NULL,NULL,'ALISHBA TOLAT','AFZALMAHEDI','TOLAT','Female','2022-12-08','WAGHODIA','','','Unknown','20','20',NULL,'Gujarati','NR OLD BUS STAND.KHANDHA ROAD VAGHODIA','8200231804','Both','TAIYABAPARVIN',NULL,NULL,NULL,NULL,'','','','9870071899','','AFZALMAHEDI',NULL,NULL,NULL,NULL,'','','','8200231804','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 10:06:06','2026-08-10 10:16:12','Waghodia','23000','23000','NA','NA','NA'),(23,0,'1120261','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Henvi Valand','Vishalbhai','Valand','Female','2023-07-18','','','','Unknown','20','20',NULL,'Gujarati','Amodar Village,New Waghodia Road','8780781996','Both','Niraliben',NULL,NULL,NULL,NULL,'','','','9358075478','','Vishalbhai',NULL,NULL,NULL,NULL,'','','','8780781996','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 12:45:07','2026-08-10 12:52:53','GayatriMandir','22000','NA','NA','NA','NA'),(24,0,'1120262','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Mivan Santra','Satyaranjan','Santra','Male','2023-05-19','','','','Unknown','20','20',NULL,'Gujarati','A/267 Blues Spring Field,Opp Gayatri Temple,New Waghodia Road 390019 ','9913173185','Both','Susmita',NULL,NULL,NULL,NULL,'','Service','','8820868886','','Satyaranjan',NULL,NULL,NULL,NULL,'','','','9913173185','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 12:53:56','2026-08-10 12:57:03','GayatriMandir','22000','NA','NA','NA','NA'),(25,0,'1120263','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Darsh Bariya','Harishbhai','Bariya','Male','2023-09-01','','','','Unknown','20','20','1786366879_child_birth_certificate_8103.png','Gujarati','B/106 Shiv Bunglows, Khatamba,New Waghodia Road 390019','7567313555','Both','Jyotikaben',NULL,NULL,NULL,NULL,'','','','6351756190','','Harishbhai',NULL,NULL,NULL,NULL,'','','','7567313555','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 12:57:36','2026-08-10 13:01:19','GayatriMandir','22000','NA','NA','NA','NA'),(26,0,'1120264','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Naksh Patel','Hardikkumar','Patel','Male','2023-08-24','','','','Unknown','20','20',NULL,'Gujarati','B-116 J P Green Timbi New Waghodia Road 19','9662635285','Both','Jaiminiben',NULL,NULL,NULL,NULL,'','','','6354744105','','Hardikkumar',NULL,NULL,NULL,NULL,'','','','9662635285','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:02:17','2026-08-10 13:09:04','GayatriMandir','22000','NA','NA','NA','NA'),(27,0,'1120265','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Henika Gohil','Kamalsinh','Gohil','Female','2023-01-18','','','','Unknown','20','20',NULL,'Gujarati','','','Both','Pinkal',NULL,NULL,NULL,NULL,'','','','','','Kanaksinh',NULL,NULL,NULL,NULL,'','','','','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:10:27','2026-08-10 13:13:10','GayatriMandir','22000','NA','NA','NA','NA'),(28,0,'1120266','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Neel Gajjar','Sanjaykumar','Gajjar','Male','2023-07-29','','','','Unknown','20','20',NULL,'Gujarati','D/46 Prime Vatika ,Nr.Sumandeep,Waghodia Road','9924024406','Both','Binalben',NULL,NULL,NULL,NULL,'','','','9924024406','','Sanjaykumar',NULL,NULL,NULL,NULL,'','','','9924024406','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:16:15','2026-08-10 13:19:11','GayatriMandir','22000','NA','NA','NA','NA'),(29,0,'1120267','2026-08-10','Play Group',NULL,NULL,NULL,NULL,NULL,'Shivanshisinh Sindha','Sindha','Sindha','Male','2023-10-24','','','','Unknown','20','20',NULL,'Gujarati','Darbar Faliya Amodar','8735055545','Both','Jaimikaben',NULL,NULL,NULL,NULL,'','','','6352406508','','Indrajitsinh',NULL,NULL,NULL,NULL,'','','','8735055545','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:19:37','2026-08-10 13:21:47','GayatriMandir','23500','NA','NA','NA','NA'),(30,0,'1120268','2026-08-10','Pre Nursery',NULL,NULL,NULL,NULL,NULL,'Chhavi Sutare','Nishant','Sutare','Female','2023-06-29','','','','Unknown','20','20',NULL,'Gujarati','HN 69 Palm Exotica,Opp Gayatri Temple,New Waghodia Road 19','9890163252','Both','Shamal',NULL,NULL,NULL,NULL,'','','','9881209178','','Nishant',NULL,NULL,NULL,NULL,'','','','9890163252','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:22:03','2026-08-10 13:24:50','GayatriMandir','23500','NA','NA','NA','NA'),(31,0,'1120269','2026-08-10','Play Group','1788685801_child_photo_8178.png',NULL,NULL,NULL,NULL,'Nitya Parmar','Dharmesh','Parmar','Female','2023-08-25','','','','Unknown','20','20',NULL,'Gujarati','Parmar Faliyu Amodar','9664632573','Both','Minakshi','1788685801_mother_photo_3526.png',NULL,NULL,NULL,'','','','6351396160','','Dharmesh','1788685801_father_photo_4785.png',NULL,NULL,NULL,'','','','6351396160','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:25:09','2026-09-06 09:58:33','GayatriMandir','23500','NA','NA','NA','NA'),(32,0,'11202610','2026-08-10','Pre Nursery',NULL,NULL,NULL,NULL,NULL,'Prinsh bhai Amaliyar','','Amaliyar','Male','2023-05-18','','','','Unknown','20','20',NULL,'Gujarati','','','Both','N',NULL,NULL,NULL,NULL,'','','','','','N',NULL,NULL,NULL,NULL,'','','','','','confirmed','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-10 13:27:29','2026-08-21 13:11:33','GayatriMandir','23500','NA','NA','NA','NA'),(33,0,'333333333333','2026-09-06','Play Group',NULL,NULL,NULL,NULL,NULL,'11','','11','Male','2017-01-01','','','','Unknown','20','20',NULL,'Gujarati','','','Both','11',NULL,NULL,NULL,NULL,'22','','','','','22',NULL,NULL,NULL,NULL,'','','','','','inquiry','N',NULL,0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-06 11:56:22','2026-09-06 09:58:18','GayatriMandir','80000','140000','10000','10000','10000');
/*!40000 ALTER TABLE `admissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(191) NOT NULL,
  `email_address` varchar(191) NOT NULL,
  `contact_number` varchar(199) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'Mayank Patel','mayankp@yopmail.com','92929292','General Inquiry','dsfsaf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:19:46'),(2,'Mayank Patel','mayankp@yopmail.com','92929292','General Inquiry','dsfsaf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:33:22'),(3,'Mayank Patel','mayankp@yopmail.com','92929292','General Inquiry','dsfsaf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:38:39'),(4,'Mayank Patel','mayankp@yopmail.com','92929292','General Inquiry','dsfsaf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:43:17'),(5,'Brijesh Patel','brijesh@yopmail.com','92929299292','Programs & Curriculum','fdasff\r\nfsf\r\naf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:45:21'),(6,'Chirag Patel','chiragpatel@yopmail.com','992929292922','Programs & Curriculum','fsadfsdf\r\nf\r\nfsaf\r\ns',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:46:04'),(7,'Mayank Patel','mayankp@yopmail.com','92929299229','General Inquiry','dfsdafsf\r\nsd\r\nfa\r\nfs',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:50:18'),(8,'Mike Ptl','mike@yopmail.com','93939399339','General Inquiry','sdfsdfsdfsa',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:51:17'),(9,'mayank','321313@yopmail.com','939939339','General Inquiry','fdsff\r\nf\r\nsf\r\nasf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:52:21'),(10,'sdfsa','dfas@yopmail.com','93939393993','General Inquiry','dfdsf\r\ndf\r\nfdsfas',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:53:03'),(11,'sdfsa','dfas@yopmail.com','93939393993','General Inquiry','dfdsf\r\ndf\r\nfdsfas',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:53:39'),(12,'qqqqqqqqq','fadf@yopmail.com','9292929','General Inquiry','dfdsa',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:55:09'),(13,'111','111@yopmail.com','929292`192`','General Inquiry','sfsdfafds',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:55:38'),(14,'Mayank Patel','mayankp@yopmail.com','93939939933','General Inquiry','dfds\r\nfsdf\r\naf\r\nsf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 11:56:23'),(15,'Mayank Patel','mayank.patel104@gmail.com','9393939393','Schedule a Visit','fdsf\r\ndsfsf\r\ns\r\nfd\r\nsfd\r\nsf\r\nasd',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 18:27:20'),(16,'Mayank Patel','mayankp@yopmail.com','292992929292','General Inquiry','dsfas\r\nfd\r\nf\r\nsf\r\nsdaf\r\nasf',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 18:36:20'),(17,'Kavatji Gohil','kavatjigohil@gmail.com','','Other','Inquiry ',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 19:46:28'),(18,'Hi','sjgohil@gmail.com','','Admissions','Admissions ',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-06 12:19:47'),(19,'Dilipkumar ','advocatedilipkumar18@gmail.com','9925939523','Admissions','Please contact me on rhis numner ',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-09 11:26:03'),(20,'Divyesh Shah','divyeshshah91@gmail.com','9974680592','General Inquiry','Hi',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-10 09:50:43'),(21,'DavidGep','no.reply.OlivierSimonson@gmail.com','84837712621','Programs &amp; Curriculum','Hey! gopikids.in, \r\nI recently found your website while researching related topics. \r\nWe offer tool for contacting websites through their contact pages. \r\nMany companies use web outreach to find new partners. \r\nThe service is available with flexible pricing options. \r\nYou can check how the platform works in practice. \r\nFeel free to contact us if you want more information. \r\n \r\nHope you have a great day. \r\nContact us. \r\nTelegram - https://t.me/FeedbackFormEU \r\nWhatsApp - +375259112693 \r\nWhatsApp  https://wa.me/+375259112693 \r\nWe only use chat for communication.',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-14 18:35:37'),(22,'Rajiv Bhatiya','rajeev.bhatiya@gmail.com','+919879000860','General Inquiry','Hi',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-22 07:02:59'),(23,'DavidNem','no.reply.MarcEriksson@gmail.com','83647648398','Schedule a Visit','Salutations! gopikids.com, \r\nI recently saw gopikids.com during my research. \r\nWe provide  that helps businesses reach website owners through contact forms. \r\nOur platform supports communication with websites . \r\n  \r\nYou can explore the service and see what it does. \r\nLet us know if you would like more details. \r\n \r\nThank you for your time. \r\nContact us. \r\nTelegram - https://t.me/FeedbackFormEU \r\nWhatsApp - +375259112693 \r\nWhatsApp  https://wa.me/+375259112693 \r\nWe only use chat for communication.',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-30 08:29:30');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id_pk` int(11) DEFAULT 0,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `customer_pin` int(11) NOT NULL DEFAULT 0,
  `pos_customer` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `guest_customer` varchar(1) NOT NULL DEFAULT '0',
  `access_token` varchar(255) DEFAULT NULL,
  `security_question_id` int(11) NOT NULL DEFAULT 0,
  `security_answer` varchar(191) DEFAULT NULL,
  `user_address1` varchar(191) DEFAULT NULL,
  `user_address2` varchar(191) DEFAULT NULL,
  `user_city` varchar(191) DEFAULT NULL,
  `user_state` varchar(191) DEFAULT NULL,
  `user_zipcode` varchar(191) DEFAULT NULL,
  `user_country` varchar(191) DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `web_token` varchar(255) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `item_type` varchar(25) NOT NULL DEFAULT 'users',
  `wallet_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `blocked` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `admission_id` int(11) NOT NULL DEFAULT 0,
  `enroll_for` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `invoice_no` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `total_paid_amount` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `payment_date` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(255) DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(255) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_for` varchar(255) DEFAULT NULL,
  `invoice_prefix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,3,'Play Group','Cash','R1001','2026-08-01','2026-08-31','1000','1','2026-08-26',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-26 10:53:13','Tuition','1001'),(2,3,'Play Group','OnlineTransfer','R1002','2026-08-01','2026-08-31','2000','1','2026-08-26',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-26 10:53:30','Tuition','1002'),(3,3,'Play Group','Cheque','BO1001','2026-08-01','2026-08-31','500','1','2026-08-26',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-26 10:53:46','Book','1001'),(4,3,'Play Group','UPI','BA1001','2026-08-01','2026-08-31','500','1','2026-08-26',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-26 10:54:05','Bag','1001'),(5,2,'Play Group','Cash','R1003','2026-04-01','2026-09-30','10000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:48:31','Tuition','1003'),(6,2,'Play Group','OnlineTransfer','BO1002','2026-04-01','2026-09-30','2000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:48:59','Book','1002'),(7,2,'Play Group','OnlineTransfer','BA1002','2026-04-01','2026-09-30','500','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:49:25','Bag','1002'),(8,2,'Play Group','OnlineTransfer','NB1001','2026-04-01','2026-09-30','1000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:49:47','Notebook','1001'),(9,2,'Play Group','Cash','AF1001','2026-04-01','2026-09-30','1000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:50:06','AdmissionForm','1001'),(10,2,'Play Group','Cash','R1004','2026-10-01','2027-04-30','10000','1','2026-10-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:51:33','Tuition','1004'),(11,2,'Play Group','OnlineTransfer','BO1003','2026-10-01','2027-04-30','500','1','2026-10-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:51:05','Book','1003'),(12,2,'Play Group','OnlineTransfer','BA1003','2026-10-01','2027-04-30','500','1','2026-10-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:52:12','Bag','1003'),(13,2,'Play Group','DemandDraft','NB1002','2026-10-01','2027-04-30','3000','1','2026-10-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:52:41','Notebook','1002'),(14,7,'Play Group','Cash','R1005','2026-04-01','2026-09-30','12000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:49:00','Tuition','1005'),(15,7,'Play Group','OnlineTransfer','BO1004','2026-04-01','2026-09-30','2000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:49:21','Book','1004'),(16,7,'Play Group','UPI','BA1004','2026-04-01','2026-09-30','1000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:49:41','Bag','1004'),(17,7,'Play Group','Cheque','NB1003','2026-04-01','2026-09-30','2000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:50:07','Notebook','1003'),(18,30,'Pre Nursery','Cash','R1006','2026-04-01','2026-09-30','20000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:51:16','Tuition','1006'),(19,30,'Pre Nursery','UPI','BO1005','2026-04-01','2026-09-30','2000','1','2026-04-05',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:51:39','Book','1005');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section`
--

DROP TABLE IF EXISTS `item_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section` (
  `item_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_section_parent_id` int(11) NOT NULL DEFAULT 0,
  `section_title` varchar(255) DEFAULT NULL,
  `section_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section`
--

LOCK TABLES `item_section` WRITE;
/*!40000 ALTER TABLE `item_section` DISABLE KEYS */;
INSERT INTO `item_section` VALUES (1,0,0,'Section1','section1','default','Section1','1779799317_isec_2676.png',0,'Section1','Section1',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:41:57','2026-05-26 12:41:57'),(2,0,0,'Section2','section2','default','Section2','1779799330_isec_6580.png',0,'Section2','Section2',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:10','2026-05-26 12:42:10'),(3,0,0,'Section3','section3','default','Section3',NULL,0,'Section3','Section3',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:21','2026-05-26 12:42:21'),(4,0,0,'Section4','section4','default','Section4',NULL,0,'Section4','Section4',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:32','2026-05-26 12:42:32'),(5,0,0,'Section5','section5','default','Section5',NULL,0,'Section5','Section5',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:44','2026-05-26 12:42:44'),(6,0,0,'Section6','section6','default','Section6',NULL,0,'Section6','Section6',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:55','2026-05-26 12:42:55'),(7,0,0,'Section7','section7','default','Section7',NULL,0,'Section7','Section7',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:07','2026-05-26 12:43:07'),(8,0,0,'Section8','section8','default','Section8',NULL,0,'Section8','Section8',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:18','2026-05-26 12:43:18'),(9,0,0,'Section9','section9','default','Section9',NULL,0,'Section9','Section9',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:33','2026-05-26 12:43:33'),(10,0,0,'Section10','section10','default','Section10',NULL,0,'Section10','Section10',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:44','2026-05-26 12:43:44'),(11,0,0,'Section11','section11','default','Section11',NULL,0,'Section11','Section11',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:54','2026-05-26 12:43:54'),(12,0,0,'Section12','section12','default','Section12',NULL,0,'Section12','Section12',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:06','2026-05-26 12:44:06'),(13,0,0,'Section13','section13','default','Section13',NULL,0,'Section13','Section13',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:17','2026-05-26 12:44:17'),(14,0,0,'Section14','section14','default','Section14',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:26','2026-05-26 12:44:26'),(15,0,0,'Section15','section15','default','Section15',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:34','2026-05-26 12:44:34'),(16,0,0,'Section16','section16','default','Section16',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:42','2026-05-26 12:44:42'),(17,0,0,'Section 17','section-17','default','Section 17',NULL,0,'Section 17','Section 17',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-06-13 10:58:59','2026-06-13 14:28:59'),(18,0,0,'Section 18','section-18','default','Section 18',NULL,0,'Section 18','Section 18',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-06-13 11:02:57','2026-06-13 14:32:57'),(19,0,0,'Section 18','section-18-1781341611','default','Section 18',NULL,0,'Section 18','Section 18',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 14:53:37','2026-06-13 11:06:51','2026-06-13 14:36:51'),(20,0,0,'Section 18','section-18-1781341631','default','Section 18',NULL,0,'Section 18','Section 18',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 14:48:18','2026-06-13 11:07:11','2026-06-13 14:37:11'),(21,0,0,'Section 18','section-18-1781341922','default','Section 18',NULL,0,'Section 18','Section 18',0,'N',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 14:47:30','2026-06-13 11:12:02','2026-06-13 14:42:02'),(22,0,0,'Section 19','section-19','default','Section 19',NULL,0,'Section 19','Section 19',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:04:24','2026-06-13 11:26:11','2026-06-13 14:56:11'),(23,0,0,'Section 20','section-20','default','Section 20',NULL,0,'Section 20','Section 20',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:03:27','2026-06-13 14:20:26','2026-06-13 17:50:26'),(24,0,0,'Technolog z','technology','default','All technology-related articles and resources','28b7708bd5074701956179bc37b7c2b9_Screenshot_from_2026-07-09_17-47-21.png',0,'Technology Section','Explore the latest technology updates and tutorial',1,'Y',1,'',1,'N',0,NULL,NULL,'2026-07-10 18:21:00','2026-07-10 18:52:27'),(25,0,0,'Independence Day 2025-26','independence-day-2026','gallery','','',0,'','',0,'',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:25:00','2026-08-21 16:25:00'),(26,0,0,'Achivements','achivements','gallery','','',0,'','',0,'',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:25:12','2026-08-21 16:25:12'),(27,0,0,'Annual Function ','annual-function','gallery','','',0,'','',0,'',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:30:47','2026-08-21 18:30:47'),(28,0,0,'Sports Day 2025-26','sports-day-202526','gallery','','',0,'','',0,'',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:36:10','2026-08-21 18:36:10');
/*!40000 ALTER TABLE `item_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section_relation`
--

DROP TABLE IF EXISTS `item_section_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section_relation` (
  `item_section_relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_id` bigint(20) NOT NULL DEFAULT 0,
  `section_id` bigint(20) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section_relation`
--

LOCK TABLES `item_section_relation` WRITE;
/*!40000 ALTER TABLE `item_section_relation` DISABLE KEYS */;
INSERT INTO `item_section_relation` VALUES (1,0,38,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:26:42','2026-08-21 16:26:42'),(2,0,39,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:26:58','2026-08-21 16:26:58'),(3,0,40,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:27:13','2026-08-21 16:27:13'),(4,0,41,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:27:27','2026-08-21 16:27:27'),(5,0,42,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:27:40','2026-08-21 16:27:40'),(6,0,43,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:27:55','2026-08-21 16:27:55'),(7,0,44,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:28:07','2026-08-21 16:28:07'),(8,0,45,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:28:20','2026-08-21 16:28:20'),(9,0,46,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:28:33','2026-08-21 16:28:33'),(11,0,47,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:29:52','2026-08-21 16:29:52'),(12,0,48,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:34:27','2026-08-21 16:34:27'),(13,0,49,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:34:40','2026-08-21 16:34:40'),(14,0,50,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:34:53','2026-08-21 16:34:53'),(15,0,51,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:35:06','2026-08-21 16:35:06'),(16,0,52,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:35:21','2026-08-21 16:35:21'),(17,0,53,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:35:34','2026-08-21 16:35:34'),(18,0,54,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:35:47','2026-08-21 16:35:47'),(19,0,55,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:35:59','2026-08-21 16:35:59'),(20,0,56,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:36:11','2026-08-21 16:36:11'),(21,0,57,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:36:23','2026-08-21 16:36:23'),(22,0,58,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:36:35','2026-08-21 16:36:35'),(23,0,59,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:36:46','2026-08-21 16:36:46'),(24,0,60,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:36:59','2026-08-21 16:36:59'),(25,0,61,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:37:10','2026-08-21 16:37:10'),(26,0,62,28,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 18:45:17','2026-08-21 18:45:17'),(27,0,63,28,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 18:46:05','2026-08-21 18:46:05'),(28,0,64,28,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 18:46:38','2026-08-21 18:46:38'),(29,0,65,28,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 18:47:14','2026-08-21 18:47:14'),(30,0,66,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:00:16','2026-08-21 19:00:16'),(31,0,67,27,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:01:08','2026-08-21 19:01:08'),(32,0,68,27,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:01:44','2026-08-21 19:01:44'),(33,0,69,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:02:18','2026-08-21 19:02:18'),(34,0,70,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:04:06','2026-08-21 19:04:06'),(35,0,71,28,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:12:44','2026-08-21 19:12:44'),(36,0,72,28,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 19:13:57','2026-08-21 19:13:57'),(37,0,73,27,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-23 11:02:25','2026-08-23 11:02:25');
/*!40000 ALTER TABLE `item_section_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_parent` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) DEFAULT NULL,
  `item_sections_id` varchar(255) DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `attachment2` varchar(255) DEFAULT NULL,
  `item_shortdescription` text DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT 'index',
  `published_at` date DEFAULT NULL,
  `published_end_at` date DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,0,'Home','home',100,'page','24','description update','attachment1-1758612676875.png','attachment2-1758612676877.png','short description update',3,'controller','action','2026-05-26','2026-05-26','meta title update','meta description update',1,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(2,0,'About Us','about-us',0,'page',NULL,'About Us',NULL,'','',1,'','','2026-05-26','2026-05-26','About Us','About Us',1,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(3,0,'Terms & Conditions','terms-and-conditions',0,'page',NULL,'Terms & Conditions',NULL,'','',1,'','','2026-05-26','2026-05-26','Terms & Conditions','Terms & Conditions',2,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(4,0,'Privacy Policy','privacy-policy',0,'page',NULL,'Privacy Policy',NULL,'','',1,'','','2026-05-26','2026-05-26','Privacy Policy','Privacy Policy',3,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(5,0,'Item1','item1',0,'default','1','Item1','1779799500_item1_4858.png',NULL,'Item1',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:00','2026-05-26 12:45:00'),(6,0,'Item2','item2',0,'default','1,2,3','Item2','1779799515_item1_2600.png',NULL,'Item2',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:15','2026-05-26 12:45:15'),(7,0,'Item3','item3',0,'default','1,2,3,4','Item3',NULL,NULL,'Item3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:29','2026-05-26 12:45:29'),(8,0,'Item4','item4',0,'default','1,2,3,4','Item4','1779799547_item1_7270.png','1779799547_item2_6385.png','Item4',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:47','2026-05-26 12:45:47'),(9,0,'Item5','item5',0,'default','1,2,3,4,5','Item5',NULL,NULL,'Item5',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:59','2026-05-26 12:45:59'),(10,0,'Item6','item6',0,'default','1,2,3,4,5,6','Item6',NULL,NULL,'Item6',0,NULL,'index','2026-05-26','2031-05-26','Item6','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:13','2026-05-26 12:46:13'),(11,0,'Item7','item7',0,'default','5,6,7,8,9','Item7',NULL,NULL,'Item7',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:26','2026-05-26 12:46:26'),(12,0,'Item8','item8',0,'default','12,13,14,15,16','Item8',NULL,NULL,'Item8',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:40','2026-05-26 12:46:40'),(13,0,'Item9','item9',0,'default','1,2,3,4','Item9',NULL,NULL,'Item9',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:51','2026-05-26 12:46:51'),(14,0,'Item10','item10',0,'default','12,13,14,15,16','Item10',NULL,NULL,'Item10',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:02','2026-05-26 12:47:02'),(15,0,'Item11','item11',0,'default','4,5,6,7,8,9','Item11',NULL,NULL,'Item11',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:13','2026-05-26 12:47:13'),(16,0,'Item12','item12',0,'default','5,6,7,8,9','Item12',NULL,NULL,'Item12',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:24','2026-05-26 12:47:24'),(17,0,'Item13','item13',0,'default','5,6,7,8,9','Item12',NULL,NULL,'Item12',0,NULL,'index','2026-05-26','2031-05-26','Item12','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:37','2026-05-26 12:47:37'),(18,0,'Item14','item14',0,'default','8,9,10,11','Item14',NULL,NULL,'Item14',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:56','2026-05-26 12:47:56'),(19,0,'Item15','item15',0,'default','4,5,6,7,8','Item15',NULL,NULL,'Item15',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:09','2026-05-26 12:48:09'),(20,0,'Item16','item16',0,'default','1,2,3','Item16',NULL,NULL,'Item16',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:22','2026-05-26 12:48:22'),(21,0,'Item17','item17',0,'default','9,10,11,12,13','Item17',NULL,NULL,'Item17',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:34','2026-05-26 12:48:34'),(22,0,'Item18','item18',0,'default','7,8,9,10','Item18',NULL,NULL,'Item18',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:46','2026-05-26 12:48:46'),(23,0,'Item19','item19',0,'default','12,13,14,15','Item19',NULL,NULL,'Item19',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:57','2026-05-26 12:48:57'),(24,0,'Item20','item20',0,'default','4,5,6,7,8,9','Item20',NULL,NULL,'Item20',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:49:10','2026-05-26 12:49:10'),(25,0,'Item21','item21',0,'default','13,14','Item21',NULL,NULL,'Item21',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:49:25','2026-05-26 12:49:25'),(26,0,'Item22','item22',0,'default','2,3,4,5,6','Item22',NULL,NULL,'Item22',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:49:39','2026-05-26 12:49:39'),(27,0,'Item23','item23',0,'default','7,8,9,10,11','Item23',NULL,NULL,'Item23',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:50:02','2026-05-26 12:50:02'),(28,0,'Item24','item24',0,'default','3,4,5','Item24',NULL,NULL,'Item24',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:50:13','2026-05-26 12:50:13'),(29,0,'Item25','item25',0,'default','1,2,3,4','Item25',NULL,NULL,'Item25',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:50:25','2026-05-26 12:50:25'),(30,0,'dsf','dsf',0,'default','','<p>f</p><p>fdsf</p><p>dsf</p><p><br></p><p>fs</p><p>f</p><p>sdf</p><p>sdf</p><p>sf</p><p>sf</p><p>sfs</p><p>df</p><p>ds</p><p>ds</p><p>ds</p><p>f</p><p>sf</p><p>dsf</p><p>s</p><p>fsd</p><p>f</p><p>dsfd</p><p>sf</p><p>dsf</p><p>ds</p><p>fs</p><p>fdsfs</p>',NULL,NULL,'fds\r\nfds\r\nfds\r\nfs\r\ndfsa',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 15:29:25','2026-05-26 18:59:25'),(31,0,'11111111','11111111',0,'default','1,2,3,4','<p>&nbsp; &nbsp; 111111111<br></p>',NULL,NULL,'3333333333',0,NULL,'index','2026-06-13','2031-06-13','11','22',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-06-13 12:17:54','2026-06-13 15:47:54'),(32,0,'11111111','11111111-1781346007',0,'default','1,2,3,4','<p>&nbsp; &nbsp; 111111111<br></p>',NULL,NULL,'3333333333',0,NULL,'index','2026-06-13','2031-06-13','11','22',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-06-13 12:20:07','2026-06-13 15:50:07'),(33,0,'11111111','11111111-1781346071',0,'default','1,2,3,4','<p>&nbsp; &nbsp; 111111111<br></p>',NULL,NULL,'3333333333',0,NULL,'index','2026-06-13','2031-06-13','11','22',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 16:34:30','2026-06-13 12:21:11','2026-06-13 15:51:11'),(34,0,'22222','22222',0,'default','1,2,3,4','<p>22222</p>',NULL,NULL,'22222',0,NULL,'index','2026-06-13','2031-06-13','22222','22222',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-06-13 14:21:02','2026-06-13 17:51:02'),(35,0,'3333333','3333333',0,'default','17,18,22','<p>    3333333<br></p>',NULL,NULL,'3333333',0,NULL,'index','2026-06-13','2031-06-13','3333333','3333333',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:04:49','2026-06-13 14:32:08','2026-06-13 18:02:08'),(36,0,'How to Build a REST API Updated','build-rest-api',0,'blog',NULL,'<p>This is a comprehensive guide to building REST APIs.</p>','api-guide.pdf','code-samples.zip','Step-by-step tutorial on REST API development.',0,'blog','view','2026-07-10','2026-12-31','REST API Tutorial | MySite','Learn how to build RESTful APIs with Python and Flask.',0,'Y',1,'',1,'Y',1,NULL,'2026-07-10 18:26:28','2026-07-10 18:25:18','2026-07-10 18:25:55'),(37,0,'How to Build a REST API 37','build-rest-api',0,'default','1,2,4','<p>This is a comprehensive guide to building REST APIs.</p>','da8d114c8f434d88b6f08aebde5bad5a_Screenshot_from_2026-07-10_12-17-01.png','9cacf33e7cf84d20b7783df8c2b2f57e_Screenshot_from_2026-07-09_17-47-44.png','11',1,'blog','view','2026-07-10','2026-11-10','REST API Tutorial | MySite','Learn how to build RESTful APIs with Python and Flask.',0,'Y',1,'',1,'N',0,NULL,NULL,'2026-07-10 18:35:12','2026-07-10 19:06:34'),(38,0,'A1','a1',0,'gallery','26','','1787329602_item1_2635.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:26:42','2026-08-21 16:26:42'),(39,0,'A2','a2',0,'gallery','26','','1787329618_item1_4026.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',2,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:26:58','2026-08-21 16:26:58'),(40,0,'A3','a3',0,'gallery','26','','1787329633_item1_8554.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',3,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:27:13','2026-08-21 16:27:13'),(41,0,'A4','a4',0,'gallery','26','','1787329647_item1_6364.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',4,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:27:27','2026-08-21 16:27:27'),(42,0,'A5','a5',0,'gallery','26','','1787329660_item1_5805.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',5,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:27:40','2026-08-21 16:27:40'),(43,0,'A6','a6',0,'gallery','26','','1787329675_item1_7893.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',6,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:27:55','2026-08-21 16:27:55'),(44,0,'A7','a7',0,'gallery','26','','1787329687_item1_4277.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',7,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:28:07','2026-08-21 16:28:07'),(45,0,'A8','a8',0,'gallery','26','','1787329700_item1_9400.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',8,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:28:20','2026-08-21 16:28:20'),(46,0,'A9','a9',0,'gallery','26','','1787329713_item1_3216.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',9,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:28:33','2026-08-21 16:28:33'),(47,0,'A10','a10',0,'gallery','26','','1787329727_item1_6729.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:28:47','2026-08-21 16:28:47'),(48,0,'G1','g1',0,'gallery','25','','1787330067_item1_1409.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:34:27','2026-08-21 16:34:27'),(49,0,'G2','g2',0,'gallery','25','','1787330080_item1_9479.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',2,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:34:40','2026-08-21 16:34:40'),(50,0,'G3','g3',0,'gallery','25','','1787330093_item1_1025.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',3,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:34:53','2026-08-21 16:34:53'),(51,0,'G4','g4',0,'gallery','25','','1787330106_item1_6967.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',4,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:35:06','2026-08-21 16:35:06'),(52,0,'G5','g5',0,'gallery','25','','1787330121_item1_5052.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',5,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:35:21','2026-08-21 16:35:21'),(53,0,'G6','g6',0,'gallery','25','','1787330134_item1_3097.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',6,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:35:34','2026-08-21 16:35:34'),(54,0,'G7','g7',0,'gallery','25','','1787330147_item1_1493.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',7,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:35:47','2026-08-21 16:35:47'),(55,0,'G8','g8',0,'gallery','25','','1787330159_item1_5676.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',8,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:35:59','2026-08-21 16:35:59'),(56,0,'G9','g9',0,'gallery','25','','1787330171_item1_6429.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',9,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:36:11','2026-08-21 16:36:11'),(57,0,'G10','g10',0,'gallery','25','','1787330183_item1_7273.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',10,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:36:23','2026-08-21 16:36:23'),(58,0,'G11','g11',0,'gallery','25','','1787330195_item1_3585.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',11,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:36:35','2026-08-21 16:36:35'),(59,0,'G12','g12',0,'gallery','25','','1787330206_item1_5698.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',12,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:36:46','2026-08-21 16:36:46'),(60,0,'G13','g13',0,'gallery','25','','1787330219_item1_7499.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',13,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:36:59','2026-08-21 16:36:59'),(61,0,'G14','g14',0,'gallery','25','','1787330230_item1_4563.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',14,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:37:10','2026-08-21 16:37:10'),(62,0,'Sports Day 2025-26','sports-day-202526',0,'gallery','28','','1787337917_item1_4477.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:45:17','2026-08-21 18:45:17'),(63,0,'Sports Day 2025-26','sports-day-202526-1787337965',0,'gallery','28','','1787337965_item1_4656.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:46:05','2026-08-21 18:46:05'),(64,0,'Sports Day 2025-26','sports-day-202526-1787337998',0,'gallery','28','','1787337998_item1_3963.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:46:38','2026-08-21 18:46:38'),(65,0,'Sports Day 2025-26','sports-day-202526-1787338034',0,'gallery','28','','1787338034_item1_3532.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:47:14','2026-08-21 18:47:14'),(66,0,'G40','g40',0,'gallery','25','','1787338816_item1_9525.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:00:16','2026-08-21 19:00:16'),(67,0,'G41','g41',0,'gallery','27','','1787338868_item1_1853.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:01:08','2026-08-21 19:01:08'),(68,0,'G42','g42',0,'gallery','27','','1787338904_item1_1889.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:01:44','2026-08-21 19:01:44'),(69,0,'G43','g43',0,'gallery','25','','1787338938_item1_3236.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:02:18','2026-08-21 19:02:18'),(70,0,'G44','g44',0,'gallery','25','','1787339046_item1_5442.jpg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:04:06','2026-08-21 19:04:06'),(71,0,'G45','g45',0,'gallery','28','','1787339564_item1_3689.jpeg','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:12:44','2026-08-21 19:12:44'),(72,0,'G45','g45-1787339637',0,'gallery','28','','1787339637_item1_1106.mp4','','',0,NULL,'index','2026-08-21','2031-08-21','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 19:13:57','2026-08-21 19:13:57'),(73,0,'G44','g44-1787482945',0,'gallery','27','','1787482945_item1_7155.jpeg','','',0,NULL,'index','2026-08-23','2031-08-23','','',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-23 11:02:25','2026-08-23 11:02:25');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `location_address1` varchar(255) DEFAULT NULL,
  `location_address2` varchar(255) DEFAULT NULL,
  `location_city` varchar(255) DEFAULT NULL,
  `location_state` varchar(255) DEFAULT NULL,
  `location_pincode` varchar(255) DEFAULT NULL,
  `location_contact` varchar(255) DEFAULT NULL,
  `location_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Gayatri Mandir','A-2 Springfield, Opp. Gayatri Temple','Nr. Khatamba, New Waghodia Road','Vadodara','GJ','390019','769-898-08-99','info@gopikids.com'),(2,'Waghodia','244/245 Axar Township',' Bh Waghodia Court','Vadodara','GJ','391760','769-898-08-99','info@gopikids.com');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_details`
--

DROP TABLE IF EXISTS `meta_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_details` (
  `meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `end_points` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `sidebar_title` varchar(255) DEFAULT NULL,
  `sidebar_icon` varchar(255) DEFAULT NULL,
  `sidebar_order` int(11) NOT NULL DEFAULT 0,
  `params` varchar(255) DEFAULT NULL,
  `is_module` smallint(6) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_details`
--

LOCK TABLES `meta_details` WRITE;
/*!40000 ALTER TABLE `meta_details` DISABLE KEYS */;
INSERT INTO `meta_details` VALUES (1,0,0,'/dashboard','Dashboard','Dashboard','Dashboard','Dashboard','mdi-view-dashboard',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(2,0,0,'/users','Users','Users','Users','Users','mdi-account-box',104,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(3,0,0,'/change-password','Change Password','Change Password','Change Password','Change Password','mdi mdi-server-security',105,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(4,0,0,'/items?item_type=page','Pages','Pages','Pages','Pages','mdi-format-list-bulleted',3,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(5,0,0,'/configurations','Configurations','Configurations Meta','Desc','Configurations','mdi-view-headline',109,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(6,0,0,'/user_form','User Form','User Form','User Form','User Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(7,0,0,'/item_section_form','Section Form','Section Form','Section Form','Section Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(8,0,0,'/logout','Logout','Logout','Logout','Logout','mdi-logout-variant',201,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(9,0,0,'/login','Login','Login','Login','Login',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(10,0,0,'/metadetails','Meta Details','Meta Details','Meta Details','SEO','mdi-format-list-bulleted',108,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(11,0,0,'/item_form','Item Form','Item Form','Item Form','Item Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(12,0,0,'/forgot-password','Forgot Password','Forgot Password','Forgot Password','Forgot Password',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(13,0,0,'/password-token','Password Token','Password Token','Password Token','Password Token',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(14,0,0,'/reset-password','Reset Password','Reset Password','Reset Password','Reset Password',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(15,0,0,'/roles','Roles','Roles','Roles','Roles','mdi mdi-account',103,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(16,0,0,'/role_form','Role Form','Role Form','Role Form','Role Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(17,0,0,'/item_form?item_type=blog','Blog Form','Blog Form','Blog Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(18,0,0,'/item_form?item_type=page','Page Form','Page Form','Page Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(19,0,0,'/item_section_form?item_type=default','Default Section Form','Default Section Form','Default Section Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(20,0,0,'/item_section_form?item_type=blog','Blog Category Form','Blog Category Form','Blog Category Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(21,0,0,'/items/default','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(22,0,0,'/database_table','Database Tables','Database Tables','Database Tables','Database Tables','mdi mdi-view-headline',200,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(23,0,0,'/item_section?item_type=blog','Blog Category','Blog Category','Blog Category','Blog Category','mdi mdi-view-headline',5,NULL,0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(24,0,0,'/items?item_type=blog','Blogs','Blogs','Blogs','Blogs','mdi-format-list-bulleted',5,NULL,0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(25,0,0,'/item_form?item_type=default','Default Form','Default Form','Default Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(26,0,0,'/item_section?item_type=default','Default Section','Default Section','Default','Default Section','mdi mdi-view-headline',1,NULL,0,0,'N',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(27,0,0,'/items?item_type=default','Default Item','Default','Default','Default Items','mdi-format-list-bulleted',1,NULL,0,0,'N',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(28,0,52,'/template/mdiicons','Demonstration Company','Demonstration Company','Demonstration Company Description','MDI Icons','mdi mdi-view-headline',404,'ui-basic',0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(29,0,52,'/template/formelement','Form Elements','Form Elements','Form Elements','Form Element','mdi mdi-view-headline',403,'ui-basic',0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(30,0,52,'/template/gallery','Gallery','Gallery','Gallery','Gallery','mdi mdi-view-headline',402,'ui-basic',1,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(31,0,-1,'/template','Templates','Templates','Templates','Templates','ui-basic',401,NULL,0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(32,0,0,'/items','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(41,0,0,'/role_form?item_type=role','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-06-13 16:38:34'),(42,0,0,'/roles?item_type=role','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-06-13 16:40:52'),(43,0,0,'/item_section?item_type=gallery','Gallery Category','Gallery Category','Gallery Category','Gallery Category','mdi mdi-view-headline',5,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(44,0,0,'/items?item_type=gallery','Gallery Photos','Gallery Photos','Gallery Photos','Gallery Photos','mdi mdi-library-books',5,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(45,0,0,'/admissions','Admissions','Admissions','Admissions','Admissions','mdi mdi-account-card-details',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(46,0,0,'/admission_form','Admission Form','Admission Form','Admission Form','Admission Form',NULL,1,NULL,0,1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(48,0,0,'/admissions?item_type=default','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-03 23:09:51'),(49,0,0,'/admissions?item_type=admission','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-03 23:10:00'),(50,0,0,'/fees','Fees','Fees','Fees','Fees','mdi mdi-currency-inr\n',1,NULL,1,1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(51,0,0,'/dashboard','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 08:00:46'),(52,0,0,'/','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 08:13:41'),(53,0,0,'/inquiry','Inquiry','Inquiry','Inquiry','Inquiry','mdi mdi-account-box\r\n',1,NULL,1,1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(55,0,0,'/item_form?item_type=gallery','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-21 13:20:48'),(56,0,0,'/item_section_form?item_type=gallery','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-21 13:21:07'),(57,0,0,'/reports','Reports','Reports','Reports','Reports','mdi mdi mdi mdi mdi-calendar-multiple-check',3,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 06:56:35');
/*!40000 ALTER TABLE `meta_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'role',
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,0,'Developer','developer','role','Y','Y','N',1,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(2,0,'Super Admin','superadmin','role','Y','Y','N',1,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(3,0,'Admin','admin','role','Y','Y','Y',1,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(4,0,'RoleFormmmmmmm','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:36','2026-06-13 16:38:49'),(5,0,'RoleFormmmmmmm','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:08:36','2026-06-13 16:40:49'),(6,0,'New','','role','Y','Y','Y',0,'Y',0,NULL,0,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:24:55','2026-06-13 17:55:07'),(7,0,'New','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:24:55','2026-06-13 17:55:48'),(8,0,'New2','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:29','2026-06-13 18:02:35');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_access`
--

DROP TABLE IF EXISTS `role_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_access` (
  `role_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_id` int(11) DEFAULT 0,
  `module_id` int(11) DEFAULT 0,
  `grant_add` varchar(1) NOT NULL DEFAULT 'N',
  `grant_edit` varchar(1) NOT NULL DEFAULT 'N',
  `grant_delete` varchar(1) NOT NULL DEFAULT 'N',
  `grant_view` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_access`
--

LOCK TABLES `role_access` WRITE;
/*!40000 ALTER TABLE `role_access` DISABLE KEYS */;
INSERT INTO `role_access` VALUES (18,0,4,1,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(19,0,4,2,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(20,0,4,3,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(21,0,4,4,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(22,0,4,5,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(23,0,4,8,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(24,0,4,10,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(25,0,4,15,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(26,0,4,22,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(27,0,4,23,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(28,0,4,24,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(29,0,4,26,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(30,0,4,27,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(31,0,4,28,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(32,0,4,29,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(33,0,4,30,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(34,0,4,31,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(35,0,5,1,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(36,0,5,2,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(37,0,5,3,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(38,0,5,4,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(39,0,5,5,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(40,0,5,8,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(41,0,5,10,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(42,0,5,15,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(43,0,5,22,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(44,0,5,23,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(45,0,5,24,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(46,0,5,26,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(47,0,5,27,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(48,0,5,28,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(49,0,5,29,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(50,0,5,30,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(51,0,5,31,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(52,0,7,1,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(53,0,7,2,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(54,0,7,3,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(55,0,7,4,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(56,0,7,5,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(57,0,7,8,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(58,0,7,10,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(59,0,7,15,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(60,0,7,22,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(61,0,7,23,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(62,0,7,24,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(63,0,7,26,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(64,0,7,27,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(65,0,7,28,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(66,0,7,29,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(67,0,7,30,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(68,0,7,31,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(69,0,8,1,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(70,0,8,2,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(71,0,8,3,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(72,0,8,4,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(73,0,8,5,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(74,0,8,8,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(75,0,8,10,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(76,0,8,15,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(77,0,8,22,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(78,0,8,23,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(79,0,8,24,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(80,0,8,26,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(81,0,8,27,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(82,0,8,28,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(83,0,8,29,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(84,0,8,30,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(85,0,8,31,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(184,0,3,1,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(185,0,3,4,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(186,0,3,30,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(187,0,3,43,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(188,0,3,44,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(189,0,3,45,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(190,0,3,50,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(191,0,3,53,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(192,0,3,57,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:47','2026-09-05 09:35:47'),(193,0,2,1,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(194,0,2,4,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(195,0,2,30,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(196,0,2,43,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(197,0,2,44,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(198,0,2,45,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(199,0,2,50,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(200,0,2,53,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(201,0,2,57,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:35:56','2026-09-05 09:35:56'),(202,0,1,1,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(203,0,1,4,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(204,0,1,30,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(205,0,1,43,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(206,0,1,44,'Y','Y','Y','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(207,0,1,45,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(208,0,1,50,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(209,0,1,53,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07'),(210,0,1,57,'N','N','N','Y',0,'Y',32,'Data Entry',3,'N',0,NULL,NULL,'2026-09-05 09:36:07','2026-09-05 09:36:07');
/*!40000 ALTER TABLE `role_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `config_title` varchar(1024) DEFAULT NULL,
  `config_name` varchar(1024) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `input_type` varchar(15) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 100,
  `maxlength` int(11) NOT NULL DEFAULT 100,
  `input_type_title` varchar(100) DEFAULT NULL,
  `classname` varchar(100) DEFAULT 'textbox',
  `required` varchar(1) DEFAULT 'O',
  `comments` varchar(255) DEFAULT NULL,
  `additional` varchar(100) DEFAULT NULL,
  `display_on_dashboard` varchar(1) NOT NULL DEFAULT 'N',
  `display_on_third_party` varchar(1) NOT NULL DEFAULT 'N',
  `site_config_parent_id` smallint(6) NOT NULL DEFAULT 0,
  `root_user_only` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,0,'Application Title','FRONT_APPLICATION_TITLE','Gopi Kids Pre School & Day Care','text',100,100,'Please enter your application name for display on frontend side as title','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2026-01-30 09:34:40'),(2,0,'Records per page','FRONT_RECORD_PER_PAGE','16','select',100,60,'Records per page','form-control','Y','8@=16@=24@=32@=40@=80',NULL,'Y','Y',1,'N',5,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(3,0,'Maintenance Mode','SITE_CONSTRUCTION','No','select',100,60,'Site Under Construction Status','form-control','Y','Yes@=No',NULL,'Y','N',1,'N',12,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-12-07 22:07:04'),(4,0,'Default Timezone','FRONT_DEFAULT_TIMEZONE','Asia/Kolkata','select',100,60,'Default Timezone','form-control','Y','America/Chicago@=Asia/Kolkata@=Europe/London@=Australia/Perth',NULL,'Y','Y',1,'N',13,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(5,0,'Backend application Title','BACKEND_APPLICATION_TITLE','Gopi Kids :: Administrator','text',100,60,'Application Title','form-control','Y',NULL,NULL,'Y','N',2,'N',14,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:08:57'),(6,0,'Meta Description','FRONT_META_DESCRIPTION','Education center','text',100,60,'Meta Description','form-control','Y',NULL,NULL,'N','N',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2020-04-17 01:06:07'),(7,0,'Default Robots','FRONT_DEFAULT_ROBOTS','INDEX,FOLLOW','select',100,60,'Default Robots','form-control','Y','INDEX,FOLLOW@=NOINDEX@=NOFOLLOW@=NOINDEX,NOFOLLOW',NULL,'Y','Y',3,'N',25,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-17 08:06:12'),(8,0,'Company Name','COMPANY_NAME','Gopi Kids','text',100,60,'Company Name','form-control','Y',NULL,NULL,'N','Y',5,'N',64,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-11-07 22:26:19'),(9,0,'Company Address','COMPANY_ADDRESS1','A-2 Springfield, Opp. Gayatri Temple,','text',100,60,'Company Address','form-control','Y',NULL,NULL,'N','Y',5,'N',65,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(10,0,'Company Address 2','COMPANY_ADDRESS2','New Waghodia Road','text',100,60,'Company Address 2','form-control','Y',NULL,NULL,'N','Y',5,'N',66,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 08:43:53'),(11,0,'City','COMPANY_CITY','Vadodara','text',100,60,'City','form-control','Y',NULL,NULL,'N','Y',5,'N',67,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(12,0,'State','COMPANY_STATE','GJ','text',100,60,'State','form-control','Y',NULL,NULL,'N','Y',5,'N',68,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(13,0,'Country','COMPANY_COUNTRY','INN','text',100,60,'Country','form-control','Y',NULL,NULL,'N','Y',5,'N',69,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(14,0,'Zipcode','COMPANY_ZIPCODE','390009','text',100,60,'Zipcode','form-control','Y','max six digits',NULL,'N','Y',5,'N',70,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(15,0,'Contact Number','COMPANY_CONTACT_NUMBER','7698980699','text',100,60,'Contact Number','form-control','Y',NULL,NULL,'N','Y',5,'N',71,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2020-04-13 11:50:21'),(16,0,'Contact us email address','COMPANY_EMAIL','info@gopikids.in','email',100,60,'Contact us email address','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-08-13 00:40:23'),(17,0,'Contact us person name','COMPANY_CONTACT_PERSON','Sangita Gohil','text',100,60,'Contact us person name','form-control','Y',NULL,NULL,'N','Y',8,'N',75,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-08-13 01:15:54'),(18,0,'Allow Sending emails','ALLOW_SENDING_EMAIL','Yes','select',100,5,'Allow to send email throughout site? If no, not a single email will execute in this project.','form-control','Y','Yes@=No',NULL,'N','N',8,'N',82,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(19,0,'Order email name','ORDER_CONTACT_PERSON','Jayesh Gohil','text',100,60,'order person name','form-control','Y',NULL,NULL,'N','N',8,'N',75,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-11-18 20:14:30'),(20,0,'From email address','FROM_EMAIL_ADDRESS','support@gopikids.in','email',100,60,'from email address','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-06-21 21:54:54'),(21,0,'Backend Logo title display','BACKEND_LOGO_TITLE_DISPLAY','Administrator','text',100,60,'backend_logo_title_display','form-control','Y','',NULL,'N','Y',2,'N',8,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(22,0,'Content to display before end of body tag','CONTENT_BEFORE_BODY_TAG','','textarea',100,6000,'Please enter content that will before close of body tag.','form-control','N',NULL,NULL,'N','Y',6,'N',26,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 09:24:46'),(23,0,'Script after begin head tag','AFTER_HEAD_TAG','','text',100,60,'After head tag javacript script','form-control','N',NULL,NULL,'N','Y',3,'N',39,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 08:43:53'),(24,0,'Application json script','APPLICATION_JSON_SCRIPT','','textarea',100,6000,'Application json script','form-control','N',NULL,NULL,'N','Y',3,'N',26,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 09:24:46'),(25,0,'Upload Max Size','UPLOAD_MAX_FILESIZE','2M','select',100,60,'Upload Max Size','form-control','Y','2M@=8M@=16M@=24M',NULL,'N','N',4,'N',44,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(26,0,'Facebook','FACEBOOK_URL','https://www.facebook.com/cloudswiftsolutions/','text',100,60,'Please enter your facebook page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:58:52'),(27,0,'Twitter','TWITTER_URL','https://twitter.com/cloudswiftsolutions','text',100,60,'Please enter your twitter page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:59:00'),(28,0,'Linkedin','LINKEDIN_URL','https://www.linkedin.com/company/cloudswiftsolutions/','text',100,60,'Please enter your Linkedin page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:59:06'),(29,0,'Allow to sent email to admin for contact,feedback,etc.','ALLOW_CONTACT_EMAIL','Y','select',100,60,'Please select option','form-control','Y','Y@=N',NULL,'Y','N',8,'N',5,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(30,0,'Application Name','FRONT_APPLICATION_NAME','Demonstration Project','text',100,100,'Please enter your application name for display on frontend side as name','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2019-10-14 13:22:59'),(31,0,'Closed Store Status','CLOSED_STORE_STATUS','N','select',100,100,'This store is closed at present.','form-control','Y','Y@=N',NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-02 10:54:46'),(32,0,'Closed Store Message','CLOSED_STORE_MESSAGE','Store is Under Construction','text',100,100,'Closed Store Message','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-02 10:52:45'),(33,0,'BCC Email 1','BCC_EMAIL_1','bcc@yopmail.com','email',100,60,'BCC Email','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2026-01-29 15:39:46'),(34,0,'SMTP HOST','SMTP_HOST','smtp.hostinger.com','text',100,60,'SMTP HOST','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-13 06:20:26'),(35,0,'SMTP PORT','SMTP_PORT','587','text',100,60,'SMTP Port','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2023-09-16 22:32:56'),(36,0,'SMTP PASSWORD','SMTP_PASSWORD','Cloud@112018','email',100,60,'SMTP PASSWORD','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-13 06:20:26');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config_parent`
--

DROP TABLE IF EXISTS `site_config_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config_parent` (
  `site_config_parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `site_config_title` varchar(191) NOT NULL,
  `classname` varchar(191) NOT NULL,
  `root_user_only` varchar(1) NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`site_config_parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config_parent`
--

LOCK TABLES `site_config_parent` WRITE;
/*!40000 ALTER TABLE `site_config_parent` DISABLE KEYS */;
INSERT INTO `site_config_parent` VALUES (1,0,'Frontend Settings','collapseOne','N',1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(2,0,'Backend Settings','collapseTwo','N',2,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(3,0,'SEO Settings','collapseThree','N',3,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(4,0,'Security Settings','collapseFour','Y',4,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(5,0,'Site Details','collapseSeven','N',7,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(6,0,'Privacy Settings','collapseNine','Y',9,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(7,0,'Follow Us','collapseTen','Y',10,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(8,0,'Email Settings','collapseEight','N',8,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06');
/*!40000 ALTER TABLE `site_config_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `site_db` varchar(255) DEFAULT NULL,
  `user_firstname` varchar(255) DEFAULT NULL,
  `user_lastname` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_token` varchar(255) DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  `user_role_id` smallint(6) NOT NULL DEFAULT 0,
  `is_developer_account` varchar(1) NOT NULL DEFAULT 'N',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `web_or_app` varchar(4) NOT NULL DEFAULT 'App',
  `active_status` varchar(25) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `add_1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'nodejsframework','Developer','Account','developer','developer112018@yopmail.com','$2b$12$A1kkSLpFoyNxFpl9LRiWfOhfSf3t61UGw72tYIWtaZtBuo3tFBHJW',NULL,NULL,1,'Y','N','Web','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06',NULL),(2,1,'nodejsframework','Administrator','User','jayeshgohil082026','gopikids082026@yopmail.com','$2a$10$kJTPNZHNRH8L.YWfYLqsX.eZNpNRvzW/6ZnqD0nauEpxObP2kDw26','511882',NULL,3,'N','N','App','Y',0,'Y',0,NULL,0,'N',0,NULL,'2026-07-10 18:11:23','2026-05-26 12:32:06','2026-05-26 12:32:06',NULL),(31,0,NULL,'John 31','Doe',NULL,'john@example.com','$2b$12$bS55o0.lbacsuS2sZUL4t.gSUH6MPLkwNINI8MKIZMO.htznhPRoq',NULL,NULL,3,'N','Y','App','Y',0,'Y',1,'',1,'N',0,NULL,NULL,'2026-07-10 18:12:31','2026-07-10 18:13:08',NULL),(32,0,'u797036281_gopikids','Data','Entry','dataentry','dataentry@yopmail.com','c671cf1dc2975aa97094dcb4cc74dd2a','822328',NULL,1,'N','Y','App','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 09:02:34','2026-09-03 09:02:45',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15 18:00:03
