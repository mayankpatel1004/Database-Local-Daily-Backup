-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: gloriousjournal_com
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `INPUT_TYPE` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) DEFAULT NULL,
  `GROUPS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'template_name','Print Invoice','text','Y',NULL,'1'),(2,'left_margin','5','text','Y','(%)','1'),(3,'top_margin','2','text','Y','(%)','1'),(4,'top_bar_height','140','text','Y','(px)','1'),(5,'top_address_width','50','text','Y','(%)','2'),(6,'top_center_width','40','text','Y','(%)','2'),(7,'top_right_width','10','text','Y','(%)','2'),(8,'item_section_height','200','text','Y','(px)','1'),(9,'qty','8','text','Y','(%)','3'),(10,'hsn_code','9','text','Y','(%)','3'),(11,'mrp','9','text','Y','(%)','3'),(12,'particular','25','text','Y','(%)','3'),(13,'rate','9','text','Y','(%)','3'),(14,'free','1','text','Y','(%)','3'),(15,'sch_per','1','text','Y','(%)','3'),(16,'sch_amt','9','text','Y','(%)','3'),(17,'sch1_per','10','text','N','(%)','3'),(18,'sch1_amt','10','text','N','(%)','3'),(19,'sch2_per','10','text','N','(%)','3'),(20,'sch2_amt','10','text','N','(%)','3'),(21,'amt','9','text','Y','(%)','3'),(22,'gst_per','2','text','Y','(%)','3'),(23,'gst_amt','9','text','Y','(%)','3'),(24,'net_amt','9','text','Y','(%)','3'),(25,'footer_top_margin','0','text','N','(%)','4'),(26,'footer_height','90','text','N','(%)','4'),(27,'footer_left','24','text','Y','(%)','4'),(28,'footer_gross','9','text','Y','(%)','4'),(29,'footer_scheme','9','text','Y','(%)','4'),(30,'footer_discount','9','text','Y','(%)','4'),(31,'footer_display','9','text','Y','(%)','4'),(32,'footer_damage','9','text','Y','(%)','4'),(33,'footer_gst_amt','12','text','Y','(%)','4'),(34,'footer_add','7','text','Y','(%)','4'),(35,'footer_net_amt','26','text','Y','(%)','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `current_issue`
--

DROP TABLE IF EXISTS `current_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `current_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publish_date` date DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author_description` text DEFAULT NULL,
  `volume` varchar(255) DEFAULT NULL,
  `issue` int(11) NOT NULL DEFAULT 0,
  `country` varchar(255) DEFAULT 'India',
  `doi_no` varchar(255) DEFAULT NULL,
  `doi_link` text DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `keywords` text DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `add_field_1` text DEFAULT NULL,
  `add_field_2` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `active_status` varchar(4) NOT NULL DEFAULT 'Y',
  `deleted_status` varchar(4) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `current_issue`
--

LOCK TABLES `current_issue` WRITE;
/*!40000 ALTER TABLE `current_issue` DISABLE KEYS */;
INSERT INTO `current_issue` VALUES (5,'2026-05-11','11112222','22211','22111',0,'India',NULL,'1222',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-05-11 06:22:24','Y','N'),(6,'2026-05-11','11112222','22211','22111',0,'India',NULL,'1222',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-05-11 06:22:38','Y','N'),(7,'2026-05-11','33333333333','33333333333','33333333333',0,'India',NULL,'33333333333',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-05-11 06:22:48','Y','N'),(8,'2026-05-11','11','11','11',11,'India','11','11','111111111','11','',NULL,NULL,0,NULL,'2026-05-11 10:25:50','Y','N'),(9,'2026-05-11','22','22','22',22,'India','22','22','222','22','',NULL,NULL,0,NULL,'2026-05-11 10:26:25','Y','N'),(10,'2026-05-11','111','222','222',11,'India','11','11','11','11','',NULL,NULL,0,NULL,'2026-05-11 10:28:29','Y','N'),(11,'2026-05-11','11','11','11',11,'India','11','11','111','11','1778495510_Screenshot from 2026-05-09 15-20-39.png',NULL,NULL,0,NULL,'2026-05-11 10:31:50','Y','N'),(12,'2026-05-11','Lorem Ipsum','Lorem Ipsum','2320',29,'India','fdfsadfsfs','dfsdfdsfdfs','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\r\n\r\n','Lorem Ipsum','1778496179_Screenshot from 2026-05-09 10-33-46.png',NULL,NULL,0,NULL,'2026-05-11 10:42:59','Y','N'),(13,'2026-05-11','01','01','02',3,'India','102','102','\r\nddsds\r\nfds\r\nfsa\r\nfsafsdfsdf','','',NULL,NULL,0,NULL,'2026-05-11 11:21:39','Y','N'),(14,'2026-05-11','33333333333','33333333333','33333333333',23,'India','33333333333','33333333333','3333333333333333333333\r\n33333333333\r\n333333333333333333333333333333333\r\n33333333333\r\n33333333333','','',NULL,NULL,0,NULL,'2026-05-11 11:23:32','Y','N');
/*!40000 ALTER TABLE `current_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manuscript_submissions`
--

DROP TABLE IF EXISTS `manuscript_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manuscript_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `institute` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `co_authors` text DEFAULT NULL,
  `manuscript_title` text DEFAULT NULL,
  `manuscript_file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manuscript_submissions`
--

LOCK TABLES `manuscript_submissions` WRITE;
/*!40000 ALTER TABLE `manuscript_submissions` DISABLE KEYS */;
INSERT INTO `manuscript_submissions` VALUES (1,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','1778505423_website draft.docx','2026-05-11 13:17:03'),(2,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','1778505995_website draft.docx','2026-05-11 13:26:35'),(3,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','1778506040_website draft.docx','2026-05-11 13:27:20'),(4,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','1778506140_','2026-05-11 13:29:00'),(5,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:30:50'),(6,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:32:08'),(7,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:33:09'),(8,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:33:29'),(9,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:34:42'),(10,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:35:03'),(11,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:35:57'),(12,'mayank','mayankp@yopmail.com','9898989898','test inst.','IN','author','mstitle','','2026-05-11 13:37:15');
/*!40000 ALTER TABLE `manuscript_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `display_status` varchar(255) DEFAULT 'Y',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','gloriousjournal@yopmail.com','Z2xvcmlvdXNqb3VybmFsQHlvcG1haWwuY29t','Y');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-20 18:00:35
