-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: nodejsframework
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `INPUT_TYPE` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) DEFAULT NULL,
  `GROUPS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'template_name','Print Invoice','text','Y',NULL,'1'),(2,'left_margin','5','text','Y','(%)','1'),(3,'top_margin','2','text','Y','(%)','1'),(4,'top_bar_height','140','text','Y','(px)','1'),(5,'top_address_width','50','text','Y','(%)','2'),(6,'top_center_width','40','text','Y','(%)','2'),(7,'top_right_width','10','text','Y','(%)','2'),(8,'item_section_height','200','text','Y','(px)','1'),(9,'qty','8','text','Y','(%)','3'),(10,'hsn_code','9','text','Y','(%)','3'),(11,'mrp','9','text','Y','(%)','3'),(12,'particular','25','text','Y','(%)','3'),(13,'rate','9','text','Y','(%)','3'),(14,'free','1','text','Y','(%)','3'),(15,'sch_per','1','text','Y','(%)','3'),(16,'sch_amt','9','text','Y','(%)','3'),(17,'sch1_per','10','text','N','(%)','3'),(18,'sch1_amt','10','text','N','(%)','3'),(19,'sch2_per','10','text','N','(%)','3'),(20,'sch2_amt','10','text','N','(%)','3'),(21,'amt','9','text','Y','(%)','3'),(22,'gst_per','2','text','Y','(%)','3'),(23,'gst_amt','9','text','Y','(%)','3'),(24,'net_amt','9','text','Y','(%)','3'),(25,'footer_top_margin','0','text','N','(%)','4'),(26,'footer_height','90','text','N','(%)','4'),(27,'footer_left','24','text','Y','(%)','4'),(28,'footer_gross','9','text','Y','(%)','4'),(29,'footer_scheme','9','text','Y','(%)','4'),(30,'footer_discount','9','text','Y','(%)','4'),(31,'footer_display','9','text','Y','(%)','4'),(32,'footer_damage','9','text','Y','(%)','4'),(33,'footer_gst_amt','12','text','Y','(%)','4'),(34,'footer_add','7','text','Y','(%)','4'),(35,'footer_net_amt','26','text','Y','(%)','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section`
--

DROP TABLE IF EXISTS `item_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section` (
  `item_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_section_parent_id` int(11) NOT NULL DEFAULT 0,
  `section_title` varchar(255) DEFAULT NULL,
  `section_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `display_order` int(11) DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section`
--

LOCK TABLES `item_section` WRITE;
/*!40000 ALTER TABLE `item_section` DISABLE KEYS */;
INSERT INTO `item_section` VALUES (34,0,0,'1234456 update','1234456-1769749437','default','1234456 update',NULL,1,4,'Y','1234456 update','1234456 update',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-30 10:33:43','2026-01-30 05:03:57'),(33,0,0,'1111111111112222222','111111111111-1769702432','default','1111111111','attachment1-1769702432060.png',1,3,'Y','111111111','2222222222',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-29 21:30:17','2026-01-29 16:00:32'),(32,0,0,'3344551122','334455-1769694419','blog-category','221133','',1,26,'Y','112233','11222',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-29 19:16:48','2026-01-29 13:46:59'),(31,0,0,'112233','112233','blog-category','eeee','',1,25,'Y','123','233',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-29 18:37:46','2026-01-29 13:07:56'),(30,0,0,'Section 2','section-2','default','item description2',NULL,1,2,'Y','meta title','',1,'Developer Account',1,'N',0,NULL,NULL,'2025-10-24 10:38:52','2025-10-24 05:09:10'),(29,0,0,'Admin Category 1','admin-category-1','blog-category','Admin Category 1','',3,24,'Y','Admin Category 1','Admin Category 1',3,'Admin Admin',3,'N',0,NULL,NULL,'2025-10-03 12:11:45','2025-10-03 06:41:52'),(28,0,0,'Default 2 update','default-2','default','Default 2 update','attachment1-1758621718238.sql',1,1,'Y','Default 2 update','Default 2 update',1,'Cloudswift Solutions',1,'N',0,NULL,NULL,'2025-09-23 15:31:42','2025-09-23 10:01:58'),(27,0,0,'Default Title','default-title','blog','Default Description','attachment1-1758621657001.sql',1,1,'Y','Default Title','Default Title',1,'Cloudswift Solutions',1,'N',0,NULL,NULL,'2025-09-23 15:30:34','2025-09-23 10:00:57'),(24,0,0,'Blog Category 1','custom-section','blog-category','Blog Category 1',NULL,1,23,'Y','Blog Category 1','Blog Category 1',1,'Cloudswift Solutions',1,'N',0,NULL,NULL,'2025-09-23 08:42:42','2025-09-23 03:12:51'),(25,0,0,'Blog Category 2','blog-category-2','blog-category','Blog Category 2',NULL,1,23,'Y','Blog Category 2','Blog Category 2',1,'Cloudswift Solutions',1,'N',0,NULL,NULL,'2025-09-23 08:45:59','2025-09-23 03:16:09'),(26,0,0,'Blog Category 3','blog-category-3','blog-category','Blog Category 3',NULL,1,23,'Y','Blog Category 3','Blog Category 3',1,'Cloudswift Solutions',1,'N',0,NULL,NULL,'2025-09-23 08:46:23','2025-09-23 03:16:31'),(35,0,0,'mfdffasfs','mfdffasfs-1769762441','blog-category','dsfsf','',1,27,'Y','dfsfsadfsd','fdsfs',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-30 14:10:33','2026-01-30 08:40:41'),(36,0,0,'3231321 31 23 123','3231321-31-23-123-1769765314','default','3231321 31 23 123','attachment1-1769765324886.png',1,5,'Y','3231321 31 23 123','3231321 31 23 123',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-30 14:58:21','2026-01-30 09:28:34'),(37,0,0,' fd fd  43 423 3 32 334 324','fd-fd-43-423-3-32-334-324-1769765780','default',' fd fd  43 423 3 32 334 324','attachment1-1769765780115.png',1,6,'Y',' fd fd  43 423 3 32 334 324',' fd fd  43 423 3 32 334 324',1,'Developer Account',1,'Y',1,'Developer Account','2026-01-30 15:06:32','2026-01-30 15:06:07','2026-01-30 09:36:20'),(38,0,0,'2222222','2222222-1769766193','default','2222222','attachment1-1769766193676.png',1,7,'Y','2222222','2222222',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-30 15:13:03','2026-01-30 09:43:13'),(39,0,0,'`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<','','default','`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<',NULL,1,8,'Y','`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<','`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-30 17:05:58','2026-01-30 11:36:08'),(40,0,0,'112233','112233-1769773670','default','112233',NULL,1,9,'Y','112233','112233',1,'Developer Account',1,'N',0,NULL,NULL,'2026-01-30 17:17:42','2026-01-30 11:47:50');
/*!40000 ALTER TABLE `item_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section_relation`
--

DROP TABLE IF EXISTS `item_section_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section_relation` (
  `item_section_relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_id` bigint(20) NOT NULL DEFAULT 0,
  `section_id` bigint(20) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_time` datetime DEFAULT NULL,
  PRIMARY KEY (`item_section_relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section_relation`
--

LOCK TABLES `item_section_relation` WRITE;
/*!40000 ALTER TABLE `item_section_relation` DISABLE KEYS */;
INSERT INTO `item_section_relation` VALUES (8,0,31,24,'N',0,NULL),(9,0,31,25,'N',0,NULL),(10,0,31,26,'N',0,NULL),(11,0,34,25,'N',0,NULL),(12,0,35,24,'N',0,NULL),(14,0,36,25,'N',0,NULL),(16,0,37,25,'N',0,NULL),(21,0,38,25,'N',0,NULL),(22,0,39,25,'N',0,NULL),(24,0,40,24,'N',0,NULL),(25,0,40,25,'N',0,NULL),(26,0,40,26,'N',0,NULL),(30,0,41,25,'N',0,NULL),(31,0,41,29,'N',0,NULL),(32,0,41,31,'N',0,NULL),(33,0,42,29,'N',0,NULL),(34,0,42,31,'N',0,NULL),(35,0,42,32,'N',0,NULL),(36,0,43,24,'N',0,NULL),(37,0,44,25,'N',0,NULL),(38,0,44,29,'N',0,NULL),(39,0,45,24,'N',0,NULL),(40,0,45,25,'N',0,NULL),(41,0,45,26,'N',0,NULL);
/*!40000 ALTER TABLE `item_section_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_parent` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) DEFAULT NULL,
  `item_sections_id` varchar(255) DEFAULT NULL,
  `item_description` longtext DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `attachment2` varchar(255) DEFAULT NULL,
  `item_shortdescription` text DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT 'index',
  `published_at` date DEFAULT NULL,
  `published_end_at` date DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (24,0,'Mayank ','mayank',100,'default','24','description update','attachment1-1758612676875.png','attachment2-1758612676877.png','short description update',3,'controller','action','2025-09-03','2025-09-21','meta title update','meta description update',1,'Cloudswift Solutions',1,1,'Y','N',0,NULL,NULL,'2025-09-23 06:18:45','2025-09-23 06:20:51'),(25,0,'About Us','about-us',0,'page','','About Us',NULL,'','',1,'','','2025-09-23','2030-09-23','About Us','About Us',1,'Cloudswift Solutions',1,1,'Y','N',0,NULL,NULL,'2025-09-23 07:45:18','2025-09-23 07:45:27'),(26,0,'Terms & Conditions','terms-and-conditions',0,'page','','Terms & Conditions',NULL,'','',1,'','','2025-09-23','2030-09-23','Terms & Conditions','Terms & Conditions',1,'Cloudswift Solutions',1,2,'Y','N',0,NULL,NULL,'2025-09-23 07:46:35','2025-09-23 07:46:43'),(27,0,'Privacy Policy','privacy-policy',0,'page','','Privacy Policy',NULL,'','',1,'','','2025-09-23','2030-09-23','Privacy Policy','Privacy Policy',1,'Cloudswift Solutions',1,3,'Y','N',0,NULL,NULL,'2025-09-23 08:09:19','2025-09-23 08:09:27'),(28,0,'Blog2','blog2',0,'blog','24','Blog2',NULL,'','',1,'','','2025-09-23','2030-09-23','Blog2','Blog2',1,'Cloudswift Solutions',1,2,'Y','N',0,NULL,NULL,'2025-09-23 08:22:54','2025-09-23 08:23:25'),(29,0,'Default2','default2',0,'default','24','Default2',NULL,NULL,'Default2',1,'Default2','Default2','2025-09-23','2030-09-23','Default2','Default2',1,'Cloudswift Solutions',1,2,'Y','N',0,NULL,NULL,'2025-09-23 08:23:44','2025-09-23 08:24:03'),(30,0,'Default3','default3',0,'default','24','Default3',NULL,NULL,'Default3',1,'Default3','Default3','2025-10-03','2030-10-03','Default3','Default3',1,'Developer Account',1,3,'Y','N',0,NULL,NULL,'2025-10-03 05:55:14','2025-10-03 06:04:53'),(31,0,'Default4','default4',0,'default','24,25,26','Default4',NULL,NULL,'',1,'','','2025-10-03','2030-10-03','','',1,'Developer Account',1,4,'Y','N',0,NULL,NULL,'2025-10-03 06:05:29','2025-10-03 06:05:40'),(32,0,'Admin Blog1','admin-blog1',0,'blog','24','Admin Blog1',NULL,'','',3,'','','2025-10-03','2030-10-03','Admin Blog1','Admin Blog1',3,'Admin Admin',3,3,'Y','N',0,NULL,NULL,'2025-10-03 06:38:11','2025-10-03 06:38:22'),(33,0,'Admin Blog 2','admin-blog-2',0,'blog','24','Admin Blog 2','attachment1-1759473524880.png','','',3,'','','2025-10-03','2030-10-03','','',3,'Admin Admin',3,4,'Y','N',0,NULL,NULL,'2025-10-03 06:38:31','2025-10-03 06:38:44'),(34,0,'blog 1','blog-1-8967',0,'blog','25','description',NULL,'','',1,'','','2025-10-24','2030-10-24','meta title','meta desc',1,'Developer Account',1,5,'Y','N',0,NULL,NULL,'2025-10-24 04:44:50','2025-10-24 04:45:08'),(35,0,'12222222222','12222222222-1769694565',0,'blog','24','12222222222','attachment1-1769694565480.png','','',1,'','','2026-01-29','2031-01-29','12222222222','12222222222',1,'Developer Account',1,6,'Y','N',0,NULL,NULL,'2026-01-29 13:49:11','2026-01-29 13:49:25'),(36,0,'mayank','mayank-1769702274',0,'default','25','fdsfafs','attachment1-1769702274939.png','attachment2-1769702274954.png','sdfsadf',1,'','','2026-01-29','2031-01-29','fsdf','fsda1111',1,'Developer Account',1,5,'Y','N',0,NULL,NULL,'2026-01-29 15:57:27','2026-01-29 15:57:54'),(37,0,'Mayankpatel Update','mayankpatel-1769746822',0,'default','25','112233',NULL,NULL,'221133',1,'','','2026-01-30','2031-01-30','','',1,'Developer Account',1,6,'Y','N',0,NULL,NULL,'2026-01-30 04:20:11','2026-01-30 04:20:22'),(38,0,'30012026','30012026-1769747084',0,'default','25','30012026','attachment1-1769747084387.png',NULL,'30012026',1,'','','2026-01-30','2031-01-30','30012026','30012026',1,'Developer Account',1,7,'Y','N',0,NULL,NULL,'2026-01-30 04:24:20','2026-01-30 04:24:44'),(23,0,'Blog 1','blog-1',0,'blog',NULL,'Blog 1',NULL,NULL,'Blog 1',1,NULL,'index','2025-09-23','2030-09-23','Blog 1','Blog 1',1,'Cloudswift Solutions',1,1,'Y','N',0,NULL,NULL,'2025-09-23 03:23:45','2025-09-23 03:23:56'),(39,0,'fdfasfs','fdfasfs-1769762467',0,'default','25','sdfdsafs',NULL,NULL,'fsdafsd',1,'','','2026-01-30','2031-01-30','fdsf','dsfsa',1,'Developer Account',1,8,'Y','N',0,NULL,NULL,'2026-01-30 08:40:55','2026-01-30 08:41:07'),(40,0,'112233 update','112233-1769765248',0,'default','24,25,26','112233 update','attachment1-1769765248817.png','attachment2-1769765248834.png','112233',1,'112233','112233','2026-01-30','2031-01-30','112233','112233',1,'Developer Account',1,9,'Y','N',0,NULL,NULL,'2026-01-30 09:27:02','2026-01-30 09:27:28'),(41,0,' fd fd  43 423 3 32 334 324','fd-fd-43-423-3-32-334-324-1769765720',0,'default','25,29,31',' fd fd  43 423 3 32 334 324','attachment1-1769765720869.png','attachment2-1769765720890.png',' fd fd  43 423 3 32 334 324',1,' fd fd  43 423 3 32 334 324',' fd fd  43 423 3 32 334 324','2026-01-30','2031-01-30',' fd fd  43 423 3 32 334 324',' fd fd  43 423 3 32 334 324',1,'Developer Account',1,10,'Y','Y',1,'Developer Account','2026-01-30 15:05:57','2026-01-30 09:34:59','2026-01-30 09:35:20'),(42,0,'10','10-1769766176',0,'default','29,31,32','10','attachment1-1769766176134.png',NULL,'10',1,'11','23','2026-01-30','2031-01-30','12','12',1,'Developer Account',1,11,'Y','N',0,NULL,NULL,'2026-01-30 09:42:29','2026-01-30 09:42:56'),(43,0,'const query = util.promisify(db.query).bind(db);','const-query-utilpromisifydbquerybinddb-1769766586',0,'default','24','const query = util.promisify(db.query).bind(db);',NULL,NULL,'const query = util.promisify(db.query).bind(db);',1,'','','2026-01-30','2031-01-30','','',1,'Developer Account',1,12,'Y','N',0,NULL,NULL,'2026-01-30 09:49:31','2026-01-30 09:49:46'),(44,0,'`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<','',0,'default','25,29','`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<',NULL,NULL,'',1,'','','2026-01-30','2031-01-30','','',1,'Developer Account',1,13,'Y','N',0,NULL,NULL,'2026-01-30 11:33:27','2026-01-30 11:35:37'),(45,0,'112233','112233-1769773779',0,'default','24,25,26','112233',NULL,NULL,'112233',1,'','','2026-01-30','2031-01-30','','',1,'Developer Account',1,14,'Y','N',0,NULL,NULL,'2026-01-30 11:49:26','2026-01-30 11:49:39');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_details`
--

DROP TABLE IF EXISTS `meta_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_details` (
  `meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `end_points` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `sidebar_title` varchar(255) DEFAULT NULL,
  `sidebar_icon` varchar(255) DEFAULT NULL,
  `sidebar_order` int(11) NOT NULL DEFAULT 0,
  `params` varchar(255) DEFAULT NULL,
  `is_module` tinyint(4) NOT NULL DEFAULT 0,
  `deleted_status` char(4) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`meta_id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_details`
--

LOCK TABLES `meta_details` WRITE;
/*!40000 ALTER TABLE `meta_details` DISABLE KEYS */;
INSERT INTO `meta_details` VALUES (1,0,0,'/','Dashboard','Dashboard','Dashboard','Dashboard','mdi-view-dashboard',1,NULL,1,'N'),(2,0,0,'/users','Users','Users','Users','Users','mdi-account-box',104,NULL,1,'N'),(3,0,0,'/change-password','change password','Change Password','Change Password','Change Password','mdi mdi-server-security',105,NULL,1,'N'),(5,0,0,'/items?item_type=page','Pages','Pages','Pages','Pages','mdi-format-list-bulleted',3,NULL,1,'N'),(6,0,0,'/configurations','Configurations','Configurations Meta','Desc','Configurations','mdi-view-headline',109,NULL,1,'N'),(12,0,0,'/user_form','user form','user form','user form','user form',NULL,0,NULL,0,'N'),(10,0,0,'/item_section_form','section form','section form','section form','section form',NULL,0,NULL,0,'N'),(7,0,0,'/logout','Logout','Logout','Logout','Logout','mdi-logout-variant',201,NULL,1,'N'),(8,0,0,'/login','Login','Login','Login','Login',NULL,0,NULL,0,'N'),(9,0,0,'/metadetails','Meta Details','Meta Details','Meta Details','SEO','mdi-format-list-bulleted',108,NULL,1,'N'),(11,0,0,'/item_form','item form','item form','item form','item form',NULL,0,NULL,0,'N'),(13,0,0,'/forgot-password','Forgot Password','Forgot Password','Forgot Password','Forgot Password',NULL,0,NULL,0,'N'),(14,0,0,'/password-token','Password Token','Password Token','Password Token','Password Token',NULL,0,NULL,0,'N'),(15,0,0,'/reset-password','Reset Password','Reset Password','Reset Password','Reset Password',NULL,0,NULL,0,'N'),(16,0,0,'/roles','Roles','Roles','Roles','Roles','mdi mdi-account',103,NULL,1,'N'),(17,0,0,'/role_form','Role Form','Role Form','Role Form','Role Form',NULL,0,NULL,0,'N'),(42,0,0,'/item_form?item_type=blog','Blog Form','Blog Form','Blog Form',NULL,NULL,0,NULL,0,'N'),(41,0,0,'/item_form?item_type=page','Page Form','Page Form','Page Form',NULL,NULL,0,NULL,0,'N'),(45,0,0,'/item_section_form?item_type=default','Default Section Form','Default Section Form','Default Section Form',NULL,NULL,0,NULL,0,'N'),(46,0,0,'/item_section_form?item_type=blog-category','Blog Category Form','Blog Category Form','Blog Category Form',NULL,NULL,0,NULL,0,'N'),(47,0,0,'/items/default','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,'N'),(48,0,0,'/database_table','Database Tables','Database Tables','Database Tables','Database Tables','mdi mdi-view-headline',200,NULL,1,'N'),(33,0,0,'/item_section?item_type=blog-category','Blog Category','Blog Category','Blog Category','Blog Category','mdi mdi-view-headline',5,NULL,1,'N'),(34,0,0,'/items?item_type=blog','Blogs','Blogs','Blogs','Blogs','mdi-format-list-bulleted',5,NULL,1,'N'),(39,0,0,'/item_form?item_type=default','Default Form','Default Form','Default Form',NULL,NULL,0,NULL,0,'N'),(38,0,0,'/items?item_type=default','Default Item','Default','Default','Default Items','mdi-format-list-bulleted',1,NULL,1,'N'),(44,0,0,'/item_section?item_type=default','Default Section','Default Section','Default','Default Section','mdi mdi-view-headline',1,NULL,1,'N'),(49,0,52,'/template/mdiicons','Demonstration Company','Demonstration Company','Demonstration Company Description','MDI Icons','mdi mdi-view-headline',404,'ui-basic',1,'Y'),(50,0,52,'/template/formelement','Form Elements','Form Elements','Form Elements','Form Element','mdi mdi-view-headline',403,'ui-basic',1,'Y'),(51,0,52,'/template/gallery','Gallery','Gallery','Gallery','Gallery','mdi mdi-view-headline',402,'ui-basic',1,'Y'),(52,0,-1,'/template','Templates','Templates','Templates','Templates','ui-basic',401,NULL,1,'Y'),(60,0,0,'/items','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,'N');
/*!40000 ALTER TABLE `meta_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'role',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `display_on_listing` enum('Y','N') NOT NULL DEFAULT 'Y',
  `show_action_checkbox` enum('Y','N') NOT NULL DEFAULT 'Y',
  `allow_delete` enum('Y','N') NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,0,'Developer','developer','role',1,'Y','Y','Y','N',0,'N',0,NULL,NULL,'2025-08-11 04:42:44','2025-08-11 04:42:53'),(2,0,'Super Admin','superadmin','role',1,'Y','Y','Y','N',0,'N',0,NULL,NULL,'2025-08-12 12:52:34','2025-08-12 12:52:50'),(3,0,'Admin','admin','role',1,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-09-01 04:43:03','2025-09-01 04:43:17'),(4,0,'Franchise','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:40:32','2025-10-24 05:10:44'),(5,0,'Reporter','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:42:38','2025-10-24 05:12:50'),(6,0,'Editor','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:44:01','2025-10-24 05:14:15'),(7,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:16:03'),(8,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:16:38'),(9,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:17:19'),(10,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:17:40'),(11,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:17:58'),(12,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:22:45'),(13,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:23:11'),(14,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:28:21'),(15,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:28:30'),(16,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:29:31'),(17,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:30:11'),(18,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 05:15:46','2025-10-24 05:30:26'),(19,0,'Fr','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2025-10-24 10:45:46','2025-10-24 05:31:17'),(20,0,'mikeeeeeeee','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 18:21:14','2026-01-29 12:51:32'),(21,0,'11223','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 18:24:05','2026-01-29 12:54:12'),(22,0,'11223','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 18:24:05','2026-01-29 12:54:50'),(23,0,'11223','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 12:54:05','2026-01-29 12:55:39'),(24,0,'11223','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 18:24:05','2026-01-29 12:57:30'),(25,0,'note update @$#%^%&((()\'\'\\','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 18:29:49','2026-01-29 12:59:56'),(26,0,'newwwwww','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-29 21:26:44','2026-01-29 15:56:51'),(27,0,'3231321 31 23 123','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-30 14:59:15','2026-01-30 09:32:01'),(28,0,'Rv','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-30 15:07:08','2026-01-30 09:37:16'),(29,0,'2222222','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-30 15:13:24','2026-01-30 09:43:57'),(30,0,'`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-30 17:06:33','2026-01-30 11:36:38'),(31,0,'112233','','role',0,'Y','Y','Y','Y',0,'N',0,NULL,NULL,'2026-01-30 17:15:51','2026-01-30 11:45:59');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_access`
--

DROP TABLE IF EXISTS `role_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_access` (
  `role_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_id` int(11) DEFAULT 0,
  `module_id` int(11) DEFAULT 0,
  `grant_add` enum('Y','N') NOT NULL DEFAULT 'N',
  `grant_edit` enum('Y','N') NOT NULL DEFAULT 'N',
  `grant_delete` enum('Y','N') NOT NULL DEFAULT 'N',
  `grant_view` enum('Y','N') NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_access_id`)
) ENGINE=MyISAM AUTO_INCREMENT=605 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_access`
--

LOCK TABLES `role_access` WRITE;
/*!40000 ALTER TABLE `role_access` DISABLE KEYS */;
INSERT INTO `role_access` VALUES (311,0,1,6,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(310,0,1,7,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(309,0,1,9,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(328,0,2,6,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(327,0,2,7,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(326,0,2,9,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(308,0,1,16,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(307,0,1,33,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(306,0,1,34,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(305,0,1,38,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(304,0,1,44,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(383,0,3,1,'Y','Y','Y','Y',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(382,0,3,2,'Y','Y','Y','Y',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(381,0,3,3,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(380,0,3,5,'Y','Y','Y','Y',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(379,0,3,6,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(378,0,3,7,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(377,0,3,9,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(376,0,3,16,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(303,0,1,48,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(302,0,1,49,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(301,0,1,50,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(300,0,1,51,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(299,0,1,52,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(325,0,2,16,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(324,0,2,33,'Y','Y','Y','Y',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(323,0,2,34,'Y','Y','Y','Y',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(322,0,2,38,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(321,0,2,44,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(320,0,2,48,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(319,0,2,49,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(318,0,2,50,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(317,0,2,51,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(316,0,2,52,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(298,0,1,53,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(297,0,1,54,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(296,0,1,55,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(295,0,1,56,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(312,0,1,5,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(313,0,1,3,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(314,0,1,2,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(315,0,1,1,'Y','Y','Y','Y',0,'Y','N','2025-10-01 12:01:34','2025-10-01 06:31:34'),(329,0,2,5,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(330,0,2,3,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(331,0,2,2,'N','N','N','N',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(332,0,2,1,'Y','Y','Y','Y',0,'Y','N','2025-10-02 09:44:20','2025-10-02 04:14:20'),(375,0,3,33,'Y','Y','Y','Y',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(374,0,3,34,'Y','Y','Y','Y',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(373,0,3,38,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(372,0,3,44,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(371,0,3,48,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(370,0,3,49,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(369,0,3,50,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(368,0,3,51,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(367,0,3,52,'N','N','N','N',0,'Y','N','2025-10-03 12:14:39','2025-10-03 06:44:39'),(384,0,NULL,52,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(385,0,NULL,51,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(386,0,NULL,50,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(387,0,NULL,49,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(388,0,NULL,48,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(389,0,NULL,44,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(390,0,NULL,38,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(391,0,NULL,34,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(392,0,NULL,33,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(393,0,NULL,16,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(394,0,NULL,9,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(395,0,NULL,7,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(396,0,NULL,6,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(397,0,NULL,5,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(398,0,NULL,3,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(399,0,NULL,2,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(400,0,NULL,1,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:40:44','2025-10-24 05:10:44'),(401,0,4,52,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(402,0,4,51,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(403,0,4,50,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(404,0,4,49,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(405,0,4,48,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(406,0,4,44,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(407,0,4,38,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(408,0,4,34,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(409,0,4,33,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(410,0,4,16,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(411,0,4,9,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(412,0,4,7,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(413,0,4,6,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(414,0,4,5,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(415,0,4,3,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(416,0,4,2,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(417,0,4,1,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:41:33','2025-10-24 05:11:33'),(418,0,NULL,52,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(419,0,NULL,51,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(420,0,NULL,50,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(421,0,NULL,49,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(422,0,NULL,48,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(423,0,NULL,44,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(424,0,NULL,38,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(425,0,NULL,34,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(426,0,NULL,33,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(427,0,NULL,16,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(428,0,NULL,9,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(429,0,NULL,7,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(430,0,NULL,6,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(431,0,NULL,5,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(432,0,NULL,3,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(433,0,NULL,2,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(434,0,NULL,1,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:42:50','2025-10-24 05:12:50'),(435,0,NULL,52,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(436,0,NULL,51,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(437,0,NULL,50,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(438,0,NULL,49,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(439,0,NULL,48,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(440,0,NULL,44,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(441,0,NULL,38,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(442,0,NULL,34,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(443,0,NULL,33,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(444,0,NULL,16,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(445,0,NULL,9,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(446,0,NULL,7,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(447,0,NULL,6,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(448,0,NULL,5,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(449,0,NULL,3,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(450,0,NULL,2,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(451,0,NULL,1,'Y','Y','Y','Y',0,'Y','N','2025-10-24 10:44:15','2025-10-24 05:14:15'),(452,0,24,52,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(453,0,24,51,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(454,0,24,50,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(455,0,24,49,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(456,0,24,48,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(457,0,24,44,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(458,0,24,38,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(459,0,24,34,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(460,0,24,33,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(461,0,24,16,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(462,0,24,9,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(463,0,24,7,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(464,0,24,6,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(465,0,24,5,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(466,0,24,3,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(467,0,24,2,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(468,0,24,1,'N','N','N','Y',0,'Y','N','2026-01-29 18:27:30','2026-01-29 12:57:30'),(502,0,25,1,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(501,0,25,2,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(500,0,25,3,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(499,0,25,5,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(498,0,25,6,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(497,0,25,7,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(496,0,25,9,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(495,0,25,16,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(494,0,25,33,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(493,0,25,34,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(492,0,25,38,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(491,0,25,44,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(490,0,25,48,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(489,0,25,49,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(488,0,25,50,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(487,0,25,51,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(486,0,25,52,'Y','N','N','N',0,'Y','N','2026-01-29 18:30:16','2026-01-29 13:00:16'),(503,0,26,52,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(504,0,26,51,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(505,0,26,50,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(506,0,26,49,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(507,0,26,48,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(508,0,26,44,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(509,0,26,38,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(510,0,26,34,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(511,0,26,33,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(512,0,26,16,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(513,0,26,9,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(514,0,26,7,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(515,0,26,6,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(516,0,26,5,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(517,0,26,3,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(518,0,26,2,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(519,0,26,1,'N','Y','N','Y',0,'Y','N','2026-01-29 21:26:51','2026-01-29 15:56:51'),(520,0,27,52,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(521,0,27,51,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(522,0,27,50,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(523,0,27,49,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(524,0,27,48,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(525,0,27,44,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(526,0,27,38,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(527,0,27,34,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(528,0,27,33,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(529,0,27,16,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(530,0,27,9,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(531,0,27,7,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(532,0,27,6,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(533,0,27,5,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(534,0,27,3,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(535,0,27,2,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(536,0,27,1,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:02:01','2026-01-30 09:32:01'),(537,0,28,52,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(538,0,28,51,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(539,0,28,50,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(540,0,28,49,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(541,0,28,48,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(542,0,28,44,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(543,0,28,38,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(544,0,28,34,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(545,0,28,33,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(546,0,28,16,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(547,0,28,9,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(548,0,28,7,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(549,0,28,6,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(550,0,28,5,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(551,0,28,3,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(552,0,28,2,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(553,0,28,1,'Y','N','N','Y',0,'Y','N','2026-01-30 15:07:16','2026-01-30 09:37:16'),(554,0,29,52,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(555,0,29,51,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(556,0,29,50,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(557,0,29,49,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(558,0,29,48,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(559,0,29,44,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(560,0,29,38,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(561,0,29,34,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(562,0,29,33,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(563,0,29,16,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(564,0,29,9,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(565,0,29,7,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(566,0,29,6,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(567,0,29,5,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(568,0,29,3,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(569,0,29,2,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(570,0,29,1,'Y','Y','Y','Y',0,'Y','N','2026-01-30 15:13:57','2026-01-30 09:43:57'),(571,0,30,52,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(572,0,30,51,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(573,0,30,50,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(574,0,30,49,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(575,0,30,48,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(576,0,30,44,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(577,0,30,38,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(578,0,30,34,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(579,0,30,33,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(580,0,30,16,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(581,0,30,9,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(582,0,30,7,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(583,0,30,6,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(584,0,30,5,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(585,0,30,3,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(586,0,30,2,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(587,0,30,1,'N','N','N','Y',0,'Y','N','2026-01-30 17:06:38','2026-01-30 11:36:38'),(588,0,31,52,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(589,0,31,51,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(590,0,31,50,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(591,0,31,49,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(592,0,31,48,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(593,0,31,44,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(594,0,31,38,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(595,0,31,34,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(596,0,31,33,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(597,0,31,16,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(598,0,31,9,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(599,0,31,7,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(600,0,31,6,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(601,0,31,5,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(602,0,31,3,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(603,0,31,2,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59'),(604,0,31,1,'Y','N','N','Y',0,'Y','N','2026-01-30 17:15:59','2026-01-30 11:45:59');
/*!40000 ALTER TABLE `role_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `config_title` varchar(1024) DEFAULT NULL,
  `config_name` varchar(1024) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `input_type` varchar(15) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 100,
  `maxlength` int(11) NOT NULL DEFAULT 100,
  `input_type_title` varchar(100) DEFAULT NULL,
  `class` varchar(100) DEFAULT 'textbox',
  `required` enum('Y','N','O') DEFAULT 'O',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `comments` varchar(255) DEFAULT NULL,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `additional` varchar(100) DEFAULT NULL,
  `display_on_dashboard` enum('Y','N') NOT NULL DEFAULT 'N',
  `display_on_third_party` enum('Y','N') NOT NULL DEFAULT 'N',
  `site_config_parent_id` tinyint(4) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `root_user_only` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`config_id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,0,'Application Title','FRONT_APPLICATION_TITLE','CMS123','text',100,100,'Please enter your application name for display on frontend side as title','form-control','Y',1,NULL,'Y',NULL,'Y','Y',1,'N','N','2019-04-11 13:00:00','2026-01-30 09:34:40'),(2,0,'Records per page','FRONT_RECORD_PER_PAGE','16','select',100,60,'Records per page','form-control','Y',5,'8@=16@=24@=32@=40@=80','Y',NULL,'Y','Y',1,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(7,0,'Maintenance Mode','SITE_CONSTRUCTION','No','select',100,60,'Site Under Construction Status','form-control','Y',12,'Yes@=No','Y',NULL,'Y','N',1,'N','N','2019-04-11 13:00:00','2021-12-07 22:07:04'),(8,0,'Default Timezone','FRONT_DEFAULT_TIMEZONE','Asia/Kolkata','select',100,60,'Default Timezone','form-control','Y',13,'America/Chicago@=Asia/Kolkata@=Europe/London@=Australia/Perth','Y',NULL,'Y','Y',1,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(9,0,'Backend application Title','BACKEND_APPLICATION_TITLE','Cloudswift :: Administrator','text',100,60,'Application Title','form-control','Y',14,NULL,'Y',NULL,'Y','N',2,'N','N','2019-04-11 13:00:00','2019-10-14 07:08:57'),(14,0,'Meta Description','FRONT_META_DESCRIPTION','We are the leading Custom Software Solution Company in Vadodara, Gujarat, India who servered more then 50 Clients across World.','text',100,60,'Meta Description','form-control','Y',1,NULL,'Y',NULL,'N','N',1,'N','N','2019-04-11 13:00:00','2020-04-17 01:06:07'),(15,0,'Default Robots','FRONT_DEFAULT_ROBOTS','INDEX,FOLLOW','select',100,60,'Default Robots','form-control','Y',25,'INDEX,FOLLOW@=NOINDEX@=NOFOLLOW@=NOINDEX,NOFOLLOW','Y',NULL,'Y','Y',3,'N','N','2019-04-11 13:00:00','2019-10-17 08:06:12'),(38,0,'Company Name','COMPANY_NAME','Cloudswift Solutions Pvt. Ltd.','text',100,60,'Company Name','form-control','Y',64,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-11-07 22:26:19'),(39,0,'Company Address','COMPANY_ADDRESS1','Sama, Near Chanikya crossing','text',100,60,'Company Address','form-control','Y',65,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(40,0,'Company Address 2','COMPANY_ADDRESS2','','text',100,60,'Company Address 2','form-control','Y',66,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-09-24 08:43:53'),(41,0,'City','COMPANY_CITY','Vadodara','text',100,60,'City','form-control','Y',67,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(42,0,'State','COMPANY_STATE','GJ','text',100,60,'State','form-control','Y',68,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(43,0,'Country','COMPANY_COUNTRY','INN','text',100,60,'Country','form-control','Y',69,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(44,0,'Zipcode','COMPANY_ZIPCODE','390009','text',100,60,'Zipcode','form-control','Y',70,'max six digits','Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(45,0,'Contact Number','COMPANY_CONTACT_NUMBER','886-630-3621','text',100,60,'Contact Number','form-control','Y',71,NULL,'Y',NULL,'N','Y',7,'N','N','2019-04-11 13:00:00','2020-04-13 11:50:21'),(47,0,'Contact us email address','COMPANY_EMAIL','connect@cloudswiftsolutions.com','email',100,60,'Contact us email address','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 13:00:00','2021-08-13 00:40:23'),(48,0,'Contact us person name','COMPANY_CONTACT_PERSON','CloudSwift Solutions','text',100,60,'Contact us person name','form-control','Y',75,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 13:00:00','2021-08-13 01:15:54'),(53,0,'Allow Sending emails','ALLOW_SENDING_EMAIL','Yes','select',100,5,'Allow to send email throughout site? If no, not a single email will execute in this project.','form-control','Y',82,'Yes@=No','Y',NULL,'N','N',9,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(67,0,'Order email name','ORDER_CONTACT_PERSON','Cloud Swift Solutions','text',100,60,'order person name','form-control','Y',75,NULL,'Y',NULL,'N','N',8,'N','N','2019-04-11 13:00:00','2019-11-18 20:14:30'),(75,0,'From email address','FROM_EMAIL_ADDRESS','notifications@cloudswiftsolutions.com','email',100,60,'from email address','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 13:00:00','2021-06-21 21:54:54'),(76,0,'Backend Logo title display','BACKEND_LOGO_TITLE_DISPLAY','Administrator','text',100,60,'backend_logo_title_display','form-control','Y',8,'','Y',NULL,'N','Y',2,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(83,0,'Content to display before end of body tag','CONTENT_BEFORE_BODY_TAG','','textarea',100,6000,'Please enter content that will before close of body tag.','form-control','N',26,NULL,'Y',NULL,'N','Y',9,'N','N','2019-04-11 13:00:00','2019-09-24 09:24:46'),(86,0,'Script after begin head tag','AFTER_HEAD_TAG','','text',100,60,'After head tag javacript script','form-control','N',39,NULL,'Y',NULL,'N','Y',3,'N','N','2019-04-11 13:00:00','2019-09-24 08:43:53'),(88,0,'Application json script','APPLICATION_JSON_SCRIPT','','textarea',100,6000,'Application json script','form-control','N',26,NULL,'Y',NULL,'N','Y',3,'N','N','2019-04-11 13:00:00','2019-09-24 09:24:46'),(97,0,'Upload Max Size','UPLOAD_MAX_FILESIZE','2M','select',100,60,'Upload Max Size','form-control','Y',44,'2M@=8M@=16M@=24M','Y',NULL,'N','N',4,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(102,0,'Facebook','FACEBOOK_URL','https://www.facebook.com/cloudswiftsolutions/','text',100,60,'Please enter your facebook page url','form-control','N',40,NULL,'Y',NULL,'N','Y',10,'N','N','2019-04-11 13:00:00','2019-10-14 07:58:52'),(103,0,'Twitter','TWITTER_URL','https://twitter.com/cloudswiftsolutions','text',100,60,'Please enter your twitter page url','form-control','N',40,NULL,'Y',NULL,'N','Y',10,'N','N','2019-04-11 13:00:00','2019-10-14 07:59:00'),(104,0,'Linkedin','LINKEDIN_URL','https://www.linkedin.com/company/cloudswiftsolutions/','text',100,60,'Please enter your Linkedin page url','form-control','N',40,NULL,'Y',NULL,'N','Y',10,'N','N','2019-04-11 13:00:00','2019-10-14 07:59:06'),(197,0,'Allow to sent email to admin for contact,feedback,etc.','ALLOW_CONTACT_EMAIL','Y','select',100,60,'Please select option','form-control','Y',5,'Y@=N','Y',NULL,'Y','N',8,'N','N','2019-04-11 13:00:00','2019-04-11 21:45:59'),(211,0,'Application Name','FRONT_APPLICATION_NAME','Cloudswift Solutions','text',100,100,'Please enter your application name for display on frontend side as name','form-control','Y',1,NULL,'Y',NULL,'Y','Y',1,'N','N','2019-04-11 18:30:00','2019-10-14 13:22:59'),(236,0,'Closed Store Status','CLOSED_STORE_STATUS','N','select',100,100,'This store is closed at present.','form-control','Y',1,'Y@=N','Y',NULL,'Y','Y',1,'N','N','2019-04-11 18:30:00','2021-08-02 10:54:46'),(237,0,'Closed Store Message','CLOSED_STORE_MESSAGE','Store is Under Construction','text',100,100,'Closed Store Message','form-control','Y',1,NULL,'Y',NULL,'Y','Y',1,'N','N','2019-04-11 18:30:00','2021-08-02 10:52:45'),(241,0,'BCC Email 1','BCC_EMAIL_1','bcc','email',100,60,'BCC Email','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2026-01-29 15:39:46'),(243,0,'SMTP HOST','SMTP_HOST','smtp.hostinger.com','text',100,60,'SMTP HOST','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2021-08-13 06:20:26'),(244,0,'SMTP PORT','SMTP_PORT','587','text',100,60,'SMTP Port','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2023-09-16 22:32:56'),(245,0,'SMTP PASSWORD','SMTP_PASSWORD','Cloud@112018','email',100,60,'SMTP PASSWORD','form-control','Y',74,NULL,'Y',NULL,'N','Y',8,'N','N','2019-04-11 18:30:00','2021-08-13 06:20:26');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config_parent`
--

DROP TABLE IF EXISTS `site_config_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config_parent` (
  `site_config_parent_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `site_config_title` varchar(191) NOT NULL,
  `display_order` int(11) NOT NULL,
  `display_status` enum('Y','N') NOT NULL,
  `class` varchar(191) NOT NULL,
  `deleted_status` enum('Y','N') NOT NULL,
  `root_user_only` enum('Y','N') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`site_config_parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config_parent`
--

LOCK TABLES `site_config_parent` WRITE;
/*!40000 ALTER TABLE `site_config_parent` DISABLE KEYS */;
INSERT INTO `site_config_parent` VALUES (1,0,'Frontend Settings',1,'Y','collapseOne','N','N',NULL,NULL),(2,0,'Backend Settings',2,'Y','collapseTwo','N','N',NULL,NULL),(3,0,'SEO Settings',3,'Y','collapseThree','N','N',NULL,NULL),(4,0,'Security Settings',4,'Y','collapseFour','N','Y',NULL,NULL),(7,0,'Site Details',7,'Y','collapseSeven','N','N',NULL,NULL),(8,0,'Email Settings',8,'Y','collapseEight','N','N',NULL,NULL),(9,0,'Privacy Settings',9,'Y','collapseNine','N','Y',NULL,NULL),(10,0,'Follow Us',10,'Y','collapseTen','N','Y',NULL,NULL);
/*!40000 ALTER TABLE `site_config_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `site_db` varchar(255) DEFAULT NULL,
  `user_firstname` varchar(255) DEFAULT NULL,
  `user_lastname` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_token` varchar(255) DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  `user_role_id` tinyint(4) NOT NULL DEFAULT 0,
  `is_developer_account` enum('Y','N') NOT NULL DEFAULT 'N',
  `allow_delete` enum('Y','N') NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `active_status` varchar(25) NOT NULL DEFAULT 'N',
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` varchar(4) NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'nodejsframework','Developer','Account','developer','developer112018@yopmail.com','$2a$10$UISTV//uhMD7OzURd9rxDOM5IrLAPAjVtb/saPfYqIjGCATQl7Tuq','',NULL,1,'Y','N',0,NULL,0,'Y','Y','N','2025-05-16 10:17:06','2026-01-30 11:01:25'),(2,1,'nodejsframework','Super','Admin','cloudswiftsolutions','cloudswiftsolutions@gmail.com','$2a$10$kJTPNZHNRH8L.YWfYLqsX.eZNpNRvzW/6ZnqD0nauEpxObP2kDw26',NULL,NULL,2,'N','N',0,NULL,0,'Y','Y','N','2025-05-16 10:17:06','2026-01-30 07:09:50'),(3,1,'nodejsframework','Admin','Admin',NULL,'admin112018@yopmail.com','$2a$10$LtWMrprwz8Y4pD9uvw/bSOC6nY8rBeViBiN31EdIFGBS9wKOp6W4K','',NULL,3,'N','Y',0,NULL,0,'Y','Y','N','2025-10-03 11:42:46','2026-01-30 07:09:50'),(4,1,'nodejsframework','Admin','User',NULL,'adminuser1@yopmail.com',NULL,NULL,NULL,3,'N','Y',3,NULL,0,'Y','Y','N','2025-10-03 12:19:39','2026-01-30 07:09:50'),(5,1,'nodejsframework','Admin','User2',NULL,'adminuser2@yopmail.com',NULL,NULL,NULL,3,'N','Y',3,'Admin Admin',3,'Y','Y','N','2025-10-03 12:21:22','2026-01-30 07:09:50'),(6,1,'nodejsframework','tempuser','tempuser',NULL,'mayankkkp@yopmail.com',NULL,NULL,'user_photo-1769689790113.png',1,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-29 17:59:29','2026-01-30 07:09:50'),(7,1,'nodejsframework','mike','mikeee',NULL,'mayankpppppp@yopmail.com','$2a$10$3k4wyyWWjn3Nzrczb.l9nuoA2Y2y5J1yGnKGG5GYQiq1ldBzg7mC.','','user_photo-1769702467644.png',3,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-29 21:30:51','2026-01-30 07:09:50'),(8,0,NULL,'fffffff','wwwwwww',NULL,'fadf@yopmail.com',NULL,NULL,'user_photo-1769762499350.png',4,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-30 14:11:23','2026-01-30 08:41:39'),(9,0,NULL,' fd fd  43 423 3 32 334 324',' fd fd  43 423 3 32 334 324',NULL,'a@a.com',NULL,NULL,NULL,1,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-30 15:02:17','2026-01-30 09:32:29'),(10,0,NULL,'mayank','patel',NULL,'mayankp@yopmail.com',NULL,NULL,NULL,1,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-30 16:51:10','2026-01-30 11:21:23'),(11,0,'nodejsframework','`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<','`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<',NULL,'`\'\"\\\\\\`~!@#$%^&*()_-+=[]{}|:;\"\'<@afs.com',NULL,NULL,NULL,1,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-30 17:06:45','2026-01-30 11:40:46'),(12,0,'nodejsframework','11223344','11223344',NULL,'sdfsf@yopmail.com',NULL,NULL,NULL,1,'N','Y',1,'Developer Account',1,'Y','Y','N','2026-01-30 17:13:58','2026-01-30 11:44:08');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-16 11:00:05
