-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emF0JJ2lqH
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AREA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'167',NULL,NULL,'5','DYANESWAR NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(2,'167',NULL,NULL,'4','CHARAI KOPAT TO VRINDAVAN (SAMT)',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(3,'167',NULL,NULL,'24','SHREE NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(4,'167',NULL,NULL,'19','RAMCHNDRA NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(5,'167',NULL,NULL,'28','WHOLESALE MARKET',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(6,'167',NULL,NULL,'26','VRINDHAVAN RABODI',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(7,'167',NULL,NULL,'7','KISHAN NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(8,'167',NULL,NULL,'21','SAVARKAR NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(9,'167',NULL,NULL,'15','LOKMANYA NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(10,'167',NULL,NULL,'13','VARTAK NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(11,'167',NULL,NULL,'14','LOIUSWADI 1',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(12,'167',NULL,NULL,'6','INDRA NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(13,'167',NULL,NULL,'9','KOPARI  STATION ROAD',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(14,'167',NULL,NULL,'18','NAUPADA PANCHPAKHADI',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(15,'167',NULL,NULL,'27','VRINDHAVAN RABODI 2',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(16,'167',NULL,NULL,'16','LOKMANYA NAGAR 1',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(17,'167',NULL,NULL,'12','LOIUSWADI',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(18,'167',NULL,NULL,'17','LOKMANYA NAGAR 2',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(19,'167',NULL,NULL,'25','VARTAK NAGAR TO LUISWADI ( SAMT)',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(20,'167',NULL,NULL,'8','KISHAN NAGAR 2',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(21,'167',NULL,NULL,'22','SAVARKAR NAGAR 2',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(22,'167',NULL,NULL,'23','SHIVAJI NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(23,'167',NULL,NULL,'20','RAMNAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(24,'167',NULL,NULL,'3','CHARAI KHOPAT',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(25,'167',NULL,NULL,'10','KOPARI HARIOM NAGAR',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(26,'167',NULL,NULL,'29','BHIWANDI',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(27,'167',NULL,NULL,'11','KOPARI HARIOM NAGAR 1',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(28,'167',NULL,NULL,'1','DEFAULT',NULL,'284','284',NULL,0,'2026-02-23 09:15:37','2026-02-23 09:15:37'),(29,'167',NULL,NULL,'5','NAVI MUMBAI',NULL,'284','284',NULL,0,'2026-02-26 05:31:37','2026-02-26 05:31:37');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text DEFAULT NULL,
  `MASTER` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint(20) DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'167','0','emF0JJ2lqH',167,'','','','2026-02-23 09:13:00','2026-02-23 09:13:00','','','','','','','','','2026-02-23 09:13:00','284','284','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (167,NULL,NULL,NULL,'Paras Enterprises.','2025-04-01','2026-03-31','GROUND FLOOR,PLOT NO 8, BUNGLOW NO 8,','NEW MHADA , PAWAR NAGAR, THANE WEST','Thane','21','9987888830','','','','','','','','','','','','','','11516014001014',NULL,'0',NULL,NULL,'27','27AIQPG5593C1Z0','','123@yopmail.com','','400610',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-02-23 09:13:00','2026-02-23 09:13:00',NULL,'','','Paras');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `CREATED_TS` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `BATCH_ID` int(11) DEFAULT 0,
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DISP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `DELETED` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int(11) DEFAULT 0,
  `TAX_ID` int(11) DEFAULT 0,
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT 'mm',
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int(11) NOT NULL DEFAULT 0,
  `GROUP_ID` int(11) NOT NULL DEFAULT 0,
  `DISPLAY_ORDER` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','mm','Y',0,1,0),(2,'Printpage_Top_Margin','10','mm','Y',0,1,0),(3,'Printpage_Left_Margin','16','mm','Y',0,1,0),(4,'Printpage_Border','0','px','Y',0,1,0),(5,'Top_Left_Width','97','mm','Y',0,2,0),(6,'Top_Center_Width','100','mm','Y',0,2,0),(7,'Padding_Top_Right','5','px','Y',0,2,0),(8,'Item_Listing_Padding_Top','0','mm','Y',0,3,0),(9,'Items_Height','45','mm','Y',0,3,0),(10,'List_1','47','mm','Y',0,3,0),(11,'List_2','20','mm','Y',0,3,0),(12,'List_3','35','mm','Y',0,3,0),(13,'List_4','94','mm','Y',0,3,0),(14,'List_5','23','mm','Y',0,3,0),(15,'List_6','5','mm','Y',0,3,0),(16,'List_7','5','mm','Y',0,3,0),(17,'List_8','25','mm','Y',0,3,0),(18,'List_9','25','mm','Y',0,3,0),(19,'List_10','15','mm','Y',0,3,0),(20,'List_11','20','mm','Y',0,3,0),(21,'List_12','25','mm','Y',0,3,0),(22,'Blank_Space_Top_Padding','2','mm','Y',0,4,0),(23,'Footer_Padding_Top','2','mm','Y',0,4,0),(24,'Footer_1','17','mm','Y',0,4,0),(25,'Footer_2','25','mm','Y',0,4,0),(26,'Footer_3','21','mm','Y',0,4,0),(27,'Footer_4','17','mm','Y',0,4,0),(28,'Footer_5','24','mm','Y',0,4,0),(29,'Footer_6','21','mm','Y',0,4,0),(30,'Footer_7','21','mm','Y',0,4,0),(31,'Footer_8','14','mm','Y',0,4,0),(32,'Footer_9','25','mm','Y',0,4,0),(33,'Footer_10','0','mm','Y',0,4,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INV_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'167',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'167',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'167',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'167',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'167',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'167',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'167',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'167',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'167',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'167',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'167',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'167',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'167',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'167',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LEDGER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `MAC_ID` int(11) DEFAULT 0,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int(11) DEFAULT 0,
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int(11) DEFAULT 0,
  `ROOT_PARENT_ID` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(14,'1',NULL,'1','UPI','UPI','bank','1','1','','','','',0,'2026-07-15 19:33:33','2026-07-15 19:33:33');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text DEFAULT NULL,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `PROD_ID` int(11) NOT NULL DEFAULT 0,
  `PACK` int(11) NOT NULL DEFAULT 0,
  `PROD_BATCH_ID` int(11) NOT NULL DEFAULT 0,
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_RET_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_TOTAL` int(11) NOT NULL DEFAULT 0,
  `SALE_QTY` int(11) DEFAULT 0,
  `SALE_RET_QTY` int(11) DEFAULT 0,
  `SALE_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `SALE_TOTAL` int(11) NOT NULL DEFAULT 0,
  `OP_STOCK` int(11) NOT NULL DEFAULT 0,
  `CLOSING_STOCK` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
INSERT INTO `OP_CL_STOCK` VALUES (1,167,9,0,9,'2025-11-22',80,0,0,0,0,0,0,0,0,0),(2,167,1,0,1,'2025-11-22',5000,0,0,0,0,0,0,0,0,0),(3,167,5,0,5,'2025-11-22',2000,0,0,0,0,0,0,0,0,0),(4,167,4,0,4,'2025-11-22',1500,0,0,0,0,0,0,0,0,0),(5,167,2,0,2,'2025-11-22',2520,0,0,0,0,0,0,0,0,0),(6,167,3,0,3,'2025-11-22',720,0,0,0,0,0,0,0,0,0),(7,167,13,0,13,'2025-11-22',16,0,0,0,0,0,0,0,0,0),(8,167,8,0,8,'2025-11-22',80,0,0,0,0,0,0,0,0,0),(9,167,12,0,12,'2025-11-22',40,0,0,0,0,0,0,0,0,0),(10,167,6,0,6,'2025-11-22',9600,0,0,0,0,0,0,0,0,0),(11,167,14,0,14,'2025-11-22',120,0,0,0,0,0,0,0,0,0),(12,167,7,0,7,'2025-11-22',120,0,0,0,0,0,0,0,0,0),(13,167,11,0,11,'2025-11-22',120,0,0,0,0,0,0,0,0,0),(14,167,10,0,10,'2025-11-22',400,0,0,0,0,0,0,0,0,0),(15,167,15,0,15,'2025-11-30',2400,0,0,0,0,0,0,0,0,0),(16,167,4,0,4,'2025-12-12',1000,0,0,0,0,0,0,0,0,0),(17,167,4,0,4,'2025-12-19',1250,0,0,0,0,0,0,0,0,0),(18,167,2,0,2,'2025-12-23',180,0,0,0,0,0,0,0,0,0),(19,167,15,0,15,'2025-12-23',600,0,0,0,0,0,0,0,0,0),(20,167,1,0,1,'2025-12-23',500,0,0,0,0,0,0,0,0,0),(21,167,5,0,5,'2025-12-23',100,0,0,0,0,0,0,0,0,0),(22,167,3,0,3,'2025-12-24',90,0,0,0,0,0,0,0,0,0),(23,167,2,0,2,'2025-12-24',1764,0,0,0,0,0,0,0,0,0),(24,167,13,0,13,'2025-12-24',40,0,0,0,0,0,0,0,0,0),(25,167,11,0,11,'2025-12-24',80,0,0,0,0,0,0,0,0,0),(26,167,15,0,15,'2025-12-24',1500,0,0,0,0,0,0,0,0,0),(27,167,17,0,17,'2025-12-24',48,0,0,0,0,0,0,0,0,0),(28,167,3,0,3,'2025-12-31',180,0,0,0,0,0,0,0,0,0),(29,167,2,0,2,'2025-12-31',360,0,0,0,0,0,0,0,0,0),(30,167,4,0,4,'2025-12-31',150,0,0,0,0,0,0,0,0,0),(31,167,5,0,5,'2025-12-31',320,0,0,0,0,0,0,0,0,0),(32,167,8,0,8,'2025-12-31',40,0,0,0,0,0,0,0,0,0),(33,167,7,0,7,'2025-12-31',40,0,0,0,0,0,0,0,0,0),(34,167,1,0,26,'2026-01-10',1000,0,0,0,0,0,0,0,0,0),(35,167,15,0,15,'2026-01-10',1500,0,0,0,0,0,0,0,0,0),(36,167,5,0,5,'2026-01-10',600,0,0,0,0,0,0,0,0,0),(37,167,16,0,16,'2025-12-12',40,0,0,0,0,0,0,0,0,0),(38,167,13,0,13,'2025-12-26',8,0,0,0,0,0,0,0,0,0),(39,167,4,0,4,'2026-02-26',50,0,0,0,0,0,0,0,0,0),(40,167,1,0,1,'2026-02-27',0,0,0,0,5520,0,0,5520,0,-5520),(41,167,2,0,2,'2026-02-27',2000,0,0,0,0,0,0,0,0,0),(42,167,3,0,3,'2026-02-27',0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `MINIMUM_STOCK_LEVEL` int(11) NOT NULL DEFAULT 0,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'167',NULL,NULL,'01',NULL,'','GOW GHEE 100 ML JAR','GOW GHEE 100 ML JAR','04059020','100','5',NULL,'1','GOW GHEE','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(2,'167',NULL,NULL,'03',NULL,'','GOW GHEE 500ML JAR','GOW GHEE 500ML JAR','04059020','500','5',NULL,'1','GOW GHEE','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(3,'167',NULL,NULL,'04',NULL,'','GOW GHEE 1 LTR JAR','GOW GHEE 1 LTR JAR','04059020','1','6',NULL,'1','GOW GHEE','7','7','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(4,'167',NULL,NULL,'06',NULL,'','GOW GHEE 1LTR PP','GOW GHEE 1LTR PP','04059020','1','6',NULL,'1','GOW GHEE','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(5,'167',NULL,NULL,'05',NULL,'','GOW GHEE 500ML PP','GOW GHEE 500ML PP','04059020','500','5',NULL,'1','GOW GHEE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(6,'167',NULL,NULL,'07',NULL,'','GOW GHEE 20 ML','GOW GHEE 20 ML','04059020','20','5',NULL,'1','GOW GHEE','7','7','384',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','384','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(7,'167',NULL,NULL,'11',NULL,'','AVVATAR W.B CHOCLATE','AVVATAR W.B CHOCLATE','19053211','40','2',NULL,'2','AVVATAR','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','AVVATAR',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(8,'167',NULL,NULL,'12',NULL,'','AVVATAR W.B COFFEE','AVVATAR W.B COFFEE','19053211','40','2',NULL,'2','AVVATAR','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','AVVATAR',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(9,'167',NULL,NULL,'13','','','AVVATAR W.B CHEESE','AVVATAR W.B CHEESE','19053211','40','2','0','2','AVVATAR','7','7','8',NULL,NULL,'2','2','0','',NULL,'','','',NULL,NULL,NULL,'7','0','0','0','8','0','0','0','',0.00,0.00,0.00,0.00,0,NULL,NULL,'','Goods','NO',NULL,'284','284',NULL,0,'2026-02-23 10:01:38','2026-02-23 10:01:38'),(10,'167',NULL,NULL,'21',NULL,'','GOW GULAB JAMUNM 200 GM','GOW GULAB JAMUNM 200 GM','21069099','200','2',NULL,'3','GULAB JAMUNM','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','GULAB JAMUNM',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(11,'167',NULL,NULL,'31',NULL,'','GOW PEANUT CHIKKI 25GM','GOW PEANUT CHIKKI 25GM','210690','25','2',NULL,'4','CHIKKI','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','CHIKKI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(12,'167',NULL,NULL,'32',NULL,'','GOW SESAME CHIKKI 25GM','GOW SESAME CHIKKI 25GM','210690','25','2',NULL,'4','CHIKKI','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','CHIKKI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(13,'167',NULL,NULL,'33',NULL,'','GOW DRY FRUIT CHIKKI 25 GM','GOW DRY FRUIT CHIKKI 25 GM','210690','25','2',NULL,'4','CHIKKI','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','CHIKKI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(14,'167',NULL,NULL,'08',NULL,'','GOW GHEE 2 LTR CONT','GOW GHEE 2 LTR CONT','04059020','2','6',NULL,'1','GOW GHEE','7','7','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(15,'167',NULL,NULL,'02',NULL,'','GOW PREM GHEE 200ML JAR','GOW PREM GHEE 200ML JAR','04059020','200','5',NULL,'1','GOW GHEE','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GOW GHEE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(16,'167',NULL,NULL,'14',NULL,'','AVVATAR WB TIRAMISU','AVVATAR WB TIRAMISU','19053211','0.042','3',NULL,'2','AVVATAR','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','AVVATAR',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(17,'167',NULL,NULL,'41',NULL,'','CHEESE SLICE 200GM','CHEESE SLICE 200GM','04062000','0.2','3',NULL,'5','CHEESE','7','7','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(18,'167',NULL,NULL,'42',NULL,'','GO CHEESE HIGH MELT 200 GM','GO CHEESE HIGH MELT 200 GM','04062000','0.2','3',NULL,'5','CHEESE','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(19,'167',NULL,NULL,'43',NULL,'','GO PROCESS CHEESE 400 GM','GO PROCESS CHEESE 400 GM','04062000','0.4','3',NULL,'5','CHEESE','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(20,'167',NULL,NULL,'44',NULL,'','GO PIZZA CHEESE BLOCK 200 GM','GO PIZZA CHEESE BLOCK 200 GM','04062000','0.2','3',NULL,'5','CHEESE','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(21,'167',NULL,NULL,'45',NULL,'','CHEESE SLICE 408 GM','CHEESE SLICE 408 GM','04062000','0.408','3',NULL,'5','CHEESE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(22,'167',NULL,NULL,'46',NULL,'','GO CHEESE SLICE 750+50GM','GO CHEESE SLICE 750+50GM','04062000','0.8','3',NULL,'5','CHEESE','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(23,'167',NULL,NULL,'47',NULL,'','FOUR CHEESE 200 GM','FOUR CHEESE 200 GM','04062000','0.2','3',NULL,'5','CHEESE','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(24,'167',NULL,NULL,'48',NULL,'','GO MOZZ PIZZA BLEND 200 GM','GO MOZZ PIZZA BLEND 200 GM','04062000','0.2','3',NULL,'5','CHEESE','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','CHEESE',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'167',NULL,NULL,'GOW GHEE','1',NULL,NULL,NULL,NULL,'284','284',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(2,'167',NULL,NULL,'AVVATAR','1',NULL,NULL,NULL,NULL,'284','284',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(3,'167',NULL,NULL,'GULAB JAMUNM','1',NULL,NULL,NULL,NULL,'284','284',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(4,'167',NULL,NULL,'CHIKKI','1',NULL,NULL,NULL,NULL,'284','284',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(5,'167',NULL,NULL,'CHEESE','1',NULL,NULL,NULL,NULL,'284','284',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `MINIMUM_STOCK_LEVEL` int(11) NOT NULL DEFAULT 0,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'167',NULL,NULL,'1','251122184239','','0100-01-01','01','0','0','1981','100','88.18','88.18','84.62','84.6200','3.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(2,'167',NULL,NULL,'2','251122184453','','2036-01-01','03','0','0','9824','415','365.96','0','351.21','351.2100','14.75','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(3,'167',NULL,NULL,'3','251122184712','','Invalid date','04','0','0','990','799','704.59','0','676.19','676.1900','28.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(4,'167',NULL,NULL,'4','251122184956','','2001-10-01','06','0','0','3950','780','687.83','0','660.11','660.1100','27.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(5,'167',NULL,NULL,'5','251122185425','','Invalid date','05','0','0','3020','405','357.14','0','342.74','342.7400','14.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(6,'167',NULL,NULL,'6','251122185645','','0384-01-01','07','0','0','9600','20','17.63668','0','16.92375','16.92','0.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(7,'167',NULL,NULL,'7','251122190025','','2001-08-01','11','0','0','160','80','554.11','0','531.79','531.7900','22.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(8,'167',NULL,NULL,'8','251122190213','','2001-08-01','12','0','0','120','80','554.11','0','531.79','531.7900','22.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(9,'167',NULL,NULL,'9','251122190334','','2001-08-01','13','0','0','0','80','554.11','0','531.79','531.7900','22.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(10,'167',NULL,NULL,'10','251122190556','','2040-01-01','21','0','0','400','155','131.8','0','123.18','123.1800','8.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(11,'167',NULL,NULL,'11','251122190801','','2001-08-01','31','0','0','200','200','142.86','0','137.1','137.1000','5.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(12,'167',NULL,NULL,'12','251122190943','','2001-08-01','32','0','0','40','200','142.86','0','137.1','137.1000','5.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(13,'167',NULL,NULL,'13','251122191227','','2001-08-01','33','0','0','48','500','357.14','0','342.7500','342.7500','14.39','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(14,'167',NULL,NULL,'14','251122192528','','2001-06-01','08','0','0','120','1575','1388.89','0','1332.95','1332.9500','55.94','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(15,'167',NULL,NULL,'15','251204143553','','1960-01-01','02','0','0','6000','199','175.485','0','168.4153','168.4153','7.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(16,'167',NULL,NULL,'16','251212162213','','2001-08-01','14','0','0','40','80','554.1125','0','531.7875','531.7875','22.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(17,'167',NULL,NULL,'17','251226175507','','2048-01-01','41','0','0','48','190','164.502','0','157.869','157.8690','6.63','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(18,'167',NULL,NULL,'18','260108165107','','2040-01-01','42','0','0','280','185','160.1731','0','153.7035','153.7035','6.47','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(19,'167',NULL,NULL,'19','260108165425','','Invalid date','43','0','0','120','280','242.4242','0','232.6325','232.6325','9.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(20,'167',NULL,NULL,'20','260108165742','','2040-01-01','44','0','0','280','200','173.1601','0','166.166','166.1660','6.99','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(21,'167',NULL,NULL,'21','260108170207','','Invalid date','45','0','0','500','305','264.069','0','253.4035','253.4035','10.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(22,'167',NULL,NULL,'22','260108170449','','2001-12-01','46','0','0','12','510','441.558','0','423.723','423.7230','17.83','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(23,'167',NULL,NULL,'23','260108170915','','Invalid date','47','0','0','60','160','138.5281','0','132.9346','132.9346','5.59','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(24,'167',NULL,NULL,'24','260108171212','','Invalid date','48','0','0','120','155','134.1991','0','128.776','128.7760','5.42','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(25,'167',NULL,NULL,'17','1767873101828','','2048-01-01','41','0','0','960','210','181.8181','0','174.4872','174.4872','7.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL),(26,'167',NULL,NULL,'1','1768044956444','','0100-01-01','01','0','0','1000','105','92.5925','0','88.8511','88.8511','3.74','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-02-23 09:15:59',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int(11) DEFAULT 0,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int(11) DEFAULT 0,
  `M_ROUND_OFF` int(11) DEFAULT 0,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
INSERT INTO `PURCHASE` VALUES (1,'167',NULL,NULL,'2026-02-27',415,'123',NULL,'702420.00','0','0','0.00','0.00','0','2','14048.40','34418.58','17209.29','17209.29','0.00','0','0','0.18','722790.00','722790.18','2000/0','1000000.00','688371.60','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'0.00','0','0',0,'0',0,NULL,NULL,0,0,'0','0','0',0,NULL,'0','0',NULL,0,'2026-02-27 18:02:58','2026-02-27 18:03:23');
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
INSERT INTO `PURCHASE_ITEM` VALUES (1,'167',NULL,NULL,1,1,1,7,'84.6200','5.00','2.5','2.5','0','0','0',1,NULL,'10.00','01000','2','1692.4',NULL,0,'0','0','0','0','84620.0000','4146.38','2073.19','2073.19','',NULL,NULL,'','',NULL,'100','7','7','0','0','0','100',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,0,'284','284',NULL,1,'2026-02-27 18:02:58','2026-02-27 18:02:58'),(2,'167',NULL,NULL,2,2,1,7,'351.2100','5.00','2.5','2.5','0','0','0',1,NULL,'55.56','02000','2','14048.4',NULL,0,'0','0','0','0','702420.0000','34418.58','17209.29','17209.29','',NULL,NULL,'','',NULL,'500','7','7','0','0','0','415',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,0,'284','284',NULL,1,'2026-02-27 18:02:58','2026-02-27 18:02:58'),(4,'167',NULL,NULL,2,2,1,7,'351.2100','5.00','2.5','2.5','0','0','0',1,NULL,'55.56','02000','2','14048.4',NULL,0,'0','0','0','0','702420.0000','34418.58','17209.29','17209.29','',NULL,NULL,'','0',NULL,'500','7','7','0','0','0','415',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,0,'284','284',NULL,0,'2026-02-27 18:03:23','2026-02-27 18:03:23');
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL,
  `LITE_ID` varchar(50) DEFAULT '',
  `WEB_ID` varchar(50) DEFAULT '',
  `PROD_ID` int(11) NOT NULL,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` varchar(50) DEFAULT NULL,
  `PUR_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT` varchar(25) DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) DEFAULT '0',
  `PUR_CESS` varchar(25) DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) DEFAULT '0',
  `PACK` varchar(25) DEFAULT '0',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(25) DEFAULT '0',
  `DISC_PERCENT` varchar(25) DEFAULT '0',
  `DISC_AMOUNT` varchar(25) DEFAULT '0',
  `RETURN_QTY` varchar(25) DEFAULT '0',
  `FREE` varchar(25) DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) DEFAULT '0',
  `AMT` varchar(25) DEFAULT '0',
  `TAX_AMT` varchar(25) DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) DEFAULT '0',
  `RETURN` varchar(25) DEFAULT '0',
  `SR_NO` varchar(50) DEFAULT '',
  `CESS_AMT` varchar(25) DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) DEFAULT '0',
  `UI_DISP_BAG` varchar(50) DEFAULT '',
  `WEIGHT` varchar(25) DEFAULT '0',
  `PRICE_PER` varchar(25) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT NULL,
  `TE_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) DEFAULT '0',
  `MRP` varchar(25) DEFAULT '0',
  `DAMAGE` varchar(25) DEFAULT '0',
  `DAMAGE_AMT` varchar(25) DEFAULT '0',
  `REPLACE` varchar(25) DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) DEFAULT '0',
  `DMG_MRP` varchar(25) DEFAULT '0',
  `PUR_INSURANCE` varchar(25) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) DEFAULT '0',
  `CLOUD_SYNC` varchar(25) DEFAULT '0',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT current_timestamp(),
  `UPDATED_TS` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `FINAL_AMT` varchar(25) DEFAULT '0',
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `TCS_TAX` varchar(100) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `BROKER_ID` int(11) DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
INSERT INTO `PURCHASE_ORDER` VALUES (1,'167',NULL,NULL,'2026-02-27',801,'PO000001','PO','000001','',0,'8','3','31185.80','0','0','0.00','0.00','0','0','0','1559.28','779.64','779.64','0.00','0','0','-0.08','0','0','32745.00','32745.08','3/40','16030.00','31185.80','',3,1,NULL,NULL,0,'0.00','0',0,'0',0,'0',0,0,0,NULL,'284','284',NULL,0,'2026-02-27 18:15:40','2026-02-27 18:15:40');
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
INSERT INTO `PURCHASE_ORDER_ITEM` VALUES (1,'167',NULL,NULL,4,4,1,7,'660.1100','5.00','2.5','2.5','0','0','0',1,NULL,'3.00','030','0','0',NULL,0,'0','0','0','0','19803.30','990.16','495.08','495.08','',NULL,NULL,'','',NULL,'1','7','7','0','0','0','780',0,NULL,'284','284','0',0,'2026-02-27 18:15:40','2026-02-27 18:15:40'),(2,'167',NULL,NULL,2,2,1,7,'351.2100','5.00','2.5','2.5','0','0','0',1,NULL,'0.83','030','0','0',NULL,0,'0','0','0','0','10536.30','526.81','263.405','263.405','',NULL,NULL,'','',NULL,'500','7','7','0','0','0','415',0,NULL,'284','284','0',0,'2026-02-27 18:15:40','2026-02-27 18:15:40'),(3,'167',NULL,NULL,1,1,1,7,'84.6200','5.00','2.5','2.5','0','0','0',1,NULL,'0.10','010','0','0',NULL,0,'0','0','0','0','846.20','42.31','21.155','21.155','',NULL,NULL,'','',NULL,'100','7','7','0','0','0','100',0,NULL,'284','284','0',0,'2026-02-27 18:15:40','2026-02-27 18:15:40');
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
INSERT INTO `PUR_SALE_RET_MAPPING` VALUES (1,'167',NULL,NULL,'17','9','P','2879',NULL,'284','284','PurchaseReturn',0,'2026-02-23 10:34:51','2026-02-23 10:34:51');
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `IS_SUPERSTOCKIST` tinyint(4) NOT NULL DEFAULT 0,
  `SUPERSTOCKIST_ID` int(11) NOT NULL DEFAULT 0,
  `EXTRA_1` varchar(255) DEFAULT NULL,
  `EXTRA_2` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REMARKS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT 0,
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-02-23 09:13:00',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text DEFAULT NULL,
  `MAC_ID` int(11) DEFAULT 0,
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text DEFAULT NULL,
  `S_ADD2` text DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `DISCOUNT2` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1088 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'167',NULL,NULL,'YOGSHWAR DHANYA BHANDAR',5,'0','DR','SHOP NO 1ROAD NO 27 CHADWA SADAN NEAT VIRA GENERAL STORES  SHANTI NAGER THANE','DEFAULT','THANE','21','400606',NULL,'9987408041.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:45','2026-02-23 09:15:45'),(2,'167',NULL,NULL,'YOGITA GENERAL STORE',5,'0','DR','SHOP NO7SANTOSHI BHAVAN GANESH CHAWK BHATWADI ROAD KISHAN NAGER NO 3 THANE W','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:45','2026-02-23 09:15:45'),(3,'167',NULL,NULL,'YOGESH MEDICAL & GENERAL STORE',5,'0','DR','PARTY NAME - YOGEGALA NO.1 GROUND FLOOR, LAXMI CHHAYA NIWAS, LOKMANYA NAGAR PADA NO.04, NEAR HANUMAN SUPER MARKET \\r\\nADDRESS. - GALA NO.1 GR. FLOOR, LAXMI CHHAYA NIWAS, LOKMANYA NAGAR PADA NO.4\\r\\nCONTACT NO - 9896413764 \\r\\nGST-\\r\\nFSAI- 21517069000406\\r\\nLOCTION -\\r\\nORDER- PROTEIN WAFER BAR CHOCOLATE FLAVOUR 1OUTER RS.40/PC','DEFAULT','THANE','21','400606',NULL,'9896413764.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:45','2026-02-23 09:15:45'),(4,'167',NULL,NULL,'YOGESH GENERAL STORE',5,'0','DR','SHOP NO 10,RUPADEVI PADA NO 1,OPP MAHAVEER MEDICAL, RD NO 33,INDIRA NAGAR, WAGALE ESTATE,THANE WEST','DEFAULT','THANE','21','400602',NULL,'8652577348.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:45','2026-02-23 09:15:45'),(5,'167',NULL,NULL,'YASH GENERAL STORE',5,'0','DR','SHOP NO 4 PREM SAGAR HOUSE OPP BHAIRAV CHEMIST K B PATIL MARG OPP MANIBHADRA DRY FRUITS THANE WEST','DEFAULT','THANE','21','400606',NULL,'9004580063.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:45','2026-02-23 09:15:45'),(6,'167',NULL,NULL,'YASH GENERAL STORE',5,'0','DR','SHOP NO 1.KISAN NAGAR NO 2.ROAD NO 16.NEAR DURGA PUNJAB HOTEL .THANE.WEST','DEFAULT','THANE','21','400604',NULL,'9594953019','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(7,'167',NULL,NULL,'YADAV DAIRY FARM',5,'0','DR','HAJURI','DEFAULT','THANE','21','400604',NULL,'8828055668.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(8,'167',NULL,NULL,'WHOLE SALE BAZAR',5,'0','DR','ROAD NO 28','NR HARE KRISHNA MEDICAL','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(9,'167',NULL,NULL,'WELLCARE MEDICAL',5,'0','DR','SATYAM GENERAL STORE NEAR AMBEWADI ROAD NO 22 WAGLE STATE','DEFAULT','THANE','21','400604',NULL,'8668558660.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(10,'167',NULL,NULL,'WELL COME STORE',5,'0','DR','SHOP NO.1 A-WING SYLVESTER HOUSE D SOUZA WADI,SHIVAJI NAGAR WAGLE ESTATE\\r\\nTHANE WEST','DEFAULT','THANE','21','400604',NULL,'9969840803.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(11,'167',NULL,NULL,'WELCOME TEBOCO',5,'0','DR','SIDHARTH CHAWAL NO 2 SHOP NO 1 DR GANGADHAR NAGAR ROAD NEAR KAMGAR HOSPITAL OPP SIDDHIVINAYAK DHANYA BHANDAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9987335378.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(12,'167',NULL,NULL,'WELCOME GENRAL',5,'0','DR','RABIDI','DEFAULT','THANE','21','400602',NULL,'8454992880.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(13,'167',NULL,NULL,'WELCOME GENERAL STORE',5,'0','DR','SHOP BESIDES SHIV SAKA SAWANT CHAWL OPP OPPO MOBILE STORE LOKMANYA NAGAR NEAR ASHAPURA DRY FRUITS THANE WEST','DEFAULT','THANE','21','400604',NULL,'9869633981.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(14,'167',NULL,NULL,'WALRAM TRADING',5,'0','DR','SHOP NO 4 SHIVSHAKTI APARTMENT OPP.SHIVLEELA MEDICAL AND GENERAL STORES OPP. POOJA SNACKS CORNER VEER SAVARKAR NAGAR THANE WEST THANE 400606','DEFAULT','THANE','21','400602',NULL,'8928855860.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(15,'167',NULL,NULL,'VYAS BROTHERS',5,'0','DR','SHOP NO . 1 OPP. SUNITA DRY FRUITS AND GENERAL STORS MANJULANIWAS KISAN NAGAR NO. 3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'9769561639.0','',NULL,'27','27AUYPV5248B1ZZ','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,'11519000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:46','2026-02-23 09:15:46'),(16,'167',NULL,NULL,'VYAS',5,'0','DR','SHREE NAGAR','DEFAULT','THANE','21','400604',NULL,'8369766838.0','',NULL,'27','27ADSPV4080E1Z2','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(17,'167',NULL,NULL,'VVYGRESHWAR KRUPA DRYFRUIT AND GENERAL STORES',5,'0','DR','SHOP NO 3 SHIVANAND SOC M S ROAD NEAR HIGHWAY DARSHAN BEHIND SWATIK POLI BHAJI TEEN HATH NAKA THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(18,'167',NULL,NULL,'VRAJLAL JADHAVJI',5,'0','DR','SHOP NO 2,OPP POLICE CHOWKI, POOJA MARKET GALLI, WHOLSALE MARKET,MOHD ALI RD, THANE WEST','DEFAULT','THANE','21','400601',NULL,'9930921327.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(19,'167',NULL,NULL,'VIVEK OIL GENERAL STORE',5,'0','DR','SHOP NO 8,OPP GIRI DARSHAN CHAWL, LOKMANYA NAGAR PADA NO 3, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(20,'167',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','SHOP NO 1&2 ,KINJAL APT,2ND RABODI ,THANE WEST','DEFAULT','THANE','21','400601',NULL,'8828474628.0','',NULL,'27','27BWJPC8322F1ZN','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(21,'167',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','SHOP NO 08 BLD NO 10 DEVDAYA NAGAR POKHARAN ROAD NO 01 OPP SHREE EYE CLINIC THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(22,'167',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','SHOP NO 1, DESHMUKH CHAWL, NEAR LAKDI POOL, LOKMANYA NAGAR PADA NO 3, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(23,'167',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','DEVDAYA NAGAR POKHARAN ROAD  NEAR DEEPAK D/F','DEFAULT','THANE','21','400606',NULL,'9987085148.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(24,'167',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','SHOP NO 2 GAUTAM ARCADE CHENDANI KOLIWADA OPP SHUBHDAM CHINESE CORNER KOPARI ROAD THANE MUMBAI 400603','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','27ACCPS2123G1ZV','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(25,'167',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','KOAPRI','DEFAULT','THANE','21','400603',NULL,'8097005856.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:47','2026-02-23 09:15:47'),(26,'167',NULL,NULL,'VISHAL GENERAL STORES',5,'0','DR','ROAD NO 33 NEAR SAGAR SUPER MARKET WIREMEN WADI DNYANESHWAR NAGAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(27,'167',NULL,NULL,'VISHAL GENERAL STORE',5,'0','DR','SHIVAJI NAGAR NEAR MARUTI GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9167043006.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(28,'167',NULL,NULL,'VISHAL DHANYA BHANDAR SUPER MARKET',5,'0','DR','SHOP NO 06 SHASTRI NAGAR BUS STOP OPP CAKE POINT OPP MAYUR GOLD VARTAK NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27AAFPG7990N1ZO','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,'115160000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(29,'167',NULL,NULL,'VIRA GENERAL  STORE',5,'0','DR','SHANTI NAGER ROAD NO 27  OPP MUNCHIPAL SCHOOL  NEXT TO JAY AMBEY MEDICAL NEAR SHREE MAHALAXMI SWEET THANE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27AATPV4527E1Z7','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(30,'167',NULL,NULL,'VIPUL DRY FRUITS',5,'0','DR','SHOP NO 1 VAIDYA BUILDING OPPOSITE ST. JONSAN ENGLISH SCHOOL','NEAR TJSB BANK OLD BOMBAY ROAD THANE WEST','THANE','21','400601',NULL,'9920708518','',NULL,'27','27BUXPS0329A1ZG','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(31,'167',NULL,NULL,'VINOD PROVISION STORE',5,'0','DR','SHOP NO 1.KISAN NAGAR NO 2.ROAD NO 16.WAGLE ESTATE.NEAR SAI KRUPA GENERAL STORE.NEAR PARAS STORE.THANE.WEST.','DEFAULT','THANE','21','400604',NULL,'9004380475.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(32,'167',NULL,NULL,'VINAYAK TRADERS',5,'0','DR','KAILASH NAGAR NEAR SHIV SHENA SHAKHA','DEFAULT','THANE','21','400604',NULL,'6377693344.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(33,'167',NULL,NULL,'VINAYAK KIRANA STORE',5,'0','DR','LOKMANYA NAGAR NEAR VIKASH STORE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(34,'167',NULL,NULL,'VINAYAK DARIY',5,'0','DR','RAMCHANDRA NAGAR NEAR NEW SAGAR SWEETS','DEFAULT','THANE','21','400604',NULL,'9987513426.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(35,'167',NULL,NULL,'VINAY OIL DEPO AND GENERAL STORES',5,'0','DR','ROAD NO 33 AMBE WADI WAGLE EASTATE OPP JAI BHAWANI MEDICAL AND GENERAL STORES NEAR SANTOSH GENERAL S','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:48','2026-02-23 09:15:48'),(36,'167',NULL,NULL,'VINAY',5,'0','DR','THANE','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','26',NULL,NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(37,'167',NULL,NULL,'VIKRAM TRADERS',5,'0','DR','SHOP NO 1 SEEMA SOCIETY KOPARI COLONY.NEAR MIRANI NAGAR.NEAR APOLLO PHARMACY THANE EAST.','DEFAULT','THANE','21','400603',NULL,'9987064667.0','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(38,'167',NULL,NULL,'VIKRAM GENERAL STORE',5,'0','DR','SHOP NO-1,BALAJI APT,MAHTMA PHULE NAGAR,NEAR AAI MATA MANDIR,THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(39,'167',NULL,NULL,'VIKASH GENERAL STORE',5,'0','DR','SHOP NO 3, SWANT CHAWL, LOKMANYA NAGAR, PADA NO 4, NEAR GANPATI MADIR, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(40,'167',NULL,NULL,'VIKAS GENERAL STORE',5,'0','DR','CHAITY NAAGAR  LOKMANYA NAGAR PADA NO 3 NAER LAXMI MEDICAL NAER JAY BALAJI SUPER MARKET THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(41,'167',NULL,NULL,'VIJAYLAKSHMI GENERAL STORE',5,'0','DR','KALYANI NIVAS OPP SHREE GANESH MEDICAL AND GENERAL STORES NEXT TO JAY AMBE KIRANA STORES K.L COLONY GANDHI NAGAR KOPARI THANE EAST','DEFAULT','THANE','21','400603',NULL,'9594554030.0','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(42,'167',NULL,NULL,'VIJAY STORE',5,'0','DR','SHOP NO 01 MOHAMMED ALI ROAD NEAR JB KARIA NEAR VARDHAMAN STORE SATION ROAD KHARTAN THANE WEST','DEFAULT','THANE','21','400601',NULL,'7738767041.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(43,'167',NULL,NULL,'VIJAY STORE',5,'0','DR','ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'9930509977.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(44,'167',NULL,NULL,'VIJAY PROVISION AND GENERAL STORES',5,'0','DR','SHOP NO-1 CHAWAL NO-21 NEAR KHERDEKAR CLINIC  NEAR KAMGAR HOSPITAL OPP RAMESHWAR GENERAL STORES DYANESHWAR NAGAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9324315028.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(45,'167',NULL,NULL,'VIJAY MEDICAL & GENERAL STORE',5,'0','DR','SHOP NO 2 NEAR SHIVSENA SHAKHA RAGHUNATH NAGAR WAGLE WEST','DEFAULT','THANE','21','400604',NULL,'9821826269.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:49','2026-02-23 09:15:49'),(46,'167',NULL,NULL,'VIJAY KIRANA STORES',5,'0','DR','NAAMDEVVADI ALMEDA ROAD NEAR NITIN COMPANY  NEAR NEW JANTA SUPER MARKET NEAR JAI MATAJI DRYFRUIT AND','DEFAULT','THANE','21','400602',NULL,'9892182134.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(47,'167',NULL,NULL,'VIGNAHARTA FRESH SUPER MARKET',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'9702803613.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(48,'167',NULL,NULL,'VIGHANHAR KIRANA',5,'0','DR','PADA NO.3-4','DEFAULT','THANE','21','400606',NULL,'9326727864.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(49,'167',NULL,NULL,'VARSHA MASALA WALA',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400604',NULL,'9323529785.0','',NULL,'27','','','TJSB SHAKARI BANK LTD',NULL,NULL,'SHREE NAGAR','7',NULL,NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(50,'167',NULL,NULL,'VARSHA AGARBATHI BHANDAR',5,'0','DR','SHOP NO 2 ATHARV APT BEHIND ASHOK CINEMA NEAR DATT MANDIR THANE WEST','DEFAULT','THANE','21','400601',NULL,'9920953311.0','',NULL,'27','27AAUPG8500H1ZI','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(51,'167',NULL,NULL,'VARIETY GENERAL STORES',5,'0','DR','RABODI NO 02 DOCTOR ANSARI ROAD OPP NEW JALARAM DHAN BHANDAR THANA WEST','DEFAULT','THANE','21','400607',NULL,'','',NULL,'27','27ACUPP8743M1ZH','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(52,'167',NULL,NULL,'VARDHAMAN STORE',5,'0','DR','MOHAMMAD ALI ROAD  MAHATMA FULE MARKET NEAR VIJAY STORES WHOLSALE MARKET THANE E','DEFAULT','THANE','21','400601',NULL,'9820894449.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,'11517000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(53,'167',NULL,NULL,'VANDANA GENERAL STORE',5,'0','DR','CHEDNI KOLIWAD NEAR JALARAM TRADERS KOPRI','DEFAULT','THANE','21','400603',NULL,'9930750368.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(54,'167',NULL,NULL,'VAISHANVI GENRAL STORE',5,'0','DR','ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'7977287744.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:50','2026-02-23 09:15:50'),(55,'167',NULL,NULL,'VAISHALI TREDING COMPANY',5,'0','DR','SWA.DATTATRAY KHADE CHUK','DEFAULT','THANE','21','400606',NULL,'8591509995.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(56,'167',NULL,NULL,'VAIRETY STORE',5,'0','DR','RABODU','DEFAULT','THANE','21','400602',NULL,'9321432473.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'56',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(57,'167',NULL,NULL,'VAIBHAV TRADERS',5,'0','DR','SHOP NO 01 MAHATMA PHULE ROAD WHOLESALE MARKET OPP SAWALA TRADERS NEAR R.B.TEA COMPANY THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27AHPPM8188F1ZN','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(58,'167',NULL,NULL,'VAIBHAV KIRANA STORE',5,'0','DR','PARALA NAGAR NEXT TO KISAN KIRANA STORE LOKMANYA NAGAR PADA NO 3 AMBEDKAR CHOWK THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(59,'167',NULL,NULL,'VAGHESHWAR KRUPA DRY FRUIT AND GENERAL STORES A',5,'0','DR','HARE KRISHNA CO OP SOCIETY SHOP NO 6 M S ROAD WAGHLE RAGHUNATH NAGAR THANE W','DEFAULT','THANE','21','400606',NULL,'7039882464.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'59',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(60,'167',NULL,NULL,'V. D. MART',5,'0','DR','LUIESWADI','DEFAULT','THANE','21','400604',NULL,'9930483756.0','',NULL,'27','27BOLPD1161D1ZD','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'60',NULL,NULL,NULL,NULL,NULL,'11523000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(61,'167',NULL,NULL,'V K TEADING',5,'0','DR','SHOP NO 2 NEAR MARUTI SUPER MARKET OPP HINDUSTAN BANK YASODHAN NAGAR PADA NO 2 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27BCOPG8719B1ZI','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'61',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(62,'167',NULL,NULL,'UTTAM COLD DRINK',5,'0','DR','BHATWADI','','','21','',NULL,'1234567890','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'SHREE NAGAR','7',NULL,NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(63,'167',NULL,NULL,'UTKARSH GENERAL STORE',5,'0','DR','SHOP NO D 3 TALPTARU SOCIETY NEXT TO SHREE VISHWAVRUNDA AYURVEDIC CLINIC OPP GAJANAN MEDICAL NEAR SAVARKAR BUS STOP SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(64,'167',NULL,NULL,'USHA GENERAL STORES',5,'0','DR','SIVAI NAGAR POKHARAN ROAD 1 OPP JIJA MATA BLDG NEAR MATOSHRI DAIRY THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:51','2026-02-23 09:15:51'),(65,'167',NULL,NULL,'UPKAR DAIRY AND SWEET',5,'0','DR','SATHE NAGAR  ROAD NO 22 NEAR SATYAM GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9594848949.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(66,'167',NULL,NULL,'UDAY FOOD PRODUCT',5,'0','DR','ROAD NO 22 NEAR JAMA MASJID NEST TO NEW KOMAL GENERAL STORE SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','27AAHPT4430G1ZN','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(67,'167',NULL,NULL,'UDAY FOOD LTD',5,'0','DR','SAWARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'8268120241.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(68,'167',NULL,NULL,'TUSHAR STORES SUPER MARKET',5,'0','DR','SHOP NO 11 12 POKHRAN ROAD NI 01 SAI BABA MANDIR NEAR RBL BANK  ROAD VARTAK NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27AABPG3674P1ZB','','ICICI',NULL,NULL,'1','19',NULL,NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(69,'167',NULL,NULL,'TRIBHUVAN SUPER MARKET',5,'0','DR','SHOP NO.7.8.9.FGP COMPLEX KASHISH PARK L.B.S.MARG NEAR TIP TOP HOTEL THANE WEST','DEFAULT','THANE','21','400604',NULL,'8080501890','',NULL,'27','27ADNPC2236N1ZD','','TJSB SAHAKARI BANK LTD',NULL,NULL,'WAGLE ESTATE','17',NULL,NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(70,'167',NULL,NULL,'TIP TOP SUPER MARKET',5,'0','DR','KOLBAD','DEFAULT','THANE','21','400602',NULL,'8655296196.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,'21512400000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(71,'167',NULL,NULL,'THANERI SHOP',5,'0','DR','CHARAI','DEFAULT','THANE','21','400606',NULL,'9892281136.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(72,'167',NULL,NULL,'THANA TRADERS',5,'0','DR','SHOP NO 2, BOHARI BLDG, DEVIDAS RD, OPP VISHAL TRADERS AND DARSHAN TRADERS WHOLSALE MARKET, THANE WEST','DEFAULT','THANE','21','400601',NULL,'9702481111.0','',NULL,'27','27ACSPV1884H1ZS','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(73,'167',NULL,NULL,'THAKKAR PURSHOTTAM LALJI',5,'0','DR','SHOP NO 210 CHENDANI NAKA NEAR ASHOK TALKIES NEAR THANE WEST BUS DEPO STATION ROAD THANE WEST','DEFAULT','THANE','21','400601',NULL,'7715988685.0','',NULL,'27','27AGFPG2682M1Z3','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(74,'167',NULL,NULL,'TELAGANA PAN BIDI SHOP AND POOJA BHANDAR',5,'0','DR','VARTAK NAGAR NEAR LAXMI POOJA BHANDAR NAKA','DEFAULT','THANE','21','400606',NULL,'8692948541.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:52','2026-02-23 09:15:52'),(75,'167',NULL,NULL,'TARA OIL AND SOAP CENTRE',5,'0','DR','SHOP NO. 4 LAXMI SADAN KISAN NAGAR NO. 3 BHATWADI ROAD NO. 16 THANE WEST','DEFAULT','THANE','21','400604',NULL,'9619267006.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(76,'167',NULL,NULL,'TAMBDE KIRANA STORE',5,'0','DR','SHOP NO 1.ROAD NO 16.NEAR LOKMANYA STORE.NEAR LAXMI STORE.KISAN NAGAR NO 3.THANE WEST.','DEFAULT','THANE','21','400604',NULL,'8169689764.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(77,'167',NULL,NULL,'TAJ KIRANA',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9892346041.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(78,'167',NULL,NULL,'SWEET CORNIR',5,'0','DR','PANCHPAKDI','DEFAULT','THANE','21','400601',NULL,'9821268912.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(79,'167',NULL,NULL,'SWEET CORNER',5,'0','DR','SWEET CORNER NAVPADA ROAD NEXT TO NAVPADA MEDICAL AND GENERAL STORE THANE WEST','DEFAULT','THANE','21','400602',NULL,'9820072245.0','',NULL,'27','27ARMPS4861N1ZU','','STATE BANK OF INDIA',NULL,NULL,'KHOPAT','14',NULL,NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,'11524100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(80,'167',NULL,NULL,'SWASTID PRODUCT',5,'0','DR','PACB','DEFAULT','THANE','21','400603',NULL,'7796274270.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(81,'167',NULL,NULL,'SWASTID INNOVATIVE PRODUCT LLP',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400602',NULL,'9987666782.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(82,'167',NULL,NULL,'SWARAJ TRADERS',5,'0','DR','NEAR BHAJI MARKET','SHIVAJI NAGAR','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(83,'167',NULL,NULL,'SWARAJ SUPER MARKET',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'9224331877.0','',NULL,'27','','','TJSB SAHAKARI BANK LTD',NULL,NULL,'TILAK NAGAR THANE E','13',NULL,NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(84,'167',NULL,NULL,'SWAPNIL KIRANA AND GENERAL STORES',5,'0','DR','SHOP NO 01 MAULI SOCIETY GYANESHWAR NAGAR OPP SOMESHWAR SOCIETY NEAR VISHAKHA BEAUTY PARLOUR THANE W','DEFAULT','THANE','21','400604',NULL,'9867092389.0','',NULL,'27','','','ESAF',NULL,NULL,'GHATKOPAR','1',NULL,NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:53','2026-02-23 09:15:53'),(85,'167',NULL,NULL,'SWAMI SAMARTH GEN',5,'0','DR','BHATWADI','','','21','',NULL,'9076099024','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(86,'167',NULL,NULL,'SWAMI MILK CENTER',5,'0','DR','SHOP NO 23 JIJAMATA NAGAR GRIAHNIRMAN SANSTHA RAMCHANDAR NAGAR NEAR MAMTA KIRANA STORE THANE','DEFAULT','THANE','21','400604',NULL,'9870399906','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(87,'167',NULL,NULL,'SUSHMA GENRAL',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9833360213.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(88,'167',NULL,NULL,'SUSHMA GENERAL STORES',5,'0','DR','SHOP NO 1 A ,NAVRACHANA BLDG, SHIVAJI NAGAR,NEAR PANCHGANGA OPP CANARA BANK ATM AKASHGANGA ROAD, RABODI NO 2,THANE WEST','DEFAULT','THANE','21','400607',NULL,'7738029410.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(89,'167',NULL,NULL,'SURYA GENERAL STORES',5,'0','DR','HANUMAN NAGAR NEAR ROAD NO 34 NEAR MAHESH KIRANA AND GENERAL STORE OPP SHIVSENA SAKA OFFICE WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'8850108070.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(90,'167',NULL,NULL,'SURAJRAAJ GENERAL STORE',5,'0','DR','INDIRA NAGAR TEKADI PANI KI TAKI','DEFAULT','THANE','21','400606',NULL,'9920237669.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(91,'167',NULL,NULL,'SURAJ DARIY',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI SAI BABA MANDIR NEAR SANJAY PROVISION STORE','DEFAULT','THANE','21','400604',NULL,'8655581970.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(92,'167',NULL,NULL,'SUPREME MEDICAL',5,'0','DR','SATYAM GENERAL STORE NEAR AMBEWADI ROAD NO 22 WAGLE STATE','DEFAULT','THANE','21','400604',NULL,'8779263523.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(93,'167',NULL,NULL,'SUPER HIND BAKERY',5,'0','DR','HANUMAN NAGAR','NR  MAHESH SWEET AND GEN STORE','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(94,'167',NULL,NULL,'SUNITA DRY FRUITS &AMP; GENERAL STORE',5,'0','DR','SHOP NO 2 VAIBHAV SADAN NEAR SUNDAR GENERAL STORE KISAN NAGER NO 3 ROAD NO 16 WAGLE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9321747489.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:54','2026-02-23 09:15:54'),(95,'167',NULL,NULL,'SUNDMATA GENERAL STORES',5,'0','DR','DHARAMVEER NAGAR NO 2 NEAR DYANSADHNA COLG OPP MENTAL HOSPITAL THANE W','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(96,'167',NULL,NULL,'SUNDHA MATA GENERAL STORES',5,'0','DR','SHOP NO 68 GITANJALI CO-OP OPP GAJANAND MANDIR SHIVAI NAGAR POKHARAN ROAD 1 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(97,'167',NULL,NULL,'SUNDER GEN',5,'0','DR','KISAN NAGAR-3','NR SUNITA DRY FRUIT','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(98,'167',NULL,NULL,'SUNANDA GENERAL STORE',5,'0','DR','NEAR CHENDNI KOLIWADA MITHABANDAR ROAD KOPRI','DEFAULT','THANE','21','400603',NULL,'9930345005.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(99,'167',NULL,NULL,'SUMANGAL SHREE GANESH AGARBATTI BHANDAR',5,'0','DR','LOKMANYA NAGAR PADA NO 2 LAKADI POOL NEAR PADMA AGARBATTI','DEFAULT','THANE','21','400606',NULL,'9987327199.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(100,'167',NULL,NULL,'SUMAN MEDICAL & GENERAL STORE',5,'0','DR','RAMCHANDRA NAGAR NEAR A ONE SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'9892296549.0','',NULL,'27','27BRUPC5353E1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,'21516100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(101,'167',NULL,NULL,'SUDHIR GENRAL STORE',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'7977447230.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'101',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(102,'167',NULL,NULL,'SUDAMA GENERAL STORE',5,'0','DR','SHREE RAM GENERAL STORE NEAR SAMTA NAGAR VARTAK NAGAR','DEFAULT','THANE','21','400606',NULL,'9833580420.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'102',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(103,'167',NULL,NULL,'SUBHASH GEN',5,'0','DR','KISAN NAGAR-2','NR GUPTA OIL DEPO','','21','',NULL,'9220214662','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'103',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(104,'167',NULL,NULL,'STAR MEDICAL & GENERAL STORE',5,'0','DR','RAGHUNATH NAGAR, NEAR KAILASH SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'9920980265.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'104',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:55','2026-02-23 09:15:55'),(105,'167',NULL,NULL,'ST MARRY BAKAERY',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'7668847811.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'105',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(106,'167',NULL,NULL,'SRI KRISHNA GENERAL STORES',5,'0','DR','BLOCK NO 92.759 OPP NILKANT BUS STOP KOKNI PADA NEAR RONAK PARK GATE POKHARAN ROAD 2 THANE WEST','DEFAULT','THANE','21','400606',NULL,'8356873626.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'106',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(107,'167',NULL,NULL,'SREE SAI GENERAL STORE',5,'0','DR','NEAR HARI OM GENERAL STORE.OMKAR APARTMENT SHOP NO.1.SHREE NAGAR.GANESH CHOWK.THANE WEST.','DEFAULT','THANE','21','400606',NULL,'8108307949.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'107',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(108,'167',NULL,NULL,'SONU OIL DEPO',5,'0','DR','LOKMANYA NAGAR PADA NO 3','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'108',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(109,'167',NULL,NULL,'SONU DRY FRUIT FARSAN',5,'0','DR','SHOP NO.4 LAXMI NIWAS NEAR MAN SNEH MEDICAL AND GENERAL STORE NEAR SANTOSH GENERAL STORE SAVARKAR NAGAR NEAR PAVAN MEDICAL THANE WEST THANE 400606','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'109',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(110,'167',NULL,NULL,'SOLANKI GENERAL STORE',5,'0','DR','NEAR YASHODHA SCHOOL SHASTRI NAGAR','DEFAULT','THANE','21','400606',NULL,'8291126272.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'110',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(111,'167',NULL,NULL,'SOLANKI GEN STORE',5,'0','DR','SHASTRI NAGAR','NR  MAHAKALI GEN STORE','','21','',NULL,'8291126272','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'111',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(112,'167',NULL,NULL,'SOHAM SAI ICECREAM PARLOR COLD DRINKS AND GENERAL STORES',5,'0','DR','SHOP NO 3 SAI BALAJI BLDG OPP SANJAY PROVISION STORES RAMCHANDAR NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'1234567890','',NULL,'27','','','DMK JAOLI BANK',NULL,NULL,'LOUISWADI','4',NULL,NULL,NULL,NULL,NULL,'112',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(113,'167',NULL,NULL,'SOCIETY SUPER MARKET',5,'0','DR','KOAPRI','DEFAULT','THANE','21','400603',NULL,'8169102028.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'113',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(114,'167',NULL,NULL,'SOCIETY DHANYA BHANDAR',5,'0','DR','SHOP NO 4.AKSHATA SOCIETY.ALMEDIA ROAD.CHANDANWADI.PANCHPAKDI.NEAR SANTOSH KIRANA.NEAR JAI BAJRANG CHANA BHANDAR.THANE.WEST','DEFAULT','THANE','21','400602',NULL,'9004028570.0','',NULL,'27','27AHGPG3987M1QZ','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'114',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:56','2026-02-23 09:15:56'),(115,'167',NULL,NULL,'SNTOSH CHIKI',5,'0','DR','STN ROAD','DEFAULT','THANE','21','400602',NULL,'7506268091.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'115',NULL,NULL,NULL,NULL,NULL,'115114000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(116,'167',NULL,NULL,'SNEHA TRADERS',5,'0','DR','HANS NAGAR','NR POOJA SUPER MARKET','','21','',NULL,'8652353121','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'116',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(117,'167',NULL,NULL,'SIRVI PROVISION STORES',5,'0','DR','SHOP NO  13 NEAR SWANT SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'9969514156.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'117',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(118,'167',NULL,NULL,'SINGH GENERAL STORE',5,'0','DR','AMBEWADI ROAD NO 22 WAGLE STATE NEAR CHUDHARY STORE','DEFAULT','THANE','21','400604',NULL,'8858613866','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'118',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(119,'167',NULL,NULL,'SINDHUR FOODS',5,'0','DR','SAVARKAR NAGAR','OPP MAHAVIR OIL','','21','',NULL,'9082555564','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'119',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(120,'167',NULL,NULL,'SIDHIVINAYAK GENRAL STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'9324649526.0','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'RUTU PARK BRANCH','6',NULL,NULL,NULL,NULL,NULL,'120',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(121,'167',NULL,NULL,'SIDHIVINAYAK DAIRY',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'7715982456.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'121',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(122,'167',NULL,NULL,'SIDHI MEDICAL',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'8454871968.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'122',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(123,'167',NULL,NULL,'SIDHGIRI KIRANA AND GENERAL STORE',5,'0','DR','RAMCHANDRA NAGAR','NR SHIV SENA SAKHA','','21','',NULL,'1234567890','',NULL,'27','','','STATE BANK OF INDIA',NULL,NULL,'INDIRA NAGAR','4',NULL,NULL,NULL,NULL,NULL,'123',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(124,'167',NULL,NULL,'SIDDHIVINAYAK TRADING',5,'0','DR','SHOP NO 3 HILABORD BUILDING SHANTI NAGAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'124',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:57','2026-02-23 09:15:57'),(125,'167',NULL,NULL,'SIDDHIVINAYAK GENERAL STORE',5,'0','DR','SHOP NO 2 RAKESH VILLA OPP TJSB BANK K VILLA NEAR SANJIVENI HOSPOTAL RABODI NO 1 THANE WEST','DEFAULT','THANE','21','400607',NULL,'7427896145.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'125',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(126,'167',NULL,NULL,'SIDDHIVINAYAK GENERAL STORE',5,'0','DR','SAMTA NAGAR NEAR SHREE RAM GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'9833827249.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'126',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(127,'167',NULL,NULL,'SIDDHIVINAYAK DHANYA BHANDAR',5,'0','DR','SHOP NO-1;SHIVSHAKTI CHAWAL NO 03 ,NEAR KAMGAR HOSPITAL ,DHYANESHWAR NAGAR, ROAD NUMBER -33,WAGHALE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'127',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(128,'167',NULL,NULL,'SIDDHI VINAYAK MEDICAL',5,'0','DR','TEMBHI NAKA','NR MAHARASTRA DRYFRUIT','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'128',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(129,'167',NULL,NULL,'SHUBHAM DRY FRUITS',5,'0','DR','NEAR BANK OF BARODA','DEFAULT','THANE','21','400604',NULL,'9821347326.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'129',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(130,'167',NULL,NULL,'SHUBHAM DEPARTMENT',5,'0','DR','BUILDING.NO.2B.SHOP NO4 AND 5.AND5A.BRINDABAN .NEAR LAXMI STORE.THANE WESTNDAWAN SOCIETY','DEFAULT','THANE','21','400602',NULL,'9869545454.0','',NULL,'27','27ALXPB9230H1ZS','','STATE BANK OF INDIA',NULL,NULL,'MAJIWADE','6',NULL,NULL,NULL,NULL,NULL,'130',NULL,NULL,NULL,NULL,NULL,'11516000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(131,'167',NULL,NULL,'SHUBHAGI MILK',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'9987256218.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'131',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(132,'167',NULL,NULL,'SHRISHA STORE',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9867634747.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'132',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(133,'167',NULL,NULL,'SHRIAM ENTERPRISES',5,'0','DR','KISHAN NAGAR 03, MOUNT VIEW BUILDING,OPPOSITE TO GALA SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'8108798981.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'133',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(134,'167',NULL,NULL,'SHRI SAI DHANYA BHANDAR',5,'0','DR','SHOP NO.1 SHIVNERI GRUH NIRMAN SOCIETY BUILDING  NO.1 NEAR SATISH MILK CENTER SUBHASH NAGAR THANE EAST THANE 400603','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'134',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:58','2026-02-23 09:15:58'),(135,'167',NULL,NULL,'SHRI RAM GENRAL',5,'0','DR','SHRI NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'135',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(136,'167',NULL,NULL,'SHRI KALA STORES',5,'0','DR','OPP NARAYAN DAIRY NEAR OM NIWAS BLDG ROAD NO 27 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'9702025666.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'136',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(137,'167',NULL,NULL,'SHRI GANESH STORE',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'9820240291.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'137',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(138,'167',NULL,NULL,'SHRI GANESH DRY FRUIT AND SWEETS',5,'0','DR','SHOP NO 1 VAIDHYA BUILDING','OPPOSITE MTNL OFFICE NAUPADA THANE WEST','THANE','21','400602',NULL,'7900095885','',NULL,'27','27BBCPB5366A1Z6','','COSMOS BANK',NULL,NULL,'THANE','14',NULL,NULL,NULL,NULL,NULL,'138',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(139,'167',NULL,NULL,'SHRI BAJRANG KIRANA STORES',5,'0','DR','AMBEWADI NEAR SHANKAR MANDIR BEHIND SHIV SENA NAGAR BEHIND SHIV SENA SHAKHA THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'139',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(140,'167',NULL,NULL,'SHRI  ASHAPURA PROVISION STORES',5,'0','DR','SHRI VAMAN KRUPA GALA NO 05 RABODI NO 02 KOLIWADA NEAR APNA STOR THANE WEST','DEFAULT','THANE','21','400607',NULL,'9594538662.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'140',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(141,'167',NULL,NULL,'SHREERAM GENERAL STORES',5,'0','DR','SHOP NO 03 AND 04 YASHWANT CHS SAMTANAGAR POKHARAN ROAD NO 01 OPP J K GRAM THANE','DEFAULT','THANE','21','400606',NULL,'9892736097.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'141',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(142,'167',NULL,NULL,'SHREENATH DARIY',5,'0','DR','DNYANESHWAR NAGAR NEAR POOJA KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'8652686886.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'142',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(143,'167',NULL,NULL,'SHREE YOGESHWARI FOOD\\\'S',5,'0','DR','GAUTAM ARCADE SADHU VASWANI NAGAR','DEFAULT','THANE','21','400603',NULL,'8080053854.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'143',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(144,'167',NULL,NULL,'SHREE TULSI DARIY',5,'0','DR','DNYANESHWAR NAGAR NEAR OM SWEETS','DEFAULT','THANE','21','400604',NULL,'8693031971.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'144',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:15:59','2026-02-23 09:15:59'),(145,'167',NULL,NULL,'SHREE SWAMI SAMARTH GENERAL STORE',5,'0','DR','CP TALAV ROAD NO-27','DEFAULT','THANE','21','400604',NULL,'9892902644.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'145',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(146,'167',NULL,NULL,'SHREE SURYA OIL DEPO',5,'0','DR','INDRA NAGAR CIRCLE NEAR JAMA MASJID','DEFAULT','THANE','21','400606',NULL,'9920701048.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'146',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(147,'167',NULL,NULL,'SHREE SUDHHIVINAYAK GENERAL STORE',5,'0','DR','SHOP NO 1  EVEREST BALDING GANESH CHAWK BHATWADI ROAD KISAN NAGER NO 3 THANE W','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'147',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(148,'167',NULL,NULL,'SHREE SIDDHIVINAYAK MEDICAL AND GENERAL STORE',5,'0','DR','DEEPAK STORE NEAR SHASTRI NAGAR','DEFAULT','THANE','21','400606',NULL,'9892564850.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'148',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(149,'167',NULL,NULL,'SHREE SIDDHIVINAYAK GENERAL AND KIRANA STORES',5,'0','DR','SAMBHAJI NAGAR VETIWADI OP POOJA DRY FRUITS NEAR SANJAY PROVISION STORES WAGHLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'8693861012.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'149',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(150,'167',NULL,NULL,'SHREE SAWARIYA DARIY',5,'0','DR','VARTAK NAGAR NEAR HIRA OIL DEPO','DEFAULT','THANE','21','400606',NULL,'7849871616.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'150',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(151,'167',NULL,NULL,'SHREE SATYAM GENERAL STORE',5,'0','DR','SHOP NO 1,GURAV NIWAS, NEAR PANCHPARMESHWAR MANDIR, NEXT RADHA KRISHNA DAIRY KISAN NAGAR NO 1,WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400606',NULL,'8433613714.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'151',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(152,'167',NULL,NULL,'SHREE SAI SUPER MARKET',5,'0','DR','SHOP NO 1,NEAR HINGALAJ MATA MANDIR,OPP BLDG NO 56 BHIM NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'8104347090.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'152',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(153,'167',NULL,NULL,'SHREE SAI OIL DEPOT',5,'0','DR','SHOP NO 4 AND 5 OMKAR APARTMENT NEAR SHIVSENA SHAKHA SAMOR VEER SAVARKAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'9869513014.0','',NULL,'27','27AVLPS6384H1ZU','','TJSB SAHAKARI BANK',NULL,NULL,'WAGLE ESTATE','8',NULL,NULL,NULL,NULL,NULL,'153',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(154,'167',NULL,NULL,'SHREE SAI MEDICAL AND GENERAL STORE',5,'0','DR','R K CHAUHAN GENERAL STORE NEAR VARTAK NAGAR BHIM NAGAR ROAD','DEFAULT','THANE','21','400606',NULL,'9167763952.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'154',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:00','2026-02-23 09:16:00'),(155,'167',NULL,NULL,'SHREE SAI  KRUPA GENERAL STORE',5,'0','DR','SHOP NO 2 CHYAPARKASH BLD PATEL CHOWK SHIVAJI NAGAR WAGHLE ESTETE THANE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'155',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(156,'167',NULL,NULL,'SHREE RAMDEV GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 4 NEAR HARI SETH TALAO NEAR AMBIKA DHANYA BHANDAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','GS MAHANAGAR',NULL,NULL,'100368','18',NULL,NULL,NULL,NULL,NULL,'156',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(157,'167',NULL,NULL,'SHREE RAM OIL DEPO',5,'0','DR','SAVARKAR NAGAR NEAR SAI OIL INDIRA NAGAR','DEFAULT','THANE','21','400606',NULL,'9833953025.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'157',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(158,'167',NULL,NULL,'SHREE RADHE OIL DEPO',5,'0','DR','SHOP NO.2 SAI NATH SOCIETY B. NEAR JAI SANTOSHI MAA GENERAL STORE HAJURI WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'158',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(159,'167',NULL,NULL,'SHREE RADHA RANI GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 3 NEAR KRISHNA DHANYA BHANDAR','DEFAULT','THANE','21','400602',NULL,'9619250263.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'159',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(160,'167',NULL,NULL,'SHREE RADHA KISHNA DAIRY',5,'0','DR','SHOP NO1 VIHANG PARK P L DESHPANDAY ROAD NEAR MANOJ MEDICO SHASTRI NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'9653961573.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'160',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(161,'167',NULL,NULL,'SHREE R K CHAUHAN TOBACCO SUPER MARKET',5,'0','DR','VARTAK NAGAR NEAR RAJESH PROVISION STORE','DEFAULT','THANE','21','400606',NULL,'9022607880.0','',NULL,'27','','','KARNATAKA BANK LTD',NULL,NULL,'853163','10',NULL,NULL,NULL,NULL,NULL,'161',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(162,'167',NULL,NULL,'SHREE PREMANAND DRY FRUITS',5,'0','DR','SHREE PREMANAND DRY FRUITS OPP NEELIMA XETO NEAR SAV JI RANCHHOD PATEL  VARTAK NAGER THANE WEST','DEFAULT','THANE','21','400606',NULL,'9172777119.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'162',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(163,'167',NULL,NULL,'SHREE MAHALAXMI SWEETS AND FARSHAN MART',5,'0','DR','SADGURU NIWAS SHOP NO 6 NEAR MAA BHAVANI DHAYAN BHANDER NEAR CP TALAV POLICE CHAWKI ROAD NO 28 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'163',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(164,'167',NULL,NULL,'SHREE MAHAKALI TRADERS',5,'0','DR','PADA NO 2','NR AXIS BANK ATM','','21','',NULL,'7977042884','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'164',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:01','2026-02-23 09:16:01'),(165,'167',NULL,NULL,'SHREE MAA RAVECHI STORE',5,'0','DR','KISHAN NAGAR NO.02, ROAD NO.16,NEAR GUPTA OIL DEPO','DEFAULT','THANE','21','400604',NULL,'9004704611.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'165',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(166,'167',NULL,NULL,'SHREE LAXMI KIRANA',5,'0','DR','DYANSADHNA COLLEGE','NR SHIV SHAKTI KIRANA','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'166',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(167,'167',NULL,NULL,'SHREE LAKSHMI KIRANA',5,'0','DR','NEAR SHIVSHAKTI KIRANA','DEFAULT','THANE','21','400602',NULL,'9664357385.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'167',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(168,'167',NULL,NULL,'SHREE KRISHNA DHAYNA BHANDAR',5,'0','DR','SHOP NO. 2 LOKMANYA NAGAR PADA NO. 3 NEAR JAIN MANDIR NEXT TO SHREE SAINATH SUPER MARKET THANE WEST','DEFAULT','THANE','21','400604',NULL,'9833750615','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'168',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(169,'167',NULL,NULL,'SHREE KRISHNA DAIRY',5,'0','DR','PADA NO 4','NEAR CHARBHUJA GEN','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'169',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(170,'167',NULL,NULL,'SHREE KRISHNA DAIRY',5,'0','DR','KISAN NAGER NO 3 ROAD NO 16 SHIV RATAN GALLI NEAR SAI BABA PACKING THANE W','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'170',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(171,'167',NULL,NULL,'SHREE JYOTILING SUPAR MARKWT',5,'0','DR','OPP KAMAL MEDICAL NEAR WELCOME TOBACO GANGA DHAR NAGAR GANESHWAR NAGAR WAGLE ESTATE','DEFAULT','THANE','21','400604',NULL,'9975568674.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'171',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(172,'167',NULL,NULL,'SHREE JI STORE',5,'0','DR','LUIESWADI','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'172',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(173,'167',NULL,NULL,'SHREE JI ICE CREAM',5,'0','DR','RAMCHANDRA NAGAR NEAR NEW SAGAR SWEETS','DEFAULT','THANE','21','400604',NULL,'6378659856.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'173',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(174,'167',NULL,NULL,'SHREE JAKASHWAR GRAIN STORE',5,'0','DR','SHOP NO. 2 SHIVAJI NAGAR NEAR MARU GENERAL STORE NEXT TO AMBIKA SCHOOL THANE WEST MUMBAI','DEFAULT','THANE','21','400606',NULL,'8879306960.0','',NULL,'27','27ACCPS2171E1ZR','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'174',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:02','2026-02-23 09:16:02'),(175,'167',NULL,NULL,'SHREE JAI BHAVANI TREDING',5,'0','DR','SHOP NO 1 CHANDRA DARSHAN BLDG.NEAR SANJAY MEDICO NEXT TO MATOSHREE GENERAL STORES PADWAL NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'175',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(176,'167',NULL,NULL,'SHREE HARI TREDERS',5,'0','DR','SHOP NO 04 INDIRA NAGAR NAKA ROAD NO 33 NEAR RAMDEV SWEET AND FARSAN NEAR KAMLA HOTLE SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'7016447440.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'176',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(177,'167',NULL,NULL,'SHREE HARI TREDARS',5,'0','DR','INDIAR NAGAR NEAR RAMDEV DAIRY AND SWEET','DEFAULT','THANE','21','400604',NULL,'9768628177.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'177',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(178,'167',NULL,NULL,'SHREE HARI OM KIRANA AND GENERAL STORE',5,'0','DR','BLDG NO. 8 MAIN BHAJI MARKET NEAR RADHE KISHAN SUPER MARKET  OPP SHREE GANESH  MILK CENTER','KOPRI COLONY THANE EAST','THANE','21','400603',NULL,'9920996273','',NULL,'27','27AGLPB9040J1ZA','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'178',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(179,'167',NULL,NULL,'SHREE GOKUL DAIRY',5,'0','DR','LOKMANYA NAGAR, PADA NO.04, NEAR CHARBHUJA GENERAL STORE','DEFAULT','THANE','21','400603',NULL,'7021837427.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'179',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(180,'167',NULL,NULL,'SHREE GANESH SUPER MARKET',5,'0','DR','OPP.BABA SHAHEB AMBEDKAR STATUE ,BHIM NAGAR/VARTAK NAGAR,THANE (W)','DEFAULT','THANE','21','400606',NULL,'7021615130.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'180',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(181,'167',NULL,NULL,'SHREE GANESH SUPER MARKET',5,'0','DR','ANAND NAGAR KOPARI','DEFAULT','THANE','21','400606',NULL,'9004288003.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'181',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(182,'167',NULL,NULL,'SHREE GANESH OIL DEPO AND GENERAL STORES',5,'0','DR','A 201 OMKAR APPARTMENT INDIRA SHOPPING CENTER OPP DR MANJIT SINGH SAVARKAR NAGAR OPP KRISHANA CHEMIST OPP MAHAVIR OIL AND GENERAL STORED SAVARKAR NAGAR THANE','DEFAULT','THANE','21','400602',NULL,'9769205579.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'182',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(183,'167',NULL,NULL,'SHREE GANESH KRUPA GEN STORE',5,'0','DR','SHANTI NAGAR NEAR HANUMAN MANDIR','DEFAULT','THANE','21','400604',NULL,'9082577644.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'183',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(184,'167',NULL,NULL,'SHREE GANESH GENERAL STORES',5,'0','DR','SABIRA COMPOUND NEAR CHHATRAPATI HIGH SCHOOL SAVARKAR NAGAR OPP CHAMUNDA AGARWATI SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'184',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:03','2026-02-23 09:16:03'),(185,'167',NULL,NULL,'SHREE GANESH GENERAL STORE',5,'0','DR','NG VIHAR BUILDING SHASTRI NAGAR','DEFAULT','THANE','21','400606',NULL,'8879337724.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'185',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(186,'167',NULL,NULL,'SHREE GANESH GENERAL STORE',5,'0','DR','SHOP NO 5  SHREE KRISHNA APARTMENT GENESH NAGAR SHIVAI NAGAR NEAR JAY BHAWANI GENERAL STORE THANE WEST','DEFAULT','THANE','21','400604',NULL,'7977567772.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'186',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(187,'167',NULL,NULL,'SHREE GANESH DUGHDHALYA',5,'0','DR','ROAD NO 28 ITI RAMNAGAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'187',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(188,'167',NULL,NULL,'SHREE GANESH DUDHALAY',5,'0','DR','SHOP NO 5 BUILDING NO 5 OPPOSIT SHREE HARIOM KIRANA AND GENERAL STORE NEAR RADHE KISHAN SUPER MARKET  KOPRI COLONY,BHAJI MKT THANE EAST','DEFAULT','THANE','21','400603',NULL,'7900004694.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'188',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(189,'167',NULL,NULL,'SHREE GANESH DRYFRUITS &AMP; GENERAL STORE',5,'0','DR','SANTOSHI BHAVAN GANESH CHAWK BHATT VADI KISHAN NAGER NO 3 OPP SHIVSENA KARYALAYA THANE W','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'189',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(190,'167',NULL,NULL,'SHREE GANESH DRYFRUITS & MASALA',5,'0','DR','NR SANJAY OIL','MAHAGIRI','THANE','21','400601',NULL,'9869007440','',NULL,'27','27AEMPB1669J1ZA','','YES PROSPERITY',NULL,NULL,'TALAO PALI','5',NULL,NULL,NULL,NULL,NULL,'190',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(191,'167',NULL,NULL,'SHREE GANESH DHANYA BHANDAR',5,'0','DR','KOLBAD NR HANUMAN GEN STORE','','','21','',NULL,'9769570378','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'191',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(192,'167',NULL,NULL,'SHREE GAJANAN FLOUR MILL AND KIRANA STORES',5,'0','DR','SHOP NO 2A NEAR MTNL OFFICE KOPRI COLONY NEAR JANTA KIRANA STORE KOPRI THANE EAST','DEFAULT','THANE','21','400602',NULL,'9867845860.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'192',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(193,'167',NULL,NULL,'SHREE DURGA KIRANA AND GENERAL STORE',5,'0','DR','SHOP NO 01 NEXT TO MAHAKALI GENERAL STORE OPP PREETI TAILORS NEAR DR DINKAR GANESH PATIL MARG POKHRA','DEFAULT','THANE','21','400604',NULL,'9987418951.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'193',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(194,'167',NULL,NULL,'SHREE DRYFRUIT AND GENRAL STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400602',NULL,'9893268953.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'194',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:04','2026-02-23 09:16:04'),(195,'167',NULL,NULL,'SHREE DRY FRUITS AND GENERAL STORE',5,'0','DR','SHOP NO-5.LILADHAR SMRUTI SOCIETY .DHARMAVEER MARG,GURUKUL ROAD.NEAR PRITAM DAIRY.PANCHPAKHADI,THANE WEST','DEFAULT','THANE','21','400602',NULL,'9987434928.0','',NULL,'27','27CCRPP6237P1ZJ','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'195',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(196,'167',NULL,NULL,'SHREE DHANLAXMI DARIY',5,'0','DR','DNYANESHWAR NAGAR','DEFAULT','THANE','21','400604',NULL,'9820559495.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'196',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(197,'167',NULL,NULL,'SHREE DEVNARAYAN KIRANA STORE',5,'0','DR','SHOP NO 1.KISAN NAGAR NO 3.BHATWADI ROAD .NEAR RAVECHI GRAIN STORE.NEAR MAHALAXMI STORE.THANE.WEST','DEFAULT','THANE','21','400604',NULL,'9167363404.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'197',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(198,'167',NULL,NULL,'SHREE DEVI SATERI GEN STORE',5,'0','DR','LOKMANYA NAGAR','NR RAJE SHIVAJI SCHOOL','','21','',NULL,'9969647421','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'198',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(199,'167',NULL,NULL,'SHREE DATTAKRIPA KIRANA STORE',5,'0','DR','OPP EKTA RHEVASI CHAWAL CP TALAO ROAD NO 27 WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'199',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(200,'167',NULL,NULL,'SHREE CHANDAN GENERAL STORES',5,'0','DR','LOKMANNAGAR PADA NO 3 SIDDHESHWAR SOC LAKDI POOL NEAR DAAT MANDIR OPP AASHA TRADERS THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27AVNPC8582D1ZC','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'200',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(201,'167',NULL,NULL,'SHREE BHAVANI DARIY',5,'0','DR','RAMCHANDRA NAGAR NEAR MATAJI SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'7738403753.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'201',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(202,'167',NULL,NULL,'SHREE BHAIRAVNAT KIRANA STORE',5,'0','DR','SHOP NO 7.KISAN NAGAR NO 3.BHATWADI.NEAR AMBIKA SUPER MARKET.NEAR LAXMI GENERAL STORE.KISAN NAGAR.THANE .WEST','DEFAULT','THANE','21','400604',NULL,'9987173936.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'202',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(203,'167',NULL,NULL,'SHREE BHAIRAV NATH DAIRY',5,'0','DR','SHOP NO 4 SURAJ PAL NIVAS NEAR SHANKAR SHET BANGLA NEXT TO ANIL GENERAL STORES KISAN NAGAR NO 3 WAGLE THANE W','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'203',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(204,'167',NULL,NULL,'SHREE BHAGYA LAXMI KIRANA',5,'0','DR','LOKMANYA NAGAR BUS DEPO','NR AMBICA SUPAR MARKET','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'204',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:05','2026-02-23 09:16:05'),(205,'167',NULL,NULL,'SHREE BALAJI TRADERS',5,'0','DR','SHOP NO 6.NEAR SHIV MANDIR.NEAR JANTA DHANYA BHANDAR.','DEFAULT','THANE','21','400603',NULL,'7666885356.0','',NULL,'27','','','THE NAVJEEVAN COP BANK',NULL,NULL,'KOPRI','25',NULL,NULL,NULL,NULL,NULL,'205',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(206,'167',NULL,NULL,'SHREE BALAJI SUPER MARKET',5,'0','DR','KORES ROAD OPP SHIV SENA OFFICE NEAR HANUMAN MANDIR MAHATMA PHULE NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'206',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(207,'167',NULL,NULL,'SHREE BALAJI SUPER MARKET',5,'0','DR','MAHATMA FHULE NAGAR NEAR KOHINOOR BEKARY','DEFAULT','THANE','21','400606',NULL,'7568306683.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'207',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(208,'167',NULL,NULL,'SHREE BALAJI DRYFRUITS',5,'0','DR','RAMCHANDRA NAGAR NEAR GUPTA JUSH','DEFAULT','THANE','21','400604',NULL,'8792768558.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'208',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(209,'167',NULL,NULL,'SHREE BADRAKALI GEN STORE',5,'0','DR','KISAN NAGAR 2','','','21','',NULL,'9892951432','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'209',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(210,'167',NULL,NULL,'SHREE ASHAPURA MART',5,'0','DR','SHOP NO.1 RAUNKA TULIP BLDG  UNNATI BLDG OPP .DEVDAYA  NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27AEXFS8666K1ZQ','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'210',NULL,NULL,NULL,NULL,NULL,'11523000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(211,'167',NULL,NULL,'SHREE ASHAPURA DHANYA BHANDAR',5,'0','DR','SHOP NO 1 AND 2 MEET APT WAIREMAN WADI SANT DYANESHWAR NAGAR NEAR JANTA DHANY BHANDAR WAGLE STATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9076491266.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'211',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(212,'167',NULL,NULL,'SHIVSHAKTI GEN',5,'0','DR','PADWAL NAGAR','NR PANCH PARMESHWAR MANDIR','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'212',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(213,'167',NULL,NULL,'SHIVDAYA DAIRY FARM',5,'0','DR','SHOP NO 15 RAJIV GANDHI SHIPPING CENTER MITH BANDAR ROAD NEXT TO ROYAL FOOD THANE EAST','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'213',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(214,'167',NULL,NULL,'SHIVANI KIRANA STORE',5,'0','DR','SHOP NO. 2 ITI CIRCLE JUNAGAON ROAD NO. 28 NEXT TO ICICI ATM RAM NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9619374997.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'214',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:06','2026-02-23 09:16:06'),(215,'167',NULL,NULL,'SHIVAM TREDARS',5,'0','DR','SHIRI NAGAR SHIWANI HOSPITAL','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','BANK OF MAHARASTRA',NULL,NULL,'SHREE NAGAR','3',NULL,NULL,NULL,NULL,NULL,'215',NULL,NULL,NULL,NULL,NULL,'2.02206e+16','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(216,'167',NULL,NULL,'SHIVAM SUPER MARKET',5,'0','DR','SHOP NO 2.BRINDAVAN SOCIETY.NEAR PRAKASH DEPARTMENT STORE.THANE WEST','DEFAULT','THANE','21','400602',NULL,'8779038229.0','',NULL,'27','27ACYPY1728M1ZH','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'216',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(217,'167',NULL,NULL,'SHIVAM GENERAL STORE',5,'0','DR','ROAD NO 22 NEAR NEW KOMAL GENERAL STORE OPP SAI POOJA BHANDAR SAVARKAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'6392463699.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'217',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(218,'167',NULL,NULL,'SHIVAM DHANYA BHANDAR',5,'0','DR','ROAD NO 22 WAKHLE STREET SAATE ROAD INDIRA NAGAR NEXT TO LAXMI DIARY THANE WEST MUMBAI','DEFAULT','THANE','21','400604',NULL,'8452807605.0','',NULL,'27','27ADMFS4811L1ZM','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'218',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(219,'167',NULL,NULL,'SHIV SHANKAR DAIRY',5,'0','DR','SHOP NO 1 GIRIDHAR BHAVAN KISAHAN NAGER 16 21WAGLE ESTATE OPP SHREE MAA RAVECHI STORE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'219',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(220,'167',NULL,NULL,'SHIV SHAKTI TRADER',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'8451077273.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'220',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(221,'167',NULL,NULL,'SHIV SHAKTI OIL',5,'0','DR','KISAN NAGAR-3','NR MAA CHAMUNDA','','21','',NULL,'9324346635','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'221',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(222,'167',NULL,NULL,'SHIV SHAKTI KIRANA AND GENERAL STORE',5,'0','DR','NEAR DHYAN SADHANA COLLEGE','DEFAULT','THANE','21','400604',NULL,'9004163158.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'222',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(223,'167',NULL,NULL,'SHIV SHAKTI ICREAM',5,'0','DR','KOPAR','DEFAULT','THANE','21','400603',NULL,'9029790728.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'223',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(224,'167',NULL,NULL,'SHIV SHAKTI GENERAL STORES',5,'0','DR','SHOP NO 3 PANCHRATNA APARTMENT OPPOSITE SHIVKRISHNA VILLA NEAR NEW SHARMA DAIRY NEAR DAINIK CHAINESE CORNER CHARAI  GEETA SOCIETY ROAD THANE WEST','DEFAULT','THANE','21','400601',NULL,'9821422005.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'224',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:07','2026-02-23 09:16:07'),(225,'167',NULL,NULL,'SHIV SHAKTI DAIRY FARM',5,'0','DR','SHOP NO 02 ROAD NO 28 HILL ABODE CHS SHANTI NAGAR WAGLE ESTATE THANE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'225',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(226,'167',NULL,NULL,'SHIV SAGAR FARSAN',5,'0','DR','SHIVAJI NAGAR','NR MOMAI GEN','','21','',NULL,'9867375273','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'226',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(227,'167',NULL,NULL,'SHIV SAGAR DAIRY',5,'0','DR','SHOP NO 1, BAGLA NO 5, ARCHANA BANGLOW LOKMANYA NAGAR PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'227',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(228,'167',NULL,NULL,'SHIV PRERNA OIL DEPO',5,'0','DR','NEAR JAY AMBE D/B PADWAL NAGAR PANCHAPARMESWAR MANDIR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'228',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(229,'167',NULL,NULL,'SHIV MEDICAL AND GENERAL STORE',5,'0','DR','SHOP NO 3 BIDG NO 4 ADARSH NAGAR KOLBAD ROAD KHOPAT','DEFAULT','THANE','21','400601',NULL,'9167638423.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'229',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(230,'167',NULL,NULL,'SHIV MAHIMA DAIRY',5,'0','DR','SHANTI NAGAR BHAJI MARKET AMBIKA APARTMENT SHOP NO.3,','DEFAULT','THANE','21','400604',NULL,'9653353849.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'230',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(231,'167',NULL,NULL,'SHIV KRUPA SWEET',5,'0','DR','NEAR WELCOME STORE SHIVAJI NAGAR','DEFAULT','THANE','21','400604',NULL,'9819422571.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'231',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(232,'167',NULL,NULL,'SHIV KRUPA MASALA CENTER',5,'0','DR','SHOP NO.6,MARKETING COMPLEX,NEAR THANE BHARAT SAHKARI BANK,SHREE NAGAR,THANE (W)','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'232',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(233,'167',NULL,NULL,'SHIV DAYA DEARY',5,'0','DR','MITH BANDAR ROAD','DEFAULT','THANE','21','400603',NULL,'9867900917.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'233',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(234,'167',NULL,NULL,'SHIV AARTI DAIRY',5,'0','DR','SHOP NO-1 VIJYA APPARTMEMT GROUND FLOOR MAHMTA PHULE NAGAR J K GRAM ROAD NEAR MAN PASAND SWEETS NEAR SADGURU GENERAL STORES THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'234',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:08','2026-02-23 09:16:08'),(235,'167',NULL,NULL,'SHINDE PROVISION MASALA STORE',5,'0','DR','SANTOSHI BHAVAN BHATWADI KISAN NAGER NO 3 GANESH CHAWK WAGLE THANE W','DEFAULT','THANE','21','400604',NULL,'8169722153.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'235',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(236,'167',NULL,NULL,'SHILESH TEA',5,'0','DR','STN RODA','DEFAULT','THANE','21','400601',NULL,'9870742341.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'236',NULL,NULL,NULL,NULL,NULL,'1151140000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(237,'167',NULL,NULL,'SHIDNATH MASALA',5,'0','DR','INDIAR NAGAR','DEFAULT','THANE','21','400604',NULL,'7719845602.0','',NULL,'27','','','INDUSIND BANK',NULL,NULL,'NAUPADA','12',NULL,NULL,NULL,NULL,NULL,'237',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(238,'167',NULL,NULL,'SHIDHIVINAYAK GENERAL STORE',5,'0','DR','OPP KOLHAPUR VYAM SALA GOKUL NAGAR THANE','DEFAULT','THANE','21','400601',NULL,'9819812295.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'238',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(239,'167',NULL,NULL,'SHETE KIRANA',5,'0','DR','OPP ANAND SAWLI RESIDENSCY','RAMCHANDRA NAGAR-','','21','',NULL,'8689882564','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'239',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(240,'167',NULL,NULL,'SHEHA STORE',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'8652353121.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'240',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(241,'167',NULL,NULL,'SHEETAL GENERAL STORES',5,'0','DR','GOSAL APARTMENTS NEAR TO MINI GENERAL STORES AND NEXT TO VIRA GENERAL STORES SHANTI NAGER','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'241',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(242,'167',NULL,NULL,'SHEETAL GENERAL STORE',5,'0','DR','GAVTE GALLI WAGLE ESTATE BESIDE RAKESH GENERAL STORE NEAR ITI JUNA GAAV THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'242',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(243,'167',NULL,NULL,'SHEETAL DHANYA BHANDAR',5,'0','DR','ROAD NO 22 SAATE ROAD INDIRA NAGAR OPP SHIVAM DHANYA BHANDAR THANE WEST MUMBAI','DEFAULT','THANE','21','400604',NULL,'9967519475.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'243',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(244,'167',NULL,NULL,'SHANTABAI GENRAL STORE',5,'0','DR','ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'7900105424.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'244',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:09','2026-02-23 09:16:09'),(245,'167',NULL,NULL,'SHAKTI DHANYA BHANDAR',5,'0','DR','ANAND NAGAR KOPARI','DEFAULT','THANE','21','400606',NULL,'9594036758.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'245',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(246,'167',NULL,NULL,'SHAILESH GANERAL STORE',5,'0','DR','SHOP NO 1 DHONDALI BAG ROAD NEAR DAINIK CHINESE CORNER CHARAI THANE W','DEFAULT','THANE','21','400601',NULL,'9819544760.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'246',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(247,'167',NULL,NULL,'SHAH RAMESH CHANDAR MALSI',5,'0','DR','RAMCHANDAR NAGAR 2 E S I C HOSPITAL ROAD NEAR SANJAY PROVISION STORES WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'8454895291.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'247',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(248,'167',NULL,NULL,'SHAH MURJI JETHALAL AND COMPANY',5,'0','DR','SHOP NO 2 AMAR KUNJ MAHATMA PHULE ROAD OPPOSITE GANESH GRAIN STORE WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27AAHPF4016A1ZF','','GP PARSIK SAHAKARI BANK LTD',NULL,NULL,'JAMBHALI NAKA','2',NULL,NULL,NULL,NULL,NULL,'248',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(249,'167',NULL,NULL,'SHAH MANILAL NARSHI AND SONS',5,'0','DR','RAMCHANDRA NIWAS MAHA TMA PHULE MARG NEAR DINESH TRADERS OPP R B TEA COMPANY','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27AARPB2229F1ZW','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'249',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(250,'167',NULL,NULL,'SHAH LAXMICHAND KHIMJI',5,'0','DR','THANE WHOLESALE MARKET OPPOSITE POLICE CHAWKI NO 2 POOJA GALLI THANE WEST','DEFAULT','THANE','21','400601',NULL,'9892681311.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'250',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(251,'167',NULL,NULL,'SHAH BROTHERS',5,'0','DR','SAMAJ MANDIR HALL  NEAR BUS STOP NEAR BABUBHAI SHAH SHOP SHASTRI NAGAR THANE W','DEFAULT','THANE','21','400604',NULL,'9867501794.0','',NULL,'27','27ABIPS6319M1Z0','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'251',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(252,'167',NULL,NULL,'SHAH BHAVANJI KHIMJI & COM',5,'0','DR','SHOP NO 2 NIRMAL APARTMENT OPPOSITE EANAAJ NEAR SHREE GAJANAN STORE','OLD BOMBAY ROAD CHARAI THANE WEST','THANE','21','400601',NULL,'8898761761','',NULL,'27','27BATPS4146M1ZT','','MODEL CO OP BANK',NULL,NULL,'139506','24',NULL,NULL,NULL,NULL,NULL,'252',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(253,'167',NULL,NULL,'SHABNAM KIRANA STORE',5,'0','DR','SHOP NO.2 HAJURI DARGAH ROAD OPP. SHIV ANANT DAIRY NEAR MAHARASHTRA STORES WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'7977765201.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'253',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(254,'167',NULL,NULL,'SHAA SHAMJI KARA',5,'0','DR','LOKMANYA SOCIETY GAJANAN MAHARAJ CHAWK NEAR CHIPS AND NUTS GENERAL STORES CHARAI THANE W','DEFAULT','THANE','21','400601',NULL,'9867529695.0','',NULL,'27','27AFHPS4190P1ZM','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'254',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:10','2026-02-23 09:16:10'),(255,'167',NULL,NULL,'SEVEN ELEVEN',5,'0','DR','VARTAK NAGAR','DEFAULT','THANE','21','400604',NULL,'9819284571.0','',NULL,'27','','','SARASWATH BANK',NULL,NULL,'HIRANANADI MEADOWS','19',NULL,NULL,NULL,NULL,NULL,'255',NULL,NULL,NULL,NULL,NULL,'11515000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(256,'167',NULL,NULL,'SAYAD GENRAL STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9324695330.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'256',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(257,'167',NULL,NULL,'SAWANT TRADERS',5,'0','DR','VAITY WADI RAMCHANDAR NAGAR 3 NEAR NILKANTH AGGRO WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'7083238175.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'257',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(258,'167',NULL,NULL,'SAWANT TRADERS',5,'0','DR','LAKADI POOL NEAR MAYA TRADERS LOKMANYA NAGAR','DEFAULT','THANE','21','400606',NULL,'8104826322.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'258',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(259,'167',NULL,NULL,'SAWANT SUPER MARKET',5,'0','DR','SHOP NO.1.2.3 SHARDDHA RESIDENCY NEAR  KAJU WADI BUS STOP AND SAI BABA MANDIR LOUISWADI THANE WEST','DEFAULT','THANE','21','400606',NULL,'9920755115.0','',NULL,'27','27BCFPS2321N1ZC','','GP PARSIK SAHKARI BANK LTD',NULL,NULL,'LOUISWADI','19',NULL,NULL,NULL,NULL,NULL,'259',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(260,'167',NULL,NULL,'SAVLA DRY FRUITS',5,'0','DR','SHRADHA BHAVAN GHANTALI CHOWK VISHNU NAGAR NAUPADA THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27ATMPS8036P1ZN','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'260',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(261,'167',NULL,NULL,'SAVJI RANCHHOD PATEL',5,'0','DR','SHOP NO 65. POKHRAN ROAD NO 01','VARTAK NAGAR','THANE','21','400606',NULL,'8879344093','',NULL,'27','27AAUPP3283A1ZH','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'261',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(262,'167',NULL,NULL,'SAVARIYA DAIRY',5,'0','DR','DNYANESHWAR NAGAR NEAR DHANRAJ MASALA','DEFAULT','THANE','21','400604',NULL,'8779119465.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'262',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(263,'167',NULL,NULL,'SATYAM KIRANA BHANDAR',5,'0','DR','NEAR SHREE SAI GENERAL STORE BHATWADI','DEFAULT','THANE','21','400604',NULL,'9967403571.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'263',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(264,'167',NULL,NULL,'SATARKAR SUPER MARKET',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400606',NULL,'9405415741.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'264',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:11','2026-02-23 09:16:11'),(265,'167',NULL,NULL,'SATARKAR SUPER MARKET',5,'0','DR','DYANESHWAR NAGAR','NR JYOTIRLING KIRANA','','21','',NULL,'9867018001','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'265',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(266,'167',NULL,NULL,'SAROJINI GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 3 NEAR KRISHNA DHANYA BHANDAR','DEFAULT','THANE','21','400602',NULL,'9987368985.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'266',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(267,'167',NULL,NULL,'SANTOSHI KIRANA STORE',5,'0','DR','INDIRA NAGAR ROAD NO 33 WAGLE STREET RUPADEVI PADA NO 2 NEAR CHAMUNDA GENERAL STORE THANE WEST MUMBAI','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27AONPC4030P1ZQ','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'267',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(268,'167',NULL,NULL,'SANTOSHI DHANYA BHANDAR',5,'0','DR','INDIAR NAGAR RUPA DEVI PADA NO 2','DEFAULT','THANE','21','400604',NULL,'8879953927.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'268',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(269,'167',NULL,NULL,'SANTOSH SHIVA KIRANA STORE',5,'0','DR','KISHAN NAGAR NO.02,ROAD NO.16, NEAR NAGRIK DHANYA BHANDAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'269',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(270,'167',NULL,NULL,'SANTOSH MILK CENTRE',5,'0','DR','INDIRA NAGAR ROAD NO 33 RUPADEVI PADA NO 02 WAGLE STREET OPP KISHAN KIRANA STORE THANE WEST MUMBAI','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'270',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(271,'167',NULL,NULL,'SANTOSH KIRANA STORES',5,'0','DR','EKTA RAVASI CHAWAL INDIRA NAGAR RUPADEVI PADA NO 1 NEAR GAYATRI MEDICAL NEAR MAURYA GENERAL STORES I','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'271',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(272,'167',NULL,NULL,'SANTOSH KIRANA STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400603',NULL,'9702748948.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'272',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(273,'167',NULL,NULL,'SANTOSH GENERAL STORE',5,'0','DR','AMBEWADI ROAD NO 22 NEAR SHIV SENA OFFICE NEAR CHOUDHURY GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'7718962789.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'273',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(274,'167',NULL,NULL,'SANTOSH CUTLERY AND GENRAL STORE',5,'0','DR','INDIRA NAGAR NAKA','DEFAULT','THANE','21','400606',NULL,'9702453835.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'274',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:12','2026-02-23 09:16:12'),(275,'167',NULL,NULL,'SANSAT SWEET',5,'0','DR','KISANON NAGAR','DEFAULT','THANE','21','400603',NULL,'9967802068.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'275',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(276,'167',NULL,NULL,'SANSAR SWEET',5,'0','DR','KISAN NAGAR','NR KASHIRAM','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'276',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(277,'167',NULL,NULL,'SANKET GENERAL STORE',5,'0','DR','VARTAK NAGAR BHIM NAGAR NEAR PRITHVIRAJ CHAUHAN KIRANA STORE','DEFAULT','THANE','21','400606',NULL,'9821784154.0','',NULL,'27','','','KARNATAKA BANK',NULL,NULL,'VARTAK NAGAR','10',NULL,NULL,NULL,NULL,NULL,'277',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(278,'167',NULL,NULL,'SANJIVANI MEDICAL AND GENRAL STORE',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9619591000.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'278',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(279,'167',NULL,NULL,'SANJAY TRADERS',5,'0','DR','SHOP NO 4,NAKODA BHAIRAV SOCIETY, DEVIDAS RD, NR ISHWAR OIL, WHOLSALE MARKET, THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27ADUPT2672C1Z4','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'279',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(280,'167',NULL,NULL,'SANJAY STORE',5,'0','DR','KOLBAD','DEFAULT','THANE','21','400606',NULL,'9930659148.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'280',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(281,'167',NULL,NULL,'SANJAY PROVISION STORES',5,'0','DR','SAGAR APPARTMENT SHOP NO 2 RAMCHANDAR NAGAR 3 OPP SAI KRUPA GENERAL STORES NEAR SAI BABA MANDIR WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'9987556619.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'281',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(282,'167',NULL,NULL,'SANJAY OIL',5,'0','DR','THANE HOLSALE','DEFAULT','THANE','21','400601',NULL,'9825183287.0','',NULL,'27','27ADIPN3690A1ZM','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'282',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(283,'167',NULL,NULL,'SANGAM SWEETS',5,'0','DR','LOKMANYA NAGAR PADA NO 4','NR OM SUPER MARKET','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'283',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:13','2026-02-23 09:16:13'),(284,'167',NULL,NULL,'SANDEEP KIRANA STORE',5,'0','DR','BHIM NAGAR NEAR PRITHVIRAJ CHAUHAN KIRANA STORE','DEFAULT','THANE','21','400606',NULL,'8369794163.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'284',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(285,'167',NULL,NULL,'SANAS SNACKS CENTRE',5,'0','DR','NEAR DYANASADHANA COLLEGE','DEFAULT','THANE','21','400604',NULL,'7304188054.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'285',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(286,'167',NULL,NULL,'SAMARTHA BHANDAR',5,'0','DR','SHREENAGAR','DEFAULT','THANE','21','400604',NULL,'8369525950','',NULL,'27','27ABKCS5529E1Z4','','TJSB SAHAKARI BANK LTD',NULL,NULL,'SHREE NAGAR','3',NULL,NULL,NULL,NULL,NULL,'286',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(287,'167',NULL,NULL,'SAMARTH KRIPA',5,'0','DR','SHIVAI NAGAR','NR NARESH GEN','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'287',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(288,'167',NULL,NULL,'SALONI ENTERPRISES',5,'0','DR','AKASHGANGA','DEFAULT','THANE','21','400603',NULL,'9152078027.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'288',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(289,'167',NULL,NULL,'SAIDHAM MEDICAL',5,'0','DR','SAVAR LNAGAR','DEFAULT','THANE','21','400603',NULL,'9769713883.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'289',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(290,'167',NULL,NULL,'SAI PRIYA GENERAL STORE',5,'0','DR','BHAGODAR SOCIETY PLOT NO 76 ROOM NO D1 LOKMANYA NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'290',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(291,'167',NULL,NULL,'SAI PRASAD DRY FRUITS',5,'0','DR','LAKMANYA NAGAR PADA NO 4 NEAR HARI OM SUPER MARKET THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','HINDUSTAN BANK',NULL,NULL,'LOKMANYA NAGAR','18',NULL,NULL,NULL,NULL,NULL,'291',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(292,'167',NULL,NULL,'SAI PRASAD DAIRY',5,'0','DR','SHREE NAGAR NEAR GALA SUPER MARKET','DEFAULT','THANE','21','400603',NULL,'9892687152.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'292',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(293,'167',NULL,NULL,'SAI PRASAD DAIRY',5,'0','DR','LOKMANYA NAGAR','NR VIDHI DAIRY','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'293',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:14','2026-02-23 09:16:14'),(294,'167',NULL,NULL,'SAI PLUS MANGLORE STORE',5,'0','DR','SHANTI NAGAR OPP HOTEL SREYA','DEFAULT','THANE','21','400604',NULL,'9920493022.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'294',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(295,'167',NULL,NULL,'SAI KRUPA GENERAL STORE',5,'0','DR','SHOP NO-23,CHWAL NO 15,NEAR PANCH PARMESHWAR MANDIR,SANTA?? SHIVAJI NAGAR ,THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'295',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(296,'167',NULL,NULL,'SAI KRUPA GENERAL STORE',5,'0','DR','RAJEEV GANDHI NAGAR SAI BABA MANDIR NEAR HARI OM MILK','DEFAULT','THANE','21','400604',NULL,'7023844908.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'296',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(297,'167',NULL,NULL,'SAI KRUPA GENERAL STORE',5,'0','DR','DNYANESHWAR NAGAR NEAR SATGURU','DEFAULT','THANE','21','400604',NULL,'9167742827.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'297',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(298,'167',NULL,NULL,'SAI KRUPA GENARAL STORE',5,'0','DR','SHOP NO 4 SHIVANAND APARTMENT KARWALO NAGAR  SAVARKAR OPP MAHPALICA SCHOOL SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'298',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(299,'167',NULL,NULL,'SAI KRUPA GEN STORE',5,'0','DR','RAMCHANDRA NAGAR. SAIBABA MANDIR ROAD','DEFAULT','THANE','21','400604',NULL,'9702836129.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'299',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(300,'167',NULL,NULL,'SAHAKAR BAZAR',5,'0','DR','RABODI KATAL KHANA','DEFAULT','THANE','21','400606',NULL,'8849411346.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'300',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(301,'167',NULL,NULL,'SAHAKAR BAZAR',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'9687229611.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'301',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(302,'167',NULL,NULL,'SAHAJANAND  OIL  TRADERS',5,'0','DR','GROUND  FLOOR   FLAT  NO. 04  DURGAMATA  CHS  LOUISE  WADI   SAINATH  NAGAR  THANE  EAST  400604','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27APOPT8668Q1ZC','','TJSB SAHAKARI BANK LTD',NULL,NULL,'LOUISWADI','2',NULL,NULL,NULL,NULL,NULL,'302',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(303,'167',NULL,NULL,'SAHA GENRAL STORE',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9867622012.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'303',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:15','2026-02-23 09:16:15'),(304,'167',NULL,NULL,'SAGAR SUPER MARKET',5,'0','DR','SHOP NO. 1 AND 2 BLDG NO. B-53 MVRINDAVAN SOCIETY THANE WEST','DEFAULT','THANE','21','400602',NULL,'9004704713.0','',NULL,'27','27ABMPY2400R1ZY','','NKGS',NULL,NULL,'1','2',NULL,NULL,NULL,NULL,NULL,'304',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(305,'167',NULL,NULL,'SAGAR DHANYA BHANDAR',5,'0','DR','ITI CIRCLE ROAD NO 28','RAMNAGAR WAGLE ESTATE THANE WEST','THANE','21','400604',NULL,'9702987135','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'305',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(306,'167',NULL,NULL,'SADHANA MASALA',5,'0','DR','BHAJI MARKIT OPP BHAVESH TRADING INDIRA NAGAR','DEFAULT','THANE','21','400606',NULL,'9892412382.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'306',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(307,'167',NULL,NULL,'SADGURU STORE',5,'0','DR','BHAJI MKT','DEFAULT','THANE','21','400602',NULL,'9702490617.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'307',NULL,NULL,NULL,NULL,NULL,'115114000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(308,'167',NULL,NULL,'SADGURU MEDICAL',5,'0','DR','KOAPEI','DEFAULT','THANE','21','400603',NULL,'9821407678.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'308',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(309,'167',NULL,NULL,'SADGURU CHANA FARSAN STORE',5,'0','DR','SHOP NO  4 VIJAY APARTMENT MAHATAMA PHULE NAGAR','DEFAULT','THANE','21','400606',NULL,'9702254083.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'309',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(310,'167',NULL,NULL,'SADGRU KIRANA STORE',5,'0','DR','CHWAL NO 15 SHOP NO 8 SANT FHYANESWAR NAGAR ROAD NO 33 WAGHALE EASTATE THANE','DEFAULT','THANE','21','400604',NULL,'9326243058.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'310',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(311,'167',NULL,NULL,'S K ENTERPRISES',5,'0','DR','PADWAL NAGAR BHAJI MARKIT NEAR SWARAJ','DEFAULT','THANE','21','400606',NULL,'9324637422.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'311',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(312,'167',NULL,NULL,'RUTU SUPER MARKET',5,'0','DR','D3 SHOP NO. 6 AND 7 RUTU PARK OPP.  VRINDAVAN  BUS STOP NEXT TO NEW SIDDHIVINAYAK DHANYA BHANDAR  TH','DEFAULT','THANE','21','400602',NULL,'6351090045.0','',NULL,'27','27AFKPC2827G1ZM','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'312',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(313,'167',NULL,NULL,'RUSHABH TRADING',5,'0','DR','NEAR TOWN BAZAAR NEAR NIKITA STORE DEVIDAS ROAD MAHAGIRI THANE WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'0123456789','',NULL,'27','27AAAHG5275K1Z2','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'313',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:16','2026-02-23 09:16:16'),(314,'167',NULL,NULL,'RUSHABH MART',5,'0','DR','NEAR VANDANA CINEMA BHATIYA COMPOUND','DEFAULT','THANE','21','400602',NULL,'9082090827.0','',NULL,'27','27ABEFR5154P1ZL','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'314',NULL,NULL,NULL,NULL,NULL,'11522000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(315,'167',NULL,NULL,'RUPCHAND MADHAVDAS KIRANA MERCHANT',5,'0','DR','SHOP NO 5 NEHRU BAZAR KOPARI COLONY OPPOSITE SARVODAY GARDEN NEAR KRISHNA DAIRY AND SWEET MART THANE EAST','DEFAULT','THANE','21','400603',NULL,'9930599590.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'315',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(316,'167',NULL,NULL,'RUPALI KIRANA STORE',5,'0','DR','AMBIKA NAGAR NO 2 NEAR NEW MAHARSHTRA','DEFAULT','THANE','21','400604',NULL,'9167761270.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'316',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(317,'167',NULL,NULL,'RUPA GENRAL STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'7021400012.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'317',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(318,'167',NULL,NULL,'RUCHITA MASALA',5,'0','DR','LOKMANYA NAGAR PADA NO 2 NEAR MATAJI MEDICAL','DEFAULT','THANE','21','400606',NULL,'9373846503.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'318',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(319,'167',NULL,NULL,'ROYAL MEDICAL',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'8441032043.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'319',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(320,'167',NULL,NULL,'ROYAL FOOD\\\'S',5,'0','DR','MITH BANDAR ROAD','DEFAULT','THANE','21','400603',NULL,'8169893339.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'320',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(321,'167',NULL,NULL,'ROYAL DRY FRUITS',5,'0','DR','SHOP NO 2 NANDGAINKER HEIGHT OPP DUPAK GENERAL STORE UTHALSER THANE','DEFAULT','THANE','21','400601',NULL,'9867113821.0','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'321',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(322,'167',NULL,NULL,'ROSHAN DAIRY',5,'0','DR','ROAD NO 33 INDIRA NAGAR NAKA SHOP NO 8 SAVARLAR NAGAR OPP ADDARSH GENERAL STORES WAGLE EASTATE SAVARKAR NAGAR THANE','DEFAULT','THANE','21','400602',NULL,'9819808865.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'322',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(323,'167',NULL,NULL,'ROKDA DRY FOOD AND GENERAL STORE',5,'0','DR','SHOP NO 2 RAJE HOUSE EDULJI ROAD CHARAI OPPOSITE ZOROASTRIAN BANK NEAR NEW SHARMA DAIRY THANE WEST','DEFAULT','THANE','21','400601',NULL,'9820880804.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'323',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:17','2026-02-23 09:16:17'),(324,'167',NULL,NULL,'ROHIT STORE',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'8928692138.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'324',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(325,'167',NULL,NULL,'ROHIT MASALA',5,'0','DR','LOKMANYA NAGAR PADA NO 3 NEAR CHANDAN GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'8104500653.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'325',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(326,'167',NULL,NULL,'ROBIN TEA AND DRYFRUITS',5,'0','DR','SHOP NO 5 OPP NAGRIK STEEL CENTER POOJA GALI WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'9892046080.0','',NULL,'27','','','GP PARSIK SAHAKARI BANK LTD',NULL,NULL,'KHARKAR ALI','5',NULL,NULL,NULL,NULL,NULL,'326',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(327,'167',NULL,NULL,'RK DRY FRUITS',5,'0','DR','SHOP NO 04 KAMDHENU BUILDING NEAR BANK OF BARODA STATION ROAD KOPARI THANE EAST','DEFAULT','THANE','21','400602',NULL,'8425950726.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'327',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(328,'167',NULL,NULL,'RISHAB KIRANA STORE',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI NEAR NAKODA GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'8591813043.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'328',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(329,'167',NULL,NULL,'REAL SUPER MARKET',5,'0','DR','SHOP NO 14.15 SUN PLAZA HARI OM NAGAR OPPOSITE SANNIDHI PARK','NEAR BHAVANI DRY FRUIT AND GENERAL STORES KOPARI THANE EAST','THANE','21','400603',NULL,'7715988500','',NULL,'27','27AOAPG4733Q1ZN','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'329',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(330,'167',NULL,NULL,'RAVAJI KIRANA',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400603',NULL,'9969430012.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'330',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(331,'167',NULL,NULL,'RAVACHI PROVISON STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400602',NULL,'9820961115.0','',NULL,'27','27AADPZ8942M1ZR','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'331',NULL,NULL,NULL,NULL,NULL,'115160000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(332,'167',NULL,NULL,'RAVACHI GRAIN STORE',5,'0','DR','NAULADA','DEFAULT','THANE','21','400606',NULL,'7738026884.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'332',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(333,'167',NULL,NULL,'RASIKLAL KHIMJI AND SONS',5,'0','DR','SHOP NO 9,MAHATMA PHULE ROAD , NR KARIYA STORE, OPP SAWALA TRADERS WHOLSALE MARKET, THANE WEST','DEFAULT','THANE','21','400601',NULL,'9082029350.0','',NULL,'27','27AFPPC4291M1ZY','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'333',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:18','2026-02-23 09:16:18'),(334,'167',NULL,NULL,'RANE BANDHU GENERAL STORES',5,'0','DR','SHOP NO 7 SHIVAM CO OP HSG SOCIETY RAGHUNATH NAGAR NEAR KAILASH SUPER MARKET THANE W','DEFAULT','THANE','21','400606',NULL,'7232967069.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'334',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(335,'167',NULL,NULL,'RAMESHWAR DHANYA BHANDAR',5,'0','DR','DNYANESHWAR NAGAR NEAR AAIJI KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'7738579784.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'335',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(336,'167',NULL,NULL,'RAMESH MEDICAL AND GENERAL STORE',5,'0','DR','SHOP NO 1 MAHAKALI ARCT OPP RJ THAKUR COLLEGE NEAR PJ FAST FOOD CORNER SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'7023425133.0','',NULL,'27','27AUSPC8005B2ZU','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'336',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(337,'167',NULL,NULL,'RAMESH GEN',5,'0','DR','ROAD NO 28','','','21','',NULL,'9967407318','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'337',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(338,'167',NULL,NULL,'RAMESH DUGDALAYA',5,'0','DR','RAMESH NIWAS.KISAN NAGAR NO 2.NEAR A1 DRY FRUIT.NEAR LOKMANYA STORE.THANE.WEST','DEFAULT','THANE','21','400604',NULL,'7900060984.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'338',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(339,'167',NULL,NULL,'RAMDEV KIRANA STORE',5,'0','DR','SHOP NO 2 PARAMDHAM BLDG  PADWAL NAGAR NEAR PANCHPARMESHWAR MANDIR NEAR JAI AMBE GENERAL STORES THANE WEST','DEFAULT','THANE','21','400606',NULL,'8108398319.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'339',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(340,'167',NULL,NULL,'RAMDEV KIRANA AND GENERAL STORES',5,'0','DR','SHOP NO 3 OPP RJ THAKUR COLLAGE OPP GATE NO 3 MAHATMA PHULE NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9987163232.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'340',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(341,'167',NULL,NULL,'RAMDEV DAIRY AND SWEET MART',5,'0','DR','INDIAR NAGAR','DEFAULT','THANE','21','400604',NULL,'9869824622.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'341',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(342,'167',NULL,NULL,'RAM SWAMI ICECREAM CENTRE',5,'0','DR','PLOT  NO. 14 SAVARKAR NAGAR','DEFAULT','THANE','21','400606',NULL,'9619695646.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'342',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(343,'167',NULL,NULL,'RAJPUROHIT STORES',5,'0','DR','PARSEWADI NEAR PREM NAGAR GAS NEAR VITTHAL MANDIR KOPARI THANE EAST','DEFAULT','THANE','21','400602',NULL,'8355805510.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'343',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:19','2026-02-23 09:16:19'),(344,'167',NULL,NULL,'RAJESH PROVISION STORES',5,'0','DR','VARTAK NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'9987712737','',NULL,'27','27AEAPP5678K1ZX','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'344',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(345,'167',NULL,NULL,'RAJESH PROVISION STORE',5,'0','DR','DHOBI GHAT KOPRI THANE EAST','DEFAULT','THANE','21','400603',NULL,'9869984152.0','',NULL,'27','','','PNB BANK',NULL,NULL,'THANE EAST','25',NULL,NULL,NULL,NULL,NULL,'345',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(346,'167',NULL,NULL,'RAJESH KIRANA STORE',5,'0','DR','HAJURI NEAR SHABNAM KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'7021929652.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'346',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(347,'167',NULL,NULL,'RAJESH KIRANA STORE',5,'0','DR','42SANT DYANESWAR NAGAR OPP HARSH KIRANA STORE KAMGAR HOSPITAL ROAD  WAGHLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9930837053.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'347',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(348,'167',NULL,NULL,'RAJESH KIRANA AND GENERAL STORE',5,'0','DR','NEAR SHIVSENA SHAKHA, BEHIND WATER TANK, RUPADEVI PADA NO 2,RD NO 33,INDIRA NAGAR, WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400602',NULL,'8689924137.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'348',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(349,'167',NULL,NULL,'RAJENDRA GENERAL STORES',5,'0','DR','SHOP NO-5,OMKAR NIWAS,MAHATMA PHULE NAGAR,KORAS ROAD,OPP SACHIN TENDULKAR GROUND,THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'349',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(350,'167',NULL,NULL,'RAJ LAXMI KIRANA STORE',5,'0','DR','DNYANESHWAR NAGAR NEAR WELCOME TOBOCO','DEFAULT','THANE','21','400604',NULL,'9082255835.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'350',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(351,'167',NULL,NULL,'RAJ COLDDRINK CENTRE',5,'0','DR','RAGHUNATH NAGAR NEAR AMBEDKAR MATA MANDIR','DEFAULT','THANE','21','400604',NULL,'9860667434.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'351',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(352,'167',NULL,NULL,'RAHUL OIL DEPO',5,'0','DR','JIJAMATA NAGAR RAMCHANDAR NAGAR NEAR GANESH MEDICAL NEAR ASHAPURA GENERAL STORES JAJAMATA NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'9920116452.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'352',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(353,'167',NULL,NULL,'RAHEJA CONVENIENCE STORE',5,'0','DR','RAHEJA GARDEN','DEFAULT','THANE','21','400602',NULL,'9076007711.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'353',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:20','2026-02-23 09:16:20'),(354,'167',NULL,NULL,'RADHIKA GENERAL STORE',5,'0','DR','SHOP NO 2, MATRU CHAYA APARTMENT, VARTAK NAGAR, PADA NO 1,THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'354',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(355,'167',NULL,NULL,'RADHE RADHE STORE',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'8693882725.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'355',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(356,'167',NULL,NULL,'RADHE KRISHNA DAIRY',5,'0','DR','SHOP NO 7,DURVANKUR BLDG,OPP MEDTIYA MEDICAL AND GENERAL STORES NEAR PANCHPARMESHWAR MANDIR , KISAN NAGAR NO 1,WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400604',NULL,'9892575623.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'356',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(357,'167',NULL,NULL,'RADHE KISHAN SUPER MARKET',5,'0','DR','6.192.A.BHAJI MARKET NEAR SARVODAY GARDEN COPRI COLONY THANE EAST','DEFAULT','THANE','21','400603',NULL,'8879536538.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'357',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(358,'167',NULL,NULL,'RADHA KRISHNA ICECREAM AND COLDRINK CENTER',5,'0','DR','SHOP NO 4 OPP HANUMAN MANDIR NEAR SAI TRADERS RAMNAGAR ROAD 28 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'358',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(359,'167',NULL,NULL,'RADHA KRISHNA DAIRY',5,'0','DR','SHOP NO. 1 MAI KRIPA CO. OP HSG MS ROAD THANE','DEFAULT','THANE','21','400604',NULL,'8097794364.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'359',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(360,'167',NULL,NULL,'RADHA KRISHNA DAIRY',5,'0','DR','KOOARI','DEFAULT','THANE','21','400603',NULL,'8291813791.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'360',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(361,'167',NULL,NULL,'R.V. TRADER',5,'0','DR','RAGUNATH NAGAR','DEFAULT','THANE','21','400603',NULL,'8850184031.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'361',NULL,NULL,NULL,NULL,NULL,'11524000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(362,'167',NULL,NULL,'R.V. ENTERPRISES',5,'0','DR','SHOP NO.6 MATRUCHHAYA CHS OPP. AMBERGHOSALE TALAO NEAR CASTLE MILL CIRCLE OPP. SHREE NAVNATH RASVANT','DEFAULT','THANE','21','400607',NULL,'8149898548.0','',NULL,'27','27AAJPW5063E1ZF','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'362',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(363,'167',NULL,NULL,'R V MAURYA',5,'0','DR','ROAD NO 27','CP TALAO NR HANUMAN MANDIR','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'363',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:21','2026-02-23 09:16:21'),(364,'167',NULL,NULL,'R P GENERAL STORE',5,'0','DR','ROAD NO 34 OPP TMT BUS DEPO WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'7715984857','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'364',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(365,'167',NULL,NULL,'QUALITY SWEETS',5,'0','DR','BHAJI MARKET WHOLESALE JAMBLI NAKA THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27ACCPS2478N1ZY','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'365',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(366,'167',NULL,NULL,'QUALITY DRY FRUITS',5,'0','DR','KOLBAD','NR MARATHA GEN','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'366',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(367,'167',NULL,NULL,'QUALITY DRY FRUIT',5,'0','DR','WHAIOO','DEFAULT','THANE','21','400602',NULL,'9819663611.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'367',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(368,'167',NULL,NULL,'PURNIMA TREADERS',5,'0','DR','SHOP NO 3 MATRI PARK LOKMANYA NAGAR PADA NO2 OPP LAXMI  PARK POKHRAN ROAD NO1 THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'368',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(369,'167',NULL,NULL,'PURNIMA SUPER MARKET',5,'0','DR','RAMNAGAR ROAD 28 NEAR BY SAI TEMPLE NEAR RADHA KRISHNA  ICECREAM AND COLD RINK CENTRE WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'8898899641.0','',NULL,'27','','','UNION BANK OF INDIA',NULL,NULL,'WAGLE ESTATE','23',NULL,NULL,NULL,NULL,NULL,'369',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(370,'167',NULL,NULL,'PUNMIYA TRADERS',5,'0','DR','SHOP NO 1RAJAN NIWAS EDULJI ROAD TEMBHI NAKA CHARAI OPP PURVESH APT THANE WEST','DEFAULT','THANE','21','400601',NULL,'8108901053.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'370',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(371,'167',NULL,NULL,'PRITHVIRAJ CHAUHAN KIRANA STORES',5,'0','DR','SAINATH CHS NR PAWAN MEDICAL BHIM NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'9920229936.0','',NULL,'27','','','SARASWAT BANK',NULL,NULL,'034937','10',NULL,NULL,NULL,NULL,NULL,'371',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(372,'167',NULL,NULL,'PRINCE GENERAL STORE',5,'0','DR','SHOP NO 3,HUMA MANZIL, LAXMAN PATIL RD, NR NAGORI DAIRY, RABODI NO 2,THANE WEST','DEFAULT','THANE','21','400607',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'372',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(373,'167',NULL,NULL,'PRAVIN GENERAL STORE',5,'0','DR','SHOP NO.1 ANNAPURNA NIWAS. AMBEDKAR ROAD.NEAR SADGURU KRUPA JEWELLERS THANE WEST','DEFAULT','THANE','21','400601',NULL,'9892903295.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'373',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:22','2026-02-23 09:16:22'),(374,'167',NULL,NULL,'PRATIKSHA MEDICAL',5,'0','DR','INDIAR NAGAR RUPA DEVI PADA NO 1 OPP AXIX ATM','DEFAULT','THANE','21','400604',NULL,'8779761677.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'374',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(375,'167',NULL,NULL,'PRATIK',5,'0','DR','WHOSLAE','DEFAULT','THANE','21','400602',NULL,'9619665426.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'375',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(376,'167',NULL,NULL,'PRATHAMESH GENERAL STORE',5,'0','DR','KOPARI GOAN NEAR ICE FACTORY THANE EAST','DEFAULT','THANE','21','400602',NULL,'9004703462.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'376',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(377,'167',NULL,NULL,'PRASHANT SWEET CORNER',5,'0','DR','GALA NO. 14/15; JEEVAN PRAKASH SOC.., LOUISWADI, THANE (W) -  400604','DEFAULT','THANE','21','400604',NULL,'8850406427.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'377',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(378,'167',NULL,NULL,'PRASHANT GENERAL STORES',5,'0','DR','NEAR GANESH MANDIR ,SHOP NO 18,SANT DYANESHWAR NAGAR, CHAWAL NO-8, NEAR SAGAR SUPER MARKET WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'7028373681.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'378',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(379,'167',NULL,NULL,'PRAMANIK GEN STORE',5,'0','DR','KOPRI PARSHI WADI','NR JAI JANTA PROVISION','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'379',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(380,'167',NULL,NULL,'PRAKASH DEPT',5,'0','DR','VRUNDAWAN','DEFAULT','THANE','21','400606',NULL,'9167688315.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'380',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(381,'167',NULL,NULL,'PRAKASH DEPARTMENT',5,'0','DR','BRINDAVAN SOCIETY. BUILDING.NO.2A.SHOP 3AND4.NEAR LAXMI STORE.THANE WEST.','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'381',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(382,'167',NULL,NULL,'PRAFUL GENRAL STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400602',NULL,'8657345410.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'382',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(383,'167',NULL,NULL,'PRAFUL GENERAL STORE',5,'0','DR','2,PRATHAMESH, GEN A.K. VAIDYA MARG, PANCHPAKHADI, THANE WEST - 400602','DEFAULT','THANE','21','400602',NULL,'7977846455.0','',NULL,'27','27AACHJ6297C1Z6','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'383',NULL,NULL,NULL,NULL,NULL,'21520100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:23','2026-02-23 09:16:23'),(384,'167',NULL,NULL,'PRADEEP GENRAL STORE',5,'0','DR','SIDDHGIRI CHAWAL NO.48,ZYANESHWAR NAGAR,NEAR SHANKAR MANDIR, WAGLE ESTATE, THANE WEST','DEFAULT','THANE','21','400604',NULL,'9004385216.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'384',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(385,'167',NULL,NULL,'PRACHI SUPER MARKAT',5,'0','DR','ROAD NO 22 MAHARASHTRA GALLI WAGLE STREET NEAR SHRI OM AARTI DIARY THANE WEST MUMBAI','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'385',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(386,'167',NULL,NULL,'PRABHAT PROVISION STORE',5,'0','DR','SHOP NO 02 DENIS BUILDING NEXT TO SANT MERRY BAKERY OPP HOTEL BALLALESHWAR NEAR HOTEL SAI PRASAD ROAD NO 17 SAVERKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'8369148290.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'386',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(387,'167',NULL,NULL,'POONAM GENARAL STORE',5,'0','DR','KOPARI','DEFAULT','THANE','21','400604',NULL,'9967034473.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'387',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(388,'167',NULL,NULL,'POOJA SUPER MARKET',5,'0','DR','KHOPAT HANSH NAGAR','DEFAULT','THANE','21','400602',NULL,'7700061033.0','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'001875','15',NULL,NULL,NULL,NULL,NULL,'388',NULL,NULL,NULL,NULL,NULL,'11511400000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(389,'167',NULL,NULL,'POOJA SUPER MARKET',5,'0','DR','KHIPAT','DEFAULT','THANE','21','400602',NULL,'9892563924.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'389',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(390,'167',NULL,NULL,'POOJA STORE',5,'0','DR','DHANESWAR NAFAGR','DEFAULT','THANE','21','400603',NULL,'9766517356.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'390',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(391,'167',NULL,NULL,'POOJA KIRANA STORE',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400604',NULL,'7021257376.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'391',NULL,NULL,NULL,NULL,NULL,'11511400000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(392,'167',NULL,NULL,'POOJA GEN',5,'0','DR','YEOUR','','','21','',NULL,'12534567890','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'392',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(393,'167',NULL,NULL,'POOJA DRYFRUITS',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI NEAR NANDUSKAR BROTHERS','DEFAULT','THANE','21','400604',NULL,'8291691169.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'393',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:24','2026-02-23 09:16:24'),(394,'167',NULL,NULL,'PINTU OIL AND GENARAL STORE',5,'0','DR','SHANT DNYANESHWAR  NAGAR  CHWAL NO 15 ROOM NO 38 WIREMAN WADI  WAGHLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9137448704.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'394',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(395,'167',NULL,NULL,'PAYAL TRADER',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'7977144126.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'395',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(396,'167',NULL,NULL,'PAYAL OIL DEPO',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9082607928.0','',NULL,'27','27AAHPT0196K1Z7','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'396',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(397,'167',NULL,NULL,'PAYAL OIL',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9987036686.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'397',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(398,'167',NULL,NULL,'PAWAN SUPER MARKET',5,'0','DR','RAMNAGAR, HANUMAN NAGAR, NEAR WAGLE BUS DEPO','DEFAULT','THANE','21','400604',NULL,'9820450739.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'398',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(399,'167',NULL,NULL,'PAWAN MEDICAL AND GENERAL STORE',5,'0','DR','ANIL GENERAL STORE NEAR BHIM NAGAR VARTAK NAGAR','DEFAULT','THANE','21','400604',NULL,'9167301405.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'399',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(400,'167',NULL,NULL,'PAWAN KIRANA STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 4 NEAR  CHARBHUJA  STORE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'400',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(401,'167',NULL,NULL,'PAVAN DHANYA BHANDAR',5,'0','DR','SHOP NO 1,NEXT TO FAISHAL QURESHI GENERAL STORES ANAS MANSION, KATALKHANA RD, RABODI 1,NR NAKA, THANE WEST','DEFAULT','THANE','21','400607',NULL,'9819082975.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'401',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(402,'167',NULL,NULL,'PATIL KIRANA STORE',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400603',NULL,'8422019825.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'402',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(403,'167',NULL,NULL,'PATEL TRADING CO',5,'0','DR','THANE MKT','DEFAULT','THANE','21','400601',NULL,'9619121244.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'403',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:25','2026-02-23 09:16:25'),(404,'167',NULL,NULL,'PATEL SUPER MARKET',5,'0','DR','ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'8104992060.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'404',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(405,'167',NULL,NULL,'PATEL GENERAL STORE',5,'0','DR','NEAR JAI AMBE KIRANA AANAND NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'8080806922.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'405',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(406,'167',NULL,NULL,'PARKASH TRADERS OIL DEPO',5,'0','DR','LOKMANYA NAGAR PADA NO 3 NEAR JAI MALHAR AGARBATTI','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'406',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(407,'167',NULL,NULL,'PARIVAR SUPER MARKET',5,'0','DR','SHOP NO 03 SAI SABURI APARTMENT NEXT TO KISMAT POWER LAUNDRY OPP VEER HOSPITAL LANE','NEAR SMALL STEP PRE SCHOOL SAVARKAR NAGAR THANE WEST','THANE','21','400602',NULL,'8879117915','',NULL,'27','27ABSPC5936A1ZQ','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'407',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(408,'167',NULL,NULL,'PARI GENERAL STORE',5,'0','DR','SHREE NAGAR OPPOSITE TO EKVIRA FISH MARKET','DEFAULT','THANE','21','400603',NULL,'8623046084.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'408',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(409,'167',NULL,NULL,'PARDEEP MANDAP DECORATION',5,'0','DR','SHIVAJI NAGAR NEAR MOMAI GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9167171779.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'409',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(410,'167',NULL,NULL,'PARAS TRADER',5,'0','DR','WHAOALE','DEFAULT','THANE','21','400602',NULL,'8082626522.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'410',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(411,'167',NULL,NULL,'PARAS STORE',5,'0','DR','MISHRA NIWAS .SHOP NO 1.KISAN NAGAR NO 2.ROAD NO 16.NEAR LOKMANYA STORE.THANE.WEST','DEFAULT','THANE','21','400604',NULL,'8850357878.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'411',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(412,'167',NULL,NULL,'PARAS GENERAL STORE',5,'0','DR','KISHAN NAGAR NEAR LAXMI STORE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'412',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(413,'167',NULL,NULL,'PARAS GEN STORE',5,'0','DR','SAVARKAR NAGAR','NR SACHIN GEN','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'413',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:26','2026-02-23 09:16:26'),(414,'167',NULL,NULL,'PARAS GANERAL & MASALA',5,'0','DR','KISAN NAGAR NEAR RAVECHI STORE','DEFAULT','THANE','21','400606',NULL,'9820993060.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'414',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(415,'167',NULL,NULL,'PARAG MILK FOODS LTD',11,'0','CR','BHOOMI WORLD INDUSTRIAL PARK','31,32,33,34 GALA','','21','421302',NULL,'02025674761','',NULL,'27','27AABCP0425G1ZT','','',NULL,NULL,'','26',NULL,NULL,NULL,NULL,NULL,'415',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(416,'167',NULL,NULL,'PANKAJ KIRANA',5,'0','DR','KOAPRI','DEFAULT','THANE','21','400603',NULL,'8108699927.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'416',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(417,'167',NULL,NULL,'PANKAJ GENRAL STORE',5,'0','DR','KISHAN NAGAR BHATWADI','DEFAULT','THANE','21','400606',NULL,'9869768970.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'417',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(418,'167',NULL,NULL,'PANKAJ GENRAL STORE',5,'0','DR','BHATWADI','DEFAULT','THANE','21','400603',NULL,'7977683282.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'418',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(419,'167',NULL,NULL,'PALIWAL AND SONS DAIRY',5,'0','DR','NEXT TO HARI OM GENERAL STORE KISAN NAGAR 3 ROAD NO. 16 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9057239717.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'419',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(420,'167',NULL,NULL,'PADMA AGARBATTI',5,'0','DR','LOKMANYA NAGAR PADA NO 2 NEAR GIRISH SIDHHIVINKY GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'9987915184.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'420',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(421,'167',NULL,NULL,'OSWAL TRADING COMPANY',5,'0','DR','SHOP NO 1 MAHAGIRI ROAD WOLSEL MARKET THANE','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27AFPPK9826A1Z8','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'421',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(422,'167',NULL,NULL,'OMKAR AGENCY',5,'0','DR','NEAR DHYAN SADHANA COLLEGE','DEFAULT','THANE','21','400604',NULL,'9975055907.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'422',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(423,'167',NULL,NULL,'OM TRADERS',5,'0','DR','AMBIKA NAGAR NR JAGDISH','DEFAULT','THANE','21','400606',NULL,'8655547999.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'423',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:27','2026-02-23 09:16:27'),(424,'167',NULL,NULL,'OM SWEET SNACKS CORNER',5,'0','DR','SANT DNYANESHWAR NAGAR GANGADHAR NAGAR KAMGAR HOSTITAL ROAD NO 33  OPP SIDDHIVINAYAK DHANY BHANDAE T','DEFAULT','THANE','21','400604',NULL,'9892451488.0','',NULL,'27','','','DMK JAOLI BANK',NULL,NULL,'LOUISWADI','1',NULL,NULL,NULL,NULL,NULL,'424',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(425,'167',NULL,NULL,'OM SUPER MARKET',5,'0','DR','SHOP NO. 4 LOKMANYA NAGAR NEAR GANESH TEMPLE','NEXT TO SANGAM SWEETS THANE WEST','THANE','21','400604',NULL,'9082924375','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'425',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(426,'167',NULL,NULL,'OM SONU KRISHNA POOJA BHANDAR',5,'0','DR','RAMCHANDRA NAGAR NEAR SAWANT DHANYA BHANDAR','DEFAULT','THANE','21','400604',NULL,'7304128770.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'426',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(427,'167',NULL,NULL,'OM SHIVAM SUPER MARKET',5,'0','DR','SHIVAJI NAGAR NEAR BHAVNAGAR SWEET PADWAL NAGAR','DEFAULT','THANE','21','400606',NULL,'9619574471.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'427',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(428,'167',NULL,NULL,'OM SAI SUGANDHI BHANDAR',5,'0','DR','DIXIT NIWAS CHOWL SHOP NO 2 SANTI NAGAR WAGLE EASTATE OPP PRINCE MEDICAL  OPP MINI GRNERAL STORE SAN','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'428',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(429,'167',NULL,NULL,'OM SAI OIL DEPO',5,'0','DR','LOKMANYA NAGAR PADA NO 4 NEAR CHARBHUJA STORE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'429',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(430,'167',NULL,NULL,'OM SAI OIL',5,'0','DR','SHOP NO 1, OPP NAVRANG CHAWL, NEAR SHIVAJI SCHOOL, LOKMANYA NAGAR, PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'430',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(431,'167',NULL,NULL,'OM SAI MILK',5,'0','DR','SHIVAJI NAGAR','NR VISHAL GEN STORE','','21','',NULL,'9967193511','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'431',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(432,'167',NULL,NULL,'OM SAI MEDICAL',5,'0','DR','GURUKRUPA DRYFRUITS NEAR PADWAL NAGAR','DEFAULT','THANE','21','400604',NULL,'8452962734.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'432',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(433,'167',NULL,NULL,'OM SAI GENERAL STORE',5,'0','DR','ROAD NO. 16 KISAN NAGAR 2 OPP. WEMA ENGLISH SCHOOL WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'433',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:28','2026-02-23 09:16:28'),(434,'167',NULL,NULL,'OM SAI CHANA AND DRY FRUIT MART',5,'0','DR','SHOP NO 02 NEAR ADITYAWARDHAN HOSPITAL SADICHHA TOWER CASTLE MILL THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','27AMJPG7384A1Z2','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'434',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(435,'167',NULL,NULL,'OM GOSARANI GRAIN STORE',5,'0','DR','SHOP NO. 1 SHIVAJI NAGAR NEXT TO LAXMI BUHVAN THANE WEST MUMBAI','DEFAULT','THANE','21','400606',NULL,'9594196903','',NULL,'27','','','COSMOS BANK',NULL,NULL,'IMCS BRANCH','22',NULL,NULL,NULL,NULL,NULL,'435',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(436,'167',NULL,NULL,'OM  TRADERS',5,'0','DR','SHOP NO 02 NEAR SHIVANI HOSPITAL KSHITIJ BUNGALOW SHREE NAGAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27AYRPR9090E1ZO','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'436',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(437,'167',NULL,NULL,'ODHAVRAM TRADER',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400606',NULL,'9788396328.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'437',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(438,'167',NULL,NULL,'NUTAN STORE',5,'0','DR','SHOP NO 1.GOKULDASWADI.OPP SHREE GANESH DHANYA BANDAR.NEAR GUPTA KIRANA.KHOPAT .THANE.WEST','DEFAULT','THANE','21','400601',NULL,'8169595915.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'438',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(439,'167',NULL,NULL,'NITIN GROSARY',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400606',NULL,'9702450498.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'439',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(440,'167',NULL,NULL,'NITI GENERAL STORE',5,'0','DR','KAUSTUBH COOP SOCIETY VISHNU NAGAR NAUPADA THANE WEST MUMBAI','DEFAULT','THANE','21','400601',NULL,'8828333333.0','',NULL,'27','27AAUPG8496Q1ZC','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'NAUPADA','2',NULL,NULL,NULL,NULL,NULL,'440',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(441,'167',NULL,NULL,'NISAR GRAIN STORES',5,'0','DR','SHOP NO.3 ZINJA APARTMENT OPP. SHUBH HOTEL OPP. SVC BANK LBS MARG DAMANI ESTATE NAUPADA HARINIWAS CIRCLE THANE WEST THANE 400602','DEFAULT','THANE','21','400602',NULL,'9821776222.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'441',NULL,NULL,NULL,NULL,NULL,'11521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(442,'167',NULL,NULL,'NIRANJAN STORE',5,'0','DR','KOAOPR','DEFAULT','THANE','21','400603',NULL,'8355887468.0','',NULL,'27','','','TJSB SAHAKRI BANK LTD',NULL,NULL,'TILAK NAGAR','13',NULL,NULL,NULL,NULL,NULL,'442',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(443,'167',NULL,NULL,'NIKITA STORE',5,'0','DR','MAHAGIRI','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'443',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:29','2026-02-23 09:16:29'),(444,'167',NULL,NULL,'NIKIN GENERAL STORE',5,'0','DR','LOKEMANYA ALI NEAR ST JOHN SCHOOL NEAR AHILYA DEVI GARDEN CHARAI THANE WEST','DEFAULT','THANE','21','400601',NULL,'9867629269.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'444',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(445,'167',NULL,NULL,'NIKHIL DHANYA BHANDAR',5,'0','DR','RAM NAGAR SHOP NO. 5 NEAR MANSI BAR WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'445',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(446,'167',NULL,NULL,'NEW. DEVNARAYAN DAIRY',5,'0','DR','SHOP NO 1 KELA DEVI BHAVAN SHIVAJI NAGER CHECK NAKA NEAR DISOJHA WADI THANE E','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'446',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(447,'167',NULL,NULL,'NEW VISHAL TRADING',5,'0','DR','SHASTRI NAGAR SHIV SENA SKHA','DEFAULT','THANE','21','400606',NULL,'9082939584.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'447',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(448,'167',NULL,NULL,'NEW TAHILRAM KHUPCHAND PROVISIONS AND GENERAL STORES',5,'0','DR','SHOP NO_12 MAIN BAZAR KOPARI COLONY NEAR MAHAKALI FIREWORKS OPP SHANKAR BAR','NEAR KHUSHLANI ENTERPRISES THANE EAST','THANE','21','400603',NULL,'9892835775','',NULL,'27','27AANFN4723G1Z4','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'448',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(449,'167',NULL,NULL,'NEW SOCIETY DHANYA BHANDAR',5,'0','DR','SHOP NO 4B BAKERY LANE KOPARI COLONY NEAR SHIV MANDIR THANE EAST','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','27AAZPO3624K2ZY','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'449',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(450,'167',NULL,NULL,'NEW SOCIETY DHANYA BHANDAR',5,'0','DR','KISHAN NAGAR NO.02, ROAD NO.16, NEAR GUPTA OIL DEPO','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'450',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(451,'167',NULL,NULL,'NEW SIDHIVINAYAK DHANYA BHANDAR',5,'0','DR','SHOP NO 9 AND 10 D 2 RUTU PARK BLD NEAR VRINDAVAN BUS STOP THANE WEST','DEFAULT','THANE','21','400602',NULL,'9137094709.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'451',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(452,'167',NULL,NULL,'NEW SATYAM GENERAL STORE',5,'0','DR','SAATE NAGAR ROAD NO 22 INDIRA NAGAR NEXT TO UPKAR DIARY THANE WEST MUMVAI','DEFAULT','THANE','21','400604',NULL,'9930484570.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'452',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(453,'167',NULL,NULL,'NEW SAI DHANYA BHANDAR',5,'0','DR','KOAPPR','DEFAULT','THANE','21','400606',NULL,'9833818090.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'453',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:30','2026-02-23 09:16:30'),(454,'167',NULL,NULL,'NEW SAGAR SWEETS',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI HUNUMAN MANDIR','DEFAULT','THANE','21','400604',NULL,'9987691269.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'454',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(455,'167',NULL,NULL,'NEW RAMDEV KIRANA AND GENRAL',5,'0','DR','PANCHOAKADI','DEFAULT','THANE','21','400602',NULL,'8291444564.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'455',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(456,'167',NULL,NULL,'NEW RAJESH KIRANA STORE',5,'0','DR','HAJURI','DEFAULT','THANE','21','400604',NULL,'9821183466.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'456',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(457,'167',NULL,NULL,'NEW PURABJI GENERAL STORES',5,'0','DR','DHARAMVEER NAGAR NO 2 OPPOSITE MENTAL HOSPITAL NEAR DYANNSADHNA COLG THANE W','DEFAULT','THANE','21','400606',NULL,'9136345946.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'457',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(458,'167',NULL,NULL,'NEW OM SUPER MARKET',5,'0','DR','SHOP NO.2,NIL APARTMENT ,ARUN KRIDA MANDAL,NEAR GANESH GENERAL STORE OPP THANE MUNICIPAL SCHOOL YASODANAGAR,LOKMANYA NAGAR,THANE W','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'458',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(459,'167',NULL,NULL,'NEW NITIN PROVISION',5,'0','DR','SHREERANG SOCIETY.SHREERANG SHOPPING CENTRE.SHOP NO 10.BEHIND SHREERANG BUSTOP. THANE WEST.','DEFAULT','THANE','21','400602',NULL,'9892566905.0','',NULL,'27','27AFTPA1044C1ZW','','UCO BANK',NULL,NULL,'GOKUL NAGAR THANE','6',NULL,NULL,NULL,NULL,NULL,'459',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(460,'167',NULL,NULL,'NEW NEHA GENERAL STORE',5,'0','DR','SATHE NAGAR ROAD NO 22 NEAR SHIVAM DHANYA BHANDAR','DEFAULT','THANE','21','400604',NULL,'7738820585.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'460',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(461,'167',NULL,NULL,'NEW NATRAJ KIRANA AND GENARAL STORE',5,'0','DR','TRIMURTI SADAN RAMCHANDR NAGAR NO 2  CHWAL NO 22 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'461',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(462,'167',NULL,NULL,'NEW MONIKA GENRAL STORE',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'9892942472.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'462',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(463,'167',NULL,NULL,'NEW MILAN TOBACCO MART',5,'0','DR','RAMCHANDAR NAGAR 3 VAITEEWADI NEAR SAWANT TRADERS WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'9867655476.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'463',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:31','2026-02-23 09:16:31'),(464,'167',NULL,NULL,'NEW MAMTA MEDICAL',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400606',NULL,'9768093937.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'464',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(465,'167',NULL,NULL,'NEW MAHESVARI TRADERS',5,'0','DR','SHOP NO 02 HAGVANE CHWAL NEAR MASGID NEXT TO NV TRADERS KARWALO NAGAR SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'9833119972.0','',NULL,'27','27CDVPS1291R1ZA','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'465',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(466,'167',NULL,NULL,'NEW MAHARSHTRA GENERAL STORE',5,'0','DR','AMBIKA NAGAR NO 2','DEFAULT','THANE','21','400604',NULL,'7304322601.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'466',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(467,'167',NULL,NULL,'NEW MAHARASTRA TREADING STORE',5,'0','DR','NEAR JAY MA BHAVANI STORE,C.P.TALAV,ROAD NO.28,NEAR POLICE CHOWKI,THANE W','DEFAULT','THANE','21','400604',NULL,'7700004202.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'467',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(468,'167',NULL,NULL,'NEW MAHARAHTRA D. B',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400606',NULL,'9594665666.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'468',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(469,'167',NULL,NULL,'NEW KOMAL GENRAL STORE',5,'0','DR','INDIRA NAGAR NEAR UDAY FOOD','DEFAULT','THANE','21','400603',NULL,'8976149866.0','',NULL,'27','27AKHPB7180M1ZU','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'469',NULL,NULL,NULL,NULL,NULL,'21521100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(470,'167',NULL,NULL,'NEW KOMAL GENERAL STORE',5,'0','DR','SHOP NO 02 ROAD NO 22 NEAR GYANODAYA SCHOOL NEAR NEW MAHESHWARI TREDERS SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'9930649210.0','',NULL,'27','27AKHPB7180M1ZU','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'470',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(471,'167',NULL,NULL,'NEW JYOTIRLING KIRANA STORES',5,'0','DR','NEAR VALARAM TRADERS SAVARKAR NAGAR','DEFAULT','THANE','21','400606',NULL,'9321834787.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'471',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(472,'167',NULL,NULL,'NEW JASRAJ GENRAL STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400602',NULL,'9892778316.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'472',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:32','2026-02-23 09:16:32'),(473,'167',NULL,NULL,'NEW JASRAJ GENERAL STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400603',NULL,'9619559970.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'473',NULL,NULL,NULL,NULL,NULL,'1151140000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(474,'167',NULL,NULL,'NEW JANTA SUPER MARKET',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400602',NULL,'7715993072.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'474',NULL,NULL,NULL,NULL,NULL,'11517000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(475,'167',NULL,NULL,'NEW JANTA',5,'0','DR','SHOP NO 6BHANU CO SOCIETY OPP SAHIL HOSPITAL KHOPAT THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27AAQPB5980Q1ZU','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'475',NULL,NULL,NULL,NULL,NULL,'11516000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(476,'167',NULL,NULL,'NEW JALARAM TRADERS',5,'0','DR','MITHBANDAR ROAD NEAR RAVIKIRAN CLINIC  NEXT BHAWANI MEDICAL NEAR  ICICI BANK ATM THANE 400601','DEFAULT','THANE','21','400602',NULL,'8655770904.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'476',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(477,'167',NULL,NULL,'NEW JAIN GENRAL STORE',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400603',NULL,'9870157344.0','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'NAUPADA','14',NULL,NULL,NULL,NULL,NULL,'477',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(478,'167',NULL,NULL,'NEW JAGDISH KIRANA STORE',5,'0','DR','AMBIKA NAGAR NO 2 NEAR JAI AMBE STORE','DEFAULT','THANE','21','400604',NULL,'9702220869.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'478',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(479,'167',NULL,NULL,'NEW DEEPA PROVISION STORE',5,'0','DR','SHOP NO 4,SANT DAYA NIWAS PADA NO 02 YASHODHAN NAGAR LOKMANYA NAGAR NEAR  SHANKAR MANDIR THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'479',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(480,'167',NULL,NULL,'NEW BOMBAY GENRAL STORE',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'9819909032.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'480',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(481,'167',NULL,NULL,'NEW BOMBAY GENERAL STORE',5,'0','DR','KOPARI KOLIWADA','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'481',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(482,'167',NULL,NULL,'NEW APNA KIRANA',5,'0','DR','PANCH','DEFAULT','THANE','21','400606',NULL,'8097093805.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'482',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:33','2026-02-23 09:16:33'),(483,'167',NULL,NULL,'NEW ANJUM KIRANA AND GENRAL STORE',5,'0','DR','RABODO','DEFAULT','THANE','21','400602',NULL,'7678033113.0','',NULL,'27','','','NKGSB COOP BANK',NULL,NULL,'VIKAS COMPEX','6',NULL,NULL,NULL,NULL,NULL,'483',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(484,'167',NULL,NULL,'NEW  REKHA GENERAL STORE',5,'0','DR','SHOP NO 1.NUTAN JEEVAN SOCIETY.TEKDI BUNGLOW.NEAR KALPESH STORE.PANCHPAKDI.THANE WEST.','DEFAULT','THANE','21','400602',NULL,'9819094914.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'484',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(485,'167',NULL,NULL,'NEELAM STORE',5,'0','DR','NR MANISHA SUPER MARKET','RAM NAGAR','','21','',NULL,'9969051408','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'485',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(486,'167',NULL,NULL,'NEELAM GANERAL',5,'0','DR','PADWAL NAGAR NEAR ASHOK TRADAR','DEFAULT','THANE','21','400606',NULL,'9769457852.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'486',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(487,'167',NULL,NULL,'NAVRANG STORE',5,'0','DR','PANCH PAKADI','DEFAULT','THANE','21','400606',NULL,'9619976699.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'487',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(488,'167',NULL,NULL,'NAVDURGA KIRANA STORE',5,'0','DR','SHATHE NAGAR INDIRA NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'488',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(489,'167',NULL,NULL,'NAVDURGA GENERAL STORE',5,'0','DR','SHOP NO 1.ROAD NO 16.WAGLE ESTATE.KISAN NAGAR.NEAR A1 DRY FRUIT .THANE.WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'489',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(490,'167',NULL,NULL,'NATIONAL TREDARS',5,'0','DR','INDRA NAGAR NAKA,OPP.DEV DARSHAN APARTMENT,THANE W','DEFAULT','THANE','21','400604',NULL,'7039877318.0','',NULL,'27','27ACCPF0430B1ZK','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'490',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(491,'167',NULL,NULL,'NATIONAL TRADERS',5,'0','DR','INDIRA NAGAGR','DEFAULT','THANE','21','400606',NULL,'7208609555.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'491',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(492,'167',NULL,NULL,'NATIONAL MEDICAL AND GENERAL STORE',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'8879718253.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'492',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:34','2026-02-23 09:16:34'),(493,'167',NULL,NULL,'NATIONAL DAIRY FARM',5,'0','DR','SHOP NO.1 ISMAILYA BUILDING OPP.LAZIZ CHINESE  K. K. ROAD NEAR SUNNI CIRCLE  MASJID RABODI 1 THANE W','DEFAULT','THANE','21','400607',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'493',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(494,'167',NULL,NULL,'NARKAR KIRANA',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'9322644608.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'494',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(495,'167',NULL,NULL,'NARESH GEN STORE',5,'0','DR','SHIVAI NAGAR','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'495',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(496,'167',NULL,NULL,'NARAYAN DAIRY',5,'0','DR','LIME VILLA ROAD NO 28 SHANTI NAGAR WAGLE ESTATE THANE WEST OPPOSITE SHREE KAALA GRAIN','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'496',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(497,'167',NULL,NULL,'NANDUSKAR BROTHERS',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI NEAR SHAH RAMESH GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9004888755.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'497',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(498,'167',NULL,NULL,'NANDKUMAR GENRAL STORE',5,'0','DR','VRINDAEAN','DEFAULT','THANE','21','400606',NULL,'9867198228.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'498',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(499,'167',NULL,NULL,'NANA MASALA',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400603',NULL,'9969562329.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'499',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(500,'167',NULL,NULL,'NAMRATA GENRAL STORE',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9867589961.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'500',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(501,'167',NULL,NULL,'NAKODA GENERAL STORE',5,'0','DR','SHOP NO 01 SAIDHAM CHL SAI BABA MANDIR RAMCHANDRA NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9137813223.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'501',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(502,'167',NULL,NULL,'NAGRIYA DHANYA BHANDAR',5,'0','DR','SHIVMURTI CHORASIYA CHAWAL OPP SAJAN MEHDI BEUTI CENTER OPP OM SAI GENERAL STORE NEAR PAWAN MEDICAL GENERAL STORES SAVARKAR NAGAR THANE','DEFAULT','THANE','21','400602',NULL,'9987507912.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'502',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:35','2026-02-23 09:16:35'),(503,'167',NULL,NULL,'NAGRIK DHANYAN BHANDAR',5,'0','DR','SHOP NO 12 KISAN NAGAR 2 WAGLE ESTATE OPP GUPTA OIL DEPOT THANE WEST','DEFAULT','THANE','21','400604',NULL,'9967493368.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'503',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(504,'167',NULL,NULL,'NAGRIK DHANYA BHANDAR',5,'0','DR','SHOP NO. 1 GHANTALI ROAD OPP. JAI MATA JI CHANA BHANDAR NEAR SATYAM COLLECTION THANE WEST','DEFAULT','THANE','21','400602',NULL,'1234567890','',NULL,'27','27AAUFN1463E1Z2','','HDFC BANK',NULL,NULL,'TALAOPALI','14',NULL,NULL,NULL,NULL,NULL,'504',NULL,NULL,NULL,NULL,NULL,'11522100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(505,'167',NULL,NULL,'NAGNESHI STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'7039133801.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'505',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(506,'167',NULL,NULL,'NAGNESHI D. B.',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9987042735.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'506',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(507,'167',NULL,NULL,'NAGESHI TRADERS',5,'0','DR','DYANESHWAR NAGAR','NT JYOTIRLING  S/M','','21','',NULL,'7039133801','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'507',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(508,'167',NULL,NULL,'NADEEM KIRANA',5,'0','DR','K VILLA','DEFAULT','THANE','21','400603',NULL,'9555726407.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'508',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(509,'167',NULL,NULL,'N. M  TRADER',5,'0','DR','INDIRA NAGAR','DEFAULT','THANE','21','400606',NULL,'9930485959.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'509',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(510,'167',NULL,NULL,'MURLI KIRANA STORES',5,'0','DR','SHOP NO 9 RASHMI APPT MITHBHUNDER ROAD OPP I H PIPE','CHENDANI KOLIWAD NEAR TO SIDDIVINAYAK MANDIR THANE  400603','THANE','21','400602',NULL,'1234567890','',NULL,'27','27ADQPC3378L1Z1','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'510',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(511,'167',NULL,NULL,'MURLI KIRANA STORE',5,'0','DR','KOPARI','DEFAULT','THANE','21','400602',NULL,'9833368114.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'511',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(512,'167',NULL,NULL,'MURLI KIRANA',5,'0','DR','KOOARI','DEFAULT','THANE','21','400606',NULL,'9769649609.0','',NULL,'27','','','TJSB SAHAKARI BANK LTD',NULL,NULL,'510848','13',NULL,NULL,NULL,NULL,NULL,'512',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:36','2026-02-23 09:16:36'),(513,'167',NULL,NULL,'MUMBAI PAN SHOP',5,'0','DR','RAMCHANDRA NAGAR NEAR WINE SHOP','DEFAULT','THANE','21','400604',NULL,'7045449380.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'513',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(514,'167',NULL,NULL,'MUMBAI DRYFRUITS',5,'0','DR','SHOP NO.2 MONALISA SHOPPING CENTRE NEXT TO NATURAL CHEMIST HATINIWAS CIRCLE NAUPADA OLD AGRA ROAD THANE WEST 400602','DEFAULT','THANE','21','400602',NULL,'9930367399.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'514',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(515,'167',NULL,NULL,'MUKESH SUPER MART',5,'0','DR','VARTAK NAGAR','','THANE','21','400606',NULL,'9860985988','',NULL,'27','27AFPPG8712F2ZA','','1',NULL,NULL,'1','19',NULL,NULL,NULL,NULL,NULL,'515',NULL,NULL,NULL,NULL,NULL,'11525014000187','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(516,'167',NULL,NULL,'MUKESH SUPER MART',5,'0','DR','SHOP NO.6,7 RAJSHREE DHAM NEAR PRATAP CINEMA  KOLBAD ROAD NEAR TAKKAR SUPER MARKET','DEFAULT','THANE','21','400601',NULL,'9321300311.0','',NULL,'27','27CODPS9034P1Z4','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'516',NULL,NULL,NULL,NULL,NULL,'11517000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(517,'167',NULL,NULL,'MUKESH GENERAL STORE',5,'0','DR','KISHAN NAGAR, BHATWADI NEAR GURUKRUPA STORE','DEFAULT','THANE','21','400604',NULL,'9619056980.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'517',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(518,'167',NULL,NULL,'MUKESH GENERAL STORE',5,'0','DR','SHOP NO. 3 DHANLAXMI BLDG NEAR GURU KRUPA GENERAL STORE BHAT WADI KISAN NAGAR 3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'518',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(519,'167',NULL,NULL,'MRUNAL GENERAL STORES',5,'0','DR','SHOP NO-1,SHAHU SMRUTI BUILDING,MATMA PHULE NAGAR,BEHIND SACHIN TENDULKAR GRND THANE WEST','DEFAULT','THANE','21','400604',NULL,'8828067274.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'519',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(520,'167',NULL,NULL,'MR GENERAL STORES',5,'0','DR','AMBEWADI INDIRANAGAR BHAJI MARKET NEAR MEERA MEDICAL THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'520',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(521,'167',NULL,NULL,'MOTHER DAIRY',5,'0','DR','DNYANESHWAR NAGAR NEAR HARSH KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'8767949143.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'521',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(522,'167',NULL,NULL,'MOMAI TRADERS',5,'0','DR','KOLBAD','NR CKT ENTERPRISES','THANE','21','400603',NULL,'9321300311','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'522',NULL,NULL,NULL,NULL,NULL,'21525014001260','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:37','2026-02-23 09:16:37'),(523,'167',NULL,NULL,'MOMAI GENERAL STORE',5,'0','DR','GYANHOME BLDG.SHOP NO 3 SHIVAJI NAGER NEAR SHREE RAM ICECRIM SHOP WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'9967916954.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'523',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(524,'167',NULL,NULL,'MITHILESH MILK CENTER',5,'0','DR','INDAR NAGAR BHAJI MARKET','DEFAULT','THANE','21','400605',NULL,'9167403745.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'524',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(525,'167',NULL,NULL,'MISHRA KIRANA',5,'0','DR','AZAD NAGAR NR LAXMI KIRANA','','','21','',NULL,'9004704793','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'525',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(526,'167',NULL,NULL,'MISHRA DAIRY FARM',5,'0','DR','SANT DHYANESHWAR NAGAR WIREMAN WADI CHAWL BESIDE PANCH PARMESHWAR MANDIR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9594032493.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'526',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(527,'167',NULL,NULL,'MINI SUPER MARKET',5,'0','DR','SHANTI NAGAR','DEFAULT','THANE','21','400604',NULL,'9969308007.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'527',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(528,'167',NULL,NULL,'MINI GENERAL STORES',5,'0','DR','SHOP NO 3 PRABHAVTI CHHOTELA SHARAMA NIWAS ROAD NO 27  SHANTI NAGER WAGLE ESTATE NEAR VARA GENERAL STORES','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'528',NULL,NULL,NULL,NULL,NULL,'11521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(529,'167',NULL,NULL,'MINAKSHI TRADING',5,'0','DR','WHSISOS','DEFAULT','THANE','21','400602',NULL,'9821333337.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'529',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(530,'167',NULL,NULL,'MINA BARNBAL ARRYE 296',5,'0','DR','OPP.JARIMARI MANDIR,GOKUL NAGAR,THANE (W)','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'530',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(531,'167',NULL,NULL,'MILAN TRADER',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'7991934087.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'531',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(532,'167',NULL,NULL,'MILAN TOBACO',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9867124679.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'532',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:38','2026-02-23 09:16:38'),(533,'167',NULL,NULL,'MILAN PROVISION STORE',5,'0','DR','SHOP NO 3  MAN BAZAR  KOPARI.NEAR LADHARAM NARAYANDAS KIRENA AND STORE.','DEFAULT','THANE','21','400603',NULL,'9322487745.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'533',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(534,'167',NULL,NULL,'MILAN MEDICAL STORE',5,'0','DR','RAMNAGAR ROAD NO.28 NEAR NEW MAHARASHTRA GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'7738758968.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'534',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(535,'167',NULL,NULL,'MILAN KIRANA STORE',5,'0','DR','GOKUL NAGAR NEAR LAXMI KIRANA STORE KE BAJU ME','DEFAULT','THANE','21','400606',NULL,'9967546931.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'535',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(536,'167',NULL,NULL,'METRO MEDICAL',5,'0','DR','SHASTRI NAGAR NEAR VISHAL SUPER MARKET','DEFAULT','THANE','21','400605',NULL,'9833511286.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'536',NULL,NULL,NULL,NULL,NULL,'302405000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(537,'167',NULL,NULL,'METRO MDICAL',5,'0','DR','B CABIN RODA','DEFAULT','THANE','21','400603',NULL,'9967691822.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'537',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(538,'167',NULL,NULL,'METRO CHEMIST',5,'0','DR','LADHRAM KIRANA STORE NEAR KOPRI BHAJI MARKET','DEFAULT','THANE','21','400603',NULL,'9139476514.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'538',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(539,'167',NULL,NULL,'MEET TRADING',5,'0','DR','SHOP NO 2 SWASTIK TOWERNEAR NIKITA STORE THANE WHOLSALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'1234567890','',NULL,'27','27ALQPB5477R1Z5','','GP PARSIK BANK',NULL,NULL,'KHARKAR ALI','5',NULL,NULL,NULL,NULL,NULL,'539',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(540,'167',NULL,NULL,'MEENAL MEDICAL',5,'0','DR','INDIAR NAGAR RUPA DEVI TEKARI PADA NO 2','DEFAULT','THANE','21','400604',NULL,'9892737938.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'540',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(541,'167',NULL,NULL,'MEENA PROVISION STORE',5,'0','DR','JAYANAND SOCIETY KOPRI ROAD NAUPADA WEST NEAR TIMES OF INDIA OFFICE THANE','DEFAULT','THANE','21','400602',NULL,'9137659937.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'541',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(542,'167',NULL,NULL,'MAZE KITCHEN',5,'0','DR','VRUNDAEAN','DEFAULT','THANE','21','400602',NULL,'9987772990.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'542',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:39','2026-02-23 09:16:39'),(543,'167',NULL,NULL,'MAYUR GENRAL',5,'0','DR','GAODEVI','DEFAULT','THANE','21','400602',NULL,'9869750276.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'543',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(544,'167',NULL,NULL,'MAYA GENERAL STORES',5,'0','DR','ROAD NO. 27 C.P. TALAW OPP. DEEPALI GENERAL STORE WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9867164076.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'544',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(545,'167',NULL,NULL,'MAYA DHANYA BHANDAR',5,'0','DR','SHOP NO 2 NEAR CHANDAN DRYFRUITS AND SNACKS CORNER OPP MOHIT MASALA MART LOKMANYA NAGAR PADA NO 3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'9819884153.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'545',NULL,NULL,NULL,NULL,NULL,'21521100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(546,'167',NULL,NULL,'MAVIS MEDICAL & GENERAL STORE',5,'0','DR','SHOP NO.4,SWARGANDHA SOCIETY, OPPOSITE SHIVANI HOSPITAL, SHREE NAGAR, THANE','DEFAULT','THANE','21','400604',NULL,'9594097879.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'546',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(547,'167',NULL,NULL,'MAURYA KIRANA STORE',5,'0','DR','INDIAR NAGAR RUPA DEVI PADA NO 1 NEAR SANTOSH KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'9920451597.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'547',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(548,'167',NULL,NULL,'MAURYA GINER STORE',5,'0','DR','RAMCHANDRA NAGAR NEAR MAMTA KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'9969496416.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'548',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(549,'167',NULL,NULL,'MAURYA BHAJI AND GENERAL STORE',5,'0','DR','RAMCHANDRA NAGAR NEAR SWAMI MILK','DEFAULT','THANE','21','400604',NULL,'9819890931.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'549',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(550,'167',NULL,NULL,'MAULI PROVISION STORES',5,'0','DR','OPP PUNJAB NATIONAL BANK NEXT TO GUPTA PAN SHOP GONDAVI BUS STOP NAUPADA THANE WEST','DEFAULT','THANE','21','400601',NULL,'9819941295.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'550',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(551,'167',NULL,NULL,'MAULI MASALA',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'9892975428.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'551',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(552,'167',NULL,NULL,'MAULI KIRANA STORES',5,'0','DR','ROOM NO. 811 CHITAMANI CORNER  KHANDESH CHAWL NEAR MAHA LAXMI GENERAL STORE LOKMANYA NAGAR PADA NO.3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27AVLPP2137P1ZX','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'552',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:40','2026-02-23 09:16:40'),(553,'167',NULL,NULL,'MAUJI VELJI SHAH KIRANA STORE',5,'0','DR','GOLMOHAR BLDG B WING GROUND FLOOR SHOP NO 7 PATIL WADI SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9372892373.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'553',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(554,'167',NULL,NULL,'MATOSHREE WHOSALE AND GENRAL',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400603',NULL,'9326321319.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'554',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(555,'167',NULL,NULL,'MATAJI SUPER MARKET',5,'0','DR','RAMCHANDRA NAGAR NEAR LAXMI PROVISION STORE','DEFAULT','THANE','21','400604',NULL,'9969502862.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'555',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(556,'167',NULL,NULL,'MATAJI SUPER MARKET',5,'0','DR','SHOP NO. 1 GROUND FLOOR ZABINA ESTATE HAJURI DARGAH ROAD OPP. PRINCE JEWELLERS THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'556',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(557,'167',NULL,NULL,'MATAJI KIRANA STORE',5,'0','DR','GOKUL NAGAR AZAD NAGAR CHARAI','DEFAULT','THANE','21','400601',NULL,'9987664124.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'557',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(558,'167',NULL,NULL,'MATAJI KIRANA STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 4 NEAR SHREE KRISHNA DAIRY','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'558',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(559,'167',NULL,NULL,'MARUTI SUPER MARKET',5,'0','DR','LOKMANYA NAGAR','DEFAULT','THANE','21','400606',NULL,'9819617950.0','',NULL,'27','27ADZPC2722K1Z8','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'559',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(560,'167',NULL,NULL,'MARUTI GENRAL STORE',5,'0','DR','SAWARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9137249162.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'560',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(561,'167',NULL,NULL,'MARUTI GENERAL STORE',5,'0','DR','SHIVAJI NAGAR NEAR ASHAPURA OIL DEPO','DEFAULT','THANE','21','400604',NULL,'8097409844.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'561',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(562,'167',NULL,NULL,'MARU GENERAL STORE',5,'0','DR','SHOP NO. B4 VIJAY APT KISHAN NAGAR 1 WAGELE STATE THANE WEST MUMBAI','DEFAULT','THANE','21','400606',NULL,'9820805467.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'562',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:41','2026-02-23 09:16:41'),(563,'167',NULL,NULL,'MARU DRYFRUIT',5,'0','DR','NR YASH GEN STORE','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'563',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(564,'167',NULL,NULL,'MARATHA GEN STORE',5,'0','DR','KOLBAD','NR QUALITY D/F','','21','',NULL,'1234567890','',NULL,'27','','','TJSB SAHAKARI BANK LTD',NULL,NULL,'POKRAN ROAD NO1','24',NULL,NULL,NULL,NULL,NULL,'564',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(565,'167',NULL,NULL,'MANSI DAIRY',5,'0','DR','HANUMAN NAGAR OPPOSITE CNG PUMP NEAR CHAPPAN BHOG SWEETS NEAR JAI BHAVANI SWEETS ROAD NO 34 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'565',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(566,'167',NULL,NULL,'MANSHUK STORES',5,'0','DR','NEAR JANTA STORES BHAJI MARKET WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'9867091002.0','',NULL,'27','27ACAPS4490A1ZR','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'566',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(567,'167',NULL,NULL,'MANOJ KIRANA STORE',5,'0','DR','INDIRA NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'567',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(568,'167',NULL,NULL,'MANOJ GENERAL STORE',5,'0','DR','RAJESH KIRANA STORE NEAR INDIRA NAGAR RUPA DEVI TEKARI PADA NO 2','DEFAULT','THANE','21','400604',NULL,'7977725522.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'568',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(569,'167',NULL,NULL,'MANOHARLAL MOTUMAL PROVISION STORE',5,'0','DR','SHOP  6 MEN BAZAR KOPARI COLONY.NEAR MILAN PROVISION STORE.  THANE EAST','DEFAULT','THANE','21','400603',NULL,'7039819862.0','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'569',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(570,'167',NULL,NULL,'MANISHA SUPER MARKET',5,'0','DR','RAMNAGAR JUNA GAON, NEAR KRISHNA SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'7738808460.0','',NULL,'27','','','ABHUDAYA COP BANK',NULL,NULL,'LOKMANYA NAGAR','23',NULL,NULL,NULL,NULL,NULL,'570',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(571,'167',NULL,NULL,'MANISHA GENERAL STORE',5,'0','DR','RAMESHWAR SADAN GANESH CHAUK BHATWADI ROAD KISAN NAGER NO 3 THANE W','DEFAULT','THANE','21','400604',NULL,'9004388725.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'571',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(572,'167',NULL,NULL,'MANISH MARKET',5,'0','DR','RAGUNATH NAGAR','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'572',NULL,NULL,NULL,NULL,NULL,'11520000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:42','2026-02-23 09:16:42'),(573,'167',NULL,NULL,'MANIBHADRA DRY FRUITS',5,'0','DR','SHOP NO 1 RAJESH BHAVAN  KISHAN NAGAR  NO 1 OPP YASH GENARAL STORE  WAGHLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'573',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(574,'167',NULL,NULL,'MANIBADRA ENTERPRISES',5,'0','DR','GALA -1, SUNFLOWER TOWER','CIDCO ROAD','THYANE WEST','21','400601',NULL,'7977758565','',NULL,'27','27ABIPT2778B1ZF','','ICICI BANK',NULL,NULL,'BANDRA','5',NULL,NULL,NULL,NULL,NULL,'574',NULL,NULL,NULL,NULL,NULL,'11519014000437','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(575,'167',NULL,NULL,'MANGO MEDICAL',5,'0','DR','B CABIN ROAD','DEFAULT','THANE','21','400603',NULL,'9136630191.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'575',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(576,'167',NULL,NULL,'MANGLE TEA',5,'0','DR','WHOSLAE','DEFAULT','THANE','21','400602',NULL,'9869194996.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'576',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(577,'167',NULL,NULL,'MANE COMUNICATION',5,'0','DR','22 NO.CURCLE','DEFAULT','THANE','21','400604',NULL,'9820578106.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'577',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(578,'167',NULL,NULL,'MAMTA SUPER MARKAT',5,'0','DR','LAXMI PARK SHOP NEAR THAKUR BUNGALOW SHOP BESIDES PURNIMA  TRADERS LOKMANYA NAGAR PADA NO 2 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'578',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(579,'167',NULL,NULL,'MAMTA MEDICAL AND GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 2 LADKDI POOL NEAR ASHAPURA SUPER MARKET','DEFAULT','THANE','21','400606',NULL,'9987377557.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'579',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(580,'167',NULL,NULL,'MAMTA KIRANA STORES',5,'0','DR','SHOP NO 9 SHREE JIJAMATA NAGAR GRIAHNIRMAN SANSTHA NEAR SWAMI MILK CENTER JIJAMATA NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'8097808893.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'580',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(581,'167',NULL,NULL,'MAMTA KIRANA STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 4 NEAR SHIVAJI RAJE  SCHOOL','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'581',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(582,'167',NULL,NULL,'MAMTA KIRANA',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9702672945.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'582',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:43','2026-02-23 09:16:43'),(583,'167',NULL,NULL,'MAMTA KIRANA',5,'0','DR','RAMCHNADRA NAGAR','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'583',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(584,'167',NULL,NULL,'MAMTA DARIY AND GENERAL STORE',5,'0','DR','SHIVAJI NAGAR NEAR VISHAL GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9820026402.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'584',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(585,'167',NULL,NULL,'MAMTA CATRESS',5,'0','DR','GAODEVI','DEFAULT','THANE','21','400603',NULL,'8691811118.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'585',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(586,'167',NULL,NULL,'MAMATA PROVISION STORE',5,'0','DR','SHOP NO 3,ROAD NON 28 KAILASH NAGAR, NEAR ITI CIRCLE, WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400606',NULL,'9769526916.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'586',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(587,'167',NULL,NULL,'MALLESHWAR DHANYA BHANDAR',5,'0','DR','NR SIDDESHWAR TALAV','','','21','',NULL,'8652194504','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'587',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(588,'167',NULL,NULL,'MALDE STORES',5,'0','DR','SANT GHANESHWAR NAGAR GANGADHAR NAGAR NEAR SHIVSENA SAKHA ROAD NO 33 WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'8097132731.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'588',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(589,'167',NULL,NULL,'MAHESHWARI OIL TRADERS',5,'0','DR','GALA NO 4,LAXMI COMPLEX, POKHRAN RD NO 1,BESIDE TJSB BANK','VARTAK NAGAR, THANE WEST','THANE','21','400606',NULL,'9321762829','',NULL,'27','27AIOPP0527F1Z7','','TJSB SHAKARI BANK LTD',NULL,NULL,'VARTAK NAGAR','19',NULL,NULL,NULL,NULL,NULL,'589',NULL,NULL,NULL,NULL,NULL,'11516014001213','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(590,'167',NULL,NULL,'MAHESH TRADERS',5,'0','DR','SHOP NO 1 VASANT VIHAR BLDG OPP RJ THAKUR COLLEGE MAHATMA PHULE NAGAR NEAR LAXMI TRADERS THANE WEST','DEFAULT','THANE','21','400604',NULL,'9892784197.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'590',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(591,'167',NULL,NULL,'MAHESH SWEETS AND GENERAL STORE',5,'0','DR','HANUMAN NAGAR','DEFAULT','THANE','21','400604',NULL,'8433506048.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'591',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(592,'167',NULL,NULL,'MAHESH KIRANA AND GENERAL STORES',5,'0','DR','HANUMAN NAGAR ROAD NO 34 BEHIND SARAI COMPANY NEAR HARI OM DAIRY WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'592',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:44','2026-02-23 09:16:44'),(593,'167',NULL,NULL,'MAHAVIR SWEET CORNER',5,'0','DR','UTTAM BUILDING VISHNU NAGAR NEAR OPP NITI SUPER MARKET NAUPADA MUMBAI','DEFAULT','THANE','21','400601',NULL,'7738593034.0','',NULL,'27','27ALIPC5883G1ZX','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'593',NULL,NULL,NULL,NULL,NULL,'11522100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(594,'167',NULL,NULL,'MAHAVIR STORE CHARAI',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'8291171740.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'594',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(595,'167',NULL,NULL,'MAHAVIR CHANA CENTRE',5,'0','DR','VARTAK NAGAR NAKA OPP MAHANAGAR BANK POKHARAN ROAD NO 1 THANE WEST','DEFAULT','THANE','21','400606',NULL,'8425028050.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'595',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(596,'167',NULL,NULL,'MAHAVEER SUPER MARKET',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400606',NULL,'9892513303.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'596',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(597,'167',NULL,NULL,'MAHAVEER STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'9987918852.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'597',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(598,'167',NULL,NULL,'MAHAVEER OIL AND GENERAL STORE',5,'0','DR','SHOP NO 01 DHUMAL CHL SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'9967154822.0','',NULL,'27','','','BANK OF MAHARASTRA',NULL,NULL,'VARTAK NAGAR','8',NULL,NULL,NULL,NULL,NULL,'598',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(599,'167',NULL,NULL,'MAHAVEER MEDICAL',5,'0','DR','INDIAR NAGAR RUPA DEVI PADA NO 1 NEAR HIRA GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'8879045144.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'599',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(600,'167',NULL,NULL,'MAHAVEER GENRAL STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400603',NULL,'9820361072.0','',NULL,'27','','','GREATER BANK',NULL,NULL,'PANCH PAKHADI','14',NULL,NULL,NULL,NULL,NULL,'600',NULL,NULL,NULL,NULL,NULL,'11521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(601,'167',NULL,NULL,'MAHAVEER GENRAL',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9987454811.0','',NULL,'27','','','KOKAN MERCHANTILE',NULL,NULL,'RABODI','6',NULL,NULL,NULL,NULL,NULL,'601',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(602,'167',NULL,NULL,'MAHAVEER GENRAL',5,'0','DR','KOPAR','DEFAULT','THANE','21','400603',NULL,'8320036087.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'602',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:45','2026-02-23 09:16:45'),(603,'167',NULL,NULL,'MAHARASTRA MEDICAL',5,'0','DR','DYANESHWAR NAGAR','OPP AAIJI KIRANA','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'603',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(604,'167',NULL,NULL,'MAHARASTRA MASHALA',5,'0','DR','SHOP NO 9 SHIV DARSAN APARMENT RAMCHANDRA NAGAR NO 2 THANE WEST','DEFAULT','THANE','21','400604',NULL,'8779114252.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'604',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(605,'167',NULL,NULL,'MAHARASTRA GEN STORE',5,'0','DR','LAKDI POOL','PADA NO 3','','21','',NULL,'9920953422','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'605',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(606,'167',NULL,NULL,'MAHARASTRA DRYFRUIT',5,'0','DR','HANS NAGAR','NR POOJA SUPER MARKET','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'606',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(607,'167',NULL,NULL,'MAHARASTRA DHANYA BHANDAR',5,'0','DR','HANS NAGAR NR POOJA SUPER MARKET','','','21','',NULL,'1234567890','',NULL,'27','','','KARUR VYASA BANK',NULL,NULL,'TEEN HATH NAKA','24',NULL,NULL,NULL,NULL,NULL,'607',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(608,'167',NULL,NULL,'MAHARASHTRA TEA DEPO',5,'0','DR','SAWARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9833269742.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'608',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(609,'167',NULL,NULL,'MAHARASHTRA SOCIETY',5,'0','DR','SHOP NO 2 NEAR JAI MAA BHAVANI DHANYA BHANDAR CP TALA NAKA ROAD NO27 WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'609',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(610,'167',NULL,NULL,'MAHARASHTRA GENERAL STORES',5,'0','DR','OPP CIVIL HOSPITAL TEMBHI NAKA THANE W','DEFAULT','THANE','21','400601',NULL,'9004967768.0','',NULL,'27','27ABUPV3458N1ZH','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'610',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(611,'167',NULL,NULL,'MAHARASHTRA GENERAL STORE',5,'0','DR','SHOP NO 5 OPP RJ THAKUR COLLAGE MAHTMA PHULE NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9167125646.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'611',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(612,'167',NULL,NULL,'MAHARASHTRA DHANYA BHANDAR',5,'0','DR','SHOP NO 1,BHAJI MARKET, SHIVAJI MAIDAN, WHOLSALE MARKET, THANE WEST','DEFAULT','THANE','21','400601',NULL,'9820680570.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'612',NULL,NULL,NULL,NULL,NULL,'27EXFS866K1ZQ','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:46','2026-02-23 09:16:46'),(613,'167',NULL,NULL,'MAHARAJA SOCIETY',5,'0','DR','OPP SHIV SENA SHAKHA RAM NAGER ROAD NO 28 WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'8425006237.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'613',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(614,'167',NULL,NULL,'MAHALXMI KIRANA ANDGENERAL STORE',5,'0','DR','SHOP NO 3,DHARMVEER CHAWL,NR KAILASH STORE, SHANTI NAGAR, RD NO 28,WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'614',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(615,'167',NULL,NULL,'MAHALAXMI TRADERS',5,'0','DR','AZAD NAGAR NO.2 JARIMARI MANDIR NEAR TRUPTI GENERAL STORE GOKUL NAGAR THANE WEST','DEFAULT','THANE','21','400601',NULL,'8291601080.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'615',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(616,'167',NULL,NULL,'MAHALAXMI TRADERS',5,'0','DR','AZAD NAGAR GOKUL NAGAR NEAR LAXMI KIRANA STORE','DEFAULT','THANE','21','400601',NULL,'7400327474.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'616',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(617,'167',NULL,NULL,'MAHALAXMI SUPER MARKET',5,'0','DR','SHOP 3 ADINATH APARTMENT KAMGHAR HOSPITAL ROAD OPP KRISHNA SWEETS RAMCHANDRA NAGAR NO 1THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'617',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(618,'167',NULL,NULL,'MAHALAXMI SUPER MARKET',5,'0','DR','SHOP NO. 2 LOKMANYA NAGAR PADA NO. 4 OPP. ASHAPURA SWEETS NEAR KAMLESH MEDICAL THANE WEST','DEFAULT','THANE','21','400604',NULL,'7340295652','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'618',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(619,'167',NULL,NULL,'MAHALAXMI STORES',5,'0','DR','SHOP NO. 1 PANCHSHIL NIWAS KISAN NAGAR  NO. 3 BEHIND MARATHI SCHOOL ROAD NO. 16 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9819082819.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'619',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(620,'167',NULL,NULL,'MAHALAXMI MILK CENTER',5,'0','DR','KOPARI NEXT TO HARIM OM JUICE CENTRE OPP TO RAJASHREE MEDICAL N GENERAL STORE THANE EAST','DEFAULT','THANE','21','400602',NULL,'9588239543.0','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'620',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(621,'167',NULL,NULL,'MAHALAXMI MEDICAL STORE',5,'0','DR','INDIAR NAGAR NEAR BHAVESH TRENDING','DEFAULT','THANE','21','400604',NULL,'7977079100.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'621',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(622,'167',NULL,NULL,'MAHALAXMI MEDICAL',5,'0','DR','NR AMBICA SUPER MARKER','LOUISWADI','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'622',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:47','2026-02-23 09:16:47'),(623,'167',NULL,NULL,'MAHALAXMI KIRANA',5,'0','DR','CASTLE MILL NR ASARAM DAILY','DEFAULT','THANE','21','400603',NULL,'9167696560','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'623',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(624,'167',NULL,NULL,'MAHALAXMI GRAIN STORE',5,'0','DR','KL COLONY GANDHI NAGAR NEAR BY CONGRESS OFFICE BESIDE JAY AMBE KIRANA STORE THANE EAST','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'624',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(625,'167',NULL,NULL,'MAHALAXMI GENRAL STORE',5,'0','DR','RAM NAGAR ROAD NO.28,BEHAIND MUNCIPATRY GARDAN, THANE WEST','DEFAULT','THANE','21','400604',NULL,'9892461524.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'625',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(626,'167',NULL,NULL,'MAHALAXMI GENERAL STORE',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI NEAR VINAYAK DARIY','DEFAULT','THANE','21','400604',NULL,'9987886644.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'626',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(627,'167',NULL,NULL,'MAHALAXMI DAIRY & DRY FRUIT',5,'0','DR','SAVARKAR NAGAR','NR SHREE RAM OIL','','21','',NULL,'9594628269','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'627',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(628,'167',NULL,NULL,'MAHAKALI TRADRES',5,'0','DR','POKHRAN ROAD NO 1 SHASTRI NAGAR NEAR SUBHASH SUPARI   THANE WEST','DEFAULT','THANE','21','400606',NULL,'9819000662.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'628',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(629,'167',NULL,NULL,'MAHAKALI STORE',5,'0','DR','GALA NO 1 NR VIHANG PARK SHASTRI NAGAR','DEFAULT','THANE','21','400606',NULL,'9930313075','',NULL,'27','27DRAPR6543H1ZI','','BHARAT COPERATIVE BANK',NULL,NULL,'MUMUND','16',NULL,NULL,NULL,NULL,NULL,'629',NULL,NULL,NULL,NULL,NULL,'11521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(630,'167',NULL,NULL,'MAHAKALI STORE',5,'0','DR','SHASTRI NAGAR','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'630',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(631,'167',NULL,NULL,'MAHAJAN PROVISION STORE',5,'0','DR','DNYANESHWAR NAGAR NEAR PARDEEP GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9221239988.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'631',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(632,'167',NULL,NULL,'MAHAJAN FARSAN',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9265972947.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'632',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:48','2026-02-23 09:16:48'),(633,'167',NULL,NULL,'MAHADIK PROVISION STORES',5,'0','DR','NEAR WARDEN COMPANY  HAJURI GOAN  THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'633',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(634,'167',NULL,NULL,'MAHADEV TRADERS',5,'0','DR','SHOP NO 1 DATDAM APT NEAR PANCHGANGA NEAR JAYBHAWANI STORE SHIVAJI NAGAR RABODI 2 THANE WEST','DEFAULT','THANE','21','400607',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'634',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(635,'167',NULL,NULL,'MAHADEV TRADER',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9654802079.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'635',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(636,'167',NULL,NULL,'MAHADEV NAMKEEN STORE',5,'0','DR','RAGHUNATH NAGAR NEAR KAILASH SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'6377580422.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'636',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(637,'167',NULL,NULL,'MAHADEV DARIY',5,'0','DR','VARTAK NAGAR OPP HIRA OIL DEPO','DEFAULT','THANE','21','400606',NULL,'7715853924.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'637',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(638,'167',NULL,NULL,'MAA LAXMI DRY FRUITS',5,'0','DR','WAGHELA HOUSE OPP ST JOHN SCHOOL CHARAI OPP T J S B BANK NEAR LAXMI DAIRY CHARAI THANE WEST','DEFAULT','THANE','21','400601',NULL,'8108702227.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'638',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(639,'167',NULL,NULL,'MAA KRUPA PROVISION STORES',5,'0','DR','OPPOSITE SHIV SOCIETY OPPOSITE MAA VAISHNAVI HOSPITAL KOPRI COLONY THANE EAST','DEFAULT','THANE','21','400603',NULL,'9819097617.0','',NULL,'27','27AEDPT0362H1ZI','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'639',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(640,'167',NULL,NULL,'MAA JAISWAL TRADERS',5,'0','DR','KISAN NAGAR-2','GUPTA NIWAS','','21','',NULL,'9594028271','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'640',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(641,'167',NULL,NULL,'MAA CHAMUNDA KIRANA STORES',5,'0','DR','SHOP NO. 2 VAISHNAV SAI GANESH DHAM BUILDING BHATWADI KISAN NAGAR 3 WAGHALE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9029148577.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'641',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(642,'167',NULL,NULL,'MAA CHAMUNDA KIRANA STORE',5,'0','DR','BHAT WADI','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'642',NULL,NULL,NULL,NULL,NULL,'2151140000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:49','2026-02-23 09:16:49'),(643,'167',NULL,NULL,'MAA ASHAPURA KIRANA STORE',5,'0','DR','AMBIKA NAGAR NO 2 NEAR NEW JAGDISH KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'8980168516.0','',NULL,'27','','','KOTAK MAHINDRA',NULL,NULL,'MULUND','16',NULL,NULL,NULL,NULL,NULL,'643',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(644,'167',NULL,NULL,'MA ASHAPURA DEARY',5,'0','DR','RAJIV GANDHI SHOPPING CENTRE SATGURU GARDEN','DEFAULT','THANE','21','400603',NULL,'9920121814.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'644',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(645,'167',NULL,NULL,'M/S. G. ANILKUMAR & CO.',5,'0','DR','SHOP NO 05 G.ANILKUMAR OM SWASTIK CHS DEVIDAS ROAD MAHAGIRI THANE WEST','DEFAULT','THANE','21','400601',NULL,'9833244800.0','',NULL,'27','27AARFG8546L1ZJ','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'645',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(646,'167',NULL,NULL,'M. R. TRADER',5,'0','DR','SAWARKAR NAGAGR','DEFAULT','THANE','21','400603',NULL,'9867935294.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'646',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(647,'167',NULL,NULL,'M SUPER MARKET',5,'0','DR','LOKMANYA NAGAR','NR HIRA GANGA STORE','','21','',NULL,'8655776464','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'647',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(648,'167',NULL,NULL,'M M SUPER MARKET',5,'0','DR','NR KRISHNA CHEMIST','LOKMANYA NAGAR','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'648',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(649,'167',NULL,NULL,'LOKMANYA PROVISION STORE',5,'0','DR','LAXMI NARAYAN CHS.SHOP NO 1.KISAN NAGAR NO 3.','NEAR TAMBDE KIRANA STORE.NEAR LAXMI STORE.KISAN NAGAR .THANE .WEST','THANE','21','400604',NULL,'9892054326','',NULL,'27','27ATUPS5428H1ZY','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'649',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(650,'167',NULL,NULL,'LAXMI TRADERS',5,'0','DR','SHOP NO-4, NEAR RAJ THAKUR COLLAGE,NEAR KHANDOBA MANDIR,PHULE NAGAR KORES ROAD THANE WEST','DEFAULT','THANE','21','400604',NULL,'7045295990.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'650',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(651,'167',NULL,NULL,'LAXMI TRADERS',5,'0','DR','MAHATMA FULE NAGAR  OPP R.J THAKUR COLLEGE  THANE W','DEFAULT','THANE','21','400606',NULL,'7972797770.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'651',NULL,NULL,NULL,NULL,NULL,'11518000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(652,'167',NULL,NULL,'LAXMI SUPER MARKET',5,'0','DR','LOKMANYA NAGAR','NR AMBICA SUPER MARKET','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'652',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:50','2026-02-23 09:16:50'),(653,'167',NULL,NULL,'LAXMI SUPER MARKET',5,'0','DR','KOPARI','DEFAULT','THANE','21','400606',NULL,'9324449071.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'653',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(654,'167',NULL,NULL,'LAXMI STORE',5,'0','DR','SHOP NO 1.ROAD NO 16.KISAN NAGAR NO 2.NEAR RAMESH DUGDALAYA.NEAR JANTA GENERAL STORE.KISAN NAGAR.THANE .WEST','DEFAULT','THANE','21','400604',NULL,'9930485368.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'654',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(655,'167',NULL,NULL,'LAXMI PROVISION STORE',5,'0','DR','RAMCHANDRA NAGAR NEAR HUMANUM DAIRY AND SWEETS','DEFAULT','THANE','21','400604',NULL,'9930714210.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'655',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(656,'167',NULL,NULL,'LAXMI POOJA BHANDAR',5,'0','DR','VARTAK NAGAR BHAJI MARKET NAKA','DEFAULT','THANE','21','400606',NULL,'7448271533.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'656',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(657,'167',NULL,NULL,'LAXMI KIRANA',5,'0','DR','AZAD NAGAR-2','NR MAHALAXMI TRADERS','','21','',NULL,'7400327474','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'657',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(658,'167',NULL,NULL,'LAXMI GENRAL STORE',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'9892778293.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'658',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(659,'167',NULL,NULL,'LAXMI GENERAL STORE',5,'0','DR','SHOP NO 05 NEXT TO SAI BABA MANDIR NEAR TUSHAR SUPER MARKET VARTAK NAGER THANE WEST','DEFAULT','THANE','21','400606',NULL,'8112817131.0','',NULL,'27','','','RBL BANK',NULL,NULL,'VARTAK NAGAR','19',NULL,NULL,NULL,NULL,NULL,'659',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(660,'167',NULL,NULL,'LAXMI GENERAL STORE',5,'0','DR','SHOP NO 02 SAI DARSHAN APARTMENT NEXT TO BHAWANI JWELLERS OPP  OM CATERS NEAR B K ICECREAM NEAR VISHWVESHAR TEMPLE  SAVARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'8369836143.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'660',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(661,'167',NULL,NULL,'LAXMI GENERAL STORE',5,'0','DR','SHOP NO 1.NAVNATH DARSHAN.KISAN NAGAR NO 3.WAGLE ESTATE.NEAR AMBIKA SUPER MARKET.NEAR TAMBDE KIRANA STORE.THANE WEST','DEFAULT','THANE','21','400604',NULL,'9987159191.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'661',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(662,'167',NULL,NULL,'LAXMI GENERAL STORE',5,'0','DR','AMBIKA NAGAR NEAR HINDUSTAN BAR','DEFAULT','THANE','21','400604',NULL,'9892565652.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'662',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:51','2026-02-23 09:16:51'),(663,'167',NULL,NULL,'LAXMI DRYFRUITS',5,'0','DR','SHIV SENA SHAKHA KHOPAT NEAR NUTAN GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'8094380187.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'663',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(664,'167',NULL,NULL,'LAXMI DHANYA BHANDAR',5,'0','DR','NAUPADA B CABIN','DEFAULT','THANE','21','400603',NULL,'9819705055.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'664',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(665,'167',NULL,NULL,'LAXMI  DRYFRUITS AND FARSHAN MART',5,'0','DR','SHOP NO 4 KUMTHAKAR SADAN KISHAN NAGAR 1 BHAJI MARKET NEAR JAIN DUGHDHALAYA THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'665',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(666,'167',NULL,NULL,'LALJI RAJA PATEL',5,'0','DR','YEOUR','','','21','',NULL,'1234567890','',NULL,'27','','','TJSB SAHAKARI BANK LTD',NULL,NULL,'VARTAK NAGAR','10',NULL,NULL,NULL,NULL,NULL,'666',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(667,'167',NULL,NULL,'LADHARAM NARAYANDAS KIRANA AND GENERAL STORES',5,'0','DR','SHOP NO 8 KOPRI COLONY OPP SHREE VINAYAK MEDICAL NEAR MAHARASHTRA SWEETS KOPRI THANE EAST','DEFAULT','THANE','21','400602',NULL,'9892583286.0','',NULL,'27','','','AXIS BANK',NULL,NULL,'THANE EAST','27',NULL,NULL,NULL,NULL,NULL,'667',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(668,'167',NULL,NULL,'L. N. STORE',5,'0','DR','KOPAR','DEFAULT','THANE','21','400602',NULL,'9821271981.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'668',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(669,'167',NULL,NULL,'KUWARIKA GEN',5,'0','DR','YEOUR','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'669',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(670,'167',NULL,NULL,'KUSUMBAI BHAJI GENERAL STORES',5,'0','DR','RAMCHANDAR NAGAR NEAR GUPTA GENERAL STORES RAMCHANDAR NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'9920317377.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'670',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(671,'167',NULL,NULL,'KUMAR KIRANA STORE',5,'0','DR','KOPRI BHAJI MARKET','','','21','',NULL,'9322178534','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'671',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(672,'167',NULL,NULL,'KRUSHNA GENRAL',5,'0','DR','GAODEVI','DEFAULT','THANE','21','400603',NULL,'8928945365.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'672',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:52','2026-02-23 09:16:52'),(673,'167',NULL,NULL,'KRUSHNA ANAND SUPER MARKER',5,'0','DR','NAMDEV WADI','DEFAULT','THANE','21','400602',NULL,'9987714869.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'673',NULL,NULL,NULL,NULL,NULL,'11516000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(674,'167',NULL,NULL,'KRISHNA SWEETS AND DRY FRUITS',5,'0','DR','LOKMANYA NAGAR NEAR BHOOMI FOOD MART','DEFAULT','THANE','21','400606',NULL,'9137964104.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'674',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(675,'167',NULL,NULL,'KRISHNA SWEET',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'7900007897','',NULL,'27','27ADFPC2280E1Z0','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'675',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(676,'167',NULL,NULL,'KRISHNA SUPER MARKET',5,'0','DR','RAM NAGAR','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'676',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(677,'167',NULL,NULL,'KRISHNA SUPER MARKET',5,'0','DR','INDIAR NAGAR RUPA DEVI PADA NO 1 NEAR MAURYA KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'7498145666.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'677',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(678,'167',NULL,NULL,'KRISHNA PRODUCT',5,'0','DR','WHOSLAE','DEFAULT','THANE','21','400602',NULL,'7039630105.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'678',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(679,'167',NULL,NULL,'KRISHNA MINI SUPER MARKET',5,'0','DR','KOPRI','OPP SVC BANK','','21','',NULL,'9321031060','',NULL,'27','','','SVC COP BANK',NULL,NULL,'KOPRI','25',NULL,NULL,NULL,NULL,NULL,'679',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(680,'167',NULL,NULL,'KRISHNA MEDICAL',5,'0','DR','BHAVNAGAR SWEET NEAR KRISHNA NAGAR NO 1','DEFAULT','THANE','21','400604',NULL,'7977997374.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'680',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(681,'167',NULL,NULL,'KRISHNA MEDICAL',5,'0','DR','ASHOK TRADERS NEAR PADWAL NAGAR','DEFAULT','THANE','21','400604',NULL,'9619400899.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'681',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(682,'167',NULL,NULL,'KRISHNA MEDICAL',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400603',NULL,'8356082527.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'682',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:53','2026-02-23 09:16:53'),(683,'167',NULL,NULL,'KRISHNA DEARY AND SWEETS',5,'0','DR','HANUMAN NAGAR ROAD NO 34','DEFAULT','THANE','21','400604',NULL,'7900182216.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'683',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(684,'167',NULL,NULL,'KRISHNA DAIRY',5,'0','DR','SHOP NO.4, RAMCHANDRA NAGAR AREA NO-3 , VATIWADI,KAMGAR ROAD , THANE WEST.','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'684',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(685,'167',NULL,NULL,'KRISHNA DAIRY',5,'0','DR','KAOOARI','DEFAULT','THANE','21','400602',NULL,'7738802355.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'685',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(686,'167',NULL,NULL,'KRISHNA CHEMIST MEDICAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO.4 OPPOSITE TO VIVEK OIL DEPO','DEFAULT','THANE','21','400606',NULL,'8329558329.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'686',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(687,'167',NULL,NULL,'KRISHNA CHEMIST',5,'0','DR','SAVARKAR NAGAR','OPP MAHAVIR OIL DEPO','','21','',NULL,'9969810685','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'687',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(688,'167',NULL,NULL,'KRISHNA AATA BHANDAR',5,'0','DR','SHOP NO 5 52A VRINDAVAN SOCIETY THANE WEST 400601','DEFAULT','THANE','21','400602',NULL,'9820798391.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'688',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(689,'167',NULL,NULL,'KRISHANA GENERAL STORE',5,'0','DR','LUVISWADI OPP SAWANT SUPER MARKET NEAR SIRAVI PROVISION','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'689',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(690,'167',NULL,NULL,'KOPRI CONUMER SOCIETY',5,'0','DR','KOPRI BHAJI MARKET','THANE WEST','THANE','21','400602',NULL,'9022022336','',NULL,'27','27AAXPO4045N1ZU','','THE NAVJEEVAN CO OP BANK LTD',NULL,NULL,'002252','25',NULL,NULL,NULL,NULL,NULL,'690',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(691,'167',NULL,NULL,'KOPARI KIRANA STORE',5,'0','DR','SHOP NO 1 RUPA BAI VITTHAL NIVAS  KOPARI GAON NEAR CHAUDARY SUPER MARKET KOPARI GAON','DEFAULT','THANE','21','400602',NULL,'9833007544.0','',NULL,'27','27ACCPS2205BIZ6','','UNION BANK',NULL,NULL,'THANE','25',NULL,NULL,NULL,NULL,NULL,'691',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:54','2026-02-23 09:16:54'),(692,'167',NULL,NULL,'KONDAIDEVI GENRAL STORE',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400603',NULL,'7977288011.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'692',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(693,'167',NULL,NULL,'KOMAL GENRAL',5,'0','DR','RABODI','DEFAULT','THANE','21','400601',NULL,'7738229887.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'693',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(694,'167',NULL,NULL,'KOHINOOR GENERAL STORE',5,'0','DR','HAJURI NEAR DARGAH','DEFAULT','THANE','21','400604',NULL,'9920494477.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'694',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(695,'167',NULL,NULL,'KOHINOOR BAKERY STORE',5,'0','DR','SHOP NO 1 TRIMURTI SADAN BLDG NO 4 NEAR DATTA MANDIR OPP SACHIN TENDULKAR PLAY GROUND MAHATMA PHULE NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'8693084910.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'695',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(696,'167',NULL,NULL,'KISAN KIRANA STORE',5,'0','DR','ROAD NO 28 WAGLAE ESTATE RAM NAGAR NAER JAY BHAWANI DHANYA BHANDER THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'696',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(697,'167',NULL,NULL,'KIRISHNA SUPER MARKET',5,'0','DR','NEAR SADNA COLLEGE HANUMAN MANDIR CP TALAV  ROAF NO 27WAGLE  ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'7738901653.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'697',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(698,'167',NULL,NULL,'KIRAN GENERAL STORE',5,'0','DR','OPP ITI CIRCLE  OLD GOAN','ROAD NO28 WAGLE ESTATE','THANE','21','400604',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'698',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(699,'167',NULL,NULL,'KHUSHALANI STORE PRIVATE LIMITED',5,'0','DR','KOOARI','DEFAULT','THANE','21','400606',NULL,'8369645908.0','',NULL,'27','27AAHCK9658A1ZB','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'699',NULL,NULL,NULL,NULL,NULL,'11520000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(700,'167',NULL,NULL,'KETKAR AHARBHUWAN',5,'0','DR','GAODEVI','DEFAULT','THANE','21','400603',NULL,'7369809638.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'700',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(701,'167',NULL,NULL,'KESARIYA TRADING',5,'0','DR','SHIVAJI NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'701',NULL,NULL,NULL,NULL,NULL,'1151210000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:55','2026-02-23 09:16:55'),(702,'167',NULL,NULL,'KASHIRAM PROVSION STORE',5,'0','DR','SHOP NO 2 GUPTA NIVAS KISAN NAGER NO 2 OPPOSITE RAMDEV PROVSION STORE NEAR KASHIRAM ICECREAM  ROAD NO 16 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'8976710340.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'702',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(703,'167',NULL,NULL,'KARIYA GRAIN  STORE NX',5,'0','DR','WHOSALE','DEFAULT','THANE','21','400602',NULL,'8291770080','',NULL,'27','27AAWFK3755G1ZS','','KOTAK MAHINDRA BANK',NULL,NULL,'001092','5',NULL,NULL,NULL,NULL,NULL,'703',NULL,NULL,NULL,NULL,NULL,'11511400000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(704,'167',NULL,NULL,'KARIA EVERYDAY',5,'0','DR','AMAR VASHALI  SHOP NO.4','DEFAULT','THANE','21','400602',NULL,'9869868606.0','',NULL,'27','27ABBPK8805D2ZU','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'704',NULL,NULL,NULL,NULL,NULL,'11521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(705,'167',NULL,NULL,'KARAN GENRAL STORE',5,'0','DR','51.B.SHOP NO 4.VRINDAVAN SOCIETY.NEAR BALAJI DRYFRUITS.THANE WEST.','DEFAULT','THANE','21','400602',NULL,'9930565787.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'705',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(706,'167',NULL,NULL,'KANTI GENERAL STORE',5,'0','DR','SHOP NO. 2 NIRMAL APT JOSHI WADA UTTAM ANGRE MARG NEAR JANAM HOSPITAL THANE WEST MUMBAI 400601','DEFAULT','THANE','21','400601',NULL,'9892360050.0','',NULL,'27','27ANLPS3531L1ZI','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'706',NULL,NULL,NULL,NULL,NULL,'11516000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(707,'167',NULL,NULL,'KAMLESH GUPTA GENERAL STORE',5,'0','DR','KISAN NAGAR 2 WAGLE ESTATE    NAER SHREE MAA RAVECHI STORE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9869015891.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'707',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(708,'167',NULL,NULL,'KAMAL TRADING',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400604',NULL,'8451861313.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'708',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(709,'167',NULL,NULL,'KAMAL SWEET',5,'0','DR','KOPARI OPP TO THANE STATION NEXT O HOTEL TWINS N BOMBAY BURGER THANE EAST','DEFAULT','THANE','21','400602',NULL,'9930777088.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'709',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(710,'167',NULL,NULL,'KAMAL SWEET',5,'0','DR','INDIAR NAGAR NAKA NEAR SHREE RAMDEV SWEETS','DEFAULT','THANE','21','400604',NULL,'9773374991.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'710',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(711,'167',NULL,NULL,'KAMAL MEDICAL',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400603',NULL,'8097622720.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'711',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:56','2026-02-23 09:16:56'),(712,'167',NULL,NULL,'KAMAL KIRANA STORE',5,'0','DR','LOKMANYA NAGAR, PADA NO.03, NEAR VITHAL KRIDA MANDAL','DEFAULT','THANE','21','400606',NULL,'7710975640.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'712',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(713,'167',NULL,NULL,'KAMAL GENERAL STORE',5,'0','DR','SHOP NO 1 CP TALAV ROAD WAGLE ESTATE ROAD NO 27 NAER SHIV SENA OFFICE THANE WEST','WAGLE ESTATE ROAD NO 27 NAER SHIV SENA OFFICE THANE WEST','THANE','21','400604',NULL,'0123456789','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'713',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(714,'167',NULL,NULL,'KAMAL GENERAL STORE',5,'0','DR','KAMAL GENERAL STORE LOKMANYA NAGAR PADA NO. 4 NEAR JAN SEVA MITRA MANDAL NEXT TO VINSHIN BAKERY THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','HINDUSTAN BANK',NULL,NULL,'LOKMANYA NAGAR','18',NULL,NULL,NULL,NULL,NULL,'714',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(715,'167',NULL,NULL,'KAMAL ENTERPRISE',5,'0','DR','KISHAN NAGAR 2','DEFAULT','THANE','21','400606',NULL,'9892986844.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'715',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(716,'167',NULL,NULL,'KALPESH GENERAL STORE',5,'0','DR','SHOP NO 6.TEKDI BANGLA.NEAR GUPTA GENERAL STORE.NEAR NEW REKHA GENERAL STORE.PANCHPAKDI.THANE.WEST','DEFAULT','THANE','21','400602',NULL,'7738276081.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'716',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(717,'167',NULL,NULL,'KALLIKA DARIY',5,'0','DR','SHIVAJI NAGAR OPP WELCOME STORE','DEFAULT','THANE','21','400604',NULL,'8114402147.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'717',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(718,'167',NULL,NULL,'KALA GRAIN STORE',5,'0','DR','SHANTI NAGAR NEAR ARIHANT STORE GALI ME','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'718',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(719,'167',NULL,NULL,'KAJAL GENERAL STORE',5,'0','DR','SHOP NO 06 KAJAL GENERAL STORE NEXT TO SAI BABA MANDIR POKHARAN ROAD NO 01 VARATAK NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'9920395872.0','',NULL,'27','27AFIPC3897C1ZG','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'719',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(720,'167',NULL,NULL,'KAIRALI GENRAL STORE  AND PROVISION STORE',5,'0','DR','SHOP NO 7 .DEEP JYOTI APPARMENT,SHANTI NAGAR ROAD NO.27,NEAR GOLDAN BAKERY.NEAR MASJID.WAGLE STATE,THANE W','DEFAULT','THANE','21','400606',NULL,'9372112259.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'720',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(721,'167',NULL,NULL,'KAILASH TRADERS',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9930626289.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'721',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:57','2026-02-23 09:16:57'),(722,'167',NULL,NULL,'KAILASH TRADERS',5,'0','DR','PADA NO.1,LOKMANYA NAGAR,WARTAK NAGAR NAKA,OPP.SHREE AMBIKA MEDICAL AND GENRAL STORE,THANE','DEFAULT','THANE','21','400606',NULL,'9819865277.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'722',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(723,'167',NULL,NULL,'KAILASH SUPER MARKET',5,'0','DR','SHOP NO 11 SHIVAM BLDG RAGHUNATH NAGAR WAGLE ESTATE THANE W','DEFAULT','THANE','21','400606',NULL,'9967898152.0','',NULL,'27','27ACUPC4440L2Z9','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'723',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(724,'167',NULL,NULL,'KAILASH GEN STORE',5,'0','DR','ROAD  NO 28 DHARAM VEER CHAOL NEAR MAHALAXMI  KIRANA STORES  SHANTI NAGER WAGLE ESTATE THANE','DEFAULT','THANE','21','400606',NULL,'7424939715.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'724',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(725,'167',NULL,NULL,'KAILAS PROVISION STORE',5,'0','DR','SHOP NO 23 OPP SHREE SAMARTH MEDICAL AND GENERAL STORES NEXT TO R.K BAKERY. BAKERY LANE COPARI COLONY  THANE EAST','DEFAULT','THANE','21','400603',NULL,'9029308672.0','',NULL,'27','27AAQPB4210P1ZJ','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'725',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(726,'167',NULL,NULL,'KACHARNATH DAIRY',5,'0','DR','KOAPRI','DEFAULT','THANE','21','400603',NULL,'9323894917.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'726',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(727,'167',NULL,NULL,'K. G. VANGE',5,'0','DR','GAIDEVI','DEFAULT','THANE','21','400603',NULL,'9004778526.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'727',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(728,'167',NULL,NULL,'K K MART',5,'0','DR','HAJURI DARGAH WAGLE STATE THANE','DEFAULT','THANE','21','400604',NULL,'9819923184.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'728',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(729,'167',NULL,NULL,'K  P & SONS STORE',5,'0','DR','MAHATMA FHULE NAGAR  NEAR AADINATH','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'729',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(730,'167',NULL,NULL,'JYOTI DRYFRUITS',5,'0','DR','SHOP NO 4 SAI NATH BULDING STATION ROAD.OPPOSIT YASH CHEMISY.LE GATEAU. NEAR HDFC BANK','DEFAULT','THANE','21','400603',NULL,'7021670270.0','',NULL,'27','27AKLPC7697N1Z9','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'730',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(731,'167',NULL,NULL,'JYOTI DRY FRUITS',5,'0','DR','OPPOSITE HDFC BANK KOPRI COLONY','DEFAULT','THANE','21','400603',NULL,'9892063275.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'731',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:58','2026-02-23 09:16:58'),(732,'167',NULL,NULL,'JOSHI MEDICAL AND GENRAL STORE',5,'0','DR','GODBOLE HOSPITAL ROAD','DEFAULT','THANE','21','400603',NULL,'9757260954.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'732',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(733,'167',NULL,NULL,'JNS MEDICAL',5,'0','DR','NAUPDAD','','','21','',NULL,'8108101805','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'733',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(734,'167',NULL,NULL,'JK BAKERY',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI SAI BABA MANDIR','DEFAULT','THANE','21','400604',NULL,'8097574049.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'734',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(735,'167',NULL,NULL,'JITENDRA DRY FRUIT',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9819249822.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'735',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(736,'167',NULL,NULL,'JIGAR GENERAL STORE',5,'0','DR','SAVARKAR NAGAR, NEAR RAVECHI MATA MANDIR, A WING SAI APARTMENTS','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'736',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(737,'167',NULL,NULL,'JB KARIYA AND SONS',5,'0','DR','MADINA MANZIL MAHATMA PHULE MARKET BHAJI MARKET WHOLESALE MARKET OPP NAKODA FARSAN THANE WEST','DEFAULT','THANE','21','400601',NULL,'9594765040.0','',NULL,'27','27ACDPK6886B1ZI','','RBL BANK',NULL,NULL,'RAM MARUTI ROAD','5',NULL,NULL,NULL,NULL,NULL,'737',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(738,'167',NULL,NULL,'JAYESH GENERAL STORE',5,'0','DR','SHOP NO.477,CHAWL NO 67 SHIVAI NAGAR NEAR SUNDHA MATA STORES ,POKHRAN ROAD NO.1,THANE (W)','DEFAULT','THANE','21','400604',NULL,'8291388166.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'738',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(739,'167',NULL,NULL,'JAY VEER SWEET',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9819016016.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'739',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(740,'167',NULL,NULL,'JAY TRADING',5,'0','DR','SHIVAJI NAGAR NEAR WELCOME STORE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'740',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(741,'167',NULL,NULL,'JAY SHREE RAMDEV STORES',5,'0','DR','SHOP NO 1 SAI KRUPA APARTMENT NAMDEV WADI NEAR VIJAY KIRANA STORES NEAR NEW JANTA SUPER MARKET PAACH PAKHADI THANE WEST','DEFAULT','THANE','21','400602',NULL,'9892751195.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'741',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:16:59','2026-02-23 09:16:59'),(742,'167',NULL,NULL,'JAY SHREE GANESH DRY FRUIT',5,'0','DR','NAHPADA','DEFAULT','THANE','21','400603',NULL,'8830248147.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'742',NULL,NULL,NULL,NULL,NULL,'1161140000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(743,'167',NULL,NULL,'JAY SANTOSHI MOMAIYA GENERAL STORE',5,'0','DR','GYANESHWAR NAGAR NEAR SHIV SENA OPP  STORE','DEFAULT','THANE','21','400606',NULL,'8108493750.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'743',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(744,'167',NULL,NULL,'JAY SANTOSHI MAA KIRANA STORE',5,'0','DR','KOPRI ANAND NAGAR','NR KAMAL MEDICAL','','21','',NULL,'7208179726','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'744',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(745,'167',NULL,NULL,'JAY RAVECHI DHANYA BHANDAR',5,'0','DR','SAI SADAN KISAN NAGER 3 ROAD NO 16 WAGLE ESTATE THANE W','DEFAULT','THANE','21','400604',NULL,'9699359297.0','',NULL,'27','','','BANK OF BARODA',NULL,NULL,'SHREE NAGAR','7',NULL,NULL,NULL,NULL,NULL,'745',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(746,'167',NULL,NULL,'JAY MALHAR MEDICAL & GENERAL STORE',5,'0','DR','SHAKUNTALA APT. SHOP NO.11, MENTAL HOSPITAL THANE (W).','DEFAULT','THANE','21','400604',NULL,'7710833218.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'746',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(747,'167',NULL,NULL,'JAY MAJI SA DOODH DAIRY',5,'0','DR','SHOP NO 2, SHIVGANGA BULDING, NEAR SAI BABA MANDIR, LOKMANYA NAGAR, PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'747',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(748,'167',NULL,NULL,'JAY JANTA PROVISION STORE',5,'0','DR','SHOP NO 1.PARSIWADI KOPERI COLONY.OPPOSIT HANUMAN TEMPLE.','DEFAULT','THANE','21','400603',NULL,'9930200143.0','',NULL,'27','','','BANK OF BARODA',NULL,NULL,'KOPRI','25',NULL,NULL,NULL,NULL,NULL,'748',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(749,'167',NULL,NULL,'JAY DURGA GENERAL STORE',5,'0','DR','RAMNAGAR RD, NEAR ITI CIRCLE WAGLE ESTATE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'749',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(750,'167',NULL,NULL,'JAY BHAWANI KIRANA STORE',5,'0','DR','AMBEDKAR CHOWK PARERA NAGAR OPP. VISHNU KIRANA STORE LOKMANYA NAGAR PADA NO 3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'750',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(751,'167',NULL,NULL,'JAY BHAVANI TREDARS',5,'0','DR','SAI BABA MANDIR ROAD RAMCHANDRA NAGAR','DEFAULT','THANE','21','400604',NULL,'9987290983.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'751',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:00','2026-02-23 09:17:00'),(752,'167',NULL,NULL,'JAY BHARAT STORE',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'7045444865.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'752',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(753,'167',NULL,NULL,'JAY AMBIKA SUPER MAKT',5,'0','DR','KOOARI','DEFAULT','THANE','21','400603',NULL,'8433774100.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'753',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(754,'167',NULL,NULL,'JAY AMBE SUPAR MARKET',5,'0','DR','SHOP NO.3.4 GOKULDHAM CHS.SIDHARTH LAXMI EASTE CONSULTANTS NAGAR STATION  ROAD KOPARI THANE  EAST','DEFAULT','THANE','21','400603',NULL,'8879180929.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'754',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(755,'167',NULL,NULL,'JAY AMBE KIRANA STORE',5,'0','DR','K.L.COLONY GANDHI NAGAR NEAR CONGRESS OFFICE ANAND NAGAR NEAR PATEL TRADERS THANE EAST','DEFAULT','THANE','21','400603',NULL,'','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'755',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(756,'167',NULL,NULL,'JAY AMBE KIRANA',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400603',NULL,'8108294288.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'756',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(757,'167',NULL,NULL,'JAY AMBE GENERAL STORE',5,'0','DR','SHOP NO 01 AJANTI APPARTMENT RABODI 2 BEHIND EKVIRA GENERAL STORE THANE','DEFAULT','THANE','21','400607',NULL,'9869162830.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'757',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(758,'167',NULL,NULL,'JAY AMBE GENERAL STORE',5,'0','DR','SHOP NO. 1 AMAR JYOTI BULDING  NEAR LOKMANYA NAGAR BUS DEPO NEAR MAHINDRA COSMETICS AND FOOD  SHOP  PADA NO.3 DAVLA NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'758',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(759,'167',NULL,NULL,'JAY AMBE DHANYA BHANDAR',5,'0','DR','KHATAN ROAD','DEFAULT','THANE','21','400602',NULL,'9967209372','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'759',NULL,NULL,NULL,NULL,NULL,'11512100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(760,'167',NULL,NULL,'JAY AMBE',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'7977125445.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'760',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(761,'167',NULL,NULL,'JANTA SUPER MARKET',5,'0','DR','HAJURI','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'761',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:01','2026-02-23 09:17:01'),(762,'167',NULL,NULL,'JANTA STORE',5,'0','DR','WHOLESALE MARKET DEVIDAS ROAD NEAR NEW THANE BAKERY JUMMA MASJID MAHAGIRI THANE WEST','DEFAULT','THANE','21','400601',NULL,'7718912341','',NULL,'27','27AQXPS3256P1ZM','','PARSIK SAHAKARI BANK LTD',NULL,NULL,'KHARKALI','2',NULL,NULL,NULL,NULL,NULL,'762',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(763,'167',NULL,NULL,'JANTA GENERAL STORE',5,'0','DR','ANAND NAGAR NEAR KAMAL MEDICAL STORE','DEFAULT','THANE','21','400603',NULL,'9699141084.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'763',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(764,'167',NULL,NULL,'JANTA GENERAL STORE',5,'0','DR','KISAN NAGAR-3','NR PARAS MASALA','THANE','21','400604',NULL,'9967316171','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'764',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(765,'167',NULL,NULL,'JANTA DRY FRUIT',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9987812822.0','',NULL,'27','','','SARASWATH BANK',NULL,NULL,'KHOPAT','24',NULL,NULL,NULL,NULL,NULL,'765',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(766,'167',NULL,NULL,'JANTA DHANYA BHANDAR',5,'0','DR','SHOP NO 8.SHANKAR APPARMENT.NR KAMLESH HSG.SOCIETY.KAHNIYA NAGAR','DEFAULT','THANE','21','400603',NULL,'9702203573.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'766',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(767,'167',NULL,NULL,'JANTA DHANYA BANDAR',5,'0','DR','GYANESHWAR NAGAR ROAD NO 33 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9930382922.0','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'SHREE NAGAR','1',NULL,NULL,NULL,NULL,NULL,'767',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(768,'167',NULL,NULL,'JANKI GENERAL STORE',5,'0','DR','RABODI 2 NEAR MAHAVEER STORE OPP DEVNARAYAN DAIRY','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'768',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(769,'167',NULL,NULL,'JALARAM TRADERS',5,'0','DR','UTHALSAR','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'769',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(770,'167',NULL,NULL,'JALARAM TEA CENTRE',5,'0','DR','PADWAL NAGAR NEAR ASHOK TRADAR','DEFAULT','THANE','21','400606',NULL,'9004297012.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'770',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(771,'167',NULL,NULL,'JALARAM SUPER MARKET',5,'0','DR','SHOP NO 2 AND 3 DHARMVEER APPARTMENT NEAR PALASH DRYFRUITS','OPP ROYAL DEYFRUITS THANE STATION ROAD THANE WES','THANE','21','400601',NULL,'8511114733','',NULL,'27','27AARFJ3064A1ZG','','ICICI BANK',NULL,NULL,'1','2',NULL,NULL,NULL,NULL,NULL,'771',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:02','2026-02-23 09:17:02'),(772,'167',NULL,NULL,'JAI SANTOSHI MAA GENERAL STORE',5,'0','DR','HAJURI NEAR SHIV SHENA SHAKHA','DEFAULT','THANE','21','400604',NULL,'9867430469.0','',NULL,'27','','','STATE BANK OF INDIA',NULL,NULL,'LUISWADI','11',NULL,NULL,NULL,NULL,NULL,'772',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(773,'167',NULL,NULL,'JAI RATNA STORE',5,'0','DR','ROAD NO.9 RAGHUNATH NAGAR','DEFAULT','THANE','21','400604',NULL,'9892310500.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'773',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(774,'167',NULL,NULL,'JAI MATAJI KIRANA STORE',5,'0','DR','NEAR AAI MATA MANDIR SAVARKAR NAGAR','DEFAULT','THANE','21','400606',NULL,'9892130735.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'774',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(775,'167',NULL,NULL,'JAI MALHAR AGARBATTI',5,'0','DR','LOKMANYA NAGAR PADA NO 3 NEAR CHANDAN GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'7045716030.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'775',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(776,'167',NULL,NULL,'JAI MAHARASHTRA KIRANA AND GENERAL STORE',5,'0','DR','SHOP NO.16 RAJ DARSHAN APT. UMED NAGAR LOUISWADI OPP. SAI BABA MANDIR AND SHREE SIDDHIVINAYAK MEDICAL AND GENERAL STORE  WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'9892874929.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'776',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(777,'167',NULL,NULL,'JAI MAHARASHTRA GENERAL STORE',5,'0','DR','SHOP NO 933 ROAD NO 28 WAGLE ESTATE BEHIND SHIV SENA SAKHA PATIL CHAWL THANE WEST 400604','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'777',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(778,'167',NULL,NULL,'JAI MAHARASHTRA DRYFRUITS AND GENERAL STORE',5,'0','DR','YASHODA NAGAR NEAR MARUTI SUPER MARKET','DEFAULT','THANE','21','400606',NULL,'9636148259.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'778',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(779,'167',NULL,NULL,'JAI MAHARASHTRA DRY FRUIT',5,'0','DR','GITANJALI NIWAS SHOP NO 1 LOKMANNAGAR PADA NO 2 NEAR AAIJI SUPER MARKET OPP MAHAVIR MEDICAL STORES THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'779',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(780,'167',NULL,NULL,'JAI MAHAKALI KIRANA AND GENERAL STORE',5,'0','DR','AMBEWADI ROAD NO 22 NEAR SHIV SENA OFFICE NEAR GULAB GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'8127047557.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'780',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(781,'167',NULL,NULL,'JAI MAA DURGA DAIRY',5,'0','DR','RAMNAGAR ROAD NO 28 NEAR SAI TEMPLE NEAR PURNIMA SUPER MARKET WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27AAECM2933K1ZB','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'781',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:03','2026-02-23 09:17:03'),(782,'167',NULL,NULL,'JAI KUWARIKA DHANYA BHANDAR',5,'0','DR','SHASTRI NAGAR NEAR DURGA GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'8828080832.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'782',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(783,'167',NULL,NULL,'JAI JALARAM DRY FRUITS',5,'0','DR','SHOP  NO 04 LOKMANYA NAGAR NEAR AMBIKA MEDICAL WARTAK NAGAR THANE','DEFAULT','THANE','21','400606',NULL,'9221929602.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'783',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(784,'167',NULL,NULL,'JAI HANUMAN KIRANA STORE',5,'0','DR','NEAR YASHODHA SCHOOL SHASTRI NAGAR','DEFAULT','THANE','21','400606',NULL,'9867842388.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'784',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(785,'167',NULL,NULL,'JAI GURUDEV MEDICAL & GEN STORE',5,'0','DR','PADWAL NAGAR','OPP HANUMAN MEDICAL','','21','',NULL,'9987925987','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'785',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(786,'167',NULL,NULL,'JAI CHAMUNDA DRYFRUIT AND GENRAL STORE',5,'0','DR','SHOP NO 1 LOKEMANYA YASHODAN NAGAR PADA NO 2 NEAR SURESH MEDICAL NEAR MAHAVIR MEDICAL LOKEMANYA NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'8850521968.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'786',NULL,NULL,NULL,NULL,NULL,'11512100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(787,'167',NULL,NULL,'JAI BHAVANI DHANYA BHANDAR',5,'0','DR','SHOP 1 NEAR MAHARASHTRA SOCIETY NEAR CP TALAV POLICE CHOWKI CP TALAV ROAD NO 27 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'787',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(788,'167',NULL,NULL,'JAI BHAIRU BHAVANI DRY FRUIT',5,'0','DR','SHOP NO 11 POKHARAN ROAD NO 01 DEVDAYA PARK SAMATANAGAR THANE','DEFAULT','THANE','21','400606',NULL,'7304794337.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'788',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(789,'167',NULL,NULL,'JAI BHAIRAVNATH DAIRY',5,'0','DR','SHOP NO 03 NAGARIYA APARTMENT NEXT TO SHREE DHANANTAVARI CLINIC OPP YADAV FLOOR MILL NEAR JAY MAHARASHTRA SNACKS NEAR MANPASAND SWEET NEAR KHECHI MATA TEMPLE SAWARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'789',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(790,'167',NULL,NULL,'JAGRUT DAIRY AND SWEET',5,'0','DR','KOAPARI','DEFAULT','THANE','21','400602',NULL,'9920729464.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'790',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(791,'167',NULL,NULL,'JAGDAMBAY GENERAL  STORE',5,'0','DR','ROAD NO 27 VIDHA BHAVAN NEXT VIRA GENERAL STORES   OPP SHIV SENA  OFFICE SANTI NAGAR THANE','DEFAULT','THANE','21','400606',NULL,'8652593979.0','',NULL,'27','27ACDPC6288R1ZX','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'791',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:04','2026-02-23 09:17:04'),(792,'167',NULL,NULL,'JAGDAMBA GENERAL STORE',5,'0','DR','YASHODHA SCHOOL SHASTRI NAGAR NEAR HANUMAN KIRANA STORE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'792',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(793,'167',NULL,NULL,'JAGAN NATH KIRANA STORE',5,'0','DR','NR TAMBDE GEN','','','21','',NULL,'9967528495','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'793',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(794,'167',NULL,NULL,'JADHAV PROVISION STORE',5,'0','DR','SHOP NO 2 KOKNI PADA OPP GIRIJA HEIGHT NEAR HARI OM  STORES UPVAN LAKE THANE WEST','DEFAULT','THANE','21','400606',NULL,'9320244844.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'794',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(795,'167',NULL,NULL,'JADHAV MASALA',5,'0','DR','SHIVAJI NAGAR NEAR MARUTI GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9892947390.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'795',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(796,'167',NULL,NULL,'JADHAV KIRANA STORE',5,'0','DR','HAJURI','DEFAULT','THANE','21','400602',NULL,'9833437136.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'796',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(797,'167',NULL,NULL,'J. K. COMUNICATION',5,'0','DR','KOPARI','DEFAULT','THANE','21','400603',NULL,'9819467030.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'797',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(798,'167',NULL,NULL,'J M GANERAL STORE',5,'0','DR','PADWAL NAGAR BHAJI MARKIT NEAR SWARAJ','DEFAULT','THANE','21','400606',NULL,'9082087850.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'798',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(799,'167',NULL,NULL,'ISHWARLAL H THHAKAR',5,'0','DR','SHOP NO 7 AKRUTI PARK TELI GALI DHOBI AALI TEMBHI NAKA THANE','DEFAULT','THANE','21','400601',NULL,'9372931486.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'799',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(800,'167',NULL,NULL,'ISHWAR GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 3 AMBEDKAR CHAWK OPPOSITE JAY BHAWANI GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'800',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(801,'167',NULL,NULL,'INDIAN OVERSEAS BANK',11,'0','DR','DEFAULT','','','21','',NULL,'','',NULL,'27','','','INDIAN OVERSEAS BANK',NULL,NULL,'POKHRAN ROAD','28',NULL,NULL,NULL,NULL,NULL,'801',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:05','2026-02-23 09:17:05'),(802,'167',NULL,NULL,'HUNUMAN DARIY AND SWEETS',5,'0','DR','RAMCHANDRA NAGAR NEAR LAXMI PROVISION STORE','DEFAULT','THANE','21','400604',NULL,'9621479847.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'802',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(803,'167',NULL,NULL,'HITESH STORES',5,'0','DR','SHOP NO 01 ASHWINI AKASHGANGA COMPLEX 2 RABODI THANE WEST','DEFAULT','THANE','21','400607',NULL,'9324019923.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'803',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(804,'167',NULL,NULL,'HITESH STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9969267245.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'804',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(805,'167',NULL,NULL,'HITESH KUMAR DHANJI',5,'0','DR','KHATAN ROAD','DEFAULT','THANE','21','400602',NULL,'8879926404.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'805',NULL,NULL,NULL,NULL,NULL,'1151140000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(806,'167',NULL,NULL,'HITESH GEN STORE',5,'0','DR','KHATAN','','','21','',NULL,'8879926404','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'806',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(807,'167',NULL,NULL,'HIRA PANNA GENRAL STORE',5,'0','DR','STATION ROAD OPP SHREE RAM FOODS NEAR NAGRIK STORES NEAR ASHOK TALKIES THANE WEST','DEFAULT','THANE','21','400601',NULL,'7045000795.0','',NULL,'27','27AFMPM3121M1Z8','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'807',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(808,'167',NULL,NULL,'HIRA OIL DEPOT',5,'0','DR','SHOP NO 03 LOKMANYA NAGAR OPP AMBIKA MEDICAL WARTAK NAGAR THANE','DEFAULT','THANE','21','400606',NULL,'9323378017.0','',NULL,'27','','','TJSB',NULL,NULL,'1','10',NULL,NULL,NULL,NULL,NULL,'808',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(809,'167',NULL,NULL,'HIRA GENERAL STORE',5,'0','DR','SHOP NO 3,NR MAHAVIR MEDICAL, RUPADEVI PADA NO, ROAD NO 33,INDIRA NAGAR, WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400602',NULL,'9969396818.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'809',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(810,'167',NULL,NULL,'HIRA GANGA GROSARY',5,'0','DR','SHOP NO 1,OM SHIV SAI SADAN, LOKMANYA NAGAR, PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'810',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(811,'167',NULL,NULL,'HIMANSHU SWEETS',5,'0','DR','LOKMANYA NAGAR OPP DILIP DRY FRUITS','DEFAULT','THANE','21','400606',NULL,'9820636103.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'811',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:06','2026-02-23 09:17:06'),(812,'167',NULL,NULL,'HEENA AYURVADIC',5,'0','DR','PANCH','DEFAULT','THANE','21','400603',NULL,'8828090495.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'812',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(813,'167',NULL,NULL,'HASMUKH GENERAL STORE',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI NEAR NEW NATARAJ GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'8976207306.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'813',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(814,'167',NULL,NULL,'HARSHA MEDICAL',5,'0','DR','RABODI','NR RUTU SUPER MARKET','','21','',NULL,'9892951087','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'814',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(815,'167',NULL,NULL,'HARSHA KIRANA STORE',5,'0','DR','DNYANESHWAR NAGAR OPP RAJESH KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'9920995981.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'815',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(816,'167',NULL,NULL,'HARI OM SUPER MARKET',5,'0','DR','SHOP NO 01 NEAR RADHA KRISHNA MANDIR  PADA NO 04 NEAR JUNA BUS STOP LOKMANYA NAGAR THANE WEST','DEFAULT','THANE','21','400604',NULL,'9004795950.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'816',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(817,'167',NULL,NULL,'HARI OM STORE',5,'0','DR','KUMBHAR WADA','DEFAULT','THANE','21','400603',NULL,'9667850888.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'817',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(818,'167',NULL,NULL,'HARI OM MILK',5,'0','DR','RAJVEER GANDHI NAGAR SAI BABA MANDIR NEAR LAXMI GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'7039176188.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'818',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(819,'167',NULL,NULL,'HARI OM GENERAL',5,'0','DR','SHOP NO.4 MAMTA BAZAR KISAN NAGAR NO.3 ROAD NO. 3 WAGLE ESTATE THANE WEST RAYALADEVI AND WAGALE ESTATE','DEFAULT','THANE','21','400604',NULL,'9833639936.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'819',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(820,'167',NULL,NULL,'HARI OM GEN STORE',5,'0','DR','SHREE NAGER','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'820',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(821,'167',NULL,NULL,'HARI OM DHANYA BHANDAR',5,'0','DR','RAMCHANDRA NAGAR VAITIWADI NEAR NEW NATARAJ','DEFAULT','THANE','21','400604',NULL,'9819872439.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'821',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:07','2026-02-23 09:17:07'),(822,'167',NULL,NULL,'HARE KRISHNA MEDICAL',5,'0','DR','ROAD NO 28','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'822',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(823,'167',NULL,NULL,'HANUMAN SWEETS',5,'0','DR','LUISWADI','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'823',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(824,'167',NULL,NULL,'HANUMAN SWEET',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400602',NULL,'7666860627.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'824',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(825,'167',NULL,NULL,'HANUMAN SUPER MARKET',5,'0','DR','SHOP NO 1,UPKAR NIWAS, LOKMANYA NAGAR, PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'825',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(826,'167',NULL,NULL,'HANUMAN SUPER MARKET',5,'0','DR','SHASTRI NAGAR','','','21','',NULL,'8454095291','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'826',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(827,'167',NULL,NULL,'HANUMAN MASALA',5,'0','DR','CHADAI','DEFAULT','THANE','21','400603',NULL,'8652179786.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'827',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(828,'167',NULL,NULL,'HANUMAN GENERAL STORE',5,'0','DR','OPP GANESH MAIDAN CP TALAO ROAD NO 27 WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'828',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(829,'167',NULL,NULL,'GURUKRUPA SOCIETY',5,'0','DR','SHOP NO 9.SUVARNA CHS.GURUKUL ROAD.NEAR SHREE JI DRY FRUIT.NEAR PRITAM DAIRY FARM.PANCHPAKDI.THANE.WEST','DEFAULT','THANE','21','400602',NULL,'7030997745.0','',NULL,'27','27AEHPG2137F1ZU','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'829',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(830,'167',NULL,NULL,'GURUKRUPA PROVISION STORES',5,'0','DR','SHOP NO. 1 NEAR POLICE STATION NEXT TO SHREE KANCHARNATH SWAMI DUDHALAY KOPARI COLONY THANE EAST','DEFAULT','THANE','21','400602',NULL,'9653330520.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'830',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(831,'167',NULL,NULL,'GURUKRUPA PROVISION STORE',5,'0','DR','KISHAN NAGAR, BHATWADI NEAR MUKESH GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9321191935.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'831',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:08','2026-02-23 09:17:08'),(832,'167',NULL,NULL,'GURUKRUPA DRY FRUITS &AMP; GENERAL STORE',5,'0','DR','SHOP NO 1 RAMKARAN RAMRAJ CHWAL ROAD NO 8 PADWAL NAGER THANE W','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'832',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(833,'167',NULL,NULL,'GURUKRIPA SOCIETY',5,'0','DR','KOAPEI ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'9819107479.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'833',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(834,'167',NULL,NULL,'GURUKRIPA OIL DEPO',5,'0','DR','KOPARI KOLIWADA','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'834',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(835,'167',NULL,NULL,'GURUKRIPA OIL',5,'0','DR','KOOARI','DEFAULT','THANE','21','400603',NULL,'9833678521.0','',NULL,'27','','','IDBI BANK',NULL,NULL,'THANE EAST','13',NULL,NULL,NULL,NULL,NULL,'835',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(836,'167',NULL,NULL,'GURUDATTA MILK',5,'0','DR','KOPARI KOLIWADA','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'836',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(837,'167',NULL,NULL,'GURU KRUPA KIRANA STORE',5,'0','DR','SHOP NO 1.KISAN NAGAR NO 2 .ROAD NO 16.WAGLE ESTATE.NEAR DURGA HOTEL .THANE.WEST','DEFAULT','THANE','21','400604',NULL,'9920625225.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'837',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(838,'167',NULL,NULL,'GUPTA OIL DEPO AND GENERAL STORE',5,'0','DR','PADA NO 3 PARERA NAGAR LOKMANYA NAGAR OPP SANTOSH KIRANA AND GENERAL STORE NEAR RAJA SHIVAJI HIGH SC','DEFAULT','THANE','21','400604',NULL,'9869617351.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'838',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(839,'167',NULL,NULL,'GUPTA MILK SUPPLIERS',5,'0','DR','VIJAY APARTMENT MAHATAMA PHULE NAGAR','DEFAULT','THANE','21','400606',NULL,'8928680420.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'839',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(840,'167',NULL,NULL,'GUPTA KIRANA STORES',5,'0','DR','SHOP NO 111 JAI HIND CHS BLDG NO R-4 OLD SEIPAL COMPOUND KHARTAN ROAD NEXT TO SAI SANTI GENERAL STORES THANE WEST 400601','DEFAULT','THANE','21','400601',NULL,'9324578303.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'840',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(841,'167',NULL,NULL,'GUPTA JUSH',5,'0','DR','RAMCHANDRA NAGAR NEAR BAS DEPO','DEFAULT','THANE','21','400604',NULL,'9167925418.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'841',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:09','2026-02-23 09:17:09'),(842,'167',NULL,NULL,'GUPTA GENRAL STORE',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9920371077.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'842',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(843,'167',NULL,NULL,'GUPTA GENERAL STORES',5,'0','DR','SHOP R 4 OM SHREE SWAMI SAMARTH BLDG NEAR JEEVAN JTOTI  MEDICAL CENTER NEAR TO GANESH MANDIR KHARTAN ROAD THANE WEST MUMBAI','DEFAULT','THANE','21','400601',NULL,'8237273923.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'843',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(844,'167',NULL,NULL,'GUPTA GENERAL STORES',5,'0','DR','RAMCHANDAR NAGAR BEHIND POOJA DRYFRUITS NEAR SANJAY PROVISION STORES RAMCHANDAR NAGAR THANE','DEFAULT','THANE','21','400604',NULL,'9820577653.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'844',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(845,'167',NULL,NULL,'GUPTA GENERAL STORE',5,'0','DR','PARSIWADI NEAR JANTA PROVISION KOPARI COLONY THANE EAST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'845',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(846,'167',NULL,NULL,'GUPTA GENERAL STORE',5,'0','DR','AMBEWADI ROAD NO 22 NEAR SHIV SENA OFFICE','DEFAULT','THANE','21','400604',NULL,'9702045028.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'846',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(847,'167',NULL,NULL,'GULAB SWEETS FARSAN AND  DRYFRUITS',5,'0','DR','2 DEEP DARSHAN BLDG. OPP KERLA GENERAL STORE KISAN NAGER THANE WEST','DEFAULT','THANE','21','400604',NULL,'8450931857.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'847',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(848,'167',NULL,NULL,'GULAB KIRANA STORE',5,'0','DR','BEHIND SHIV SENA OFFICE NEAR BAJRANG KIRANA WAGLE ESTATE ROAD NO 22 AMBEWADI THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'848',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(849,'167',NULL,NULL,'GULAB GROSAR',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9967102705.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'849',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(850,'167',NULL,NULL,'GULAB GENERAL STORES',5,'0','DR','SHOP NO 5 TRIMURTI APARTMENT OPP IDEAL HIGH SCHOOL RABODI 2 THANE','DEFAULT','THANE','21','400607',NULL,'9619242652.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'850',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(851,'167',NULL,NULL,'GULAB GENERAL STORE',5,'0','DR','AMBEWADI ROAD NO 22 NEAR SHIV SENA SHAKHA WAGLE ESTATE','DEFAULT','THANE','21','400604',NULL,'8692936460.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'851',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:10','2026-02-23 09:17:10'),(852,'167',NULL,NULL,'GOODLUCK GENERAL STORES',5,'0','DR','SHOP NO.2 JEEVAN VIKAS SOCIETY NEAR G P PARSIK SAHAKARI BANK LOUISE WADI WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'852',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(853,'167',NULL,NULL,'GOLDEN CHEMIST',5,'0','DR','INDIRA NAGAR','NR RAMDEV DAIRY','THANE','21','400606',NULL,'9773737386','',NULL,'27','27APSPR3827F1ZE','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'853',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(854,'167',NULL,NULL,'GOKKUL HOUSE OF BENGALI SWEET',5,'0','DR','RAMCHANDRA NAGAR NEAR SHREE BALAJI DRYFRUITS','DEFAULT','THANE','21','400604',NULL,'7710025241.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'854',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(855,'167',NULL,NULL,'GIRISH BAKERY',5,'0','DR','KOAPEI','DEFAULT','THANE','21','400602',NULL,'9004995584.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'855',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(856,'167',NULL,NULL,'GIRI SIDDHI VINAYAK GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 2 LAKADI POOL NEAR SAI BABA VAD PAV','DEFAULT','THANE','21','400606',NULL,'9969490289.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'856',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(857,'167',NULL,NULL,'GIRI PROVISION STORE',5,'0','DR','PADWAL NAGAR PANCHAPARMESWAR MANDIR NEAR JAY AMBE D/B','DEFAULT','THANE','21','400606',NULL,'9819969907.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'857',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(858,'167',NULL,NULL,'GHANDHI KIRANA STORE',5,'0','DR','RAMNAGAR JUNA GAON, NEAR NEW MAHARASHTRA TRADING','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'858',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(859,'167',NULL,NULL,'GAYATRI SWEETS MART',5,'0','DR','DNYANESHWAR NAGAR NEAR MALDE STORE','DEFAULT','THANE','21','400604',NULL,'9323931316.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'859',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(860,'167',NULL,NULL,'GAYATRI GENERAL STORE',5,'0','DR','SHOP NO 1.SHELAR PADA.OPP GEETA GENERAL STORE.NEAR MUKESH SUPER MART.KOLBAD.THANE .WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'860',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(861,'167',NULL,NULL,'GAURAV GENERAL STORE',5,'0','DR','MISHRA COMPOUND OPP JAI BHAWANI MEDICAL KARWALO NAGAR ROAD NO 33 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'861',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:11','2026-02-23 09:17:11'),(862,'167',NULL,NULL,'GARDEN DRYFRUIT &AMP; G/S',5,'0','DR','SHOP NO 12 GOLDEN HEVAN SOCIETY KHOPAT THANE','DEFAULT','THANE','21','400601',NULL,'9004271111.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'862',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(863,'167',NULL,NULL,'GANGJI KHIMJI AND CO',5,'0','DR','GALA NO 1 OPP PRITAM JEWELLERY GOPIKA SADAN VITTHAL MANDIR GALLI WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'','',NULL,'27','27AHRPG8709N1ZJ','','BANK OF MAHARASTRA',NULL,NULL,'STATION ROAD','2',NULL,NULL,NULL,NULL,NULL,'863',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(864,'167',NULL,NULL,'GANGA GENERAL STORE',5,'0','DR','LOKMANYA NAGAR, PADA NO.4, NEAR OM SUPER MARKET SIDDHIVINAYAK TEMPLE','DEFAULT','THANE','21','400603',NULL,'9833463849.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'864',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(865,'167',NULL,NULL,'GANGA GENERAL STORE',5,'0','DR','KOPARI GAON NEAR HANUMAN MANDIR','DEFAULT','THANE','21','400606',NULL,'8108537108.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'865',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(866,'167',NULL,NULL,'GANESH SUPER MARKET',5,'0','DR','OPP PAPULAR DARMITARI NEAR ASHOK CINEMA CHAVATA HOUSE STATION ROAD THANE WEST','DEFAULT','THANE','21','400601',NULL,'8097228166.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'866',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(867,'167',NULL,NULL,'GANESH SUPER MARKET',5,'0','DR','ARADIA TOWER SAMTA NAGAR ROAD','DEFAULT','THANE','21','400606',NULL,'9372440098.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'867',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(868,'167',NULL,NULL,'GANESH SUPER MARKET',5,'0','DR','LOKMANYA NAGAR PADA NO 3,PARELA NAGAR NEAR AMBEDKAR PUTLA','DEFAULT','THANE','21','400606',NULL,'8655752239.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'868',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(869,'167',NULL,NULL,'GANESH SUPER MARKET',5,'0','DR','SHOP NO 04 ARADIA APT NEAR AARTI ACADEMY POKHARAN ROAD NO 01 SAMTANAGAR THANE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'869',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(870,'167',NULL,NULL,'GANESH STORE',5,'0','DR','CHARAI','DEFAULT','THANE','21','400603',NULL,'9004668977.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'870',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(871,'167',NULL,NULL,'GANESH KIRANA STORE',5,'0','DR','GULSHAN MANDIR  SHOP NO 2 SHIVAJI NAGAR NEAR BHAVANI DRY FRUIT THANE (W)','DEFAULT','THANE','21','400606',NULL,'9325847989.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'871',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:12','2026-02-23 09:17:12'),(872,'167',NULL,NULL,'GANESH GWNRAL',5,'0','DR','RABDOI','DEFAULT','THANE','21','400606',NULL,'9768728105.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'872',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(873,'167',NULL,NULL,'GANESH GRAIN STORE',5,'0','DR','MAHAGIRA','','','21','',NULL,'1234567890','',NULL,'27','27AAUPG3129N1Z6','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'873',NULL,NULL,NULL,NULL,NULL,'11516014001195','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(874,'167',NULL,NULL,'GANESH GRAIN STORE',5,'0','DR','GALA NO 1 MANILAL NARSHI BHAVAN OPP SHA MURJI COMPANY WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'1234567890','',NULL,'27','27AAUPG3129N1Z6','','GP PARSIK BANK LTD',NULL,NULL,'JAMBALI NAKA','2',NULL,NULL,NULL,NULL,NULL,'874',NULL,NULL,NULL,NULL,NULL,'11516014001195','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(875,'167',NULL,NULL,'GANESH GENRAL STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9082274166.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'875',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(876,'167',NULL,NULL,'GANESH GENERAL STORE',5,'0','DR','BHAVANI NAGAR SHIVSAHY CHAWL WAGLE ESTATE ROAD NO 32  NEAR AAKASH KIRANA STORE GENERAL STORE NEAR S','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'876',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(877,'167',NULL,NULL,'GANESH GEN STORE',5,'0','DR','PADA NO 3','NR MAYA DHANYA BHANDAR','THANE','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'877',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(878,'167',NULL,NULL,'GANADHISH MEDICAL',5,'0','DR','KESAR MILK NEAR ASARAM DAILY','DEFAULT','THANE','21','400604',NULL,'9769571551.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'878',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(879,'167',NULL,NULL,'GALA SUPER MARKAT',5,'0','DR','AROGYA NILAYM KISAN NAGER NO 3 THANE','DEFAULT','THANE','21','400606',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'879',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(880,'167',NULL,NULL,'GALA GENERAL STORE',5,'0','DR','SHOP NO 1 THAKUR HOUSE UTHALSER NAKA THANE','DEFAULT','THANE','21','400601',NULL,'9820263381.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'880',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(881,'167',NULL,NULL,'GAJANAN SWEET STORE',5,'0','DR','SATHE NAGAR, NEAR WAGLE BUS DEPO','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'881',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:13','2026-02-23 09:17:13'),(882,'167',NULL,NULL,'GAJANAN SUPER MARKET',5,'0','DR','ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'9702255186.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'882',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(883,'167',NULL,NULL,'GAJANAN STORE',5,'0','DR','CHAARI','DEFAULT','THANE','21','400603',NULL,'9819916265.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'883',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(884,'167',NULL,NULL,'GAJANAN KIRANA STORES.',5,'0','DR','SHOP NO. 1,2 NEAR SHIV SENA SHAKHA OPP DEVNARAYAN DAIRY NEXT TO HARDIK GENERAL STORES K.L COLONY GANDHI NAGAR KOPARI THANE EAST','DEFAULT','THANE','21','400603',NULL,'9380809625.0','',NULL,'27','','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'884',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(885,'167',NULL,NULL,'GAJANAN GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 4 NEAR OM SUPER MARKET  SHARMA STORE KE BAJU ME','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'885',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(886,'167',NULL,NULL,'GAJANAN DHANYA BHANDAR',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400603',NULL,'7710040999.0','',NULL,'27','27AHXPM3689B2ZQ','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'886',NULL,NULL,NULL,NULL,NULL,'11521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(887,'167',NULL,NULL,'FOOD MART',5,'0','DR','COSMOS PARADISE OPP DEVDAYA NG. POKHAN ROOD NO.1THANE W','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27BNPPM1158N1ZC','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'887',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(888,'167',NULL,NULL,'FLYLING CRUSH',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400602',NULL,'8169370567.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'888',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(889,'167',NULL,NULL,'FAMILY DRUG MEDICAL',5,'0','DR','VIJAY LAXMI GENERAL STORE NEAR GANDHI NAGAR ANAND NAGAR','DEFAULT','THANE','21','400603',NULL,'9926679500.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'889',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(890,'167',NULL,NULL,'EKVIRA GENERAL STORE',5,'0','DR','KALAMKAR HOUSE OPPOSITE MAHAVIR GENERAL STORE SHIVAJI NAGAR RABODI 2 THANE WEST','DEFAULT','THANE','21','400607',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'890',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(891,'167',NULL,NULL,'EKVEERA STORE',5,'0','DR','RAVODI','DEFAULT','THANE','21','400606',NULL,'8452013820.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'891',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:14','2026-02-23 09:17:14'),(892,'167',NULL,NULL,'EKAL SUPER MARKET',5,'0','DR','SHOP NO.1/2,SHREE NAGAR,NEAR A-ONE DHANYA BHANDAR STORE,SHREE NAGAR THANE (W)','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','27AREPP1300P2ZO','','HDFC BANK',NULL,NULL,'006833','3',NULL,NULL,NULL,NULL,NULL,'892',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(893,'167',NULL,NULL,'DURGA PROVISION STORE',5,'0','DR','SATHE NAGAR ROAD NO 22 OPP UPKAR DAIRY','DEFAULT','THANE','21','400604',NULL,'8976160618.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'893',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(894,'167',NULL,NULL,'DURGA MEDICAL AND GENERAL STORE',5,'0','DR','HIRA OIL DEPO NEAR VARTAK NAGAR','DEFAULT','THANE','21','400606',NULL,'9967149867.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'894',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(895,'167',NULL,NULL,'DURGA GENERAL STORE',5,'0','DR','OPP. RAJKAMAL NOVELTY LOKMANYA NAGAR PADA NO. 3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'895',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(896,'167',NULL,NULL,'DURGA FOODS',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400606',NULL,'9167940017.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'896',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(897,'167',NULL,NULL,'DURGA ENTERPRISE',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9930614721.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'897',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(898,'167',NULL,NULL,'DM TRADING',5,'0','DR','SHIVAJI NAGAR NR MARUTI GEN','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'898',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(899,'167',NULL,NULL,'DIVYA DRY FRUIT',5,'0','DR','WHSIALS','DEFAULT','THANE','21','400601',NULL,'9967636404.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'899',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(900,'167',NULL,NULL,'DINSHAWA ICE CREAM',5,'0','DR','NARESH KIRANA STORE','DEFAULT','THANE','21','400606',NULL,'9869468599.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'900',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(901,'167',NULL,NULL,'DINESH GENERAL STORE',5,'0','DR','AMBEVADI BHAJI MARKET ROAD NO 33 INDIRA NAGAR NEAR MAHALAXMI MEDICAL AND GRNRAL STORE THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'901',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:15','2026-02-23 09:17:15'),(902,'167',NULL,NULL,'DINESH GENERAL STORE',5,'0','DR','INDAR NAGAR BHAJI MARKET','DEFAULT','THANE','21','400605',NULL,'8828482816.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'902',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(903,'167',NULL,NULL,'DILIP DRY FRUITS AND GENERAL STORES',5,'0','DR','SHOP NO.1 GANESH PRASHAD LOKMANYA NAGAR PADA NO. 4 OPP. SHREE ASHAPURA SWEET AND SNACKS THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'903',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(904,'167',NULL,NULL,'DIAMOND GENERAL STORE',5,'0','DR','HAJURI NEAR HANUMAN MANDIR','DEFAULT','THANE','21','400604',NULL,'9967397015.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'904',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(905,'167',NULL,NULL,'DHRUVIN GENERAL STORE',5,'0','DR','SHOP NO 13,RUNWAL PLAZA VARTAK NAGAR, THANE WEST','DEFAULT','THANE','21','400604',NULL,'7309959077','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'905',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(906,'167',NULL,NULL,'DHIRAJLAL KANJI',5,'0','DR','MAHATMA PHULE MKT','DEFAULT','THANE','21','400601',NULL,'9664818288.0','',NULL,'27','27ACCPS6805R1ZV','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'906',NULL,NULL,NULL,NULL,NULL,'11518000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(907,'167',NULL,NULL,'DHIRAJ MASALA',5,'0','DR','DYANESHWAR NAGAR','','','21','',NULL,'1234567980','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'907',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(908,'167',NULL,NULL,'DHARMVEER GENERAL STORE',5,'0','DR','SHOP NO 1 NEAR DNYANODAY SCHOOL NEAR OM SAI SNACKS CENTRE NEXT TO SAVARKAR NAGAR POLICE CHAUKI THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'908',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(909,'167',NULL,NULL,'DHANRAJ MASALA',5,'0','DR','SHANT GYANESHWAR NAGAR  CHWAL NI 11 KAMGAHAR HOSPITAL ROAD NO 33  NEAR SIDDHIVINAYAK MEDICAL WAGHALE','DEFAULT','THANE','21','400604',NULL,'9082968050.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'909',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(910,'167',NULL,NULL,'DHANLAXMI SWEETS',5,'0','DR','SHANTI NAGAR','DEFAULT','THANE','21','400604',NULL,'9769610956.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'910',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(911,'167',NULL,NULL,'DHANLAXMI MEDICAL',5,'0','DR','INDIAR NAGAR SATHE NAGAR ROAD NO 22 WAGLE STATE NEAR UPKAR DAILY','DEFAULT','THANE','21','400604',NULL,'8104598624.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'911',NULL,NULL,NULL,NULL,NULL,'21524000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:16','2026-02-23 09:17:16'),(912,'167',NULL,NULL,'DHANASHREE KIRANA STORES',5,'0','DR','NEAR RAJA SHIVAJI SCHOOL OPP. OM SAI TRADERS LOKMANYA NAGAR PADA NO 4 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'912',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(913,'167',NULL,NULL,'DHANASHREE GEN STORE',5,'0','DR','KHATAN','OPP CREM CORNER','','21','',NULL,'9987507323','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'913',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(914,'167',NULL,NULL,'DHAN LAXMI SUPER MARKET',5,'0','DR','GOKUL NAGAR NEAR SHIV SENA SAKH KHOPAT','DEFAULT','THANE','21','400601',NULL,'9987468035.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'914',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(915,'167',NULL,NULL,'DEVIKA SUPER MARKET',5,'0','DR','KOPARI GAO','DEFAULT','THANE','21','400606',NULL,'8169567332.0','',NULL,'27','','','SVC COP BANK',NULL,NULL,'KOPRI','25',NULL,NULL,NULL,NULL,NULL,'915',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(916,'167',NULL,NULL,'DEVASHI KIRANA STORES',5,'0','DR','SHOP NO 8 RUPADEVI PADA NO 1 OPP SANJAY GANDHI UDYAN, RD NO 33,INDIRA NAGAR, WAGALE ESTATE THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'916',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(917,'167',NULL,NULL,'DEVANSH KIRANA',5,'0','DR','KOPRI ANAND NAGAR NAGAR','NEAR BAJRANG DAIRY','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'917',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(918,'167',NULL,NULL,'DEV GANESH DAIRY',5,'0','DR','PADA NO 3','LAKDI POOL','','21','',NULL,'8104995258','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'918',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(919,'167',NULL,NULL,'DEEPAK OIL CENTRE AND GENERAL STORE',5,'0','DR','MADVI HOUSE UTHALSAR NAKA NEAR PALASH DRY FRUITS OPP ROYAL DRY FRUIT THANE WEST','DEFAULT','THANE','21','400601',NULL,'9819969726','',NULL,'27','27AAUPG3857B1ZK','','AXIS BANK',NULL,NULL,'UTHALSAR','24',NULL,NULL,NULL,NULL,NULL,'919',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(920,'167',NULL,NULL,'DEEPAK LASSI HOUSE',5,'0','DR','SHOP NO.22,MEN BAJAR,KOPRI COLONY,NEAR JAY SANKAR BAR AND RESTAURANT,THANE (E)','DEFAULT','THANE','21','400602',NULL,'9867266096.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'920',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:17','2026-02-23 09:17:17'),(921,'167',NULL,NULL,'DEEPAK KIRANA',5,'0','DR','AZAD NAGAR 1','NEAR NAGNESHI DHANYA BHANDAR','','21','',NULL,'9819884753','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'921',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(922,'167',NULL,NULL,'DEEPAK GENRAL STORE',5,'0','DR','VRINDAVAN','DEFAULT','THANE','21','400602',NULL,'9892505682.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'922',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(923,'167',NULL,NULL,'DEEPAK DRY FRUITS AND PROVISION STORE',5,'0','DR','SHOP NO 19 BLD NO 08 DEVDAYA NAGAR POKHARAN ROAD NO 01 THANE WEST','DEFAULT','THANE','21','400604',NULL,'9004630474.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'923',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(924,'167',NULL,NULL,'DEEP OIL DEPOT 27ADIPN3690A1ZM',5,'0','DR','MAHAGIRI','','THANE','21','400601',NULL,'1234567890','',NULL,'27','27ADIPN3690A1ZM','','GP PARSIK SAHAKARI BANK LTD',NULL,NULL,'JAMBHALI NAKA','5',NULL,NULL,NULL,NULL,NULL,'924',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(925,'167',NULL,NULL,'DEEP OIL',5,'0','DR','MAHAGIRI','NR SAJANAND OIL','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'925',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(926,'167',NULL,NULL,'DEDIYA GENERAL STORE',5,'0','DR','AZAD NAGAR MASANWADA','DEFAULT','THANE','21','400606',NULL,'9819063696.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'926',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(927,'167',NULL,NULL,'DEDHIA STORE',5,'0','DR','MASANWADA AZAD NAGAR SHOP NO 1.NEAR CASTAL MIL.NEAR NILESH DHANAYA BHANDAR.NEAR THAKARE GARDEN.','DEFAULT','THANE','21','400602',NULL,'9820252971.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'927',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(928,'167',NULL,NULL,'DATTATRAY DRYFRUIT AND KIRANA STORES',5,'0','DR','SHOP NO.9 SAHYADRI SOCIETY RAVI COMPOUND NEAR PRASHANT CORNER NEAR TALWALKAR GYM PANCHPAKGADI HARINIWAS CIRCLE THANE WEST THANE 400602','DEFAULT','THANE','21','400602',NULL,'9892129636.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'928',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(929,'167',NULL,NULL,'DARSHAN TRADERS',5,'0','DR','SHOP NO 6 MANILAL NARSI BHAVAN MOHAMMED ALI ROAD WHOLSALE MARKET','OPP ALFA TRADERS AND NATIONAL TRADERS','THANE','21','400601',NULL,'9867098063','',NULL,'27','27AHSPC1893J1ZV','','ARIHANT BANK',NULL,NULL,'RAM MARUTI ROAD','5',NULL,NULL,NULL,NULL,NULL,'929',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(930,'167',NULL,NULL,'DARSAN TRADER',5,'0','DR','STN RODA','DEFAULT','THANE','21','400602',NULL,'9930537891','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'930',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:18','2026-02-23 09:17:18'),(931,'167',NULL,NULL,'D M TREADING',5,'0','DR','MATOSHRI NIWASH  SHOP NO  3 SHIVAJI NAGAR OPP APPOLO PHARMACY THANE WEST','DEFAULT','THANE','21','400606',NULL,'9920252211.0','',NULL,'27','27AFGPT1690E1ZA','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'931',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(932,'167',NULL,NULL,'CREAM CORNOR',5,'0','DR','KHATAN ROAD','DEFAULT','THANE','21','400602',NULL,'8291011608.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'932',NULL,NULL,NULL,NULL,NULL,'215114000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(933,'167',NULL,NULL,'COUNTER SALE',5,'0','DR','VASANT VIHAR','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','26',NULL,NULL,NULL,NULL,NULL,'933',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(934,'167',NULL,NULL,'COMPOUND MEDICAL',5,'0','DR','VISHAL GENERAL STORE NEAR SHIVAJI NAGAR','DEFAULT','THANE','21','400604',NULL,'9594881161.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'934',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(935,'167',NULL,NULL,'CHOUDHRI DHANYA BHANDAR',5,'0','DR','SHOP NO T1K96 FLOWERVELLY OPP ESTER EXPRESS HIGHWAY THANE','DEFAULT','THANE','21','400601',NULL,'9920852634.0','',NULL,'27','','','BANK OF BARODA',NULL,NULL,'FLOWER VALLEY','24',NULL,NULL,NULL,NULL,NULL,'935',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(936,'167',NULL,NULL,'CHOUDHARY SUPET MARKET',5,'0','DR','KOPRI GOAN SHOP NO 1 KULDEEP BUILDING THANE EAST','DEFAULT','THANE','21','400602',NULL,'9930174343.0','',NULL,'27','27AIVPC7057L1ZL','','',NULL,NULL,'','27',NULL,NULL,NULL,NULL,NULL,'936',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(937,'167',NULL,NULL,'CHODARY DHANYA BHANDAR',5,'0','DR','KOLBAD','DEFAULT','THANE','21','400602',NULL,'9867389112.0','',NULL,'27','','','BANK OF BARODA',NULL,NULL,'003591','24',NULL,NULL,NULL,NULL,NULL,'937',NULL,NULL,NULL,NULL,NULL,'11511400000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(938,'167',NULL,NULL,'CHITALI GENRAL STORE',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9892379345.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'938',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(939,'167',NULL,NULL,'CHIRAG GENERAL STORE',5,'0','DR','VARTAK NAGAR NEAR ANAND GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'9987818851.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'939',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(940,'167',NULL,NULL,'CHINTAMANI PROVISION STORE',5,'0','DR','SHOP NO 4 RAJDEEN APARTMENT MENTAL HOSPITAL ROAD THANE WEST','DEFAULT','THANE','21','400606',NULL,'8779057765.0','',NULL,'27','','','TJSB SAHAKARI BANK',NULL,NULL,'WAGLE ESTATE','17',NULL,NULL,NULL,NULL,NULL,'940',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:19','2026-02-23 09:17:19'),(941,'167',NULL,NULL,'CHIKANE MASALA STORE',5,'0','DR','BHAJI MARKET PADWAL NAGAR NEAR S K ENTERPRISES','DEFAULT','THANE','21','400606',NULL,'7039188393.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'941',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(942,'167',NULL,NULL,'CHHEDA DRY FRUITS',5,'0','DR','SHOP NO 2 SHOPAN SOCIETY RAM MARUTI ROAD THANE WEST','DEFAULT','THANE','21','400602',NULL,'9619096320.0','',NULL,'27','27AACFC8302M1ZE','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'942',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(943,'167',NULL,NULL,'CHECK NAKA PROVISION STORE',5,'0','DR','SHOP NO 1MULUND CHECK NAKA AGARAROAD RAM NAGAR','DEFAULT','THANE','21','400606',NULL,'9967565681.0','',NULL,'27','27AABPK8008M1ZJ','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'943',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(944,'167',NULL,NULL,'CHECK NAKA PROVISION',5,'0','DR','SHIVAJI NAGAR NR MULUND CHECK NAKA','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'944',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(945,'167',NULL,NULL,'CHAUDHRY GENERAL STORE',5,'0','DR','AMBEWADI ROAD NO 22 OPP SHIV SENA OFFICE','DEFAULT','THANE','21','400604',NULL,'9004944060.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'945',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(946,'167',NULL,NULL,'CHARLING ICE CREAM',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400606',NULL,'8291663562.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'946',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(947,'167',NULL,NULL,'CHARBHUJA GENERAL STORE',5,'0','DR','LOKMANYA NAGAR PADA NO 4 SAI GANESH SOCIETY RAJASHIVAJI VIDYALAYA ROAD THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27AKNPP6118K1ZM','','GP PARSIK SAHAKARI BANK LTD',NULL,NULL,'MAJIWADE','18',NULL,NULL,NULL,NULL,NULL,'947',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(948,'167',NULL,NULL,'CHAPPAN BHOG',5,'0','DR','HANUMAN NAGAR ROAD NO 34','DEFAULT','THANE','21','400604',NULL,'8451090064.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'948',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(949,'167',NULL,NULL,'CHANDAN MAL (NAKODA)',5,'0','DR','MAHAGIRI','NR DEEP OIL','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'949',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(950,'167',NULL,NULL,'CHANDAN KIRANA STORE',5,'0','DR','SHOP NO. 2 NEXT TO PRATIMA GUPTA CLICNIC AMBEDKAR CHOWK LOKMANYA NAGAR PADA NO. 3 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'950',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:20','2026-02-23 09:17:20'),(951,'167',NULL,NULL,'CHANDAN',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9619784967.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'951',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(952,'167',NULL,NULL,'CHAMUNDA KIRANA STORE',5,'0','DR','SHIVAJI NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'952',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(953,'167',NULL,NULL,'CHAMUNDA GENERAL STORE',5,'0','DR','RAJA SHIVAJI SCHOOL NEAR WATER TANK LOKMANYA NAGAR PADA NO 4 THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'953',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(954,'167',NULL,NULL,'CHAMUNDA GEN STORE',5,'0','DR','LAXMI PARK','NR PURNIMA TRADERS','THANE','21','',NULL,'8824662773','',NULL,'27','','','KOTAK MAHINDRA BANK',NULL,NULL,'VARTAK NAGAR','9',NULL,NULL,NULL,NULL,NULL,'954',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(955,'167',NULL,NULL,'CHAMUNDA  GEN STORE',5,'0','DR','INDIRA NAGAR RUPADEVI PADA WAGLE STREET  THANE WEST MUMBAI','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'955',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(956,'167',NULL,NULL,'CHALKE SIR',5,'0','DR','COUNTER SALE','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','26',NULL,NULL,NULL,NULL,NULL,'956',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(957,'167',NULL,NULL,'C K T ENTERPRISES',5,'0','DR','15 SAILAKE RESIDENCEY NEAR ADHARSH NAGAR KOLBAD THANE WEST THANE MAHARASHTRA','DEFAULT','THANE','21','400601',NULL,'9004700330.0','',NULL,'27','27AAPFC5344L1ZZ','','BANK OF MAHARASTRA',NULL,NULL,'STATION ROAD','2',NULL,NULL,NULL,NULL,NULL,'957',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(958,'167',NULL,NULL,'BRIJESH TREDARS',5,'0','DR','1AWADH BHAVAN ROAD NO 7 PADWAL NAGER OPP S K YADHAV NIWAS  WAGHLE ESTATE THANE W','DEFAULT','THANE','21','400606',NULL,'9029360102.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'958',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(959,'167',NULL,NULL,'BRIJESH TRADARS',5,'0','DR','PADWAL NAGAR PANCHAPARMESWAR MANDIR NEAR JALARAM TEA','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'959',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(960,'167',NULL,NULL,'BHURALAL SHIVJI PATEL GENERAL STORE',5,'0','DR','SHOP NO 01 PATEL NIWAS NEXT TO INN TOUCH GALARY OPP MANPASAND SWEET NEAR SHREE SAINATH BOOK DEPOT OPP SHREE DEV GANESH DAIRY SAWARKAR NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'9699230989.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'960',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:21','2026-02-23 09:17:21'),(961,'167',NULL,NULL,'BHUMI FOOD MART',5,'0','DR','SHOP NO. 2 LOKMANYA NAGAR NEAR GAYANOADAY SCHOOL NEXT TO SAMIR TRADERS THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27AFEPG6152N1Z7','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'961',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(962,'167',NULL,NULL,'BHOLENATH TREDARS',5,'0','DR','SAWARKAR NAGAR NEAR UDAY FOOD KE SAMNEE','DEFAULT','THANE','21','400604',NULL,'7600275341.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'962',NULL,NULL,NULL,NULL,NULL,'15521000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(963,'167',NULL,NULL,'BHOLENATH KIRANA STORE',5,'0','DR','HAJURI GOAN NAMDEV MATHRE CHAWL NEAR SHREE RADHE OIL DEPO AND JAI SANTOSHI MAA GENERAL STORE WAGLE E','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'963',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(964,'167',NULL,NULL,'BHINAMI STORE',5,'0','DR','SHOP NO. 5 TEMBHI NAKA OPP. CIVIL HOSPITAL NEAR JAIN MANDIR THANE WEST MUMBAI 400601','DEFAULT','THANE','21','400601',NULL,'8779585031.0','',NULL,'27','27BTKPS7056J1ZY','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'964',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(965,'167',NULL,NULL,'BHERUNATH KIRANA STORE',5,'0','DR','INDIAR NAGAR RUPA DEVI PADA NO 1.  NEAR KRISHNA SUPER MARKET','DEFAULT','THANE','21','400604',NULL,'8108654179.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'965',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(966,'167',NULL,NULL,'BHAWANI GENRAL STORE',5,'0','DR','SHANTI NAGAR','DEFAULT','THANE','21','400606',NULL,'9930149708.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'966',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(967,'167',NULL,NULL,'BHAWANI GEN STORE',5,'0','DR','HIWAY SHIRIN APT MENTAL HOSPITAL ROAD NEAR DYANSADHANA COLLAGE PARAB WADI THANE WEST 400604','DEFAULT','THANE','21','400606',NULL,'7738755010.0','',NULL,'27','27ADEPC6852B1ZX','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'967',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(968,'167',NULL,NULL,'BHAWANI DRY FRUITS',5,'0','DR','SHOP NO 8 SHUBHALAXMI CHS OPP BANK OF MAHARASHTRA  SHREE NAGAR WAGLE ESTATE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'968',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(969,'167',NULL,NULL,'BHAWANI DAIRY',5,'0','DR','HAJURI NEAR SHABNAM KIRANA STORE','DEFAULT','THANE','21','400604',NULL,'9391541450.0','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'969',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(970,'167',NULL,NULL,'BHAWANA GENRAL',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9930907730.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'970',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:22','2026-02-23 09:17:22'),(971,'167',NULL,NULL,'BHAVNAGAR SWEET',5,'0','DR','OM SHIVAM GENERAL STORE KRISHNA NAGAR NO 1','DEFAULT','THANE','21','400604',NULL,'9930127972.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'971',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(972,'167',NULL,NULL,'BHAVESH TRADING CO',5,'0','DR','SHOP 02 AMBEWADI BHAJI MARKET NEAR DINESH GERENAL STORE ROAD NO 33 INDIRA NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'8850296885.0','',NULL,'27','27CLOPK8302E1Z1','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'972',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(973,'167',NULL,NULL,'BHAVESH TRADING',5,'0','DR','BHAJI MARKIT OPP SADHANA MASALA INDIRA NAGAR','DEFAULT','THANE','21','400606',NULL,'7977409966.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'973',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(974,'167',NULL,NULL,'BHAVANI GENERAL STORE',5,'0','DR','SHOP NO 2,PATIL BLDG, NR BHAJI MARKET, BHD MAHAVIR MEDICAL, SHANTI NAGAR, WAGALE ESTATE, THANE WEST','DEFAULT','THANE','21','400606',NULL,'9930339401.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'974',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(975,'167',NULL,NULL,'BHAVANI DRY FOOD AND GENERAL STORES',5,'0','DR','SHOP NO 4 SUN PLAZA SHOPING CENTER NEAR LIFE LINE MEDICAL','OPPOSITE SANIDHI PARK BUILDING HARI OM NAGAR KOPRI THANE EAST','THANE','21','400603',NULL,'9619754854','',NULL,'27','27AKIPC1698L1ZR','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'975',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(976,'167',NULL,NULL,'BHAVANI  SUPER MARKET',5,'0','DR','CHWAL NO.53/54,SANT ZYANESHWAR NAGAR,WAGLE STATE,NEAR SANKAR MANDIR,ZYANESWER NAGAR,THANE (W)','DEFAULT','THANE','21','400604',NULL,'9892450582.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'976',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(977,'167',NULL,NULL,'BHARAT GENRAL STORE',5,'0','DR','KHATAN ROAD','DEFAULT','THANE','21','400602',NULL,'9619418328.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'977',NULL,NULL,NULL,NULL,NULL,'21511400000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(978,'167',NULL,NULL,'BHARAT GENERAL STORES',5,'0','DR','SHOP NO 3,SAI SANKET APPARTMENT,NEAR GANESH MANDIR,NEAR OM SUPER MARKET LOKMANYA NAGAR PADA NO 4,THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'978',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(979,'167',NULL,NULL,'BHAKTI PLUS',5,'0','DR','PANCHPAKADI','DEFAULT','THANE','21','400603',NULL,'9322242347.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'979',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(980,'167',NULL,NULL,'BHAIRAV SUPER MARKET',5,'0','DR','CHOUDHARY CHAWL, NEAR PANCHSHIL SCHOOL, LOKMANYA NAGAR PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'980',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:23','2026-02-23 09:17:23'),(981,'167',NULL,NULL,'BHAIRAV KIRANA AND GENERAL STORES',5,'0','DR','PLOT NO 32 ROOM NO D 4  SWAPNA CHS YOSHODHAN NAGAR NEAR MTNL OFFICE THANE WEST','DEFAULT','THANE','21','400602',NULL,'7977460958.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'981',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(982,'167',NULL,NULL,'BHAGYAWAN DHNYA BHANDAR',5,'0','DR','SHOP NO 1 AND 2 PATEL NIWAS LOKMANYA NAGAR  PADA NO 3 OPP SHRI MAHALAXMI JEWELLERS THANE WEST','DEFAULT','THANE','21','400604',NULL,'9833524626.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'982',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(983,'167',NULL,NULL,'BHAGYA LAXMI KIRANA AND GENERAL STORE',5,'0','DR','RAJA SHIVAJI SCHOOL ROAD OPP.  SHIVSENA SHAKHA NEAR CHAR BHUJA LOKMANYA NAGAR PADA NO.4 THANE WEST','DEFAULT','THANE','21','400604',NULL,'9324243650.0','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'983',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(984,'167',NULL,NULL,'BHAGWATI SWEETS AND SNACKS',5,'0','DR','KISAN NAGAR 2','','','21','',NULL,'9702616636','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'984',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(985,'167',NULL,NULL,'BHAGWATI DRY FRUITS',5,'0','DR','SHOP NO 1 SWARGANDHA CHS LTD NEAR OM TRADING OPP SHIVANI HOSPITAL SHREE NAGAR WAGLE ESTATE THANE','DEFAULT','THANE','21','400606',NULL,'9987312431.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'985',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(986,'167',NULL,NULL,'BHAGVATI GENARAL STORE',5,'0','DR','DNYANDA H S G SOC D 4KARWALO   SINDHUDIRGA KINARA HOTEL SAVARKAR NAGAR  NAGAR THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'986',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(987,'167',NULL,NULL,'BALAJI TRADERS',5,'0','DR','SHOP NO 02 SECTOR 07 DEV ASHISH BUNGALOW SHREE NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'9892858436.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'987',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(988,'167',NULL,NULL,'BALAJI TRADER',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'7021415035.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'988',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(989,'167',NULL,NULL,'BALAJI STORES',5,'0','DR','53.B.S3.VRINDAVAN SOCIETY.NEAR RAJAL MEDICO.NEAR HOTEL OMKAR.','DEFAULT','THANE','21','400602',NULL,'8451986853.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'989',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(990,'167',NULL,NULL,'BALAJI LOW PRICE',5,'0','DR','SHOP NO 8 NEW ANAND PARK MOHANJI SUNDERJI ROAD RAGHUNATH NAGAR WAGLE ESTATE THANE W','DEFAULT','THANE','21','400606',NULL,'9819503911.0','',NULL,'27','27AHWPB4146P1ZO','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'990',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:24','2026-02-23 09:17:24'),(991,'167',NULL,NULL,'BALAJI DAIRY',5,'0','DR','AZAD NAGAR NEAR NAGESHI DHANY BHANDAR','DEFAULT','THANE','21','400602',NULL,'7724939443.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'991',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(992,'167',NULL,NULL,'BAJRANG DAIRY',5,'0','DR','ANAND NAGAR','DEFAULT','THANE','21','400606',NULL,'9967491004.0','',NULL,'27','','','',NULL,NULL,'','25',NULL,NULL,NULL,NULL,NULL,'992',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(993,'167',NULL,NULL,'BAGESHWAR BALAJI DARIY',5,'0','DR','LOKMANYA NAGAR PADA NO 3 NEAR ROHIT MASALA','DEFAULT','THANE','21','400606',NULL,'8080004064.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'993',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(994,'167',NULL,NULL,'BADARIYA GENERAL STORE',5,'0','DR','KISAN NGR.2 RD.16 WE OPP JANTA STORE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9321123275.0','',NULL,'27','27AKPPG5289C1ZW','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'994',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(995,'167',NULL,NULL,'BABUBHAI AND CO',5,'0','DR','WHOASSL','DEFAULT','THANE','21','400604',NULL,'8369192032.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'995',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(996,'167',NULL,NULL,'AYYAPPA STORES',5,'0','DR','SHOP NO 2 GROUND FLOOR 56 ABRINDAVAN COMPLEX BRINDAVAN','DEFAULT','THANE','21','400602',NULL,'9967223827.0','',NULL,'27','27AHKPK9017A1ZI','','UNION BABK OF INDIA',NULL,NULL,'VRINDAVAN','6',NULL,NULL,NULL,NULL,NULL,'996',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(997,'167',NULL,NULL,'AYESHA MEDICAL AND GENRAL STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9699007888.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'997',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(998,'167',NULL,NULL,'AVIRAM ICECREAM PARLOUR AND GENERAL STORES',5,'0','DR','NEAR SASTRI NAGAR LAST BUS STOP VARTAK NAGAR OPP SHAH BROTHERS AND OPP BABUBHAI SHAH VARTAK NAGAR THANE','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'998',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(999,'167',NULL,NULL,'AVINASH GENERAL STORE',5,'0','DR','SHOP NO 1.ROAD NO 22.KISAN NAGAR NO 3.NEAR AMOL DAIRY.NEAR LAXMI GENERAL STORE.KISAN NAGAR .THANE WEST','DEFAULT','THANE','21','400604',NULL,'9769763671.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'999',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(1000,'167',NULL,NULL,'AUDHAVRAM TREADING',5,'0','DR','ROAD NO.22,INDRA NAGAR,OPP.YAS BANK ATM,THANE W ,DOWN STATE BANK OF INDIA CUSTOMER SERVICE','DEFAULT','THANE','21','400604',NULL,'8828375742.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'1000',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:25','2026-02-23 09:17:25'),(1001,'167',NULL,NULL,'ATUL MEDICAL STORE',5,'0','DR','CHARAI NEAR SHAH BHAVANJI KHIMJI','DEFAULT','THANE','21','400602',NULL,'9004813430.0','',NULL,'27','','','',NULL,NULL,'','24',NULL,NULL,NULL,NULL,NULL,'1001',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1002,'167',NULL,NULL,'ATHITHI FARSAN MART',5,'0','DR','SAVARKAR NAGAR','DEFAULT','THANE','21','400603',NULL,'8451827054.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'1002',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1003,'167',NULL,NULL,'ASTHA DHANYA BHANDAR',5,'0','DR','KISAN NAGAR 22 NO ROAD','DEFAULT','THANE','21','400606',NULL,'9930872001.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'1003',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1004,'167',NULL,NULL,'ASMITA OIL AND SIAP DEPO',5,'0','DR','SHOP NO 28 JAKAT NAKA SHOPING COMPLEX SECTOR 2 NEAR DENA BANK OPP MADAN MEDICAL AND GENERAL STORES CHEMISHT AND DRUGGIST SHREE NAGAR WAGALE ESTATE THANE','DEFAULT','THANE','21','400606',NULL,'9820250385.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'1004',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1005,'167',NULL,NULL,'ASHWIN KUMAR RAMJI AND COMPANY',5,'0','DR','SHOP NO 4 KARSANDAS DEVJI BLDG STATION RIAD CHENDANI NAKA NEAR ASHOK SINEMA  THANE WEST','DEFAULT','THANE','21','400601',NULL,'9920495204.0','',NULL,'27','27AAGFA0085R1Z2','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'1005',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1006,'167',NULL,NULL,'ASHTAVINAYAK GENERAL STORE',5,'0','DR','DHYANESHWAR NAGAR BESIDE PANCH PARMESHWAR MANDIR OPPOSITE MISHRA DAIRY THANE WEST','DEFAULT','THANE','21','400604',NULL,'9653226396.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1006',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1007,'167',NULL,NULL,'ASHTA DHANYA BAHNDAR',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400606',NULL,'8639842366.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'1007',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1008,'167',NULL,NULL,'ASHOK TRADERS',5,'0','DR','VIJAY NIWAS SHOP NO 3 PADWAL NAGAR THANE WEST  400604','DEFAULT','THANE','21','400606',NULL,'8169628236.0','',NULL,'27','','','THANE JANTA SAHKARI BANK LTD',NULL,NULL,'WAGLE ESTATE','22',NULL,NULL,NULL,NULL,NULL,'1008',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1009,'167',NULL,NULL,'ASHOK MEDICAL',5,'0','DR','KISHAN NAHAR','DEFAULT','THANE','21','400603',NULL,'9664814809.0','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'1009',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1010,'167',NULL,NULL,'ASHISH GENERAL STORE',5,'0','DR','HANUMAN NAGAR ROAD NEAR 34','DEFAULT','THANE','21','400604',NULL,'8469336980.0','',NULL,'27','','','',NULL,NULL,'','23',NULL,NULL,NULL,NULL,NULL,'1010',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:26','2026-02-23 09:17:26'),(1011,'167',NULL,NULL,'ASHIRWAD GENERAL STORES',5,'0','DR','JAIBHIM NAGAR NEAR BY ABACUS TEXTILES PVT LTD CP TALAV ROAD NO 27 WAGLE ESTATE THANE WEST','DEFAULT','THANE','21','400604',NULL,'9594523173.0','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'1011',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1012,'167',NULL,NULL,'ASHAPURA SUPER MARKET',5,'0','DR','LOKMANYA NAGAR NR SHIVSENA SHAKHA','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'1012',NULL,NULL,NULL,NULL,NULL,'21521100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1013,'167',NULL,NULL,'ASHAPURA SUPER MARKET',5,'0','DR','SANT GYANESHWAR NAGAR WAGLE ESTATE OPP MATOSHRI SAVITRI BAI PHULE CHL THANE WEST','DEFAULT','THANE','21','400604',NULL,'7208192554.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1013',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1014,'167',NULL,NULL,'ASHAPURA PROVISION',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'7738035060.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1014',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1015,'167',NULL,NULL,'ASHAPURA OIL DEPOT',5,'0','DR','SHOP NO 1, BABULAL CHAWL, NEAR HANUMAN MANDIR, SHIVAJI SCHOOL ROAD, LOKMANYA NAGAR, PADA NO 4, THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'1015',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1016,'167',NULL,NULL,'ASHAPURA OIL DEPO',5,'0','DR','SHIVAJI NAGAR OPP MARUTI GENERAL STORE','DEFAULT','THANE','21','400604',NULL,'9920355078.0','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'1016',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1017,'167',NULL,NULL,'ASHAPURA KIRANA STORE',5,'0','DR','SHOP NO 3.4.SINGH NAGAR.NEAR PADMA GENERAL STORE.NEAR POOJA GENERAL STORE.KHOPAT. THANE WEST','DEFAULT','THANE','21','400601',NULL,'9987989953.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1017',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1018,'167',NULL,NULL,'ASHAPURA GENRAL STORE',5,'0','DR','SHIVAJI NAGAR','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','22',NULL,NULL,NULL,NULL,NULL,'1018',NULL,NULL,NULL,NULL,NULL,'11512100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1019,'167',NULL,NULL,'ASHAPURA GENERAL STORE',5,'0','DR','SHOP NO 1 SHIVAM NIWAS POKHARAN ROAD NO 1 JK GRAM THANE WEST UPVAN','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'1019',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1020,'167',NULL,NULL,'ASHAPURA GEN',5,'0','DR','SHASTRI NAGAR','MR MAHAKALI STORE','','21','',NULL,'9967556744','',NULL,'27','','','CANARA BANK',NULL,NULL,'VASANT VIHAR','10',NULL,NULL,NULL,NULL,NULL,'1020',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:27','2026-02-23 09:17:27'),(1021,'167',NULL,NULL,'ASHAPURA ENTERPRISERS',5,'0','DR','PADA NO 2','NR MAHAKALI TRADERS','','21','',NULL,'9714327907','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'1021',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1022,'167',NULL,NULL,'ASHAPURA DRYFRUITS AND SWEETS CORNER',5,'0','DR','LOKMANYA NAGAR PADA NO 2 NEAR MAMTA SWEETS OPP AKSHAY MEDICAL AND GENERAL STORES NEAR AAIJEE MEDICAL AND GENERAL STORE  THANE WEST','DEFAULT','THANE','21','400604',NULL,'8779146509.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'1022',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1023,'167',NULL,NULL,'ASHA GENERAL STORE',5,'0','DR','SHOP NO.2 .GURUKUL ROAD.OPP SHREE RAVECHI PROVISION STORE.NEAR PRITAM DAIRY FARM.PANCHPAKDI.THANE.WEST','DEFAULT','THANE','21','400602',NULL,'9867252390.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'1023',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1024,'167',NULL,NULL,'ARMAN GRAIN',5,'0','DR','HAJURI DARGA ROAD','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'1024',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1025,'167',NULL,NULL,'ARIHANT KIRANA STORE',5,'0','DR','SHOP NO-5,SHIV SAHI APT,PATIL WADI,SAVARKAR NAGAR,THANE WEST','DEFAULT','THANE','21','400604',NULL,'9769695721.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'1025',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1026,'167',NULL,NULL,'ARIHANT BAZAR',5,'0','DR','VAIDYA APARMENT SHANTI NAGAR ROAD NO 27 THANE','DEFAULT','THANE','21','400604',NULL,'9820820999.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'1026',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1027,'167',NULL,NULL,'AQSA MEDICAL',5,'0','DR','RABDOI','DEFAULT','THANE','21','400603',NULL,'9029734508.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1027',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1028,'167',NULL,NULL,'APNA SOCIETY',5,'0','DR','RABOSI','DEFAULT','THANE','21','400606',NULL,'7045499630.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1028',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1029,'167',NULL,NULL,'APNA GHAR PROVISION STORE',5,'0','DR','SOLANKI APARTMENT  PIPELINE ROAD LOUIS WADI NEAR AMBIKA SUPER MARKET THANE WEST','DEFAULT','THANE','21','400604',NULL,'9930324472.0','',NULL,'27','27ACDPP0706B1Z6','','FEDERAL BANK',NULL,NULL,'LOUISWADI','19',NULL,NULL,NULL,NULL,NULL,'1029',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1030,'167',NULL,NULL,'APNA BHANDAR',5,'0','DR','LAXMI COMPLEX POKHARAN ROAD NO 1 NEAR MAHESHWARI STORE VARTAK NAGAR THANE WEST','DEFAULT','THANE','21','400606',NULL,'9967977666','',NULL,'27','27AATPG9334N1ZW','','ICICI',NULL,NULL,'1','19',NULL,NULL,NULL,NULL,NULL,'1030',NULL,NULL,NULL,NULL,NULL,'11516014001438','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:28','2026-02-23 09:17:28'),(1031,'167',NULL,NULL,'ANVI TRADERS',5,'0','DR','RAMNAGAR, HANUMAN NAGAR, ROAD NO.28,NEAR WAGLE DEPO','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','21',NULL,NULL,NULL,NULL,NULL,'1031',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1032,'167',NULL,NULL,'ANNPURNA DEARY',5,'0','DR','NARAYAN KOLI CHOUK MITH BANDAR ROAD. KOPRI','DEFAULT','THANE','21','400603',NULL,'9967654362.0','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'1032',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1033,'167',NULL,NULL,'ANJU GEN STORE',5,'0','DR','AZAD NAGAR 1','NR NAGNESHI DHANYA BHANDAR','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1033',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1034,'167',NULL,NULL,'ANJALI PAN SHOP AND GENERAL STORE',5,'0','DR','RAMCHANDRA NAGAR SAMTA NAGAR ROAD SAI BABA MANDIR','DEFAULT','THANE','21','400604',NULL,'7045371051.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'1034',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1035,'167',NULL,NULL,'ANITA DHANYA BHANDAR',5,'0','DR','KHATAN ROAD','DEFAULT','THANE','21','400602',NULL,'7021572726.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'1035',NULL,NULL,NULL,NULL,NULL,'11512100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1036,'167',NULL,NULL,'ANITA DHANYA BHANDAR',5,'0','DR','OPP SHITLA MATA MANDIR   NEXT TO GURUKRIPA DHANAYA BHANDAR KHARTAN ROAD MUMBAI 400601','DEFAULT','THANE','21','400601',NULL,'9892984045','',NULL,'27','','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'1036',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1037,'167',NULL,NULL,'ANIL GENRAL STORE',5,'0','DR','KISHAN NAGAR','DEFAULT','THANE','21','400603',NULL,'9869368529.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'1037',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1038,'167',NULL,NULL,'ANANYA TRADING CO.',5,'0','DR','SHOP NO 2 DRONGIRI APPARTMENT LOKMANYA NAGAR PADA NO 2 OPP SOCIETY JEWELLERS OPP NEW OM SUPER MARKET THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','27ANUPS1155R1ZX','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'1038',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1039,'167',NULL,NULL,'ANAND KIRANA STORE',5,'0','DR','OPP SHIV MANDIR KAILASH NAGAR ROAD NO 28 WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','20',NULL,NULL,NULL,NULL,NULL,'1039',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1040,'167',NULL,NULL,'ANAND GENRAL STORE',5,'0','DR','SHOP NO.2,DURGA SAI APARTMENT,VARTAK NAGAR PADA NO.1,OPP.HANUMAN MANDIR,NEAR CHETAN GENERAL STORE THANE (W)','DEFAULT','THANE','21','400606',NULL,'8779544953.0','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'1040',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:29','2026-02-23 09:17:29'),(1041,'167',NULL,NULL,'AMRITA TRADING',5,'0','DR','KHOPAT','DEFAULT','THANE','21','400603',NULL,'7977818567.0','',NULL,'27','27ASJPS2702C1ZY','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1041',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1042,'167',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','JIVAN PRAKASH BLDG . SHOP NO. 16-17, LOUIS WADI, THANE - 400604','DEFAULT','THANE','21','400604',NULL,'8591248844.0','',NULL,'27','27AAOFA8264A1ZG','','SBI',NULL,NULL,'1','19',NULL,NULL,NULL,NULL,NULL,'1042',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1043,'167',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','SHOP NO 01 LOKMANYA NAGER PADA NO 03 NEAR BHAGYALAXMI KIRANA STORE LOKMANYA NAGER THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'1043',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1044,'167',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','SHIP NO14 SUNITI HOUSING SOCIETY SHIVAI NAGAR POKHRAN ROAD NO 1 THANE','DEFAULT','THANE','21','400604',NULL,'8121180175.0','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'SHIVAI NAGAR','10',NULL,NULL,NULL,NULL,NULL,'1044',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1045,'167',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','SHOP NO 1.ROAD NO 22.KISAN NAGAR NO 3.NEAR LAXMI GENERAL STORE.KISAN NAGAR.THANE WEST.','DEFAULT','THANE','21','400604',NULL,'8657620572.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'1045',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1046,'167',NULL,NULL,'AMBIKA STORES',5,'0','DR','SHOP NO 4 RAMESHWAR NILKANTH HEIGHTS POKHARAN ROAD NO 2 NEAR A2Z MEDICINE OPP LAXMI NARAYAN RESIDENCY THANE WEST','DEFAULT','THANE','21','400606',NULL,'8767028144.0','',NULL,'27','27ACFPN4675F1ZE','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'1046',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1047,'167',NULL,NULL,'AMBIKA STORE',5,'0','DR','WHOSALE','DEFAULT','THANE','21','400602',NULL,'9820798344.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'1047',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1048,'167',NULL,NULL,'AMBIKA STORE',5,'0','DR','DARGA ROAD HAJURI NEAR ARMAN KIRANA','DEFAULT','THANE','21','400606',NULL,'','',NULL,'27','','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'1048',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1049,'167',NULL,NULL,'AMBIKA NEIGHBOURHOOD STORE',5,'0','DR','SHOP NO 14 DEV DAYA PARK SAMTA NAGAR','DEFAULT','THANE','21','400606',NULL,'8433626999.0','',NULL,'27','27AAUPP3217A2ZQ','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'1049',NULL,NULL,NULL,NULL,NULL,'11524000000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1050,'167',NULL,NULL,'AMBIKA DHANYA BHANDAR',5,'0','DR','LOKMANYA NAGAR PADA NO.04','DEFAULT','THANE','21','400606',NULL,'8652264033.0','',NULL,'27','','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'1050',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:30','2026-02-23 09:17:30'),(1051,'167',NULL,NULL,'AMBICA DHANYA BHANDAR',5,'0','DR','ROYAL TOWER NEAR BY WATER TANK SHREE NAGAR','DEFAULT','THANE','21','400604',NULL,'9167372931.0','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'1051',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1052,'167',NULL,NULL,'AKSHAYA GENERAL STORES',5,'0','DR','11 SHAKUNTALA KRUPA CHS OPPOSITE MENTAL HOSPITAL THANE W','DEFAULT','THANE','21','400606',NULL,'7045187451.0','',NULL,'27','','','SARASWAT BANK',NULL,NULL,'029230','17',NULL,NULL,NULL,NULL,NULL,'1052',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1053,'167',NULL,NULL,'AKSHAY MEDICAL',5,'0','DR','LOKMANYA NAGAR PADA NO 2 KAKDI POOL NEAR WELCOME GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'9594759367.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'1053',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1054,'167',NULL,NULL,'AKASHGANGA STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400606',NULL,'9757281171.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1054',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1055,'167',NULL,NULL,'AJIT KIRANA',5,'0','DR','NAUPADA','DEFAULT','THANE','21','400603',NULL,'8718037201.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'1055',NULL,NULL,NULL,NULL,NULL,'11512100000000.0','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1056,'167',NULL,NULL,'AJAY STORES',5,'0','DR','HAJI KARIMULLAH KURESI CHOWK K VILLA RABODI NAKA OPP AYESHA MEDICAL NEAR MASJID RABODI 1 THANE','DEFAULT','THANE','21','400607',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1056',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1057,'167',NULL,NULL,'AGRE ENTERPRISES',5,'0','DR','SHIVAI NAGAR','NR GANESH SUPER MARKET','','21','',NULL,'1234560789','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'1057',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1058,'167',NULL,NULL,'ADINATH GRAIN STORE',5,'0','DR','LOKMANYA NAGAR PADA NO. 4 OPP. CHARBHUJA GENERAL STORE SHIVAJI SCHOOL ROAD THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'1058',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1059,'167',NULL,NULL,'ADARSH AND COMPANY',5,'0','DR','WHOSLAE','DEFAULT','THANE','21','400602',NULL,'8433995596.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'1059',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1060,'167',NULL,NULL,'ABDUL KIRANA STORE',5,'0','DR','RABODI','DEFAULT','THANE','21','400603',NULL,'9324777528.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1060',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:31','2026-02-23 09:17:31'),(1061,'167',NULL,NULL,'ABDUL KIRANA STORE',5,'0','DR','KATAL KHANA OPP SAHAKAR BAZAR RABODI','DEFAULT','THANE','21','400606',NULL,'7827250120.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1061',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1062,'167',NULL,NULL,'ABDUL KIRANA',5,'0','DR','RABODI','DEFAULT','THANE','21','400602',NULL,'9321021304.0','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1062',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1063,'167',NULL,NULL,'AASHRAM DAIRY GENERAL STORES',5,'0','DR','SHOP NO. 1 AZAD NAGAR NO.2 NAVNIT BHARAT SOC SHRI SAI PARK CASTLE MILL THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1063',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1064,'167',NULL,NULL,'AASHIRWAD GENERAL STORE',5,'0','DR','INDIAR NAGAR NAKA \\r\\nNEAR DEEPIKA BAR AND RESTAURANT','DEFAULT','THANE','21','400604',NULL,'8108245216.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'1064',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1065,'167',NULL,NULL,'AARTI KIRANA STORE',5,'0','DR','ST DHANSHWAR NAGAR NEAR SHISENA SAKHA ROAD NO 33 OPP JAI AMBE KIRANA STORE WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'9819526516.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1065',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1066,'167',NULL,NULL,'AAREY MILK CENTRE',5,'0','DR','AAREY MILK CENTRE NEAR 35A  VRINDAVAN THANE WEST','DEFAULT','THANE','21','400602',NULL,'','',NULL,'27','','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'1066',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1067,'167',NULL,NULL,'AAPNA GENERAL STORES',5,'0','DR','MOHD ALI ROAD NEAR JD VANGE STORES MAHATMA PHULE WHOLESALE MARKET THANE WEST','DEFAULT','THANE','21','400601',NULL,'7977077271.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'1067',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1068,'167',NULL,NULL,'AAKASH KIRANA STORES',5,'0','DR','SHOP NO.4 SHRI GANESH DARSHAN SOC,RAIGGAD ALI MARG PANCHPAKHADI TEKADI BUNGALOW NEAR  NEW R.S.GUPTA KIRANA AND GENERAL STORE THANE WEST','DEFAULT','THANE','21','400602',NULL,'9969245702.0','',NULL,'27','','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'1068',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1069,'167',NULL,NULL,'AAKANSHA AGENCY',5,'0','DR','SHOP-3/C SARVANAND APT NR BLD 22','KOPRI COLONY THANE EAST','THANE','21','400601',NULL,'9819842205','',NULL,'27','27BSOPK4971R1ZM','','SVC COPERATIVE BANK',NULL,NULL,'KOPRI','13',NULL,NULL,NULL,NULL,NULL,'1069',NULL,NULL,NULL,NULL,NULL,'11521014000518','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1070,'167',NULL,NULL,'AAIJI SUPER MARKET',5,'0','DR','SHOP NO 2, GEETANJALI SOCIETY BULDING NO 2,NEAR MARUTI SUPER MARKET','NEAR SURESH MEDICAL AND GENERAL STORE YASODHAN NAGAR, PADA NO 2 THANE WEST','THANE','21','400604',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'1070',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:32','2026-02-23 09:17:32'),(1071,'167',NULL,NULL,'AAIJI SUPER MARKET',5,'0','DR','SHOP NO 2 GITANJALI NO 2 OPP MAHAVIR MEDICAL YASODAN NAGAR LOKYMANAYNAGAY PADA NO 2 THANE','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'1071',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1072,'167',NULL,NULL,'AAIGI KIRANA STORE',5,'0','DR','NAGAR','DEFAULT','THANE','21','400603',NULL,'9004703123.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1072',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1073,'167',NULL,NULL,'AAI MATAJ SUPER MARKET',5,'0','DR','SHOP NO 01 KOKANI PADA GAWAND BAUG POKHRAN NEAR ROAD NO 01 UPVAN THANE WEST','DEFAULT','THANE','21','400604',NULL,'','',NULL,'27','','','THANE BHARAT SAHAKARI BANK LTD',NULL,NULL,'SHIVAI NAGAR','10',NULL,NULL,NULL,NULL,NULL,'1073',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1074,'167',NULL,NULL,'AAI MATA MEDICAL',5,'0','DR','SURAJ RAJ GENERAL STORE NEAR INDIRA NAGAR RUPA DEVI TEKARI PADA NO 2','DEFAULT','THANE','21','400604',NULL,'9509547713.0','',NULL,'27','','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'1074',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1075,'167',NULL,NULL,'AAI MATA GWNRAL',5,'0','DR','PANCH','DEFAULT','THANE','21','400603',NULL,'9545141737.0','',NULL,'27','','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'1075',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1076,'167',NULL,NULL,'AAI JI KIRANA',5,'0','DR','SHOP NO-5,CHAWL NO 10.SANT DYANESHWAR NAGAR ROAD NO 33 NEAR GAYATRI SWEET CORNER THANE WEST','DEFAULT','THANE','21','400604',NULL,'9702246894.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1076',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1077,'167',NULL,NULL,'AAI EKVIRA GEN',5,'0','DR','NR HIRA OIL DEPO','VARTAK NAGAR','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'1077',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1078,'167',NULL,NULL,'AAI EK VEERA GENERAL STORES',5,'0','DR','LOKMANYA NAGAR PADA NO 1,NEAR SIDDHIVINAYAK SUPER MARKET VARTAK NAGAR, THANE WEST','DEFAULT','THANE','21','400604',NULL,'8433616707.0','',NULL,'27','','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'1078',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1079,'167',NULL,NULL,'AADINATH DRYFRUITS',5,'0','DR','MAHATMA FULE NAGAR NEAR K.P SONS','DEFAULT','THANE','21','400606',NULL,'9970917352.0','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'1079',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1080,'167',NULL,NULL,'A.1 DRYFRUITS',5,'0','DR','SHOP NO 1.KISAN NAGAR NO 2.NEAR RAMESH DUGDALAYA.NEAR GUPTA OIL DEPO .WAGLE ESTATE.THANE .WEST','DEFAULT','THANE','21','400604',NULL,'8449964061.0','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'1080',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:33','2026-02-23 09:17:33'),(1081,'167',NULL,NULL,'A TO Z GENERAL STORE',5,'0','DR','RABODI NEAR NAGNESHI GENERAL STORE','DEFAULT','THANE','21','400606',NULL,'9987088165.0','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'1081',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:34','2026-02-23 09:17:34'),(1082,'167',NULL,NULL,'A ONE TRADING',5,'0','DR','WHOALAE','DEFAULT','THANE','21','400602',NULL,'9702118785.0','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'1082',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:34','2026-02-23 09:17:34'),(1083,'167',NULL,NULL,'A ONE SUPER MARKET',5,'0','DR','SHOP NO 3 RAMVHANDAR NAGAR KAMGAR HOSPITAL NEAR JAYESH BAZAR WAGLE ESTATE THANE','DEFAULT','THANE','21','400604',NULL,'8928580104.0','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'1083',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:34','2026-02-23 09:17:34'),(1084,'167',NULL,NULL,'A ONE DHANYA BHANDAR',5,'0','DR','SHREE NAGAR','','THANE','21','400604',NULL,'1234567892','',NULL,'27','27AASPP3652M1ZX','','BANK OF BARODA',NULL,NULL,'SHREE NAGAR','3',NULL,NULL,NULL,NULL,NULL,'1084',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:34','2026-02-23 09:17:34'),(1085,'167',NULL,NULL,'A ONE DHANYA BHANDAR',5,'0','DR','SHOP NO 3 AND 4 RIDDHI SIDDHI SECTOR 4','NEXT TO EKAL SUPER MARKET OPP SHIV MEDICAL SHREE NAGAR WAGLE  ESTSTE THANE','THANE','21','400606',NULL,'9819336170','',NULL,'27','27AASPP3652M1ZX','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'1085',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:34','2026-02-23 09:17:34'),(1086,'167',NULL,NULL,'A 1 SUPER MARKET',5,'0','DR','DHANESHWAR NAGAR','DEFAULT','THANE','21','400603',NULL,'9820972792.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1086',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-23 09:17:34','2026-02-23 09:17:34'),(1087,'167',NULL,NULL,'hyderabad',12,'0','DR','PRISAM HEIGHT PLOT NO-20, SEC18','TALOJA PHASE-2,NEAR-RAMDAV SM','NAVI MUMBAI','21','410208',NULL,'7715980767','',NULL,'27','27AMCPA6118R1ZU','','',NULL,NULL,'','29',NULL,NULL,NULL,NULL,NULL,'1087',NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0',NULL,'0','0',NULL,0,'2026-02-26 05:31:37','2026-02-26 05:31:37');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int(11) NOT NULL DEFAULT 0,
  `ADDRESS1` text DEFAULT NULL,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1088 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `PG_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` int(11) DEFAULT 0,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT NULL,
  `LITE_ID` varchar(50) DEFAULT NULL,
  `WEB_ID` varchar(50) DEFAULT NULL,
  `PROD_ID` varchar(20) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) DEFAULT NULL,
  `SALES_ID` varchar(20) DEFAULT NULL,
  `SALE_UNIT` varchar(20) DEFAULT NULL,
  `SALE_RATE` varchar(20) DEFAULT NULL,
  `PUR_RATE` varchar(20) DEFAULT NULL,
  `PROD_PACK` varchar(20) DEFAULT NULL,
  `PUR_VAT` varchar(20) DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_VAT` varchar(20) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_CESS` varchar(20) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) DEFAULT NULL,
  `PACK` varchar(20) DEFAULT NULL,
  `BOX` varchar(20) DEFAULT NULL,
  `QTY` varchar(20) DEFAULT NULL,
  `DISC_PERCENT` varchar(20) DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) DEFAULT NULL,
  `RETURN_QTY` varchar(20) DEFAULT NULL,
  `FREE` varchar(20) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) DEFAULT NULL,
  `AMT` varchar(20) DEFAULT NULL,
  `PUR_AMT` varchar(20) DEFAULT NULL,
  `PROFIT` varchar(20) DEFAULT NULL,
  `TAX_AMT` varchar(20) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) DEFAULT NULL,
  `DAMAGE` varchar(20) DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) DEFAULT NULL,
  `REPLACE` varchar(25) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) DEFAULT NULL,
  `RETURN` varchar(25) DEFAULT NULL,
  `SR_NO` varchar(50) DEFAULT NULL,
  `CESS_AMT` varchar(20) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) DEFAULT NULL,
  `WEIGHT` varchar(20) DEFAULT NULL,
  `PUR_UNIT` varchar(20) DEFAULT NULL,
  `PRICE_PER` varchar(20) DEFAULT NULL,
  `TE_RATE` varchar(20) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) DEFAULT NULL,
  `DMG_MRP` varchar(20) DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) DEFAULT NULL,
  `INV_ARR` varchar(255) DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` varchar(20) DEFAULT NULL,
  `UPDATED_BY` varchar(20) DEFAULT NULL,
  `SECURITY_KEY` varchar(100) DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(20) DEFAULT NULL,
  `SALES_MAN` varchar(100) DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(20) DEFAULT NULL,
  `PARTY_CODE` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(20) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) DEFAULT NULL,
  `BATCH_NO` varchar(50) DEFAULT NULL,
  `MFG_DATE` varchar(20) DEFAULT NULL,
  `EXP_DATE` varchar(20) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int(11) DEFAULT 0,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int(11) DEFAULT 0,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int(11) DEFAULT 0,
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SMAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYNC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text DEFAULT NULL,
  `UPDATED_VALUE` text DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text DEFAULT NULL,
  `DIACM` text DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int(11) DEFAULT 0,
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int(11) DEFAULT 0,
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-02-23 09:13:00','2026-02-23 09:13:00');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UOM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT 0,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WEB_ID` int(11) NOT NULL DEFAULT 0,
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-23 18:00:11
