-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emf8DX3CBx
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT 'mm',
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int(11) NOT NULL DEFAULT 0,
  `GROUP_ID` int(11) NOT NULL DEFAULT 0,
  `DISPLAY_ORDER` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','mm','Y',0,1,0),(2,'Printpage_Top_Margin','10','mm','Y',0,1,0),(3,'Printpage_Left_Margin','16','mm','Y',0,1,0),(4,'Printpage_Border','0','px','Y',0,1,0),(5,'Top_Left_Width','97','mm','Y',0,2,0),(6,'Top_Center_Width','100','mm','Y',0,2,0),(7,'Padding_Top_Right','5','px','Y',0,2,0),(8,'Item_Listing_Padding_Top','0','mm','Y',0,3,0),(9,'Items_Height','45','mm','Y',0,3,0),(10,'List_1','47','mm','Y',0,3,0),(11,'List_2','20','mm','Y',0,3,0),(12,'List_3','35','mm','Y',0,3,0),(13,'List_4','94','mm','Y',0,3,0),(14,'List_5','23','mm','Y',0,3,0),(15,'List_6','5','mm','Y',0,3,0),(16,'List_7','5','mm','Y',0,3,0),(17,'List_8','25','mm','Y',0,3,0),(18,'List_9','25','mm','Y',0,3,0),(19,'List_10','15','mm','Y',0,3,0),(20,'List_11','20','mm','Y',0,3,0),(21,'List_12','25','mm','Y',0,3,0),(22,'Blank_Space_Top_Padding','2','mm','Y',0,4,0),(23,'Footer_Padding_Top','2','mm','Y',0,4,0),(24,'Footer_1','17','mm','Y',0,4,0),(25,'Footer_2','25','mm','Y',0,4,0),(26,'Footer_3','21','mm','Y',0,4,0),(27,'Footer_4','17','mm','Y',0,4,0),(28,'Footer_5','24','mm','Y',0,4,0),(29,'Footer_6','21','mm','Y',0,4,0),(30,'Footer_7','21','mm','Y',0,4,0),(31,'Footer_8','14','mm','Y',0,4,0),(32,'Footer_9','25','mm','Y',0,4,0),(33,'Footer_10','0','mm','Y',0,4,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-25 11:00:43
