-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emf8DX3CBx
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','','Y','1','1'),(2,'Printpage_margin','10mm 0 0 16mm','','Y','1','1'),(3,'invoice_page_width','255','mm','Y','1','1'),(4,'invoice_page_height','100','mm','Y','1','1'),(5,'header_height','20','mm','Y','1','2'),(6,'items_height','30','mm','Y','1','2'),(7,'items_padding_top','1','mm','Y','1','3'),(8,'blank_height','2','mm','Y','1','4'),(9,'footer_height','10','mm','Y','1','4'),(10,'top_left_address_width','97','mm','Y','1','2'),(11,'top_center_address_width','100','mm','Y','1','2'),(12,'top_center_address_padding_top','23','px','Y','1','2'),(13,'top_right_width','27','mm','Y','1','2'),(14,'top_right_padding_top','5','px','Y','1','2'),(15,'top_right_margin_left','15','px','Y','1','2'),(16,'items_qty','47','mm','Y','1','3'),(17,'items_hsn','20','mm','Y','1','3'),(18,'items_mrp','35','mm','Y','1','3'),(19,'items_particular','94','mm','Y','1','3'),(20,'items_rate','23','mm','Y','1','3'),(21,'items_free','5','mm','Y','1','3'),(22,'items_sch','5','mm','Y','1','3'),(23,'items_scheme','25','mm','Y','1','3'),(24,'items_amount','25','mm','Y','1','3'),(25,'items_gst_per','15','mm','Y','1','3'),(26,'items_gst_amt','20','mm','Y','1','3'),(27,'items_net','25','mm','Y','1','3'),(28,'footer_signature','17','mm','Y','1','4'),(29,'footer_gross','25','mm','Y','1','4'),(30,'footer_schemef','21','mm','Y','1','4'),(31,'footer_discount','17','mm','Y','1','4'),(32,'footer_display','24','mm','Y','1','4'),(33,'footer_damage','21','mm','Y','1','4'),(34,'footer_gst','21','mm','Y','1','4'),(35,'footer_add','14','mm','Y','1','4'),(36,'footer_net','25','mm','Y','1','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-13 18:00:12
