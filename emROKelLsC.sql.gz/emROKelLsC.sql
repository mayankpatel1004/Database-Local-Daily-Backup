-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emROKelLsC
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AREA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'228',NULL,NULL,'22','GHATKOPER EAST/ WEST',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(2,'228',NULL,NULL,'10','GAVDEVI-VILLAGE RD.',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(3,'228',NULL,NULL,'12','KANNAMWAR NAGAR 1&2',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(4,'228',NULL,NULL,'16','POWAI',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(5,'228',NULL,NULL,'21','THANE',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(6,'228',NULL,NULL,'3','J.N RD.-M.G.ROAD',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(7,'228',NULL,NULL,'18','KANJUR(W)-SURYA NAGAR',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(8,'228',NULL,NULL,'14','VIKH STN.RD.-TAGORE NAGAR',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(9,'228',NULL,NULL,'6','MULUND(E)',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(10,'228',NULL,NULL,'4','DUMPING ROAD',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(11,'228',NULL,NULL,'11','VIKH.PARKSITE',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(12,'228',NULL,NULL,'17','AIROLI-GHANSHOLI',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(13,'228',NULL,NULL,'15','RAMABAI-KAMRAJ NAGAR,GHT(E)',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(14,'228',NULL,NULL,'5','MULUND COLONY',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(15,'228',NULL,NULL,'9','PRATAP NAGAR-HANUMAN NAGAR',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(16,'228',NULL,NULL,'20','BHANDUP (W)',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(17,'228',NULL,NULL,'7','BHANDUP(E)& KANJUR(E)',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(18,'228',NULL,NULL,'13','HARIYALI VILLAGE,VIKH(E)',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34'),(19,'228',NULL,NULL,'8','TEMBIPADA-SAI VIHAR',NULL,'344','344',NULL,0,'2026-04-14 10:25:34','2026-04-14 10:25:34');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text DEFAULT NULL,
  `MASTER` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint(20) DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'228','0','emROKelLsC',228,'','','','2026-04-14 09:57:51','2026-04-14 09:57:51','','','','','','','','','2026-04-14 09:57:51','344','344','',0,'2026-04-14 09:57:51','2026-04-14 09:57:51');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (228,NULL,NULL,'1','TIRUPATHI ENTERPRISES','2026-04-01','2027-03-31','F18,SHARAD IND.ESTATE','LAKE ROAD,BHANDUP','MUMBAI','21','8082391869','','','','','','','','','','','','','','11518013000261',NULL,'0',NULL,NULL,'27','27AABPY3682M1ZZ','','santoshy@yopmail.com','','400078',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-04-14 09:57:51','2026-04-14 10:00:53',NULL,'','','TIRUPATHI','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `CREATED_TS` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `BATCH_ID` int(11) DEFAULT 0,
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DISP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `DELETED` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int(11) DEFAULT 0,
  `TAX_ID` int(11) DEFAULT 0,
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT 'mm',
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int(11) NOT NULL DEFAULT 0,
  `GROUP_ID` int(11) NOT NULL DEFAULT 0,
  `DISPLAY_ORDER` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','mm','Y',0,1,0),(2,'Printpage_Top_Margin','10','mm','Y',0,1,0),(3,'Printpage_Left_Margin','16','mm','Y',0,1,0),(4,'Printpage_Border','0','px','Y',0,1,0),(5,'Top_Left_Width','97','mm','Y',0,2,0),(6,'Top_Center_Width','100','mm','Y',0,2,0),(7,'Padding_Top_Right','5','px','Y',0,2,0),(8,'Item_Listing_Padding_Top','0','mm','Y',0,3,0),(9,'Items_Height','45','mm','Y',0,3,0),(10,'List_1','47','mm','Y',0,3,0),(11,'List_2','20','mm','Y',0,3,0),(12,'List_3','35','mm','Y',0,3,0),(13,'List_4','94','mm','Y',0,3,0),(14,'List_5','23','mm','Y',0,3,0),(15,'List_6','5','mm','Y',0,3,0),(16,'List_7','5','mm','Y',0,3,0),(17,'List_8','25','mm','Y',0,3,0),(18,'List_9','25','mm','Y',0,3,0),(19,'List_10','15','mm','Y',0,3,0),(20,'List_11','20','mm','Y',0,3,0),(21,'List_12','25','mm','Y',0,3,0),(22,'Blank_Space_Top_Padding','2','mm','Y',0,4,0),(23,'Footer_Padding_Top','2','mm','Y',0,4,0),(24,'Footer_1','17','mm','Y',0,4,0),(25,'Footer_2','25','mm','Y',0,4,0),(26,'Footer_3','21','mm','Y',0,4,0),(27,'Footer_4','17','mm','Y',0,4,0),(28,'Footer_5','24','mm','Y',0,4,0),(29,'Footer_6','21','mm','Y',0,4,0),(30,'Footer_7','21','mm','Y',0,4,0),(31,'Footer_8','14','mm','Y',0,4,0),(32,'Footer_9','25','mm','Y',0,4,0),(33,'Footer_10','0','mm','Y',0,4,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INV_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'228',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'228',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'228',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'228',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'228',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'228',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'228',NULL,NULL,'47','','TE','','7','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'228',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'228',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'228',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'228',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'228',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'228',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'228',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LEDGER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `MAC_ID` int(11) DEFAULT 0,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int(11) DEFAULT 0,
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int(11) DEFAULT 0,
  `ROOT_PARENT_ID` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(14,'1',NULL,'1','UPI','UPI','bank','1','1','','','','',0,'2026-07-15 19:34:00','2026-07-15 19:34:00');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text DEFAULT NULL,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `SAC_ID` int(11) NOT NULL DEFAULT 0,
  `REMOTE_ID` int(11) NOT NULL DEFAULT 0,
  `PENDING_AMT` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `PROD_ID` int(11) NOT NULL DEFAULT 0,
  `PACK` int(11) NOT NULL DEFAULT 0,
  `PROD_BATCH_ID` int(11) NOT NULL DEFAULT 0,
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_RET_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_TOTAL` int(11) NOT NULL DEFAULT 0,
  `SALE_QTY` int(11) DEFAULT 0,
  `SALE_RET_QTY` int(11) DEFAULT 0,
  `SALE_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `SALE_TOTAL` int(11) NOT NULL DEFAULT 0,
  `OP_STOCK` int(11) NOT NULL DEFAULT 0,
  `CLOSING_STOCK` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
INSERT INTO `OP_CL_STOCK` VALUES (1,228,14,0,15,'2026-04-14',0,0,0,0,5,0,0,5,0,-5),(2,228,571,0,574,'2026-04-01',0,0,0,0,10,0,0,10,0,-10);
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `MINIMUM_STOCK_LEVEL` int(11) NOT NULL DEFAULT 0,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=572 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'228',NULL,NULL,'P02',NULL,'','EVEREYDAY PALM 1*15','EVEREYDAY PALM 1*15','15119020','1','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(2,'228',NULL,NULL,'SF02',NULL,'','GEMLITE SF 1LTR*10','GEMLITE SF 1LTR*10','15121910','0.91','3',NULL,'2','SUNFLOWER OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(3,'228',NULL,NULL,'SF03',NULL,'','OLAMPIYA 750*15','OLAMPIYA 750*15','15079010','0.75','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(4,'228',NULL,NULL,'SF14',NULL,'','GEMINI SF 13kg  JAR','GEMINI SF 13kg  JAR','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(5,'228',NULL,NULL,'SF27',NULL,'','SUNRICH SF 800*10','SUNRICH SF 800*10','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(6,'228',NULL,NULL,'SF30',NULL,'','SUUNY SF 13KG TIN','SUUNY SF 13KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(7,'228',NULL,NULL,'SC04',NULL,'','SAFFOLA GOLD 5LT*4','SAFFOLA GOLD 5LT*4','15179090','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(8,'228',NULL,NULL,'SC07',NULL,'','SAFFOLA ACTIVE 1LT*20','SAFFOLA ACTIVE 1LT*20','15179090','1','3',NULL,'4','SAFFOLA OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SAFFOLA OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(9,'228',NULL,NULL,'GN13',NULL,'','RAJDHANI 15LTR TIN','RAJDHANI 15LTR TIN','150790','13.65','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(10,'228',NULL,NULL,'SB02',NULL,'','SUNNY SOYA 800G*12','SUNNY SOYA 800G*12','15079010','0.8','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(11,'228',NULL,NULL,'SB03',NULL,'','REF SOYABEAN E OIL 15KG','REF SOYABEAN E OIL 15KG','15079010','15','3',NULL,'6','SOYABEAN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(12,'228',NULL,NULL,'SB04',NULL,'','PRIYA SOYA REF 15KG TIN','PRIYA SOYA REF 15KG TIN','15079010','15','3',NULL,'6','SOYABEAN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(13,'228',NULL,NULL,'CT02',NULL,'','COTTON S REF OIL 15KG','COTTON S REF OIL 15KG','15122910','15','3',NULL,'7','COTTON OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COTTON OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(14,'228',NULL,NULL,'SF34',NULL,'','PRIYA  SF 13 KG TIN','PRIYA  SF 13 KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(15,'228',NULL,NULL,'SF35',NULL,'','SUN KING 13.500 KG TIN','SUN KING 13.500 KG TIN','15079010','13.5','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(16,'228',NULL,NULL,'SF37',NULL,'','SUNDAY SF 4.25LT*4','SUNDAY SF 4.25LT*4','15121910','4.25','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(17,'228',NULL,NULL,'VP12',NULL,'','DALDA VP 420G*20','DALDA VP 420G*20','15162091','0.42','3',NULL,'8','VANASPATI OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(18,'228',NULL,NULL,'MO03',NULL,'','AMRIT GOLD MUST(1*12)PP','AMRIT GOLD MUST(1*12)PP','15149120','0.91','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(19,'228',NULL,NULL,'SF46',NULL,'','OLAMPIYA 1LIT PP*15','OLAMPIYA 1LIT PP*15','150790','0.91','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(20,'228',NULL,NULL,'SF47',NULL,'','NATURALLI SF 13KG TIN','NATURALLI SF 13KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(21,'228',NULL,NULL,'MO05',NULL,'','SUPER TIGER 15KG TIN','SUPER TIGER 15KG TIN','151590','15','3',NULL,'9','MUSTERD OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(22,'228',NULL,NULL,'VP22',NULL,'','RUCHI VP 178GM*80','RUCHI VP 178GM*80','15162091','0.178','3',NULL,'8','VANASPATI OIL','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(23,'228',NULL,NULL,'VP23',NULL,'','RUCHI VP 90GM*160','RUCHI VP 90GM*160','15162091','0.09','3',NULL,'8','VANASPATI OIL','7','10','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(24,'228',NULL,NULL,'VP31',NULL,'','KITCHEN KING VP 15KG TIN','KITCHEN KING VP 15KG TIN','15162099','15','3',NULL,'8','VANASPATI OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(25,'228',NULL,NULL,'SF52',NULL,'','OLAMPIYA 850*15','OLAMPIYA 850*15','151219','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(26,'228',NULL,NULL,'MOO9',NULL,'','Shreeji Pouch K.g. 1*12','Shreeji Pouch K.g. 1*12','1514','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(27,'228',NULL,NULL,'SF57',NULL,'','Gulab Sf Oil 1*12','Gulab Sf Oil 1*12','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(28,'228',NULL,NULL,'SF59',NULL,'','Gulab Sf 15 Lit Jar','Gulab Sf 15 Lit Jar','15121910','13.5','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(29,'228',NULL,NULL,'SB07',NULL,'','RAJBHOG SOYA 15KG TIN','RAJBHOG SOYA 15KG TIN','15079010','15','3',NULL,'6','SOYABEAN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(30,'228',NULL,NULL,'SB06',NULL,'','SUNNY SOYA 860*16','SUNNY SOYA 860*16','15079010','0.86','3',NULL,'6','SOYABEAN OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(31,'228',NULL,NULL,'SF61',NULL,'','SUN TASTY  5LT*4','SUN TASTY  5LT*4','15079010','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(32,'228',NULL,NULL,'SF67',NULL,'','OLAMPIYA 15KG TIN','OLAMPIYA 15KG TIN','150790','15','3',NULL,'6','SOYABEAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(33,'228',NULL,NULL,'SF68',NULL,'','SUN TASTY 800G*15','SUN TASTY 800G*15','15079010','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(34,'228',NULL,NULL,'GH1',NULL,'','SHRADDHA 1L PP C G.*15','SHRADDHA 1L PP C G.*15','04059020','0.91','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(35,'228',NULL,NULL,'GH2',NULL,'','SHRADDHA 500 JAR C G,*30','SHRADDHA 500 JAR C G,*30','04059020','0.45','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(36,'228',NULL,NULL,'GH3',NULL,'','SHRADDHA 1L JAR C G.*15','SHRADDHA 1L JAR C G.*15','04059020','0.91','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(37,'228',NULL,NULL,'GH4',NULL,'','SHRADDHA 500M P C G.*20','SHRADDHA 500M P C G.*20','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(38,'228',NULL,NULL,'GN15',NULL,'','RIVO REF G.N.15 LIT TIN','RIVO REF G.N.15 LIT TIN','15089091','13.65','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(39,'228',NULL,NULL,'SF69',NULL,'','SUN N DEEP 15LIT TIN','SUN N DEEP 15LIT TIN','15079010','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(40,'228',NULL,NULL,'SF72',NULL,'','SAFFAL GOLD 13.500 KG TIN','SAFFAL GOLD 13.500 KG TIN','15079010','13.5','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(41,'228',NULL,NULL,'SF73',NULL,'','OLAMPIYA 15LIT DLX JAR','OLAMPIYA 15LIT DLX JAR','150790','13.65','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(42,'228',NULL,NULL,'RB07',NULL,'','RICE GOLD 15KG TIN','RICE GOLD 15KG TIN','15159040','15','3',NULL,'10','RICEBRAN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(43,'228',NULL,NULL,'GH5',NULL,'','PANCHJYOT H.P.900ML','PANCHJYOT H.P.900ML','151620','0.9','3',NULL,'3','GHEE OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(44,'228',NULL,NULL,'GH6',NULL,'','500ML PP *30SAHKAR C GHEE','500ML PP *30SAHKAR C GHEE','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(45,'228',NULL,NULL,'GH7',NULL,'','1LTR PP*15 SAHKAR C GHEE','1LTR PP*15 SAHKAR C GHEE','04059020','0.91','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(46,'228',NULL,NULL,'GH8',NULL,'','SG GHEE 20RS*240','SG GHEE 20RS*240','04059020','0.035','3',NULL,'3','GHEE OIL','7','10','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(47,'228',NULL,NULL,'GH9',NULL,'','SHRADDHA 200 JAR C,G.*75','SHRADDHA 200 JAR C,G.*75','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','75',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','75','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(48,'228',NULL,NULL,'GH10',NULL,'','SHRADDHA 100 JAR C.G.*100','SHRADDHA 100 JAR C.G.*100','04059020','0.1','3',NULL,'3','GHEE OIL','7','10','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(49,'228',NULL,NULL,'SF78',NULL,'','SUNNY SF E. F.JAR 13KG PROMO','SUNNY SF E. F.JAR 13KG PROMO','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(50,'228',NULL,NULL,'SF79',NULL,'','SUNNY SF 500MLPP','SUNNY SF 500MLPP','15121910','0.5','3',NULL,'2','SUNFLOWER OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(51,'228',NULL,NULL,'SF80',NULL,'','SUNNY SF 1LTR*12','SUNNY SF 1LTR*12','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(52,'228',NULL,NULL,'SF81',NULL,'','SUNNY SF 5LTR*4','SUNNY SF 5LTR*4','15121910','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(53,'228',NULL,NULL,'SF82',NULL,'','SUNNY SF 15LTR JAR','SUNNY SF 15LTR JAR','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(54,'228',NULL,NULL,'SF83',NULL,'','SUNNY SF 1*12 (OFFER)','SUNNY SF 1*12 (OFFER)','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(55,'228',NULL,NULL,'GH13',NULL,'','NANDINI GHEE 500ML JAR','NANDINI GHEE 500ML JAR','04059020','0.5','3',NULL,'3','GHEE OIL','10','10','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(56,'228',NULL,NULL,'SF84',NULL,'','SUNNY SF 500*24 BT','SUNNY SF 500*24 BT','15121910','0.5','3',NULL,'2','SUNFLOWER OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(57,'228',NULL,NULL,'SF85',NULL,'','SUNNY SF 1*12BT','SUNNY SF 1*12BT','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(58,'228',NULL,NULL,'RB10',NULL,'','FORTUNE R.B.870*12','FORTUNE R.B.870*12','15159040','0.87','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(59,'228',NULL,NULL,'RB11',NULL,'','FORTUNE R.B.4.35084','FORTUNE R.B.4.35084','15159040','4.35','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(60,'228',NULL,NULL,'VP42',NULL,'','RUCHI NO VP 447GM*20','RUCHI NO VP 447GM*20','15162091','0.447','3',NULL,'8','VANASPATI OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(61,'228',NULL,NULL,'SF87',NULL,'','OLAMPIYA 650*15','OLAMPIYA 650*15','150790','0.65','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(62,'228',NULL,NULL,'SB09',NULL,'','SUNNY REF SB 1*12 BT','SUNNY REF SB 1*12 BT','15079010','1','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(63,'228',NULL,NULL,'SF90',NULL,'','EVERYDAY GOLD SF 5*4','EVERYDAY GOLD SF 5*4','15121910','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(64,'228',NULL,NULL,'GH19',NULL,'','RADHEY KRISHNA GHEE 15KG TIN','RADHEY KRISHNA GHEE 15KG TIN','04059020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(65,'228',NULL,NULL,'VP50',NULL,'','SUNFLOWER VP 200*60','SUNFLOWER VP 200*60','15162091','0.2','3',NULL,'8','VANASPATI OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(66,'228',NULL,NULL,'SF91',NULL,'','GENIME SF 13KG TIN','GENIME SF 13KG TIN','15079010','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(67,'228',NULL,NULL,'SF92',NULL,'','SUNRICH RSF 13KG  TIN','SUNRICH RSF 13KG  TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(68,'228',NULL,NULL,'SF93',NULL,'','SUNNY SF EASY 13KG HDPE','SUNNY SF EASY 13KG HDPE','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(69,'228',NULL,NULL,'MO18',NULL,'','PAPPU MO 15 KG TIN','PAPPU MO 15 KG TIN','15149120','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(70,'228',NULL,NULL,'RB12',NULL,'','RISO RB OIL 1*12PACK','RISO RB OIL 1*12PACK','15159040','1','3',NULL,'10','RICEBRAN OIL','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(71,'228',NULL,NULL,'RB13',NULL,'','RISO RB OIL 5LT*4JAR','RISO RB OIL 5LT*4JAR','15159040','5','3',NULL,'10','RICEBRAN OIL','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(72,'228',NULL,NULL,'SF94',NULL,'','GEMLITE 15LTR JAR','GEMLITE 15LTR JAR','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(73,'228',NULL,NULL,'SF95',NULL,'','EVERYDAY R.SUN 15KG TIN','EVERYDAY R.SUN 15KG TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(74,'228',NULL,NULL,'GN18',NULL,'','GEMINI GN 1*12','GEMINI GN 1*12','15089091','1','3',NULL,'5','GROUNDNUT OIL','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(75,'228',NULL,NULL,'SF96',NULL,'','MADHURAM R.SF-5LTRJAR','MADHURAM R.SF-5LTRJAR','15121910','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(76,'228',NULL,NULL,'SF97',NULL,'','MADHURAM R.SF.-15LTRJAR','MADHURAM R.SF.-15LTRJAR','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(77,'228',NULL,NULL,'GN21',NULL,'','DIPTI GROUNDNUT OIL-5LTR','DIPTI GROUNDNUT OIL-5LTR','15089091','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(78,'228',NULL,NULL,'PCO 11',NULL,'','PARASHUTE 25 ML*576','PARASHUTE 25 ML*576','15131100','0.25','3',NULL,'11','COCONUT OIL','7','10','576',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','576','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(79,'228',NULL,NULL,'CT09',NULL,'','ANMOL COTTON 15KG TIN','ANMOL COTTON 15KG TIN','15122910','15','3',NULL,'7','COTTON OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COTTON OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(80,'228',NULL,NULL,'SF98',NULL,'','SUNNY SF 13KG TIN','SUNNY SF 13KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(81,'228',NULL,NULL,'SB10',NULL,'','SUNNY REF SOYABEAN 1*12','SUNNY REF SOYABEAN 1*12','15079010','1','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(82,'228',NULL,NULL,'SF99',NULL,'','GEMINI SF 1*12 OFFER','GEMINI SF 1*12 OFFER','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(83,'228',NULL,NULL,'SF100',NULL,'','SUNNY SF 4.3*4','SUNNY SF 4.3*4','15121910','4.35','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(84,'228',NULL,NULL,'SB11',NULL,'','SUNNY REF SB 5LT*4JAR','SUNNY REF SB 5LT*4JAR','15079010','5','3',NULL,'6','SOYABEAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(85,'228',NULL,NULL,'SF101',NULL,'','GEMIME SF 5*4','GEMIME SF 5*4','15121910','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(86,'228',NULL,NULL,'RB14',NULL,'','RISO 15LTR JAR','RISO 15LTR JAR','15159040','15','3',NULL,'10','RICEBRAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(87,'228',NULL,NULL,'VP51',NULL,'','PRIYA VP 200ML*60','PRIYA VP 200ML*60','15162091','0.2','3',NULL,'8','VANASPATI OIL','10','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(88,'228',NULL,NULL,'CT10',NULL,'','K.P. COTTON 15KG','K.P. COTTON 15KG','15122910','15','3',NULL,'7','COTTON OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COTTON OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(89,'228',NULL,NULL,'SF103',NULL,'','SUNNY SF 5*4 OFFER','SUNNY SF 5*4 OFFER','15121910','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(90,'228',NULL,NULL,'SF104',NULL,'','RIVO REF SF 15LT TAP JAR','RIVO REF SF 15LT TAP JAR','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(91,'228',NULL,NULL,'SF105',NULL,'','RIVO REF SUN 15 LIR JAR','RIVO REF SUN 15 LIR JAR','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(92,'228',NULL,NULL,'SF106',NULL,'','RIVO REF S.F.OIL-15LT TIN','RIVO REF S.F.OIL-15LT TIN','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(93,'228',NULL,NULL,'CO 04',NULL,'','ARUN GOLD COCONUT OIL-15KG','ARUN GOLD COCONUT OIL-15KG','15131100','15','3',NULL,'11','COCONUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(94,'228',NULL,NULL,'VP52',NULL,'','PRIYA H VP 1*12','PRIYA H VP 1*12','15162091','1','3',NULL,'8','VANASPATI OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(95,'228',NULL,NULL,'VP53',NULL,'','PRIYA H VP 500*24','PRIYA H VP 500*24','15162091','0.5','3',NULL,'8','VANASPATI OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(96,'228',NULL,NULL,'CO 05',NULL,'','MALI COCONUT OIL-5LTRCAN','MALI COCONUT OIL-5LTRCAN','15131100','4.5','3',NULL,'11','COCONUT OIL','10','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(97,'228',NULL,NULL,'SF107',NULL,'','SUNNY SF 15 LTRS OFFER','SUNNY SF 15 LTRS OFFER','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(98,'228',NULL,NULL,'VP54',NULL,'','RADHUNI PAM 15.KGTIN','RADHUNI PAM 15.KGTIN','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(99,'228',NULL,NULL,'SF108',NULL,'','SUN GOLD 800ML*15','SUN GOLD 800ML*15','150790','0.72','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(100,'228',NULL,NULL,'RB15',NULL,'','RISO PP1*20','RISO PP1*20','15159040','1','3',NULL,'10','RICEBRAN OIL','10','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(101,'228',NULL,NULL,'RB16',NULL,'','RISO 2LTR JAR','RISO 2LTR JAR','15159040','2','3',NULL,'10','RICEBRAN OIL','10','10','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(102,'228',NULL,NULL,'CT 11',NULL,'','RIVO COTTON IOL 15kg TIN','RIVO COTTON IOL 15kg TIN','15122910','15','3',NULL,'7','COTTON OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COTTON OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(103,'228',NULL,NULL,'VP 55',NULL,'','RAJANI VP 1*16','RAJANI VP 1*16','15162091','1','3',NULL,'8','VANASPATI OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(104,'228',NULL,NULL,'SF109',NULL,'','GEMLITE SF 1*12','GEMLITE SF 1*12','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(105,'228',NULL,NULL,'T20',NULL,'','C.R 1*20 BOX','C.R 1*20 BOX','15159040','1','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(106,'228',NULL,NULL,'TL21',NULL,'','C.R 500ML*40PC BOX','C.R 500ML*40PC BOX','15159040','0.5','3',NULL,'12','SESAME OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(107,'228',NULL,NULL,'CO15',NULL,'','COCOPURE 5LTR JAR','COCOPURE 5LTR JAR','15131100','5','3',NULL,'11','COCONUT OIL','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(108,'228',NULL,NULL,'SF110',NULL,'','KRISHIRAJ REF S OIL 680G*12','KRISHIRAJ REF S OIL 680G*12','15079010','0.68','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(109,'228',NULL,NULL,'SF111',NULL,'','FORTUNE SF5*4 OFFER','FORTUNE SF5*4 OFFER','15121910','5','3',NULL,'2','SUNFLOWER OIL','10','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(110,'228',NULL,NULL,'SF112',NULL,'','FORTUNE SF 800*16','FORTUNE SF 800*16','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(111,'228',NULL,NULL,'SF113',NULL,'','PRIYA SF 1*12','PRIYA SF 1*12','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(112,'228',NULL,NULL,'SF114',NULL,'','PRIYA SF5*4','PRIYA SF5*4','15121910','5','3',NULL,'2','SUNFLOWER OIL','10','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(113,'228',NULL,NULL,'MO19',NULL,'','MUMBAI MASTI MO1 LBT','MUMBAI MASTI MO1 LBT','1514','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(114,'228',NULL,NULL,'MO20',NULL,'','MUMBAI MASTI MO5L','MUMBAI MASTI MO5L','1514','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(115,'228',NULL,NULL,'MO21',NULL,'','FORTUNE KGMO 500ML*24','FORTUNE KGMO 500ML*24','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(116,'228',NULL,NULL,'SF115',NULL,'','SUNNY SF 15 LT TIN','SUNNY SF 15 LT TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(117,'228',NULL,NULL,'SF116',NULL,'','SF GEMIME RSF 1*15','SF GEMIME RSF 1*15','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(118,'228',NULL,NULL,'SF117',NULL,'','SUNNY SF 15KG TIN','SUNNY SF 15KG TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(119,'228',NULL,NULL,'GH21',NULL,'','BALAJI COW GHEE (1*10)PP','BALAJI COW GHEE (1*10)PP','04059020','1','3',NULL,'3','GHEE OIL','7','10','10',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(120,'228',NULL,NULL,'GH22',NULL,'','BALAJI COW GH (500*20)PP','BALAJI COW GH (500*20)PP','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(121,'228',NULL,NULL,'GH23',NULL,'','BALAJI COW GHEE (5*4) TIN','BALAJI COW GHEE (5*4) TIN','04059020','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(122,'228',NULL,NULL,'GH24',NULL,'','SORATH TP 100ML*120','SORATH TP 100ML*120','04059020','0.1','3',NULL,'3','GHEE OIL','7','10','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(123,'228',NULL,NULL,'SF118',NULL,'','SUN CLASSIC 13.500L  TIN','SUN CLASSIC 13.500L  TIN','15079010','12.2','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(124,'228',NULL,NULL,'MO22',NULL,'','FORTUNE KGMO 1LIT*12','FORTUNE KGMO 1LIT*12','15149120','0.91','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(125,'228',NULL,NULL,'MO23',NULL,'','P MARKKACHIGHANI MO500*32','P MARKKACHIGHANI MO500*32','1514','0.5','3',NULL,'9','MUSTERD OIL','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(126,'228',NULL,NULL,'MO24',NULL,'','P MARKKACHIGHANI MO1*16','P MARKKACHIGHANI MO1*16','1514','1','3',NULL,'9','MUSTERD OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(127,'228',NULL,NULL,'TL22',NULL,'','VANI TILL OIL 15KG','VANI TILL OIL 15KG','151550','15','3',NULL,'12','SESAME OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(128,'228',NULL,NULL,'SF119',NULL,'','GEMIMI R.SF 15KG TIN','GEMIMI R.SF 15KG TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(129,'228',NULL,NULL,'SB13',NULL,'','SUNNY SOYA 860*12','SUNNY SOYA 860*12','15079010','0.86','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(130,'228',NULL,NULL,'SB14',NULL,'','GULAB SOYA 15KG TIN','GULAB SOYA 15KG TIN','15079010','15','3',NULL,'6','SOYABEAN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(131,'228',NULL,NULL,'PO10',NULL,'','R.B.D.PALM 15KG','R.B.D.PALM 15KG','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(132,'228',NULL,NULL,'GH25',NULL,'','BALAJI C.GHEE1LTR JAR','BALAJI C.GHEE1LTR JAR','04059020','1','3',NULL,'3','GHEE OIL','10','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(133,'228',NULL,NULL,'GH26',NULL,'','BALAJI C.GHEE500ML JAR','BALAJI C.GHEE500ML JAR','04059020','0.5','3',NULL,'3','GHEE OIL','10','10','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(134,'228',NULL,NULL,'GH27',NULL,'','BALAJI C.GHEE200ML JAR','BALAJI C.GHEE200ML JAR','04059020','0.2','3',NULL,'3','GHEE OIL','10','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(135,'228',NULL,NULL,'GH28',NULL,'','NAND KRISHNA GHEE 100MLTP','NAND KRISHNA GHEE 100MLTP','04059020','0.1','3',NULL,'3','GHEE OIL','10','10','150',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','150','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(136,'228',NULL,NULL,'VP55',NULL,'','NIRMAL 100*160 VP','NIRMAL 100*160 VP','15162091','0.1','3',NULL,'8','VANASPATI OIL','7','10','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(137,'228',NULL,NULL,'VP56',NULL,'','RUCHI VP 50ML*320','RUCHI VP 50ML*320','15162091','0.05','3',NULL,'8','VANASPATI OIL','7','10','320',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','320','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(138,'228',NULL,NULL,'TL23',NULL,'','DEEPMALA 180*50','DEEPMALA 180*50','27101971','0.18','3',NULL,'12','SESAME OIL','7','10','50',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(139,'228',NULL,NULL,'TL24',NULL,'','C.R 100*200 BOX','C.R 100*200 BOX','15159040','0.1','3',NULL,'12','SESAME OIL','7','10','200',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(140,'228',NULL,NULL,'VP57',NULL,'','NIRMAL VP 200*80','NIRMAL VP 200*80','15162091','0.2','3',NULL,'8','VANASPATI OIL','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(141,'228',NULL,NULL,'TL25',NULL,'','C.R.15KG TIN','C.R.15KG TIN','15159040','15','3',NULL,'12','SESAME OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(142,'228',NULL,NULL,'MO26',NULL,'','P.MARKA MUSTARDN PP1*16','P.MARKA MUSTARDN PP1*16','15149120','1','3',NULL,'9','MUSTERD OIL','10','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(143,'228',NULL,NULL,'SF120',NULL,'','RAJBHOG 700*12','RAJBHOG 700*12','15079010','0.7','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(144,'228',NULL,NULL,'SF121',NULL,'','SUNDAY5LITSF(5*4)*****','SUNDAY5LITSF(5*4)*****','15121910','5','3',NULL,'2','SUNFLOWER OIL','10','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(145,'228',NULL,NULL,'T21',NULL,'','TEEL RAJ 1LTR BOTTLE','TEEL RAJ 1LTR BOTTLE','15119020','1','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(146,'228',NULL,NULL,'T22',NULL,'','TEEL RAJ 500ML BOX','TEEL RAJ 500ML BOX','15119020','0.5','3',NULL,'12','SESAME OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(147,'228',NULL,NULL,'SF122',NULL,'','GULAB SF 15LTR TIN','GULAB SF 15LTR TIN','1512910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(148,'228',NULL,NULL,'CO16',NULL,'','KHOPREL 5KG JAR','KHOPREL 5KG JAR','00131900','5','3',NULL,'11','COCONUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(149,'228',NULL,NULL,'GN22',NULL,'','SUDH GROUNDNUT 15KG','SUDH GROUNDNUT 15KG','15079020','15','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(150,'228',NULL,NULL,'TO8',NULL,'','TILRAJ 15KG TIN','TILRAJ 15KG TIN','15119020','15','3',NULL,'12','SESAME OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(151,'228',NULL,NULL,'GN23',NULL,'','H.M. 15KG TIN','H.M. 15KG TIN','15119020','15','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(152,'228',NULL,NULL,'MO001',NULL,'','NANDKISHAN 1*15LT PP BOX','NANDKISHAN 1*15LT PP BOX','15122910','0.91','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(153,'228',NULL,NULL,'GN24',NULL,'','HIRA MOTI 15KG TIN','HIRA MOTI 15KG TIN','15119020','15','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(154,'228',NULL,NULL,'T23',NULL,'','TILLRAJ  5*4','TILLRAJ  5*4','15119020','5','3',NULL,'12','SESAME OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(155,'228',NULL,NULL,'MO27',NULL,'','KISHAN 1*20 BT','KISHAN 1*20 BT','151590','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(156,'228',NULL,NULL,'SF123',NULL,'','SUNTIME 1*15','SUNTIME 1*15','1511','1','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(157,'228',NULL,NULL,'SF124',NULL,'','RIVO SF 5*4 JAR','RIVO SF 5*4 JAR','15121910','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(158,'228',NULL,NULL,'GN25',NULL,'','RIVO FILTERED GN1*12 PP','RIVO FILTERED GN1*12 PP','15089091','1','3',NULL,'5','GROUNDNUT OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(159,'228',NULL,NULL,'GN26',NULL,'','RIVO FILTER GN 5*4','RIVO FILTER GN 5*4','15089091','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(160,'228',NULL,NULL,'GN27',NULL,'','RIVO REFINED GN 1*12 PP','RIVO REFINED GN 1*12 PP','15089091','1','3',NULL,'5','GROUNDNUT OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(161,'228',NULL,NULL,'GN28',NULL,'','RIVO REFINED GN 5*4','RIVO REFINED GN 5*4','15089091','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(162,'228',NULL,NULL,'RB17',NULL,'','RIVO REFINED RICE 1*12 PP','RIVO REFINED RICE 1*12 PP','15159040','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(163,'228',NULL,NULL,'RB18',NULL,'','RIVO REFINED RICE 5*4','RIVO REFINED RICE 5*4','15159040','5','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(164,'228',NULL,NULL,'MOO16',NULL,'','KISAN MO 15KG TIN','KISAN MO 15KG TIN','15149920','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(165,'228',NULL,NULL,'RB19',NULL,'','RIVO REF RICE 15LTJAR','RIVO REF RICE 15LTJAR','15159040','13.65','3',NULL,'10','RICEBRAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(166,'228',NULL,NULL,'GN29',NULL,'','RIVO REF GROUNDNUT 15LITJAR','RIVO REF GROUNDNUT 15LITJAR','','13.65','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(167,'228',NULL,NULL,'T24',NULL,'','Tilraj 200ml*100','Tilraj 200ml*100','15122910','0.2','3',NULL,'12','SESAME OIL','7','10','0',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','0','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(168,'228',NULL,NULL,'P10',NULL,'','RADHUNI PALM 750*10','RADHUNI PALM 750*10','15119010','0.75','3',NULL,'1','PALMOLEIN OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(169,'228',NULL,NULL,'PO7',NULL,'','RIVO PALM 15KG','RIVO PALM 15KG','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(170,'228',NULL,NULL,'PO8',NULL,'','RIVO PALM 15LT','RIVO PALM 15LT','15119020','13.5','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(171,'228',NULL,NULL,'MO28',NULL,'','Rivo Kachi GANI 15 Kg Tin','Rivo Kachi GANI 15 Kg Tin','15149120','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(172,'228',NULL,NULL,'CO6',NULL,'','Rivo Coonut Oil 15 Kg Tin','Rivo Coonut Oil 15 Kg Tin','15131100','15','3',NULL,'11','COCONUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(173,'228',NULL,NULL,'SF129',NULL,'','SUNPURE SFO 13KG TIN','SUNPURE SFO 13KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(174,'228',NULL,NULL,'SF130',NULL,'','REF OIL RAJBHOG 13KG JAR','REF OIL RAJBHOG 13KG JAR','15079010','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(175,'228',NULL,NULL,'SF131',NULL,'','Kp Sf15kg Tin','Kp Sf15kg Tin','','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(176,'228',NULL,NULL,'SF132',NULL,'','Gemime 15ltr Null Jar','Gemime 15ltr Null Jar','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(177,'228',NULL,NULL,'MO35',NULL,'','RADHEY KRISHNA 15 KG TIN','RADHEY KRISHNA 15 KG TIN','15119020','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(178,'228',NULL,NULL,'SF138',NULL,'','FORTUNE SF 800*20','FORTUNE SF 800*20','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(179,'228',NULL,NULL,'VP58',NULL,'','Ruchi No1 500ml*20','Ruchi No1 500ml*20','15162091','0.5','3',NULL,'8','VANASPATI OIL','7','10','0',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','0','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(180,'228',NULL,NULL,'CO7',NULL,'','Cocolight 40ml','Cocolight 40ml','3305','0.04','3',NULL,'11','COCONUT OIL','7','10','400',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','400','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(181,'228',NULL,NULL,'CO8',NULL,'','Cocolight Coco 100ml','Cocolight Coco 100ml','330590','0.1','3',NULL,'11','COCONUT OIL','7','10','200',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(182,'228',NULL,NULL,'CO9',NULL,'','Cocolight Coco200ml','Cocolight Coco200ml','330590','0.2','3',NULL,'11','COCONUT OIL','7','10','100',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(183,'228',NULL,NULL,'CO23',NULL,'','Cocolight Coco 500ml','Cocolight Coco 500ml','330590','0.5','3',NULL,'11','COCONUT OIL','7','10','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(184,'228',NULL,NULL,'CO24',NULL,'','Cocolight Coco 1 Ltr','Cocolight Coco 1 Ltr','330590','1','3',NULL,'11','COCONUT OIL','7','10','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(185,'228',NULL,NULL,'MO40',NULL,'','Rivo Kachi Ghani 1*20 Bt','Rivo Kachi Ghani 1*20 Bt','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(186,'228',NULL,NULL,'MO41',NULL,'','SARTHI 900ML Bt1*15','SARTHI 900ML Bt1*15','15159040','0.9','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(187,'228',NULL,NULL,'MO42',NULL,'','Kolhu Mo500*40 Bt','Kolhu Mo500*40 Bt','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(188,'228',NULL,NULL,'MO43',NULL,'','PAPU MO 5*4','PAPU MO 5*4','15149120','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(189,'228',NULL,NULL,'MO44',NULL,'','MORNI REF 15 KG TIN','MORNI REF 15 KG TIN','15159040','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(190,'228',NULL,NULL,'MO45',NULL,'','(SUPER ) KISHAN MUST PP 1*15','(SUPER ) KISHAN MUST PP 1*15','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(191,'228',NULL,NULL,'CO40',NULL,'','Rivo Coconut Oil 5kg Jar','Rivo Coconut Oil 5kg Jar','15131100','5','3',NULL,'11','COCONUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(192,'228',NULL,NULL,'MO50',NULL,'','Priya Kg 1*12 Pet','Priya Kg 1*12 Pet','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(193,'228',NULL,NULL,'MO51',NULL,'','Priya Kg 500*24 Pet','Priya Kg 500*24 Pet','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(194,'228',NULL,NULL,'MO52',NULL,'','Tiger Mo 5*4 Jar','Tiger Mo 5*4 Jar','15159040','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(195,'228',NULL,NULL,'MO53',NULL,'','Priya KG 200*60 Pet','Priya KG 200*60 Pet','15149120','0.2','3',NULL,'9','MUSTERD OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(196,'228',NULL,NULL,'SF139',NULL,'','OLAMPIYA 725GM*15','OLAMPIYA 725GM*15','150790','0.725','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(197,'228',NULL,NULL,'SF 140',NULL,'','DALDA SF 13KG TIN','DALDA SF 13KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(198,'228',NULL,NULL,'GH50',NULL,'','Mahaveer Ghee 100 Ml*96','Mahaveer Ghee 100 Ml*96','0405','0.1','3',NULL,'3','GHEE OIL','7','10','96',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(199,'228',NULL,NULL,'SF160',NULL,'','Sunny Sf 15ltr Easy Fill Jar','Sunny Sf 15ltr Easy Fill Jar','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(200,'228',NULL,NULL,'RB20',NULL,'','Ricela Rice 1*12 Pp','Ricela Rice 1*12 Pp','1515','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(201,'228',NULL,NULL,'RB21',NULL,'','Ricela Rice 2*8 Jar','Ricela Rice 2*8 Jar','1515','2','3',NULL,'10','RICEBRAN OIL','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(202,'228',NULL,NULL,'RB22',NULL,'','ricela rice 5*4 jar','ricela rice 5*4 jar','1515','5','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(203,'228',NULL,NULL,'RB23',NULL,'','Ricela Rice 15 Ltr Jar','Ricela Rice 15 Ltr Jar','1515','15','3',NULL,'10','RICEBRAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(204,'228',NULL,NULL,'SF 161',NULL,'','PRIYA SF 750*16','PRIYA SF 750*16','15121910','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(205,'228',NULL,NULL,'GH51',NULL,'','KOROVA(C) GHEE 1LIT JAR','KOROVA(C) GHEE 1LIT JAR','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(206,'228',NULL,NULL,'GH52',NULL,'','PRABHAT GHE 500 JAR','PRABHAT GHE 500 JAR','0405.9020','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(207,'228',NULL,NULL,'GH53',NULL,'','PRABHAT GHE 1 PP','PRABHAT GHE 1 PP','0405.90.20','1','3',NULL,'3','GHEE OIL','7','10','16',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(208,'228',NULL,NULL,'GH54',NULL,'','PRABHAT GHE 500 PP','PRABHAT GHE 500 PP','0405.90.20','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(209,'228',NULL,NULL,'GH55',NULL,'','PRABHAT GHE 200 JAR','PRABHAT GHE 200 JAR','0405.90.20','0.2','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(210,'228',NULL,NULL,'GH56',NULL,'','PRABHAT GHE 100 JAR','PRABHAT GHE 100 JAR','0405.90.20','0.1','3',NULL,'3','GHEE OIL','7','10','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(211,'228',NULL,NULL,'MO54',NULL,'','PRIYA KG PP1*12','PRIYA KG PP1*12','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(212,'228',NULL,NULL,'MO55',NULL,'','RIVO KG 500 BT','RIVO KG 500 BT','1519120','0.5','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(213,'228',NULL,NULL,'GH57',NULL,'','PRABHAT 5LTR TIN','PRABHAT 5LTR TIN','0405.90.20','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(214,'228',NULL,NULL,'GH58',NULL,'','SHREMUL COW 200JAR','SHREMUL COW 200JAR','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(215,'228',NULL,NULL,'GH59',NULL,'','PANCHJYOT HP. G.450ML','PANCHJYOT HP. G.450ML','151620','0.45','3',NULL,'3','GHEE OIL','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(216,'228',NULL,NULL,'GH60',NULL,'','SHREMUL COW 1LTRJAR','SHREMUL COW 1LTRJAR','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(217,'228',NULL,NULL,'GH61',NULL,'','SHREMUL REG 1TR TIN','SHREMUL REG 1TR TIN','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(218,'228',NULL,NULL,'SF162',NULL,'','SUNNY SF 800*12','SUNNY SF 800*12','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(219,'228',NULL,NULL,'SF163',NULL,'','FORTUNE SF 4.350*4','FORTUNE SF 4.350*4','15121910','4.35','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(220,'228',NULL,NULL,'GN32',NULL,'','COOKWEL GN 5*4','COOKWEL GN 5*4','15159040','5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(221,'228',NULL,NULL,'MO56',NULL,'','RIVO KG 5*4','RIVO KG 5*4','15149120','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(222,'228',NULL,NULL,'SF164',NULL,'','EVERYGOLD LITE 700 GM','EVERYGOLD LITE 700 GM','15079010','0.7','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(223,'228',NULL,NULL,'GN33',NULL,'','HEALTH GN 15KG','HEALTH GN 15KG','15119020','15','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(224,'228',NULL,NULL,'MO70',NULL,'','rajdhani 5*4','rajdhani 5*4','15149920','5','3',NULL,'1','PALMOLEIN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(225,'228',NULL,NULL,'MO71',NULL,'','SK MUSTARD 1*15','SK MUSTARD 1*15','15149920','1','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(226,'228',NULL,NULL,'MO72',NULL,'','SK MUSTRAD 15KG','SK MUSTRAD 15KG','15159040','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(227,'228',NULL,NULL,'HE2',NULL,'','HELLL','HELLL','9965','0','3',NULL,'13','Test','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Test',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(228,'228',NULL,NULL,'GN34',NULL,'','RBD  15KG TIN','RBD  15KG TIN','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(229,'228',NULL,NULL,'GN35',NULL,'','rajdhani  1*15','rajdhani  1*15','15119020','1','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(230,'228',NULL,NULL,'SF165',NULL,'','Priya Sf Tab Jar','Priya Sf Tab Jar','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(231,'228',NULL,NULL,'GH80',NULL,'','KOROVA C GHEE 200*60','KOROVA C GHEE 200*60','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(232,'228',NULL,NULL,'GH81',NULL,'','KOROVA C GHEE 1*15PP','KOROVA C GHEE 1*15PP','04059020','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(233,'228',NULL,NULL,'GH82',NULL,'','KOROVA C GHEE 500*30 PP','KOROVA C GHEE 500*30 PP','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(234,'228',NULL,NULL,'GH83',NULL,'','KOROVA C GHEE 500* JAR','KOROVA C GHEE 500* JAR','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(235,'228',NULL,NULL,'GH84',NULL,'','KOROVA C GHEE 100*120','KOROVA C GHEE 100*120','04059020','0.1','3',NULL,'3','GHEE OIL','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(236,'228',NULL,NULL,'GH85',NULL,'','KOROVA C GHE 35ML *240','KOROVA C GHE 35ML *240','04059020','0.035','3',NULL,'3','GHEE OIL','7','10','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(237,'228',NULL,NULL,'SF166',NULL,'','FORTUNESF1*16 OFFER','FORTUNESF1*16 OFFER','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(238,'228',NULL,NULL,'PCO 12',NULL,'','PS COCO200*25','PS COCO200*25','1513','0.2','3',NULL,'11','COCONUT OIL','7','10','25',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','COCONUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(239,'228',NULL,NULL,'SF125',NULL,'','GEMINI SF 800*12','GEMINI SF 800*12','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(240,'228',NULL,NULL,'SF167',NULL,'','SUN TASTY 13.5 TIN','SUN TASTY 13.5 TIN','15079010','13.5','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(241,'228',NULL,NULL,'CT12',NULL,'','GUJRAT CT15 KG TIN','GUJRAT CT15 KG TIN','15119020','15','3',NULL,'7','COTTON OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COTTON OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(242,'228',NULL,NULL,'MO100',NULL,'','APPU KG 1*15','APPU KG 1*15','15149920','1','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(243,'228',NULL,NULL,'SF170',NULL,'','GULAB SF 15 KG TIN','GULAB SF 15 KG TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(244,'228',NULL,NULL,'SF189',NULL,'','SAFOLAACTIV 750*PP *20','SAFOLAACTIV 750*PP *20','15179090','0.75','3',NULL,'4','SAFFOLA OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SAFFOLA OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(245,'228',NULL,NULL,'VP60',NULL,'','DALDA VP 1*20','DALDA VP 1*20','15162091','1','3',NULL,'8','VANASPATI OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(246,'228',NULL,NULL,'VP61',NULL,'','DALDA VP 500*32','DALDA VP 500*32','15162091','0.5','3',NULL,'8','VANASPATI OIL','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(247,'228',NULL,NULL,'OL1',NULL,'','A. EXTRA LITE 5*3 OLVIE OIL','A. EXTRA LITE 5*3 OLVIE OIL','15099010','5','3',NULL,'14','OLIVE OIL','7','10','3',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','3','0','0','0','OLIVE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(248,'228',NULL,NULL,'OL 2',NULL,'','A. EXTRA LITE 1*12 OLIVE OIL','A. EXTRA LITE 1*12 OLIVE OIL','15099010','1','3',NULL,'14','OLIVE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','OLIVE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(249,'228',NULL,NULL,'OL 3',NULL,'','A. EXTRA LITE 2*6 OLIVE OIL','A. EXTRA LITE 2*6 OLIVE OIL','15099010','2','3',NULL,'14','OLIVE OIL','7','10','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','OLIVE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(250,'228',NULL,NULL,'OL 4',NULL,'','A. POMACE 1*12 OLIVE OIL','A. POMACE 1*12 OLIVE OIL','15099010','1','3',NULL,'14','OLIVE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','OLIVE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(251,'228',NULL,NULL,'OL 5',NULL,'','A. POMACE 5*4 OLIVE OIL','A. POMACE 5*4 OLIVE OIL','15099010','5','3',NULL,'14','OLIVE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','OLIVE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(252,'228',NULL,NULL,'PO15',NULL,'','RAJBHOG PALM 780*15','RAJBHOG PALM 780*15','15119020','0.78','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(253,'228',NULL,NULL,'PO17',NULL,'','NAMASTE R.B.D.PALM 1*15','NAMASTE R.B.D.PALM 1*15','15119010','1','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(254,'228',NULL,NULL,'SF150',NULL,'','SUNFINE 720GM *15','SUNFINE 720GM *15','15119020','0.72','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(255,'228',NULL,NULL,'SF175',NULL,'','SAMRAT SF15 JAR','SAMRAT SF15 JAR','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(256,'228',NULL,NULL,'SF176',NULL,'','SAMRAT SF15 KG','SAMRAT SF15 KG','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(257,'228',NULL,NULL,'SF177',NULL,'','SAMRAT SF 13 KG TIN','SAMRAT SF 13 KG TIN','15121910','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(258,'228',NULL,NULL,'GN50',NULL,'','SAURASHTRA 15KG TIN','SAURASHTRA 15KG TIN','150790','15','3',NULL,'5','GROUNDNUT OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(259,'228',NULL,NULL,'SF168',NULL,'','OLAMPIYA 13KG JAR','OLAMPIYA 13KG JAR','150790','13','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(260,'228',NULL,NULL,'MO73',NULL,'','KISHAN K 1*15 PP','KISHAN K 1*15 PP','1515','1','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(261,'228',NULL,NULL,'MO74',NULL,'','KISAN K 5*4 MO','KISAN K 5*4 MO','151590','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(262,'228',NULL,NULL,'GN30',NULL,'','RAJWADI 1*15 PP','RAJWADI 1*15 PP','1512','1','3',NULL,'5','GROUNDNUT OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(263,'228',NULL,NULL,'GN31',NULL,'','RAJWADI 5*4','RAJWADI 5*4','1512','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(264,'228',NULL,NULL,'GN39',NULL,'','RAJWADI 15 KG TIN','RAJWADI 15 KG TIN','1512','15','3',NULL,'5','GROUNDNUT OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(265,'228',NULL,NULL,'TL15',NULL,'','DEEPAKAM 1*20 BT','DEEPAKAM 1*20 BT','1512','1','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(266,'228',NULL,NULL,'TL14',NULL,'','DEEPAKAM 500*20','DEEPAKAM 500*20','1512','0.5','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(267,'228',NULL,NULL,'RB24',NULL,'','RIVOLA RICE1*12','RIVOLA RICE1*12','1515','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(268,'228',NULL,NULL,'RB25',NULL,'','RIVOLA RICE5*4','RIVOLA RICE5*4','1515','5','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(269,'228',NULL,NULL,'GH70',NULL,'','GAUDHAN 1*12 JAR','GAUDHAN 1*12 JAR','0405','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(270,'228',NULL,NULL,'GH71',NULL,'','GAUDHAN 500*24','GAUDHAN 500*24','0405','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(271,'228',NULL,NULL,'GH72',NULL,'','PANCHJYOT H P. 200ML*80','PANCHJYOT H P. 200ML*80','151620','0.2','3',NULL,'3','GHEE OIL','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(272,'228',NULL,NULL,'TL16',NULL,'','DEEPAKAM 15KG TIN','DEEPAKAM 15KG TIN','1512','15','3',NULL,'12','SESAME OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(273,'228',NULL,NULL,'SF169',NULL,'','SUNCITY 725*15','SUNCITY 725*15','150790','0.725','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(274,'228',NULL,NULL,'GN40',NULL,'','COTTON REF 15KG TIN','COTTON REF 15KG TIN','1512','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(275,'228',NULL,NULL,'TL18',NULL,'','DEEPAKAM 200*45','DEEPAKAM 200*45','1512','0.2','3',NULL,'12','SESAME OIL','7','10','45',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','45','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(276,'228',NULL,NULL,'PO9',NULL,'','RBD REF KATHIYA 15KG','RBD REF KATHIYA 15KG','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(277,'228',NULL,NULL,'SF171',NULL,'','SUNDAY SFO 800G*12','SUNDAY SFO 800G*12','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(278,'228',NULL,NULL,'SF172',NULL,'','OLAMPIYA 5LIT*4','OLAMPIYA 5LIT*4','150790','4.5','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(279,'228',NULL,NULL,'MO75',NULL,'','NANDKISHAN 1*16','NANDKISHAN 1*16','15159040','1','3',NULL,'9','MUSTERD OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(280,'228',NULL,NULL,'MO76',NULL,'','NANDKISAN 5*4','NANDKISAN 5*4','15159040','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(281,'228',NULL,NULL,'MO77',NULL,'','BANSAL 15KG TIN','BANSAL 15KG TIN','15159040','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(282,'228',NULL,NULL,'SF173',NULL,'','GEMLITE SF 720 GM','GEMLITE SF 720 GM','15079010','0.72','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(283,'228',NULL,NULL,'SF174',NULL,'','RE S OIL RAJBHOG 4*4','RE S OIL RAJBHOG 4*4','15079010','4','3',NULL,'6','SOYABEAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(284,'228',NULL,NULL,'GH86',NULL,'','Kanhaiya 200*75','Kanhaiya 200*75','0405','0.2','3',NULL,'3','GHEE OIL','7','10','75',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','75','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(285,'228',NULL,NULL,'SF 175',NULL,'','GEMLITE SF 850GM','GEMLITE SF 850GM','1512','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(286,'228',NULL,NULL,'SF178',NULL,'','OLAMPIYA 14 LTR TIN','OLAMPIYA 14 LTR TIN','151219','13.25','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(287,'228',NULL,NULL,'MO78',NULL,'','PAPU 200*50','PAPU 200*50','15149120','0.2','3',NULL,'9','MUSTERD OIL','7','10','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(288,'228',NULL,NULL,'MO79',NULL,'','PAPU 1*20','PAPU 1*20','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(289,'228',NULL,NULL,'TL26',NULL,'','TRISHUL TL 1*20','TRISHUL TL 1*20','15159040','1','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(290,'228',NULL,NULL,'TL27',NULL,'','TRISHUL TL500*40','TRISHUL TL500*40','15159040','0.5','3',NULL,'12','SESAME OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(291,'228',NULL,NULL,'TL28',NULL,'','C.R 5*4','C.R 5*4','15159040','5','3',NULL,'12','SESAME OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(292,'228',NULL,NULL,'TL29',NULL,'','DEVPOOJA 100*25','DEVPOOJA 100*25','27101971','0.1','3',NULL,'12','SESAME OIL','7','10','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(293,'228',NULL,NULL,'SF179',NULL,'','SAMRAT SF 1*12','SAMRAT SF 1*12','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(294,'228',NULL,NULL,'GH 87',NULL,'','Nandini Ghee[ 5lit *4]','Nandini Ghee[ 5lit *4]','04059020','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(295,'228',NULL,NULL,'SF180',NULL,'','SUNDEEP SF15 JAR','SUNDEEP SF15 JAR','1512','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(296,'228',NULL,NULL,'VP62',NULL,'','RUCHI VP 200*60','RUCHI VP 200*60','15162091','0.2','3',NULL,'8','VANASPATI OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(297,'228',NULL,NULL,'VP63',NULL,'','RUCHI VP( 200ML *80)','RUCHI VP( 200ML *80)','15162091','0.2','3',NULL,'8','VANASPATI OIL','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(298,'228',NULL,NULL,'MO80',NULL,'','SUPREME RASOI MU1*20','SUPREME RASOI MU1*20','15159040','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(299,'228',NULL,NULL,'MO81',NULL,'','GEMLITE SF 500ML*36','GEMLITE SF 500ML*36','15121910','0.5','3',NULL,'2','SUNFLOWER OIL','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(300,'228',NULL,NULL,'MO82',NULL,'','CRUX K G 200*60 BT','CRUX K G 200*60 BT','1514','0.2','3',NULL,'9','MUSTERD OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(301,'228',NULL,NULL,'MO83',NULL,'','CRUX K G 5*4 JAR','CRUX K G 5*4 JAR','1514','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(302,'228',NULL,NULL,'1627903291374',NULL,'','V. POOJA  GHEE 1*16','V. POOJA  GHEE 1*16','1515','1','3',NULL,'3','GHEE OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(303,'228',NULL,NULL,'GH89',NULL,'','V.POOJA GHEE 500*32','V.POOJA GHEE 500*32','151590','0.5','3',NULL,'3','GHEE OIL','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(304,'228',NULL,NULL,'GH90',NULL,'','V. POOJA GHEE 200*80','V. POOJA GHEE 200*80','151590','0.2','3',NULL,'3','GHEE OIL','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(305,'228',NULL,NULL,'GH91',NULL,'','ASHT P  GHEE 100*120','ASHT P  GHEE 100*120','151590','0.1','3',NULL,'3','GHEE OIL','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(306,'228',NULL,NULL,'T30',NULL,'','SAHYOG TL 1*20','SAHYOG TL 1*20','1518','1','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(307,'228',NULL,NULL,'T31',NULL,'','SAHYOG TL 500*40','SAHYOG TL 500*40','1518','0.5','3',NULL,'12','SESAME OIL','7','10','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(308,'228',NULL,NULL,'T32',NULL,'','SAHYOG TL 200*100','SAHYOG TL 200*100','1518','0.2','3',NULL,'12','SESAME OIL','7','10','100',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(309,'228',NULL,NULL,'SF181',NULL,'','OLAMPIYA SF 870*15','OLAMPIYA SF 870*15','150790','1','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(310,'228',NULL,NULL,'SF182',NULL,'','SUNRICH SF 4KG*4','SUNRICH SF 4KG*4','15121910','4','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(311,'228',NULL,NULL,'T33',NULL,'','NATRAJ R.B.900ML*20','NATRAJ R.B.900ML*20','1515','1','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(312,'228',NULL,NULL,'SF183',NULL,'','GEMINI GOLD 1*12','GEMINI GOLD 1*12','15180013','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(313,'228',NULL,NULL,'SF184',NULL,'','SAMRAT SF 850*12','SAMRAT SF 850*12','15121910','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(314,'228',NULL,NULL,'MO84',NULL,'','RBD BASURI 15KG TIN','RBD BASURI 15KG TIN','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(315,'228',NULL,NULL,'SF185',NULL,'','GENMIN SF 15 LTR TIN','GENMIN SF 15 LTR TIN','15079010','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(316,'228',NULL,NULL,'PO18',NULL,'','NAMASTE 1*10 PALM','NAMASTE 1*10 PALM','15119010','1','3',NULL,'1','PALMOLEIN OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(317,'228',NULL,NULL,'SF186',NULL,'','SUNELITE 650G*12','SUNELITE 650G*12','15079010','0.65','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(318,'228',NULL,NULL,'SF187',NULL,'','SUNLITE SF 15LTR JAR','SUNLITE SF 15LTR JAR','1507','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(319,'228',NULL,NULL,'T34',NULL,'','VISVDEEP 900ML 1*20','VISVDEEP 900ML 1*20','1518','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(320,'228',NULL,NULL,'MO85',NULL,'','PAPU 500*20','PAPU 500*20','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(321,'228',NULL,NULL,'MO86',NULL,'','APPU RAJA 900ML*20','APPU RAJA 900ML*20','151590','0.81','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(322,'228',NULL,NULL,'MO87',NULL,'','MAHAYOG 900ML*15','MAHAYOG 900ML*15','15159040','0.9','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(323,'228',NULL,NULL,'MO88',NULL,'','HT KG MO500*24','HT KG MO500*24','1514','0.5','3',NULL,'9','MUSTERD OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(324,'228',NULL,NULL,'SF188',NULL,'','RSF RAJBHOG 870 G*12','RSF RAJBHOG 870 G*12','15079010','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(325,'228',NULL,NULL,'SF190',NULL,'','PRIYA SF 4*4.250KG','PRIYA SF 4*4.250KG','15121910','4.25','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(326,'228',NULL,NULL,'RB26',NULL,'','H&T RICE 1*12 PP','H&T RICE 1*12 PP','1515','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(327,'228',NULL,NULL,'RB27',NULL,'','HT RICE 5*4 JAR','HT RICE 5*4 JAR','1515','5','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(328,'228',NULL,NULL,'T35',NULL,'','ASHIRWAD TIN 15KG','ASHIRWAD TIN 15KG','15079010','15','3',NULL,'12','SESAME OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(329,'228',NULL,NULL,'T36',NULL,'','GAUDHAN DIYA &LAMP OIL 900ML 1*20','GAUDHAN DIYA &LAMP OIL 900ML 1*20','1515','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(330,'228',NULL,NULL,'MO89',NULL,'','MAHAYOG 200*50','MAHAYOG 200*50','15159040','0.2','3',NULL,'9','MUSTERD OIL','7','10','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(331,'228',NULL,NULL,'MO90',NULL,'','HT KGMO (5*4)JAR','HT KGMO (5*4)JAR','15114','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(332,'228',NULL,NULL,'PO19',NULL,'','IMP PALM 15 KG','IMP PALM 15 KG','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(333,'228',NULL,NULL,'PO20',NULL,'','RADHUNI GOLD PALM 13KG','RADHUNI GOLD PALM 13KG','15119020','13','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(334,'228',NULL,NULL,'SF191',NULL,'','FAVOURITE 1LIT 1*12','FAVOURITE 1LIT 1*12','1507','1','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(335,'228',NULL,NULL,'CT13',NULL,'','NIMRANI SOYABEAN 15KG TIN','NIMRANI SOYABEAN 15KG TIN','1507','15','3',NULL,'6','SOYABEAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(336,'228',NULL,NULL,'SB15',NULL,'','SUNNY REF SOYA 15KG TIN','SUNNY REF SOYA 15KG TIN','1507','15','3',NULL,'6','SOYABEAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(337,'228',NULL,NULL,'SB16',NULL,'','NIMRANI REF SOYA PP 1*15','NIMRANI REF SOYA PP 1*15','1507','1','3',NULL,'6','SOYABEAN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(338,'228',NULL,NULL,'EX',NULL,'','MARKET DEVELOPMENT EXP','MARKET DEVELOPMENT EXP','998397','1','3',NULL,'13','Test','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Test',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(339,'228',NULL,NULL,'T37',NULL,'','SAHYOG 100*200','SAHYOG 100*200','1518','0.1','3',NULL,'12','SESAME OIL','7','10','200',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(340,'228',NULL,NULL,'SB17',NULL,'','NIMRANI SOYA (5*4)','NIMRANI SOYA (5*4)','15079010','5','3',NULL,'6','SOYABEAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(341,'228',NULL,NULL,'T38',NULL,'','VISHWADEEP 450*45','VISHWADEEP 450*45','1518','0.45','3',NULL,'12','SESAME OIL','7','10','45',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','45','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(342,'228',NULL,NULL,'SF192',NULL,'','FORTUNE SF 1*16','FORTUNE SF 1*16','15121910','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(343,'228',NULL,NULL,'MO91',NULL,'','SAGAR RB 15KG','SAGAR RB 15KG','1512','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(344,'228',NULL,NULL,'MO92',NULL,'','GOPAL KRISHNA 1*12','GOPAL KRISHNA 1*12','1512','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(345,'228',NULL,NULL,'RB28',NULL,'','SIVTY KOLAM R.B.1*12','SIVTY KOLAM R.B.1*12','15159040','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(346,'228',NULL,NULL,'SF193',NULL,'','GEMINI SF 4.200*4','GEMINI SF 4.200*4','15121910','4.2','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(347,'228',NULL,NULL,'SF194',NULL,'','GEMINI SF BT 1*12','GEMINI SF BT 1*12','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(348,'228',NULL,NULL,'SB18',NULL,'','GEMINI SOYA 1*12','GEMINI SOYA 1*12','15079010','1','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(349,'228',NULL,NULL,'SB19',NULL,'','GEMINI SOYA 5*4','GEMINI SOYA 5*4','15079010','5','3',NULL,'6','SOYABEAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(350,'228',NULL,NULL,'RB29',NULL,'','GEMINI RICE 1*12','GEMINI RICE 1*12','15159040','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(351,'228',NULL,NULL,'RB30',NULL,'','GEMINI RICE 5*4','GEMINI RICE 5*4','15159040','5','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(352,'228',NULL,NULL,'MO93',NULL,'','GEMINI MUS 1*12','GEMINI MUS 1*12','15149920','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(353,'228',NULL,NULL,'GN41',NULL,'','GEMINI GN 5*4','GEMINI GN 5*4','15089091','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(354,'228',NULL,NULL,'SF195',NULL,'','GENIME 800*15','GENIME 800*15','15079010','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(355,'228',NULL,NULL,'SF196',NULL,'','FORSUN 750G *15','FORSUN 750G *15','15121910','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(356,'228',NULL,NULL,'SF197',NULL,'','SUNRICH R.SF  PP 850 PAC','SUNRICH R.SF  PP 850 PAC','15121910','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(357,'228',NULL,NULL,'MO94',NULL,'','MAHABHOG MUS 1*12 BT','MAHABHOG MUS 1*12 BT','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(358,'228',NULL,NULL,'T39',NULL,'','VISHDEEP GOLD 1*20','VISHDEEP GOLD 1*20','1515','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(359,'228',NULL,NULL,'T40',NULL,'','VISHDEEP GOLD 450*45','VISHDEEP GOLD 450*45','1515','0.45','3',NULL,'12','SESAME OIL','7','10','45',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','45','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(360,'228',NULL,NULL,'SF198',NULL,'','GEMIMI SF 15LTR TIN','GEMIMI SF 15LTR TIN','15079010','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(361,'228',NULL,NULL,'T41',NULL,'','AMARDEEPLUV 900*15','AMARDEEPLUV 900*15','1518','0.9','3',NULL,'12','SESAME OIL','7','10','15',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(362,'228',NULL,NULL,'CT14',NULL,'','FUTURE COTON 15KG TIN','FUTURE COTON 15KG TIN','1512','15','3',NULL,'7','COTTON OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COTTON OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(363,'228',NULL,NULL,'GH95',NULL,'','V.POOJA GHEE 1*16','V.POOJA GHEE 1*16','151590','1','3',NULL,'3','GHEE OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(364,'228',NULL,NULL,'T43',NULL,'','AMARDEEPLUV 200*60','AMARDEEPLUV 200*60','15180040','0.2','3',NULL,'12','SESAME OIL','7','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(365,'228',NULL,NULL,'T44',NULL,'','AMARDEEPLUV 450*32','AMARDEEPLUV 450*32','1518','0.45','3',NULL,'12','SESAME OIL','7','10','32',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(366,'228',NULL,NULL,'GN42',NULL,'','RAJTILAK 15KG TIN','RAJTILAK 15KG TIN','','15','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(367,'228',NULL,NULL,'PO21',NULL,'','PALM PP 830*15','PALM PP 830*15','15119020','0.83','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(368,'228',NULL,NULL,'T45',NULL,'','SAHYOG 900*20','SAHYOG 900*20','151800','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(369,'228',NULL,NULL,'T46',NULL,'','SAHYOG 450*45','SAHYOG 450*45','1518','0.45','3',NULL,'12','SESAME OIL','7','10','45',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','45','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(370,'228',NULL,NULL,'SF199',NULL,'','SUNFLAME 900 ML(1*15)','SUNFLAME 900 ML(1*15)','15119020','0.9','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(371,'228',NULL,NULL,'MO95',NULL,'','TIGER BT (1*18)','TIGER BT (1*18)','15159040','1','3',NULL,'9','MUSTERD OIL','7','10','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(372,'228',NULL,NULL,'MO96',NULL,'','R.K. RB 15KG TIN','R.K. RB 15KG TIN','15119020','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(373,'228',NULL,NULL,'MO97',NULL,'','ENGINE MO 15KG TIN','ENGINE MO 15KG TIN','15149120','15','3',NULL,'9','MUSTERD OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(374,'228',NULL,NULL,'MO98',NULL,'','ENGINE MO (5*4)','ENGINE MO (5*4)','15149120','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(375,'228',NULL,NULL,'MO99',NULL,'','ENGINE MO BT (1*20)','ENGINE MO BT (1*20)','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(376,'228',NULL,NULL,'MO101',NULL,'','ENGINE MO PP (1*20)','ENGINE MO PP (1*20)','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(377,'228',NULL,NULL,'MO102',NULL,'','ENGINE MO BT (500*36)','ENGINE MO BT (500*36)','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(378,'228',NULL,NULL,'MO103',NULL,'','ENGINE MO BT (200*64)','ENGINE MO BT (200*64)','15149120','0.2','3',NULL,'9','MUSTERD OIL','7','10','64',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(379,'228',NULL,NULL,'MO104',NULL,'','ENGINE MO BT (100*162)','ENGINE MO BT (100*162)','15149120','0.1','3',NULL,'9','MUSTERD OIL','7','10','162',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','162','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(380,'228',NULL,NULL,'MO105',NULL,'','UPASANA MO (5*4)','UPASANA MO (5*4)','15149120','5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(381,'228',NULL,NULL,'MO106',NULL,'','UPASANA MO BT (1*12)','UPASANA MO BT (1*12)','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(382,'228',NULL,NULL,'MO107',NULL,'','UPASANA MO BT (500*24)','UPASANA MO BT (500*24)','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(383,'228',NULL,NULL,'MO108',NULL,'','UPASANA MO BT (200*60)','UPASANA MO BT (200*60)','15149120','0.2','3',NULL,'9','MUSTERD OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(384,'228',NULL,NULL,'SF200',NULL,'','SUNPURE 900 (1*15)','SUNPURE 900 (1*15)','15079010','0.9','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(385,'228',NULL,NULL,'RB31',NULL,'','PRIYA RB 1*12','PRIYA RB 1*12','151590','1','3',NULL,'10','RICEBRAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(386,'228',NULL,NULL,'RB32',NULL,'','PRIYA RB 5*4','PRIYA RB 5*4','151590','5','3',NULL,'10','RICEBRAN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(387,'228',NULL,NULL,'MO109',NULL,'','UPASANA MUS 15KG TIN','UPASANA MUS 15KG TIN','15149120','15','3',NULL,'9','MUSTERD OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(388,'228',NULL,NULL,'SF201',NULL,'','SUNCO (1*15)','SUNCO (1*15)','15119020','1','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(389,'228',NULL,NULL,'MO110',NULL,'','TIGER BT 500*36','TIGER BT 500*36','15149120','0.5','3',NULL,'9','MUSTERD OIL','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(390,'228',NULL,NULL,'MO111',NULL,'','KANAIYA 750GM 1*15','KANAIYA 750GM 1*15','15119020','0.75','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(391,'228',NULL,NULL,'T47',NULL,'','TILGOLD 900 1*20','TILGOLD 900 1*20','15180040','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(392,'228',NULL,NULL,'SF202',NULL,'','SUNNY SF 860*12','SUNNY SF 860*12','15121910','0.86','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(393,'228',NULL,NULL,'SF203',NULL,'','RAJBHOG SF 800*12','RAJBHOG SF 800*12','15079010','0.8','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(394,'228',NULL,NULL,'GN43',NULL,'','RAJDHANI 900ML','RAJDHANI 900ML','151219','1','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(395,'228',NULL,NULL,'GN44',NULL,'','NATURAL 5*4','NATURAL 5*4','15119020','5','3',NULL,'1','PALMOLEIN OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(396,'228',NULL,NULL,'GN45',NULL,'','RAJDHANI  13KG TIN','RAJDHANI  13KG TIN','150790','13','3',NULL,'1','PALMOLEIN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(397,'228',NULL,NULL,'GN46',NULL,'','NATURAL1*15','NATURAL1*15','15119020','1','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(398,'228',NULL,NULL,'SF204',NULL,'','OLAMPIYA 700*15','OLAMPIYA 700*15','150790','0.7','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(399,'228',NULL,NULL,'MO112',NULL,'','TASTY GOLD 15KG','TASTY GOLD 15KG','15119020','15','3',NULL,'1','PALMOLEIN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(400,'228',NULL,NULL,'SF205',NULL,'','SUN TASTY 700*15','SUN TASTY 700*15','15079010','0.7','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(401,'228',NULL,NULL,'SF206',NULL,'','FORWEL 750 *15','FORWEL 750 *15','15119020','0.75','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(402,'228',NULL,NULL,'MO113',NULL,'','UPASANA PP 1*12','UPASANA PP 1*12','15149120','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(403,'228',NULL,NULL,'MO114',NULL,'','TIGER BT 200*60','TIGER BT 200*60','15159040','0.2','3',NULL,'9','MUSTERD OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(404,'228',NULL,NULL,'SF 207',NULL,'','850g GEMIME *15','850g GEMIME *15','15079010','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(405,'228',NULL,NULL,'T48',NULL,'','PANCHJYOT 900*20','PANCHJYOT 900*20','1518','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(406,'228',NULL,NULL,'GN47',NULL,'','RAJDHANI 15KG TIN','RAJDHANI 15KG TIN','150790','15','3',NULL,'5','GROUNDNUT OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(407,'228',NULL,NULL,'SF207',NULL,'','SUN TASTY 850*15','SUN TASTY 850*15','15079010','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(408,'228',NULL,NULL,'SF208',NULL,'','EVERYGOLD SF 750G *15','EVERYGOLD SF 750G *15','15079010','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(409,'228',NULL,NULL,'MO115',NULL,'','ENGINE MUS 100*200 BT','ENGINE MUS 100*200 BT','15149120','0.1','3',NULL,'9','MUSTERD OIL','7','10','200',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(410,'228',NULL,NULL,'T49',NULL,'','750ML LAMP OIL*15','750ML LAMP OIL*15','','0.75','3',NULL,'12','SESAME OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(411,'228',NULL,NULL,'SF209',NULL,'','870 GM FORTUNE SF 1*16','870 GM FORTUNE SF 1*16','15121910','0.87','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(412,'228',NULL,NULL,'SF210',NULL,'','SUN TASTY 14 LIT TIN','SUN TASTY 14 LIT TIN','15079010','14','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(413,'228',NULL,NULL,'GN48',NULL,'','DIVAM FILTERED GN 1*16','DIVAM FILTERED GN 1*16','12022010','1','3',NULL,'5','GROUNDNUT OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(414,'228',NULL,NULL,'GN49',NULL,'','DIVAM FILTERED 5*4','DIVAM FILTERED 5*4','12022010','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(415,'228',NULL,NULL,'PO22',NULL,'','PRIYA PALM 1*10','PRIYA PALM 1*10','15119020','1','3',NULL,'1','PALMOLEIN OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(416,'228',NULL,NULL,'SF211',NULL,'','GEMLITE 750GM*15','GEMLITE 750GM*15','15121910','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(417,'228',NULL,NULL,'T50',NULL,'','PANCHJOT 450ML*45','PANCHJOT 450ML*45','1518','0.45','3',NULL,'12','SESAME OIL','7','10','45',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','45','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(418,'228',NULL,NULL,'VP64',NULL,'','Ruchi 100ml *160','Ruchi 100ml *160','15162091','0.1','3',NULL,'8','VANASPATI OIL','7','10','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(419,'228',NULL,NULL,'GN51',NULL,'','SUNNY GN 1*12','SUNNY GN 1*12','15089010','1','3',NULL,'5','GROUNDNUT OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(420,'228',NULL,NULL,'GN52',NULL,'','SUNNY GN 5*4','SUNNY GN 5*4','15089010','5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(421,'228',NULL,NULL,'SF212',NULL,'','SUNELITE 900ML','SUNELITE 900ML','15121910','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(422,'228',NULL,NULL,'T51',NULL,'','DEEPMALA 800ML*20','DEEPMALA 800ML*20','15180040','0.8','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(423,'228',NULL,NULL,'T52',NULL,'','DEEPMALA 450*30','DEEPMALA 450*30','27101971','0.45','3',NULL,'12','SESAME OIL','7','10','30',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(424,'228',NULL,NULL,'T53',NULL,'','DEEP GOLDEN 200*80','DEEP GOLDEN 200*80','15180040','0.2','3',NULL,'12','SESAME OIL','7','10','80',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(425,'228',NULL,NULL,'GH87',NULL,'','KANHAIYYA BUFALO 1*15 JAR','KANHAIYYA BUFALO 1*15 JAR','04059020','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(426,'228',NULL,NULL,'GH88',NULL,'','KANHAIYYA BUFALO 200*75','KANHAIYYA BUFALO 200*75','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','75',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','75','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(427,'228',NULL,NULL,'VP65',NULL,'','PRIYA VP 100ML*120','PRIYA VP 100ML*120','15162091','0.1','3',NULL,'8','VANASPATI OIL','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(428,'228',NULL,NULL,'VP66',NULL,'','PRIYA VP 50ML*240','PRIYA VP 50ML*240','15162091','0.05','3',NULL,'8','VANASPATI OIL','7','10','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','VANASPATI OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(429,'228',NULL,NULL,'T54',NULL,'','PANCHJOYAT P.100*200','PANCHJOYAT P.100*200','151620','0.1','3',NULL,'12','SESAME OIL','7','10','200',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(430,'228',NULL,NULL,'RB33',NULL,'','REF R.B.OIL.RADH.15KG','REF R.B.OIL.RADH.15KG','15159040','15','3',NULL,'10','RICEBRAN OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','RICEBRAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(431,'228',NULL,NULL,'SF213',NULL,'','FORSUN SF 1*15','FORSUN SF 1*15','15121910','1','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(432,'228',NULL,NULL,'T55',NULL,'','PANCHJYOT 200ML*100','PANCHJYOT 200ML*100','1518','0.2','3',NULL,'12','SESAME OIL','7','10','100',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(433,'228',NULL,NULL,'GH92',NULL,'','V.POOJA GHEE 500*20','V.POOJA GHEE 500*20','151590','0.5','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(434,'228',NULL,NULL,'T56',NULL,'','TILGOLD L. OIL 450ML*40','TILGOLD L. OIL 450ML*40','15180040','0.45','3',NULL,'12','SESAME OIL','7','10','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(435,'228',NULL,NULL,'SF214',NULL,'','GEMLITE SF BT 1*18','GEMLITE SF BT 1*18','15119020','1','3',NULL,'2','SUNFLOWER OIL','7','10','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(436,'228',NULL,NULL,'GN53',NULL,'','SUNNY GN OFFER 5*4','SUNNY GN OFFER 5*4','15089010','4.5','3',NULL,'5','GROUNDNUT OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(437,'228',NULL,NULL,'T57',NULL,'','TIL ENGINE  200*60','TIL ENGINE  200*60','15155091','0.2','3',NULL,'12','SESAME OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(438,'228',NULL,NULL,'MO116',NULL,'','KISHAN 750*15','KISHAN 750*15','151590','0.75','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(439,'228',NULL,NULL,'SC09',NULL,'','SAFOLA GOLD 4LTR*4','SAFOLA GOLD 4LTR*4','15179090','4','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(440,'228',NULL,NULL,'SF215',NULL,'','FORSUN 15LIT TIN','FORSUN 15LIT TIN','15121910','13.65','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(441,'228',NULL,NULL,'SF216',NULL,'','FORSUN 5*4','FORSUN 5*4','15121910','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(442,'228',NULL,NULL,'GH96',NULL,'','KOROVA COW 100*120 JAR','KOROVA COW 100*120 JAR','04059020','0.1','3',NULL,'3','GHEE OIL','7','10','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(443,'228',NULL,NULL,'GH97',NULL,'','KOROVA COW 200*60 JAR','KOROVA COW 200*60 JAR','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(444,'228',NULL,NULL,'GH98',NULL,'','KOROVA COW 500*24 JAR','KOROVA COW 500*24 JAR','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(445,'228',NULL,NULL,'GH99',NULL,'','KOROVA COW 1*12 JAR','KOROVA COW 1*12 JAR','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(446,'228',NULL,NULL,'GH100',NULL,'','KOROVA COW 5*4 TIN','KOROVA COW 5*4 TIN','04059020','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(447,'228',NULL,NULL,'GH101',NULL,'','KOROVA REG 100*120 JAR','KOROVA REG 100*120 JAR','04059020','0.1','3',NULL,'3','GHEE OIL','7','10','120',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(448,'228',NULL,NULL,'GH102',NULL,'','KOROVA REG 200*60 JAR','KOROVA REG 200*60 JAR','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(449,'228',NULL,NULL,'GH103',NULL,'','KOROVA REG 500*24 jar','KOROVA REG 500*24 jar','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(450,'228',NULL,NULL,'GH104',NULL,'','KOROVA REG 1*12 JAR','KOROVA REG 1*12 JAR','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(451,'228',NULL,NULL,'GH105',NULL,'','KOROVA COW 35 ML*240','KOROVA COW 35 ML*240','04059020','0.35','3',NULL,'3','GHEE OIL','7','10','240',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(452,'228',NULL,NULL,'GH106',NULL,'','KOROVA COW 500*30 PP','KOROVA COW 500*30 PP','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(453,'228',NULL,NULL,'GH107',NULL,'','KOROVA COW 1*15PP','KOROVA COW 1*15PP','04059020','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(454,'228',NULL,NULL,'GH108',NULL,'','KOROVA REG 500*30 PP','KOROVA REG 500*30 PP','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(455,'228',NULL,NULL,'GH109',NULL,'','KOROVA REG 1*15 PP','KOROVA REG 1*15 PP','04059020','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(456,'228',NULL,NULL,'T58',NULL,'','TILGOLD 200*100','TILGOLD 200*100','15159040','0.2','3',NULL,'3','GHEE OIL','7','10','100',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(457,'228',NULL,NULL,'MO117',NULL,'','SINGLE HATHI 100*120','SINGLE HATHI 100*120','151491','0.1','3',NULL,'9','MUSTERD OIL','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(458,'228',NULL,NULL,'GN54',NULL,'','GULAB GN FILTERED 15 KG TIN','GULAB GN FILTERED 15 KG TIN','15089091','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(459,'228',NULL,NULL,'SF217',NULL,'','OLAMPIYA 15LTR TIN','OLAMPIYA 15LTR TIN','150790','13.5','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(460,'228',NULL,NULL,'T59',NULL,'','TILGOLD 100ML*100','TILGOLD 100ML*100','15180040','0.1','3',NULL,'3','GHEE OIL','7','10','100',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(461,'228',NULL,NULL,'T60',NULL,'','SUPREME 900 ML*20','SUPREME 900 ML*20','151800','1','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(462,'228',NULL,NULL,'T61',NULL,'','SUPREME 450ML*40','SUPREME 450ML*40','15180040','0.45','3',NULL,'3','GHEE OIL','7','10','40',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(463,'228',NULL,NULL,'T62',NULL,'','SUPREME 200ML*100','SUPREME 200ML*100','15180040','0.2','3',NULL,'3','GHEE OIL','7','10','100',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(464,'228',NULL,NULL,'T63',NULL,'','SUPREME 100ML*200','SUPREME 100ML*200','15180040','0.1','3',NULL,'3','GHEE OIL','7','10','200',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(465,'228',NULL,NULL,'SF218',NULL,'','SUN ROYAL 750*15','SUN ROYAL 750*15','15119020','0.75','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(466,'228',NULL,NULL,'SF219',NULL,'','SUNROYAL 15LTR TIN','SUNROYAL 15LTR TIN','15119020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(467,'228',NULL,NULL,'MO118',NULL,'','SHREE K.MURARI850*15','SHREE K.MURARI850*15','15159040','0.85','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(468,'228',NULL,NULL,'MO119',NULL,'','SUPER KISHAN 750*15','SUPER KISHAN 750*15','151590','0.75','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(469,'228',NULL,NULL,'SF220',NULL,'','RIVO SF 15 LTR TIN','RIVO SF 15 LTR TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(470,'228',NULL,NULL,'PO23',NULL,'','PALM KP 890GM*15','PALM KP 890GM*15','15119020','0.89','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(471,'228',NULL,NULL,'SF221',NULL,'','RIVO SF 15KG TIN','RIVO SF 15KG TIN','15121910','15','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(472,'228',NULL,NULL,'SF222',NULL,'','SUNVITA SF 15LTR TIN','SUNVITA SF 15LTR TIN','15121910','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(473,'228',NULL,NULL,'PO24',NULL,'','KD PALM 870GM *15','KD PALM 870GM *15','15119020','0.87','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(474,'228',NULL,NULL,'T64',NULL,'','GANESHA TIL 900 ML*20','GANESHA TIL 900 ML*20','15180040','0.9','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(475,'228',NULL,NULL,'T65',NULL,'','TILDEEP 750GM *20','TILDEEP 750GM *20','15159040','0.75','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(476,'228',NULL,NULL,'MO120',NULL,'','PRIYA MO  KG 5*4','PRIYA MO  KG 5*4','15149120','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(477,'228',NULL,NULL,'TL66',NULL,'','ENGINE TIL 1LTR 1*12 BT','ENGINE TIL 1LTR 1*12 BT','15155091','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(478,'228',NULL,NULL,'TL67',NULL,'','ENGINE TIL 500*24 BT','ENGINE TIL 500*24 BT','15155091','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(479,'228',NULL,NULL,'GH110',NULL,'','SUPREME POOJA GHEE 1*12','SUPREME POOJA GHEE 1*12','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(480,'228',NULL,NULL,'GH111',NULL,'','SUPREME POOJA GHEE 500*24','SUPREME POOJA GHEE 500*24','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(481,'228',NULL,NULL,'TL68',NULL,'','SUPREME TIL 800ML*20','SUPREME TIL 800ML*20','15180040','0.8','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(482,'228',NULL,NULL,'TL69',NULL,'','TILDEEP 900ML*20','TILDEEP 900ML*20','15159040','0.9','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(483,'228',NULL,NULL,'VP59',NULL,'','PRIYA VP 15KG TIN','PRIYA VP 15KG TIN','15162091','15','3',NULL,'3','GHEE OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(484,'228',NULL,NULL,'SF223',NULL,'','SUNRICH SF 750*10','SUNRICH SF 750*10','15121910','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(485,'228',NULL,NULL,'PO11',NULL,'','PRIYA  PALM 15KG','PRIYA  PALM 15KG','15119020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(486,'228',NULL,NULL,'PO12',NULL,'','PRIYA PALM 15 LTR','PRIYA PALM 15 LTR','15119020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(487,'228',NULL,NULL,'GH112',NULL,'','NANDAN GHEE 200*60','NANDAN GHEE 200*60','04059020','0.2','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(488,'228',NULL,NULL,'GH113',NULL,'','NANDAN 500ML*24 JAR','NANDAN 500ML*24 JAR','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(489,'228',NULL,NULL,'GH114',NULL,'','NANDAN GHE 1*12 JAR','NANDAN GHE 1*12 JAR','04059020','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(490,'228',NULL,NULL,'GH115',NULL,'','NANDAN 500*30 RT','NANDAN 500*30 RT','04059020','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(491,'228',NULL,NULL,'GH116',NULL,'','NANDAN GHE 1LTR*15 RT','NANDAN GHE 1LTR*15 RT','04059020','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(492,'228',NULL,NULL,'GH117',NULL,'','NANDAN GHE 1*15 PP','NANDAN GHE 1*15 PP','04059020','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(493,'228',NULL,NULL,'GN55',NULL,'','RAJKAMAL GN 15KG TIN','RAJKAMAL GN 15KG TIN','15119020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(494,'228',NULL,NULL,'TL70',NULL,'','TILGOLD PUJA 800*20','TILGOLD PUJA 800*20','15180040','0.9','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(495,'228',NULL,NULL,'GH119',NULL,'','ASHT  P GHEE 200*72','ASHT  P GHEE 200*72','151190','0.2','3',NULL,'3','GHEE OIL','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(496,'228',NULL,NULL,'PO13',NULL,'','PRIYA PALM 870*10','PRIYA PALM 870*10','15119020','0.87','3',NULL,'1','PALMOLEIN OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(497,'228',NULL,NULL,'T06',NULL,'','TILDEEP 450 *20','TILDEEP 450 *20','15121910','0.45','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(498,'228',NULL,NULL,'GN56',NULL,'','SUNNY GN BT 1*12','SUNNY GN BT 1*12','15089091','1','3',NULL,'5','GROUNDNUT OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GROUNDNUT OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(499,'228',NULL,NULL,'PO25',NULL,'','PALM 850*15','PALM 850*15','15119020','0.85','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(500,'228',NULL,NULL,'VP67',NULL,'','DALDA VP 200*90','DALDA VP 200*90','15162091','0.2','3',NULL,'3','GHEE OIL','7','10','90',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(501,'228',NULL,NULL,'T08',NULL,'','TILDEEP 100*100','TILDEEP 100*100','15159040','0.1','3',NULL,'3','GHEE OIL','7','10','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(502,'228',NULL,NULL,'MO122',NULL,'','KISHAN 750*15','KISHAN 750*15','151590','0.75','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(503,'228',NULL,NULL,'SF224',NULL,'','SAFFAL 750 SF*15','SAFFAL 750 SF*15','15121910','0.75','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(504,'228',NULL,NULL,'SF225',NULL,'','GEMLITE SF 870*12','GEMLITE SF 870*12','15079010','0.87','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(505,'228',NULL,NULL,'SF226',NULL,'','SUN TASTY 750*15','SUN TASTY 750*15','15079010','0.75','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(506,'228',NULL,NULL,'T09',NULL,'','NANDADIP 900 *20','NANDADIP 900 *20','27090000','0.9','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(507,'228',NULL,NULL,'PO14',NULL,'','PRIYA PALM 850*10','PRIYA PALM 850*10','15119020','0.85','3',NULL,'3','GHEE OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(508,'228',NULL,NULL,'SF227',NULL,'','SUNWHITE SF15 LTR TIN','SUNWHITE SF15 LTR TIN','15121910','15','3',NULL,'3','GHEE OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(509,'228',NULL,NULL,'MO123',NULL,'','MAHABHOG MUS 1*12 PP','MAHABHOG MUS 1*12 PP','15121910','1','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(510,'228',NULL,NULL,'SF228',NULL,'','OLAMPIYA 13.500 L TIN','OLAMPIYA 13.500 L TIN','150790','12.2','3',NULL,'6','SOYABEAN OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(511,'228',NULL,NULL,'GN57',NULL,'','SAASMA OIL 15KG TIN','SAASMA OIL 15KG TIN','15119020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(512,'228',NULL,NULL,'MO124',NULL,'','SARTHI 900ML*15','SARTHI 900ML*15','15159040','0.8','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(513,'228',NULL,NULL,'MO125',NULL,'','SUPREME RASOI M 500*40','SUPREME RASOI M 500*40','15159040','0.5','3',NULL,'9','MUSTERD OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(514,'228',NULL,NULL,'MO126',NULL,'','K.G.RAJBHOG 900*20','K.G.RAJBHOG 900*20','15149120','0.9','3',NULL,'9','MUSTERD OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(515,'228',NULL,NULL,'SF229',NULL,'','GEMINI SF 4.350 OFFER','GEMINI SF 4.350 OFFER','15121910','4.35','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(516,'228',NULL,NULL,'SF230',NULL,'','NATURE SF 15LTR JAR','NATURE SF 15LTR JAR','15079010','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(517,'228',NULL,NULL,'SF231',NULL,'','NATURE SF 725*15','NATURE SF 725*15','15079010','0.725','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(518,'228',NULL,NULL,'MO127',NULL,'','MORYA REF 15 KG TIN','MORYA REF 15 KG TIN','15159040','15','3',NULL,'3','GHEE OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(519,'228',NULL,NULL,'SF232',NULL,'','840*12 gemini sf','840*12 gemini sf','15121910','0.84','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(520,'228',NULL,NULL,'MO128',NULL,'','NATURE MO 5*4','NATURE MO 5*4','15159040','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(521,'228',NULL,NULL,'MO129',NULL,'','SUDH BHOG MO 5*4','SUDH BHOG MO 5*4','15159040','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(522,'228',NULL,NULL,'MO130',NULL,'','SAASMAA MO 5*4','SAASMAA MO 5*4','15159040','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(523,'228',NULL,NULL,'GH120',NULL,'','ASHT GHEE 450*30','ASHT GHEE 450*30','151190','0.45','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(524,'228',NULL,NULL,'T011',NULL,'','NATURDEEP TIL 900*20','NATURDEEP TIL 900*20','27090000','0.9','3',NULL,'3','GHEE OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(525,'228',NULL,NULL,'T012',NULL,'','NATUREDEEP TIL 450*40','NATUREDEEP TIL 450*40','27090000','0.45','3',NULL,'3','GHEE OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(526,'228',NULL,NULL,'MO131',NULL,'','SAASMAA MO 1*12 BT','SAASMAA MO 1*12 BT','15159040','1','3',NULL,'3','GHEE OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(527,'228',NULL,NULL,'MO132',NULL,'','PATANJALI MUST 850*12','PATANJALI MUST 850*12','15149920','0.85','3',NULL,'9','MUSTERD OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(528,'228',NULL,NULL,'SF233',NULL,'','SUNRICH 1*10 (OFFER)','SUNRICH 1*10 (OFFER)','15121910','1','3',NULL,'3','GHEE OIL','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(529,'228',NULL,NULL,'MO133',NULL,'','SHREE K. MURARI 1*15','SHREE K. MURARI 1*15','15159040','1','3',NULL,'9','MUSTERD OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(530,'228',NULL,NULL,'MO144',NULL,'','MAHAYOG 15 KG TIN','MAHAYOG 15 KG TIN','15159040','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(531,'228',NULL,NULL,'MO145',NULL,'','MAHAYOG K.G. 1*15 BT','MAHAYOG K.G. 1*15 BT','15159040','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(532,'228',NULL,NULL,'MO146',NULL,'','SARTHI MO BT 1*15','SARTHI MO BT 1*15','15159040','1','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(533,'228',NULL,NULL,'MO147',NULL,'','SARTHI MO BT 500*30','SARTHI MO BT 500*30','15159040','0.5','3',NULL,'3','GHEE OIL','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(534,'228',NULL,NULL,'SF234',NULL,'','OLAMPIYA 900ML*15','OLAMPIYA 900ML*15','15079010','0.85','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(535,'228',NULL,NULL,'PO16',NULL,'','RAJBHOG PALM 15KG TIN','RAJBHOG PALM 15KG TIN','15119020','15','3',NULL,'3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(536,'228',NULL,NULL,'MO148',NULL,'','MAHAYOG MO (5*4)','MAHAYOG MO (5*4)','15159040','5','3',NULL,'3','GHEE OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(537,'228',NULL,NULL,'SF235',NULL,'','SUN TASTY 15 LTR TIN','SUN TASTY 15 LTR TIN','15079010','15','3',NULL,'3','GHEE OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(538,'228',NULL,NULL,'SF236',NULL,'','OLAMPIYA 800ML*15','OLAMPIYA 800ML*15','151219','0.8','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(539,'228',NULL,NULL,'TO13',NULL,'','NATUREDEEP TIL 900ML*21','NATUREDEEP TIL 900ML*21','27090000','0.9','3',NULL,'3','GHEE OIL','7','10','21',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','21','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(540,'228',NULL,NULL,'MO149',NULL,'','MAHAYOG 500ML*30','MAHAYOG 500ML*30','15159040','0.5','3',NULL,'9','MUSTERD OIL','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(541,'228',NULL,NULL,'MO150',NULL,'','SARTHI 5LIT *4','SARTHI 5LIT *4','15159040','4.5','3',NULL,'9','MUSTERD OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(542,'228',NULL,NULL,'MO151',NULL,'','SARTHI 15KG TIN','SARTHI 15KG TIN','15159040','15','3',NULL,'9','MUSTERD OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MUSTERD OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(543,'228',NULL,NULL,'TO14',NULL,'','NATUREDEEP L.OIL200*100','NATUREDEEP L.OIL200*100','27090000','0.2','3',NULL,'12','SESAME OIL','7','10','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(544,'228',NULL,NULL,'PO26',NULL,'','KP RBD PALM 800G*15','KP RBD PALM 800G*15','15119020','0.8','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(545,'228',NULL,NULL,'PO27',NULL,'','ALAG PALM 900*15','ALAG PALM 900*15','15119020','0.9','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(546,'228',NULL,NULL,'PO28',NULL,'','RUDRA GOLD PALM 850 GM','RUDRA GOLD PALM 850 GM','151190','0.85','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(547,'228',NULL,NULL,'PO29',NULL,'','RUDRA G. PALM 890 GM','RUDRA G. PALM 890 GM','151190','0.89','3',NULL,'1','PALMOLEIN OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PALMOLEIN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(548,'228',NULL,NULL,'SB20',NULL,'','SUNNY SOYA PP PROMO PACK','SUNNY SOYA PP PROMO PACK','15079010','1','3',NULL,'6','SOYABEAN OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SOYABEAN OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(549,'228',NULL,NULL,'SF237',NULL,'','SUNDAY SFO 860 GMS','SUNDAY SFO 860 GMS','15121910','0.86','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(550,'228',NULL,NULL,'SF238',NULL,'','SUN TASTY 900 GM*15','SUN TASTY 900 GM*15','15079010','0.9','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(551,'228',NULL,NULL,'SF239',NULL,'','SUN  TASTY 850GM*15','SUN  TASTY 850GM*15','15079010','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(552,'228',NULL,NULL,'SF240',NULL,'','870 GM GEMINI SF*12','870 GM GEMINI SF*12','15121910','0.87','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(553,'228',NULL,NULL,'SF241',NULL,'','SUN TASTY 725 GM *15','SUN TASTY 725 GM *15','15079010','0.725','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(554,'228',NULL,NULL,'SF242',NULL,'','GEMINI SF 4.35 LTR*4','GEMINI SF 4.35 LTR*4','15121910','4.35','3',NULL,'2','SUNFLOWER OIL','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(555,'228',NULL,NULL,'SF243',NULL,'','RSF RAJBHOG 15LT TIN','RSF RAJBHOG 15LT TIN','15079010','13.55','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(556,'228',NULL,NULL,'SF244',NULL,'','RSF RAJBHOG 13.5KG TIN','RSF RAJBHOG 13.5KG TIN','15079010','13','3',NULL,'2','SUNFLOWER OIL','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(557,'228',NULL,NULL,'SF245',NULL,'','RSF FORSUN 725*15','RSF FORSUN 725*15','15079010','0.725','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(558,'228',NULL,NULL,'SF246',NULL,'','RSF RAJBHOG 850*12','RSF RAJBHOG 850*12','15079010','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(559,'228',NULL,NULL,'SF247',NULL,'','PRIYA SF 850*16','PRIYA SF 850*16','15121910','0.85','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(560,'228',NULL,NULL,'SF248',NULL,'','SUNNY SF 860*16','SUNNY SF 860*16','15121910','0.86','3',NULL,'2','SUNFLOWER OIL','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(561,'228',NULL,NULL,'SF249',NULL,'','GEMLITE SF 720*12','GEMLITE SF 720*12','15079010','0.72','3',NULL,'2','SUNFLOWER OIL','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(562,'228',NULL,NULL,'SF250',NULL,'','SUN TASTY 650G*15','SUN TASTY 650G*15','15079010','0.65','3',NULL,'2','SUNFLOWER OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','SUNFLOWER OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(563,'228',NULL,NULL,'T66',NULL,'','SUPREME S.P.OIL 900ML*20','SUPREME S.P.OIL 900ML*20','15180040','0.9','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(564,'228',NULL,NULL,'T67',NULL,'','SUPREME S.P.OIL800ML*20','SUPREME S.P.OIL800ML*20','15180040','0.8','3',NULL,'12','SESAME OIL','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(565,'228',NULL,NULL,'T68',NULL,'','SUPREME S.P.450ML*40','SUPREME S.P.450ML*40','15180040','0.45','3',NULL,'12','SESAME OIL','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(566,'228',NULL,NULL,'T69',NULL,'','SUPREME S.P.OIL200ML*100','SUPREME S.P.OIL200ML*100','15180040','0.2','3',NULL,'12','SESAME OIL','7','10','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(567,'228',NULL,NULL,'T70',NULL,'','SUPREM S.P.OIL 100ML*200','SUPREM S.P.OIL 100ML*200','15180040','0.1','3',NULL,'12','SESAME OIL','7','10','200',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','SESAME OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(568,'228',NULL,NULL,'GH121',NULL,'','NANDAN GHEE 180ML*60','NANDAN GHEE 180ML*60','04059020','0.18','3',NULL,'3','GHEE OIL','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(569,'228',NULL,NULL,'GH122',NULL,'','NANDAN GHEE 450ML*24 JAR','NANDAN GHEE 450ML*24 JAR','04059020','0.45','3',NULL,'3','GHEE OIL','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(570,'228',NULL,NULL,'GH123',NULL,'','NANDAN GHEE 1LIT P*15','NANDAN GHEE 1LIT P*15','04059020','0.91','3',NULL,'3','GHEE OIL','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','GHEE OIL',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(571,'228',NULL,NULL,'GH124','','','NANDAN GHEE 900ML*12 JAR','ALAG PALM 15KG TIN','15119020','15','3','0','3','GHEE OIL','7','7','1',NULL,NULL,'2','2','0','',NULL,'','','',NULL,NULL,NULL,'7','0','0','0','12','0','0','0','',0.00,0.00,0.00,0.00,0,NULL,NULL,'','Goods','NO',NULL,'344','344',NULL,0,'2026-04-14 10:32:13','2026-04-14 10:32:13');
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-04-14 09:57:47','2026-04-14 09:57:47');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'228',NULL,NULL,'PALMOLEIN OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(2,'228',NULL,NULL,'SUNFLOWER OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(3,'228',NULL,NULL,'GHEE OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(4,'228',NULL,NULL,'SAFFOLA OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(5,'228',NULL,NULL,'GROUNDNUT OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(6,'228',NULL,NULL,'SOYABEAN OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(7,'228',NULL,NULL,'COTTON OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(8,'228',NULL,NULL,'VANASPATI OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(9,'228',NULL,NULL,'MUSTERD OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(10,'228',NULL,NULL,'RICEBRAN OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(11,'228',NULL,NULL,'COCONUT OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(12,'228',NULL,NULL,'SESAME OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(13,'228',NULL,NULL,'Test','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28'),(14,'228',NULL,NULL,'OLIVE OIL','1',NULL,NULL,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:13:28','2026-04-14 10:13:28');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT 0.00,
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `MINIMUM_STOCK_LEVEL` int(11) NOT NULL DEFAULT 0,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=575 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'228',NULL,NULL,'1','153396881251532','2000-01-01','','0','0','0','0','0','56.19','0','895.73','0','-839.54','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(2,'228',NULL,NULL,'2','1533968812888121','2000-01-01','','0','0','0','0','0','423.81','0','771.43','0','-347.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(3,'228',NULL,NULL,'3','1533968812933985','2000-01-01','','0','0','0','0','0','78.09','0','849.72','0','-771.63','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(4,'228',NULL,NULL,'4','1533968813874686','2000-01-01','','0','0','0','0','0','1342.85','0','2100','0','-757.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(5,'228',NULL,NULL,'5','153396881489462','2000-01-01','','0','0','0','0','0','104.76','0','1190.5','0','-1085.74','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(6,'228',NULL,NULL,'6','1533968815183371','2000-01-01','','0','0','0','0','0','1295.23','0','1979.05','0','-683.82','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(7,'228',NULL,NULL,'7','1533968815474384','2000-01-01','','0','0','0','0','0','723.81','0','2898.86','0','-2175.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(8,'228',NULL,NULL,'8','1533968815701131','2000-01-01','','0','0','0','0','0','104.76','0','104.304','0','0.46','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(9,'228',NULL,NULL,'8','1533968815702369','2000-01-01','','0','0','0','0','0','118.1','0','2448.95','0','-2330.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(10,'228',NULL,NULL,'9','1533968816985206','2000-01-01','','0','0','0','0','0','2028.57','0','2038.1','0','-9.53','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(11,'228',NULL,NULL,'10','1533968817174357','2000-01-01','','0','0','0','0','0','377.14','0','1281.4','0','-904.26','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(12,'228',NULL,NULL,'11','153396881724033','2000-01-01','','0','0','0','0','0','72.38','0','2057.14','0','-1984.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(13,'228',NULL,NULL,'12','1533968817308992','2000-01-01','','0','0','0','0','0','380.95','0','2007.23','0','-1626.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(14,'228',NULL,NULL,'13','1533968817477781','2000-01-01','','0','0','0','0','0','1114.28','0','2066.67','0','-952.39','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(15,'228',NULL,NULL,'14','1533968817980229','2000-01-01','','0','0','0','-3','0','1955.24','2380.9524','1955.24','0','0.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(16,'228',NULL,NULL,'15','1533968818190670','2000-01-01','','0','0','0','0','0','1950','0','1766.67','0','183.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(17,'228',NULL,NULL,'16','153396881838347','2000-01-01','','0','0','0','0','0','452.38','0','2761.92','0','-2309.54','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(18,'228',NULL,NULL,'17','1533968819684954','2000-01-01','','0','0','0','0','0','33.33','0','1438','0','-1404.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(19,'228',NULL,NULL,'18','1533968820272414','2000-01-01','','0','0','0','0','0','1381','0','1600','0','-219.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(20,'228',NULL,NULL,'19','1533968822918250','2000-01-01','','0','0','0','0','0','0','0','1857.15','0','-1857.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(21,'228',NULL,NULL,'20','1533968823234765','2000-01-01','','0','0','0','0','0','1310','0','2114.29','0','-804.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(22,'228',NULL,NULL,'21','1533968823803591','2000-01-01','','0','0','0','0','0','1400','0','1933.33','0','-533.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(23,'228',NULL,NULL,'22','1533968824188785','2000-01-01','','0','0','0','0','0','0','0','1851.2','0','-1851.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(24,'228',NULL,NULL,'23','1533968824265261','2000-01-01','','0','0','0','0','0','0','0','1867.2','0','-1867.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(25,'228',NULL,NULL,'24','1533968827200186','2000-01-01','','0','0','0','0','0','0','0','1666.67','0','-1666.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(26,'228',NULL,NULL,'25','1533968828480887','2000-01-01','','0','0','0','0','0','80','0','1051.43','0','-971.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(27,'228',NULL,NULL,'26','1533968828774933','2000-01-01','','0','0','0','0','0','95.24','0','1062.86','0','-967.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(28,'228',NULL,NULL,'27','1533968830268118','2000-01-01','','0','0','0','0','0','80','0','937.2','0','-857.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(29,'228',NULL,NULL,'28','1533968830431226','2000-01-01','','0','0','0','0','0','1257.14','0','1220','0','37.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(30,'228',NULL,NULL,'29','153396883051265','2000-01-01','','0','0','0','0','0','0','0','1995.24','0','-1995.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(31,'228',NULL,NULL,'30','1533968830589549','2000-01-01','','0','0','0','0','0','0','0','817.14','0','-817.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(32,'228',NULL,NULL,'31','1533968830801913','2000-01-01','','0','0','0','0','0','0','0','2441.92','0','-2441.92','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(33,'228',NULL,NULL,'32','1533968831531345','2000-01-01','','0','0','0','0','0','0','0','1942.86','0','-1942.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(34,'228',NULL,NULL,'33','1533968831601992','2000-01-01','','0','0','0','0','0','0','0','1660.65','0','-1660.65','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(35,'228',NULL,NULL,'34','1533968831785650','2000-01-01','','0','0','0','0','0','0','0','6957.14','0','-6957.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(36,'228',NULL,NULL,'35','1533968831883178','2000-01-01','','0','0','0','0','0','379.46','0','7171.43','0','-6791.97','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(37,'228',NULL,NULL,'36','1533968831975677','2000-01-01','','0','0','0','0','0','58.04','0','7085.71','0','-7027.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(38,'228',NULL,NULL,'37','1533968832046262','2000-01-01','','0','0','0','0','0','142.86','0','4685.71','0','-4542.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(39,'228',NULL,NULL,'38','1533968832117144','2000-01-01','','0','0','0','0','0','1542.86','0','1485.71','0','57.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(40,'228',NULL,NULL,'39','1533968832338985','2000-01-01','','0','0','0','0','0','1100','0','1942.86','0','-842.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(41,'228',NULL,NULL,'40','1533968833188592','2000-01-01','','0','0','0','0','0','0','0','1795.24','0','-1795.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(42,'228',NULL,NULL,'41','153396883347130','2000-01-01','','0','0','0','0','0','0','0','1952.38','0','-1952.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(43,'228',NULL,NULL,'42','15339688339993','2000-01-01','','0','0','0','0','0','0','0','1795.24','0','-1795.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(44,'228',NULL,NULL,'43','1533968834500656','2000-01-01','','0','0','0','0','0','355','0','2285.76','0','-1930.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(45,'228',NULL,NULL,'44','1533968834574921','2000-01-01','','0','0','0','0','0','180','0','5285.71','0','-5105.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(46,'228',NULL,NULL,'45','1533968834645253','2000-01-01','','0','0','0','0','0','0','0','5142.85','0','-5142.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(47,'228',NULL,NULL,'46','1533968834707312','2000-01-01','','0','0','0','0','0','42','0','2468.57','0','-2426.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(48,'228',NULL,NULL,'47','1533968834805525','2000-01-01','','0','0','0','0','0','1750','0','7785.71','0','-6035.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(49,'228',NULL,NULL,'48','1533968835069319','2000-01-01','','0','0','0','0','0','80','0','6190.48','0','-6110.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(50,'228',NULL,NULL,'49','1533968835473221','2000-01-01','','0','0','0','0','0','1100','0','2163','0','-1063.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(51,'228',NULL,NULL,'50','1533968835904822','2000-01-01','','0','0','0','0','0','0','0','37.562','0','-37.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(52,'228',NULL,NULL,'51','1533968835985685','2000-01-01','','0','0','0','0','0','86','0','948.57','0','-862.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(53,'228',NULL,NULL,'52','1533968836073438','2000-01-01','','0','0','0','0','0','442.86','0','1681.14','0','-1238.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(54,'228',NULL,NULL,'53','1533968836174394','2000-01-01','','0','0','0','0','0','0','0','1168','0','-1168.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(55,'228',NULL,NULL,'54','1533968836314851','2000-01-01','','0','0','0','0','0','88.57','0','995.43','0','-906.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(56,'228',NULL,NULL,'55','1533968836482478','2000-01-01','','0','0','0','0','0','185.71','0','4221.48','0','-4035.77','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(57,'228',NULL,NULL,'56','1533968837212707','2000-01-01','','0','0','0','0','0','52.38','0','1110.86','0','-1058.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(58,'228',NULL,NULL,'57','1533968837296808','2000-01-01','','0','0','0','0','0','97.14','0','1091.43','0','-994.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(59,'228',NULL,NULL,'58','1533968839973331','2000-01-01','','0','0','0','0','0','90','0','1702.86','0','-1612.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(60,'228',NULL,NULL,'59','1533968840047961','2000-01-01','','0','0','0','0','0','475','0','2914.28','0','-2439.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(61,'228',NULL,NULL,'60','1533968840282109','2000-01-01','','0','0','0','0','0','32','0','1085.8','0','-1053.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(62,'228',NULL,NULL,'61','1533968840532214','2000-01-01','','0','0','0','0','0','0','0','1500','0','-1500.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(63,'228',NULL,NULL,'62','1533968841081990','2000-01-01','','0','0','0','0','0','395','0','961.2','0','-566.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(64,'228',NULL,NULL,'63','1533968841678515','2000-01-01','','0','0','0','0','0','0','0','1527.62','0','-1527.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(65,'228',NULL,NULL,'64','1533968841774225','2000-01-01','','0','0','0','0','0','0','0','4287.74','0','-4287.74','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(66,'228',NULL,NULL,'65','1533968841876882','2000-01-01','','0','0','0','0','0','0','0','1636.8','0','-1636.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(67,'228',NULL,NULL,'66','153396884197564','2000-01-01','','0','0','0','0','0','1285.71','0','1895.24','0','-609.53','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(68,'228',NULL,NULL,'67','1533968842083892','2000-01-01','','0','0','0','0','0','1280','0','1957.14','0','-677.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(69,'228',NULL,NULL,'68','1533968842183321','2000-01-01','','0','0','0','0','0','1200','0','1930.476','0','-730.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(70,'228',NULL,NULL,'69','1533968842420515','2000-01-01','','0','0','0','0','0','1700','0','1257.14','0','442.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(71,'228',NULL,NULL,'70','1533968842493406','2000-01-01','','0','0','0','0','0','105','0','1267.43','0','-1162.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(72,'228',NULL,NULL,'71','1533968842574493','2000-01-01','','0','0','0','0','0','590','0','2587.44','0','-1997.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(73,'228',NULL,NULL,'72','1533968842676283','2000-01-01','','0','0','0','0','0','1150','0','1061.611','0','88.39','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(74,'228',NULL,NULL,'73','1533968842749737','2000-01-01','','0','0','0','0','0','0','0','1132.08','0','-1132.08','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(75,'228',NULL,NULL,'74','1533968842821323','2000-01-01','','0','0','0','0','0','0','0','2017.2','0','-2017.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(76,'228',NULL,NULL,'75','1533968843049867','2000-01-01','','0','0','0','0','0','0','0','1527.6','0','-1527.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(77,'228',NULL,NULL,'76','1533968843139861','2000-01-01','','0','0','0','0','0','0','0','1066.67','0','-1066.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(78,'228',NULL,NULL,'77','1533968843282800','2000-01-01','','0','0','0','0','0','0','0','1946.68','0','-1946.68','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(79,'228',NULL,NULL,'78','1533968843400479','2000-01-01','','0','0','0','0','10','9.5','0','8.371','0','1.13','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(80,'228',NULL,NULL,'79','1533968843501674','2000-01-01','','0','0','0','0','0','1100','0','1136.79','0','-36.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(81,'228',NULL,NULL,'80','1533968843575851','2000-01-01','','0','0','0','0','0','0','0','1895.24','0','-1895.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(82,'228',NULL,NULL,'81','1533968843664881','2000-01-01','','0','0','0','0','0','70','0','884.57','0','-814.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(83,'228',NULL,NULL,'82','1533968843749700','2000-01-01','','0','0','0','0','0','0','0','1057.82','0','-1057.82','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(84,'228',NULL,NULL,'83','153396884386445','2000-01-01','','0','0','0','0','0','0','0','2610.67','0','-2610.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(85,'228',NULL,NULL,'84','1533968843949573','2000-01-01','','0','0','0','0','0','370','0','1593.14','0','-1223.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(86,'228',NULL,NULL,'85','1533968844075571','2000-01-01','','0','0','0','0','0','1752.38','0','1676.2','0','76.18','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(87,'228',NULL,NULL,'86','1533968844192907','2000-01-01','','0','0','0','0','0','0','0','1407.677','0','-1407.68','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(88,'228',NULL,NULL,'87','1533968844407751','2000-01-01','','0','0','0','0','27','18','0','800','0','-782.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(89,'228',NULL,NULL,'88','1533968844483872','2000-01-01','','0','0','0','0','0','1200','0','1033.18','0','166.82','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(90,'228',NULL,NULL,'89','1533968844576759','2000-01-01','','0','0','0','0','0','0','0','1452.84','0','-1452.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(91,'228',NULL,NULL,'90','1533968844675653','2000-01-01','','0','0','0','0','0','0','0','1266.67','0','-1266.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(92,'228',NULL,NULL,'91','1533968844785985','2000-01-01','','0','0','0','0','0','1285.71','0','1228.57','0','57.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(93,'228',NULL,NULL,'92','15339688448744','2000-01-01','','0','0','0','0','0','1276.19','0','1219.05','0','57.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(94,'228',NULL,NULL,'93','1533968844975524','2000-01-01','','0','0','0','0','0','0','0','1327','0','-1327.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(95,'228',NULL,NULL,'94','1533968845075414','2000-01-01','','0','0','0','0','0','68.57','0','736','0','-667.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(96,'228',NULL,NULL,'95','1533968845188497','2000-01-01','','0','0','0','0','0','36.19','0','793.14','0','-756.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(97,'228',NULL,NULL,'96','1533968845283620','2000-01-01','','0','0','0','0','0','0','0','1706.16','0','-1706.16','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(98,'228',NULL,NULL,'97','1533968845374503','2000-01-01','','0','0','0','0','0','0','0','1150','0','-1150.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(99,'228',NULL,NULL,'98','1533968845471439','2000-01-01','','0','0','0','0','0','1000','0','1843.81','0','-843.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(100,'228',NULL,NULL,'99','1533968845574218','2000-01-01','','0','0','0','0','0','0','0','1399.95','0','-1399.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(101,'228',NULL,NULL,'100','1533968845673441','2000-01-01','','0','0','0','0','0','0','0','2000','0','-2000.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(102,'228',NULL,NULL,'101','1533968845772893','2000-01-01','','0','0','0','0','0','0','0','1251.18','0','-1251.18','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(103,'228',NULL,NULL,'102','1533968845873561','2000-01-01','','0','0','0','0','0','1390','0','1220','0','170.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(104,'228',NULL,NULL,'103','1533968845974817','2000-01-01','','0','0','0','0','0','0','0','981.13','0','-981.13','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(105,'228',NULL,NULL,'104','1533968846070269','2000-01-01','','0','0','0','0','0','76','0','885.71','0','-809.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(106,'228',NULL,NULL,'105','1533968846190900','2000-01-01','','0','0','0','0','0','0','0','72.38','0','-72.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(107,'228',NULL,NULL,'106','1533968846282636','2000-01-01','','0','0','0','0','0','0','0','36.792','0','-36.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(108,'228',NULL,NULL,'107','1533968846373929','2000-01-01','','0','0','0','0','0','0','0','980.95','0','-980.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(109,'228',NULL,NULL,'108','153396884647310','2000-01-01','','0','0','0','0','0','0','0','1142.86','0','-1142.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(110,'228',NULL,NULL,'109','1533968846573817','2000-01-01','','0','0','0','0','0','0','0','1947.2','0','-1947.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(111,'228',NULL,NULL,'110','1533968846688434','2000-01-01','','0','0','0','0','0','0','0','2156.19','0','-2156.19','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(112,'228',NULL,NULL,'111','1533968846814953','2000-01-01','','0','0','0','0','0','83','0','936','0','-853.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(113,'228',NULL,NULL,'112','1533968846897328','2000-01-01','','0','0','0','0','0','438.1','0','1614.86','0','-1176.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(114,'228',NULL,NULL,'113','1533968846978813','2000-01-01','','0','0','0','0','0','0','0','1495.23','0','-1495.23','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(115,'228',NULL,NULL,'114','1533968847074798','2000-01-01','','0','0','0','0','0','0','0','1533.33','0','-1533.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(116,'228',NULL,NULL,'115','1533968847174569','2000-01-01','','0','0','0','0','0','0','0','1874.4','0','-1874.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(117,'228',NULL,NULL,'116','1533968847348740','2000-01-01','','0','0','0','0','0','0','0','1109.6','0','-1109.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(118,'228',NULL,NULL,'117','1533968847514805','2000-01-01','','0','0','0','0','0','81.9','0','1164.3','0','-1082.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(119,'228',NULL,NULL,'118','1533968847583341','2000-01-01','','0','0','0','0','0','0','0','1172.87','0','-1172.87','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(120,'228',NULL,NULL,'119','1533968847686943','2000-01-01','','0','0','0','0','0','0','0','3735.5','0','-3735.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(121,'228',NULL,NULL,'120','1533968847782719','2000-01-01','','0','0','0','0','0','0','0','3779.4','0','-3779.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(122,'228',NULL,NULL,'121','15339688478917','2000-01-01','','0','0','0','0','0','0','0','7841.6','0','-7841.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(123,'228',NULL,NULL,'122','1533968847999612','2000-01-01','','0','0','0','0','0','35.71','0','3107.14','0','-3071.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(124,'228',NULL,NULL,'123','1533968848093915','2000-01-01','','0','0','0','0','0','0','0','2076.19','0','-2076.19','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(125,'228',NULL,NULL,'124','1533968848176651','2000-01-01','','0','0','0','0','0','0','0','1885.68','0','-1885.68','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(126,'228',NULL,NULL,'125','1533968848271322','2000-01-01','','0','0','0','0','0','0','0','1700.48','0','-1700.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(127,'228',NULL,NULL,'126','1533968848369852','2000-01-01','','0','0','0','0','0','0','0','1569.6','0','-1569.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(128,'228',NULL,NULL,'127','1533968848516500','2000-01-01','','0','0','0','0','0','0','0','1461.9','0','-1461.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(129,'228',NULL,NULL,'128','1533968848614776','2000-01-01','','0','0','0','0','0','0','0','1061.32','0','-1061.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(130,'228',NULL,NULL,'129','1533968848697613','2000-01-01','','0','0','0','0','0','0','0','1372.57','0','-1372.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(131,'228',NULL,NULL,'130','1533968848790723','2000-01-01','','0','0','0','-2','0','0','2504.7619','2138.1','0','-2138.10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(132,'228',NULL,NULL,'131','1533968848874692','2000-01-01','','0','0','0','0','0','0','0','1095.23','0','-1095.23','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(133,'228',NULL,NULL,'132','153396884896971','2000-01-01','','0','0','0','0','0','0','0','4570.56','0','-4570.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(134,'228',NULL,NULL,'133','1533968849073697','2000-01-01','','0','0','0','0','0','0','0','4623.12','0','-4623.12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(135,'228',NULL,NULL,'134','1533968849172812','2000-01-01','','0','0','0','0','0','0','0','5053.8','0','-5053.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(136,'228',NULL,NULL,'135','1533968849269349','2000-01-01','','0','0','0','0','0','0','0','4200','0','-4200.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(137,'228',NULL,NULL,'136','1533968849335296','2000-01-01','','0','0','0','0','0','9.52','0','929.52','0','-920.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(138,'228',NULL,NULL,'137','1533968849418710','2000-01-01','','0','0','0','0','0','6','0','975.24','0','-969.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(139,'228',NULL,NULL,'138','1533968849500748','2000-01-01','','0','0','0','0','0','0','0','1017','0','-1017.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(140,'228',NULL,NULL,'139','1533968849602123','2000-01-01','','0','0','0','0','0','0','0','2628.57','0','-2628.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(141,'228',NULL,NULL,'140','1533968849692791','2000-01-01','','0','0','0','0','0','16.19','0','1143.2','0','-1127.01','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(142,'228',NULL,NULL,'141','1533968849897673','2000-01-01','','0','0','0','0','0','0','0','1190.48','0','-1190.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(143,'228',NULL,NULL,'142','1533968849985709','2000-01-01','','0','0','0','0','0','0','0','1539.04','0','-1539.04','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(144,'228',NULL,NULL,'143','1533968850072962','2000-01-01','','0','0','0','0','0','0','0','1451.43','0','-1451.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(145,'228',NULL,NULL,'144','1533968850171654','2000-01-01','','0','0','0','0','0','0','0','1725.71','0','-1725.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(146,'228',NULL,NULL,'145','1533968850283662','2000-01-01','','0','0','0','0','190','85.71','0','1580.95','0','-1495.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(147,'228',NULL,NULL,'146','1533968850376771','2000-01-01','','0','0','0','0','135','52.38','0','1695.24','0','-1642.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(148,'228',NULL,NULL,'147','1533968850468732','2000-01-01','','0','0','0','0','0','0','0','1191.43','0','-1191.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(149,'228',NULL,NULL,'148','1533968850583686','2000-01-01','','0','0','0','0','980','900','0','904.76','0','-4.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(150,'228',NULL,NULL,'149','15339688506801','2000-01-01','','0','0','0','0','0','1238.1','0','1057.14','0','180.96','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(151,'228',NULL,NULL,'150','1533968850779791','2000-01-01','','0','0','0','0','0','1476.19','0','1295.24','0','180.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(152,'228',NULL,NULL,'151','1533968850877213','2000-01-01','','0','0','0','0','0','0','0','1190.48','0','-1190.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(153,'228',NULL,NULL,'152','1533968850975472','2000-01-01','','0','0','0','0','0','74.29','0','1057.14','0','-982.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(154,'228',NULL,NULL,'153','1533968851068201','2000-01-01','','0','0','0','0','0','1200','0','1066.67','0','133.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(155,'228',NULL,NULL,'154','1533968851165627','2000-01-01','','0','0','0','0','0','609.52','0','1676.2','0','-1066.68','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(156,'228',NULL,NULL,'155','1533968851238891','2000-01-01','','0','0','0','0','0','0','0','2457.2','0','-2457.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(157,'228',NULL,NULL,'156','1533968851322588','2000-01-01','','0','0','0','0','0','0','0','957.15','0','-957.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(158,'228',NULL,NULL,'157','1533968851401928','2000-01-01','','0','0','0','0','0','438.1','0','1676.19','0','-1238.09','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(159,'228',NULL,NULL,'158','1533968851483127','2000-01-01','','0','0','0','0','0','105.71','0','1164.62','0','-1058.91','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(160,'228',NULL,NULL,'159','1533968851592157','2000-01-01','','0','0','0','0','0','580','0','2342.86','0','-1762.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(161,'228',NULL,NULL,'160','1533968851706253','2000-01-01','','0','0','0','0','0','0','0','0','0','0.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(162,'228',NULL,NULL,'161','1533968851786316','2000-01-01','','0','0','0','0','0','0','0','2209.52','0','-2209.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(163,'228',NULL,NULL,'162','1533968851908154','2000-01-01','','0','0','0','0','0','94.29','0','0','0','94.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:28',NULL),(164,'228',NULL,NULL,'163','1533968851989768','2000-01-01','','0','0','0','0','0','580','0','2104.3','0','-1524.30','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(165,'228',NULL,NULL,'164','153396885207750','2000-01-01','','0','0','0','0','0','0','0','1380.95','0','-1380.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(166,'228',NULL,NULL,'165','153396885218046','2000-01-01','','0','0','0','0','0','0','0','1247.62','0','-1247.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(167,'228',NULL,NULL,'166','1533968852281445','2000-01-01','','0','0','0','0','0','0','0','1352.38','0','-1352.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(168,'228',NULL,NULL,'167','1533968852379356','2000-01-01','2000-01-01','0','0','0','0','0','0','0','1440','0','-1440.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(169,'228',NULL,NULL,'168','1533968852480989','2000-01-01','','0','0','0','0','0','0','0','979.77','0','-979.77','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(170,'228',NULL,NULL,'169','15339688526155','2000-01-01','','0','0','0','0','0','0','0','1030','0','-1030.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(171,'228',NULL,NULL,'170','1533968852705911','2000-01-01','','0','0','0','0','0','0','0','885.71','0','-885.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(172,'228',NULL,NULL,'171','1534591479262','','','0','0','0','0','0','1523.81','0','1371.43','0','152.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(173,'228',NULL,NULL,'172','1534591730460','','','0','0','0','0','0','2952.38','0','2761.9','0','190.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(174,'228',NULL,NULL,'173','1534594812882','','','0','0','0','0','0','1123.81','0','2028.5','0','-904.69','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(175,'228',NULL,NULL,'174','1534595080240','','','0','0','0','0','0','1276.19','0','1858.1','0','-581.91','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(176,'228',NULL,NULL,'175','1534942271600','','','0','0','0','0','0','1285.71','0','1261.9','0','23.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(177,'228',NULL,NULL,'176','1535365407367','','','0','0','0','0','0','1285.71','0','1228.57','0','57.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(178,'228',NULL,NULL,'177','1535382188133','','','0','0','0','0','0','1180.95','0','1009.52','0','171.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(179,'228',NULL,NULL,'178','1535382381888','','','0','0','0','0','0','0','0','761.9','0','-761.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(180,'228',NULL,NULL,'179','1535442910323','','2000-01-01','0','0','0','0','0','33.33','0','600','0','-566.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(181,'228',NULL,NULL,'180','1535542154123','','','0','0','0','0','0','10.17','0','2440','0','-2429.83','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(182,'228',NULL,NULL,'181','1535542272768','','','0','0','0','0','0','21.19','0','2420','0','-2398.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(183,'228',NULL,NULL,'182','1535542352939','','','0','0','0','0','0','35.59','0','2375','0','-2339.41','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(184,'228',NULL,NULL,'183','1535542635840','','','0','0','0','0','0','88.98','0','1994','0','-1905.02','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(185,'228',NULL,NULL,'184','1535542689413','','','0','0','0','0','0','144.07','0','1890','0','-1745.93','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(186,'228',NULL,NULL,'185','180919155009','','','0','0','0','0','0','105','0','1809.52','0','-1704.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(187,'228',NULL,NULL,'186','180920142859','','','0','0','0','0','0','97.14','0','1671.45','0','-1574.31','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(188,'228',NULL,NULL,'187','180920143017','','','0','0','0','0','0','55.24','0','1714.29','0','-1659.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(189,'228',NULL,NULL,'188','180920143115','','','0','0','0','0','0','540','0','1800','0','-1260.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(190,'228',NULL,NULL,'189','180920143202','','','0','0','0','0','0','1428.57','0','1309.52','0','119.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(191,'228',NULL,NULL,'190','180926151854','','','0','0','0','0','0','80','0','937.2','0','-857.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(192,'228',NULL,NULL,'191','181012163748','','','0','0','0','0','0','1123.81','0','3523.81','0','-2400.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(193,'228',NULL,NULL,'192','181012164257','','','0','0','0','0','0','109.52','0','1085.71','0','-976.19','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(194,'228',NULL,NULL,'193','181012164415','','','0','0','0','0','0','57.14','0','1154.29','0','-1097.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(195,'228',NULL,NULL,'194','181015153653','','','0','0','0','0','0','400','0','1466.67','0','-1066.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(196,'228',NULL,NULL,'195','181022163754','','','0','0','0','0','0','28.57','0','1325.71','0','-1297.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(197,'228',NULL,NULL,'196','181103151724','','','0','0','0','0','0','75.24','0','1485.75','0','-1410.51','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(198,'228',NULL,NULL,'197','181128152105','','','0','0','0','0','0','1285.71','0','2076.1','0','-790.39','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(199,'228',NULL,NULL,'198','181129184207','','','0','0','0','0','0','37.5','0','2571.84','0','-2534.34','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(200,'228',NULL,NULL,'199','181207161302','','','0','0','0','0','0','1295.24','0','1270.67','0','24.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(201,'228',NULL,NULL,'200','181212191506','','','0','0','0','0','0','102.86','0','1186.44','0','-1083.58','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(202,'228',NULL,NULL,'201','181212191632','','','0','0','0','0','0','216.19','0','1661.68','0','-1445.49','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(203,'228',NULL,NULL,'202','181212191734','','','0','0','0','0','0','595.24','0','2303.84','0','-1708.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(204,'228',NULL,NULL,'203','181212191851','','','0','0','0','0','0','1419.05','0','1400.83','0','18.22','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(205,'228',NULL,NULL,'204','181219143627','','','0','0','0','0','0','0','0','1919.97','0','-1919.97','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(206,'228',NULL,NULL,'205','190102191335','','','0','0','0','0','0','375','0','6629.6','0','-6254.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(207,'228',NULL,NULL,'206','190102191541','','','0','0','0','0','0','187.5','0','6392.7','0','-6205.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(208,'228',NULL,NULL,'207','190102191657','','','0','0','0','0','0','412.53','0','6301.28','0','-5888.75','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(209,'228',NULL,NULL,'208','190102191835','','','0','0','0','0','0','182.14','0','5895.6','0','-5713.46','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(210,'228',NULL,NULL,'209','190102192008','','','0','0','0','0','0','93.75','0','5395.68','0','-5301.93','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(211,'228',NULL,NULL,'210','190102192153','','','0','0','0','0','0','53.57','0','6099.48','0','-6045.91','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(212,'228',NULL,NULL,'211','190105190617','','','0','0','0','0','0','95.24','0','1037.71','0','-942.47','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(213,'228',NULL,NULL,'212','190123143332','','','0','0','0','0','0','60','0','1028.57','0','-968.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(214,'228',NULL,NULL,'213','190129160008','','','0','0','0','0','0','2149.47','0','8208','0','-6058.53','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(215,'228',NULL,NULL,'214','190226184108','','','0','0','0','0','0','80.36','0','4285.8','0','-4205.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(216,'228',NULL,NULL,'215','190226184951','','','0','0','0','0','0','169.64','0','2438.08','0','-2268.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(217,'228',NULL,NULL,'216','190226185104','','','0','0','0','0','0','334.82','0','4017.84','0','-3683.02','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(218,'228',NULL,NULL,'217','190226185252','','','0','0','0','0','0','334.82','0','4017.84','0','-3683.02','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(219,'228',NULL,NULL,'218','190311165221','','','0','0','0','0','0','69.52','0','1517.33','0','-1447.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(220,'228',NULL,NULL,'219','190311165310','','','0','0','0','0','0','395.24','0','2876.19','0','-2480.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(221,'228',NULL,NULL,'220','190311165541','','','0','0','0','0','0','428.57','0','1485.71','0','-1057.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(222,'228',NULL,NULL,'221','190330143919','','','0','0','0','0','0','0','0','1752.38','0','-1752.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(223,'228',NULL,NULL,'222','190402162634','','','0','0','0','0','0','0','0','1500','0','-1500.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(224,'228',NULL,NULL,'223','190408154022','','','0','0','0','0','0','0','0','1038.1','0','-1038.10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(225,'228',NULL,NULL,'224','190510170411','','','0','0','0','0','0','0','0','1447.62','0','-1447.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(226,'228',NULL,NULL,'225','190510170503','','','0','0','0','0','0','0','0','1014.29','0','-1014.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(227,'228',NULL,NULL,'226','190510170603','','','0','0','0','0','0','0','0','1028.57','0','-1028.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(228,'228',NULL,NULL,'227','190520144330','','','0','0','0','0','0','10','0','0','0','10.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(229,'228',NULL,NULL,'228','190524173713','','','0','0','0','0','0','0','0','1019.05','0','-1019.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(230,'228',NULL,NULL,'229','190524173820','','','0','0','0','0','0','0','0','1014.28','0','-1014.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(231,'228',NULL,NULL,'230','190610142544','','2001-01-01','0','0','0','0','0','0','0','1147.62','0','-1147.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(232,'228',NULL,NULL,'231','190618160844','','','0','0','0','0','0','0','0','3080.4','0','-3080.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(233,'228',NULL,NULL,'232','190618161120','','','0','0','0','0','0','0','0','0','0','0.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(234,'228',NULL,NULL,'232','190618161029','','','0','0','0','0','0','0','0','6585.75','0','-6585.75','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(235,'228',NULL,NULL,'233','190618161231','','','0','0','0','0','0','0','0','6685.8','0','-6685.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(236,'228',NULL,NULL,'234','190618161346','','','0','0','0','0','0','0','0','5478.96','0','-5478.96','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(237,'228',NULL,NULL,'235','190618161504','','','0','0','0','0','0','0','0','5817.6','0','-5817.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(238,'228',NULL,NULL,'236','190618162044','','','0','0','0','0','0','0','0','3405.6','0','-3405.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(239,'228',NULL,NULL,'237','190620163242','','','0','0','0','0','0','0','0','1409.6','0','-1409.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(240,'228',NULL,NULL,'238','190621163006','','','0','0','0','0','0','0','0','833.33','0','-833.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(241,'228',NULL,NULL,'239','190731184911','','','0','0','0','0','0','0','0','911.42','0','-911.42','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(242,'228',NULL,NULL,'240','190902195556','','','0','0','0','0','0','0','0','1657.14','0','-1657.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(243,'228',NULL,NULL,'241','190920181809','','','0','0','0','0','0','0','0','1228.57','0','-1228.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(244,'228',NULL,NULL,'242','190920182301','','','0','0','0','0','0','0','0','1228.57','0','-1228.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(245,'228',NULL,NULL,'243','191004151448','','','0','0','0','0','0','0','0','1324.76','0','-1324.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(246,'228',NULL,NULL,'244','191008164314','','','0','0','0','0','0','0','0','94.29','0','-94.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(247,'228',NULL,NULL,'245','191010182536','','','0','0','0','0','0','0','0','1695.2','0','-1695.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(248,'228',NULL,NULL,'246','191010182637','','','0','0','0','0','0','0','0','1371.52','0','-1371.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(249,'228',NULL,NULL,'247','191015173942','','','0','0','0','0','0','0','0','6362.28','0','-6362.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(250,'228',NULL,NULL,'248','191015174101','','','0','0','0','0','0','0','0','5529.84','0','-5529.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(251,'228',NULL,NULL,'249','191015174228','','','0','0','0','0','0','0','0','5683.14','0','-5683.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(252,'228',NULL,NULL,'250','191015174401','','','0','0','0','0','0','0','0','4221','0','-4221.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(253,'228',NULL,NULL,'251','191015174534','','','0','0','0','0','0','0','0','6335.72','0','-6335.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(254,'228',NULL,NULL,'252','191026170233','','','0','0','0','0','0','0','0','1732.5','0','-1732.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(255,'228',NULL,NULL,'253','191116152348','','','0','0','0','0','0','0','0','998.29','0','-998.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(256,'228',NULL,NULL,'254','191212151134','','','0','0','0','0','0','0','0','1542.86','0','-1542.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(257,'228',NULL,NULL,'255','200102152310','','','0','0','0','0','0','0','0','1275.71','0','-1275.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(258,'228',NULL,NULL,'256','200113145129','','','0','0','0','0','0','0','0','1384.81','0','-1384.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(259,'228',NULL,NULL,'257','200113145225','','','0','0','0','0','0','0','0','2085.24','0','-2085.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(260,'228',NULL,NULL,'258','200115164438','','','0','0','0','0','0','0','0','2061.9','0','-2061.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(261,'228',NULL,NULL,'259','200127190542','','','0','0','0','0','0','0','0','1780.95','0','-1780.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(262,'228',NULL,NULL,'260','200204161905','','','0','0','0','0','0','0','0','1214.25','0','-1214.25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(263,'228',NULL,NULL,'261','200204162025','','','0','0','0','0','0','0','0','1733.32','0','-1733.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(264,'228',NULL,NULL,'262','200204162316','','','0','0','0','0','0','0','0','1300.05','0','-1300.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(265,'228',NULL,NULL,'263','200204162420','','','0','0','0','0','0','0','0','1809.52','0','-1809.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(266,'228',NULL,NULL,'264','200204162611','','','0','0','0','0','0','0','0','1390.48','0','-1390.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(267,'228',NULL,NULL,'265','200204162739','','','0','0','0','0','0','0','0','1790.4','0','-1790.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(268,'228',NULL,NULL,'266','200204162840','','','0','0','0','0','0','0','0','952.4','0','-952.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(269,'228',NULL,NULL,'267','200212170505','','','0','0','0','0','0','0','0','1103.16','0','-1103.16','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(270,'228',NULL,NULL,'268','200212170650','','','0','0','0','0','0','0','0','1904.76','0','-1904.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(271,'228',NULL,NULL,'269','200212184219','','','0','0','0','0','0','0','0','2517.84','0','-2517.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(272,'228',NULL,NULL,'270','200212184315','','','0','0','0','0','0','0','0','2678.64','0','-2678.64','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(273,'228',NULL,NULL,'271','200212184424','','','0','0','0','0','0','0','0','2819.2','0','-2819.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(274,'228',NULL,NULL,'272','200217182111','','','0','0','0','0','0','0','0','1409.52','0','-1409.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(275,'228',NULL,NULL,'273','200218153339','','','0','0','0','0','0','0','0','1528.57','0','-1528.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(276,'228',NULL,NULL,'274','200218155641','','','0','0','0','0','0','0','0','1314.28','0','-1314.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(277,'228',NULL,NULL,'275','200226183226','','','0','0','0','0','0','0','0','1071.45','0','-1071.45','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(278,'228',NULL,NULL,'276','200311164919','','','0','0','0','0','0','0','0','1209.52','0','-1209.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(279,'228',NULL,NULL,'277','200313150638','','','0','0','0','0','0','0','0','1599.96','0','-1599.96','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(280,'228',NULL,NULL,'278','200314171105','','','0','0','0','0','0','0','0','2685.72','0','-2685.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(281,'228',NULL,NULL,'279','200406174514','','','0','0','0','0','0','0','0','1356.19','0','-1356.19','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(282,'228',NULL,NULL,'280','200413160204','','','0','0','0','0','0','0','0','1790.48','0','-1790.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(283,'228',NULL,NULL,'281','200413160312','','','0','0','0','0','0','0','0','1371.43','0','-1371.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(284,'228',NULL,NULL,'282','200415140854','','','0','0','0','0','0','0','0','1500','0','-1500.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(285,'228',NULL,NULL,'283','200415175716','','','0','0','0','0','0','0','0','2361.9','0','-2361.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(286,'228',NULL,NULL,'284','200417083449','','','0','0','0','0','0','0','0','6495.6','0','-6495.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(287,'228',NULL,NULL,'285','200417142331','','','0','0','0','0','0','0','0','1314.29','0','-1314.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(288,'228',NULL,NULL,'286','200417142613','','','0','0','0','0','0','0','0','1823.81','0','-1823.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(289,'228',NULL,NULL,'287','200424151652','','','0','0','0','0','0','0','0','1166.67','0','-1166.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(290,'228',NULL,NULL,'288','200424151834','','','0','0','0','0','0','0','0','2057.14','0','-2057.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(291,'228',NULL,NULL,'289','200521132455','','','0','0','0','0','0','0','0','1695.24','0','-1695.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(292,'228',NULL,NULL,'290','200521132539','','','0','0','0','0','0','0','0','1771.43','0','-1771.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(293,'228',NULL,NULL,'291','200601142222','','','0','0','0','0','0','0','0','1714.29','0','-1714.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(294,'228',NULL,NULL,'292','200601142346','','','0','0','0','0','0','0','0','360.25','0','-360.25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(295,'228',NULL,NULL,'293','200713154745','','','0','0','0','0','0','0','0','1066.06','0','-1066.06','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(296,'228',NULL,NULL,'294','200721094009','','','0','0','0','0','0','0','0','7928.6','0','-7928.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(297,'228',NULL,NULL,'295','200808170548','','','0','0','0','0','0','0','0','1343.81','0','-1343.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(298,'228',NULL,NULL,'296','200818155502','','','0','0','0','0','0','0','0','1081.9','0','-1081.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(299,'228',NULL,NULL,'297','200914145334','','','0','0','0','0','0','0','0','1188.57','0','-1188.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(300,'228',NULL,NULL,'298','201022161035','','','0','0','0','0','0','0','0','3047.6','0','-3047.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(301,'228',NULL,NULL,'299','201022161134','','','0','0','0','0','0','0','0','2382.86','0','-2382.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(302,'228',NULL,NULL,'300','201022161243','','','0','0','0','0','0','0','0','1566','0','-1566.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(303,'228',NULL,NULL,'301','201022161342','','','0','0','0','0','0','0','0','2409.52','0','-2409.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(304,'228',NULL,NULL,'302','201022161605','','','1627903291375','0','0','0','0','0','0','2408','0','-2408.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(305,'228',NULL,NULL,'303','201022161719','','','0','0','0','0','0','0','0','2568','0','-2568.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(306,'228',NULL,NULL,'304','201022161846','','','0','0','0','0','0','0','0','2808','0','-2808.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(307,'228',NULL,NULL,'305','201022162145','','','0','0','0','0','0','0','0','3128','0','-3128.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(308,'228',NULL,NULL,'306','201023152715','','','0','0','0','0','0','0','0','1760','0','-1760.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(309,'228',NULL,NULL,'307','201023152816','','','0','0','0','0','0','0','0','1980','0','-1980.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(310,'228',NULL,NULL,'308','201023152932','','','0','0','0','0','0','0','0','2500','0','-2500.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(311,'228',NULL,NULL,'309','201029084906','','','0','0','0','0','0','0','0','1131.43','0','-1131.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(312,'228',NULL,NULL,'310','201029162035','','','0','0','0','0','0','0','0','2560','0','-2560.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(313,'228',NULL,NULL,'311','201029162416','','','0','0','0','0','0','0','0','1752.38','0','-1752.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(314,'228',NULL,NULL,'312','201111162252','','','0','0','0','0','0','0','0','1359.96','0','-1359.96','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(315,'228',NULL,NULL,'313','201111162440','','','0','0','0','0','0','0','0','1471.08','0','-1471.08','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(316,'228',NULL,NULL,'314','201113152504','','','0','0','0','0','0','0','0','1747.62','0','-1747.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(317,'228',NULL,NULL,'315','201116152033','','','0','0','0','0','0','0','0','1585.71','0','-1585.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(318,'228',NULL,NULL,'316','201121182317','','','0','0','0','0','0','0','0','948.38','0','-948.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(319,'228',NULL,NULL,'317','201214172517','','','0','0','0','0','0','0','0','1074.29','0','-1074.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(320,'228',NULL,NULL,'318','201222171441','','','0','0','0','0','0','0','0','1666.67','0','-1666.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(321,'228',NULL,NULL,'319','210107181624','','','0','0','0','0','0','0','0','1830','0','-1830.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(322,'228',NULL,NULL,'320','210121161101','','','0','0','0','0','0','0','0','1295.24','0','-1295.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(323,'228',NULL,NULL,'321','210122160151','','','0','0','0','0','0','0','0','2762','0','-2762.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(324,'228',NULL,NULL,'322','210203155327','','','0','0','0','0','0','0','0','1828.5','0','-1828.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(325,'228',NULL,NULL,'323','210203160454','','','0','0','0','0','0','0','0','1596.72','0','-1596.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(326,'228',NULL,NULL,'324','210203160752','','','0','0','0','0','0','0','0','1417.14','0','-1417.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(327,'228',NULL,NULL,'325','210203160928','','','0','0','0','0','0','0','0','2494.86','0','-2494.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(328,'228',NULL,NULL,'326','210203161157','','','0','0','0','0','0','0','0','1285.68','0','-1285.68','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(329,'228',NULL,NULL,'327','210203161316','','','0','0','0','0','0','0','0','2253.44','0','-2253.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(330,'228',NULL,NULL,'328','210209145902','','','0','0','0','0','0','0','0','1866.67','0','-1866.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(331,'228',NULL,NULL,'329','210209150200','','','0','0','0','0','0','0','0','1964.8','0','-1964.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(332,'228',NULL,NULL,'330','210212094322','','','0','0','0','0','0','0','0','1524','0','-1524.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(333,'228',NULL,NULL,'331','210212094502','','','0','0','0','0','0','0','0','2661.12','0','-2661.12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(334,'228',NULL,NULL,'332','210216174624','','','0','0','0','0','0','0','0','1809.52','0','-1809.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(335,'228',NULL,NULL,'333','210216174859','','','0','0','0','0','0','0','0','1642.84','0','-1642.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(336,'228',NULL,NULL,'334','210308175407','','','0','0','0','0','0','0','0','1417.2','0','-1417.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(337,'228',NULL,NULL,'335','210310153533','','','0','0','0','0','0','0','0','1904.76','0','-1904.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(338,'228',NULL,NULL,'336','210311160436','','','0','0','0','0','0','0','0','1904.76','0','-1904.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(339,'228',NULL,NULL,'337','210311160624','','','0','0','0','0','0','0','0','1765.43','0','-1765.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(340,'228',NULL,NULL,'338','210325171946','','','0','0','0','0','0','0','0','1393','0','-1393.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(341,'228',NULL,NULL,'339','210415162232','','','0','0','0','0','0','0','0','3540','0','-3540.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(342,'228',NULL,NULL,'340','210504142130','','','0','0','0','0','0','0','0','2455.24','0','-2455.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(343,'228',NULL,NULL,'341','210504153431','','','0','0','0','0','0','0','0','2282.85','0','-2282.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(344,'228',NULL,NULL,'342','210505145552','','','0','0','0','0','0','0','0','1585.7','0','-1585.70','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(345,'228',NULL,NULL,'343','210506123153','','','0','0','0','0','0','0','0','1877.14','0','-1877.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(346,'228',NULL,NULL,'344','210506123258','','','0','0','0','0','0','0','0','1440','0','-1440.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(347,'228',NULL,NULL,'345','210517123533','','','0','0','0','0','0','0','0','1554.29','0','-1554.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(348,'228',NULL,NULL,'346','210603145203','','','0','0','0','0','0','0','0','3238.08','0','-3238.08','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(349,'228',NULL,NULL,'347','210603145337','','','0','0','0','0','0','0','0','2000.04','0','-2000.04','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(350,'228',NULL,NULL,'348','210603145621','','','0','0','0','0','0','0','0','1704.12','0','-1704.12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(351,'228',NULL,NULL,'349','210603145812','','','0','0','0','0','0','0','0','2994.4','0','-2994.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(352,'228',NULL,NULL,'350','210603150014','','','0','0','0','0','175','0','0','1760.04','0','-1760.04','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(353,'228',NULL,NULL,'351','210603150106','','','0','0','0','0','0','0','0','2937.16','0','-2937.16','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(354,'228',NULL,NULL,'352','210603150358','','','0','0','0','0','0','0','0','1962.12','0','-1962.12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(355,'228',NULL,NULL,'353','210603150624','','','0','0','0','0','0','0','0','3476.2','0','-3476.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(356,'228',NULL,NULL,'354','210603150809','','','0','0','0','0','0','0','0','1857.15','0','-1857.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(357,'228',NULL,NULL,'355','210619163703','','','0','0','0','0','0','0','0','1642.86','0','-1642.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(358,'228',NULL,NULL,'356','210625141528','','','0','0','0','0','0','0','0','1266.7','0','-1266.70','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(359,'228',NULL,NULL,'357','210626162613','','','0','0','0','0','0','0','0','1714.29','0','-1714.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(360,'228',NULL,NULL,'358','210629172735','','','0','0','0','0','0','0','0','2250','0','-2250.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(361,'228',NULL,NULL,'359','210629172909','','','0','0','0','0','0','0','0','2731.95','0','-2731.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(362,'228',NULL,NULL,'360','210702092827','','','0','0','0','0','0','0','0','1961.9','0','-1961.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(363,'228',NULL,NULL,'361','210714172323','','','0','0','0','0','0','0','0','1312.5','0','-1312.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(364,'228',NULL,NULL,'362','210717162436','','','0','0','0','0','0','0','0','2190.48','0','-2190.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(365,'228',NULL,NULL,'363','210802165108','','','0','0','0','0','0','0','0','2408','0','-2408.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(366,'228',NULL,NULL,'364','210809164506','','','0','0','0','0','0','0','0','1446.6','0','-1446.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(367,'228',NULL,NULL,'365','210817133444','','','0','0','0','0','0','0','0','1628.48','0','-1628.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(368,'228',NULL,NULL,'366','210913161847','','','0','0','0','0','0','0','0','2057.14','0','-2057.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(369,'228',NULL,NULL,'367','210921154451','','','0','0','0','0','0','0','0','1714.29','0','-1714.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(370,'228',NULL,NULL,'368','210921182328','','','0','0','0','0','0','0','0','1904.76','0','-1904.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(371,'228',NULL,NULL,'369','210921182704','','','0','0','0','0','0','0','0','2142.85','0','-2142.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(372,'228',NULL,NULL,'370','210922170305','','','0','0','0','0','0','0','0','1585.71','0','-1585.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(373,'228',NULL,NULL,'371','210923153958','','','0','0','0','0','0','0','0','2657.14','0','-2657.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(374,'228',NULL,NULL,'372','210923154157','','','0','0','0','0','0','0','0','2047.62','0','-2047.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(375,'228',NULL,NULL,'373','210924145743','','','0','0','0','0','0','0','0','2726.67','0','-2726.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(376,'228',NULL,NULL,'374','210924145949','','','0','0','0','0','0','0','0','3522.44','0','-3522.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(377,'228',NULL,NULL,'375','210924150129','','','0','0','0','0','0','0','0','3493.8','0','-3493.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(378,'228',NULL,NULL,'376','210924150410','','','0','0','0','0','0','0','0','3266.4','0','-3266.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(379,'228',NULL,NULL,'377','210924150627','','','0','0','0','0','0','0','0','3218.76','0','-3218.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(380,'228',NULL,NULL,'378','210924150821','','','0','0','0','0','0','0','0','2499.84','0','-2499.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(381,'228',NULL,NULL,'379','210924150937','','','0','0','0','0','0','0','0','3431.16','0','-3431.16','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(382,'228',NULL,NULL,'380','210924151126','','','0','0','0','0','0','0','0','3192.32','0','-3192.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(383,'228',NULL,NULL,'381','210924151423','','','0','0','0','0','0','0','0','1964.64','0','-1964.64','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(384,'228',NULL,NULL,'382','210924151551','','','0','0','0','0','0','0','0','2014.08','0','-2014.08','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(385,'228',NULL,NULL,'383','210924151715','','','0','0','0','0','0','0','0','2156.4','0','-2156.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(386,'228',NULL,NULL,'384','210925155009','','','0','0','0','0','0','0','0','1771.42','0','-1771.42','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(387,'228',NULL,NULL,'385','210925155229','','','0','0','0','0','0','0','0','1629.71','0','-1629.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(388,'228',NULL,NULL,'386','210925155318','','','0','0','0','0','0','0','0','2803.43','0','-2803.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(389,'228',NULL,NULL,'387','211004151121','','','0','0','0','0','0','0','0','2575.45','0','-2575.45','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(390,'228',NULL,NULL,'388','211007153137','','','0','0','0','0','0','0','0','1382.86','0','-1382.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(391,'228',NULL,NULL,'389','211011184829','','','0','0','0','0','0','0','0','2777.14','0','-2777.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(392,'228',NULL,NULL,'390','211015144139','','','0','0','0','0','0','0','0','1614.28','0','-1614.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(393,'228',NULL,NULL,'391','211016174505','','','0','0','0','0','0','0','0','1610.17','0','-1610.17','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(394,'228',NULL,NULL,'392','211020164341','','','0','0','0','0','0','0','0','1496','0','-1496.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(395,'228',NULL,NULL,'393','211021151202','','','0','0','0','0','0','0','0','1542.86','0','-1542.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(396,'228',NULL,NULL,'394','211027145346','','Invalid date','0','0','0','0','0','0','0','1785.71','0','-1785.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(397,'228',NULL,NULL,'395','211116161431','','','0','0','0','0','0','0','0','2666.66','0','-2666.66','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(398,'228',NULL,NULL,'396','211116161539','','','0','0','0','0','0','0','0','2114.29','0','-2114.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(399,'228',NULL,NULL,'397','211117140400','','','0','0','0','0','0','0','0','2000','0','-2000.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(400,'228',NULL,NULL,'398','211118160356','','','0','0','0','0','0','0','0','1707.142','0','-1707.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(401,'228',NULL,NULL,'399','211120153732','','','0','0','0','0','0','0','0','2542.86','0','-2542.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(402,'228',NULL,NULL,'400','211123145319','','','0','0','0','0','0','0','0','1571.4','0','-1571.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(403,'228',NULL,NULL,'401','211130161631','','','0','0','0','0','0','0','0','1471.42','0','-1471.42','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(404,'228',NULL,NULL,'402','211208160732','','','0','0','0','0','0','0','0','1927.8','0','-1927.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(405,'228',NULL,NULL,'403','211208193046','','','0','0','0','0','0','0','0','2000','0','-2000.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(406,'228',NULL,NULL,'404','211213161758','','','0','0','0','0','0','0','0','1800','0','-1800.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(407,'228',NULL,NULL,'405','211220171959','','','0','0','0','0','0','0','0','1589.2','0','-1589.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(408,'228',NULL,NULL,'406','211223162422','','','0','0','0','0','0','0','0','1914.29','0','-1914.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(409,'228',NULL,NULL,'407','220112180121','','','0','0','0','0','0','0','0','1725','0','-1725.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(410,'228',NULL,NULL,'408','220120150344','','','0','0','0','0','0','0','0','1485.75','0','-1485.75','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(411,'228',NULL,NULL,'409','220202152325','','','0','0','0','0','0','0','0','3836','0','-3836.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(412,'228',NULL,NULL,'410','220207161800','','','0','0','0','0','0','0','0','1125','0','-1125.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(413,'228',NULL,NULL,'411','220305164422','','','0','0','0','0','0','0','0','2255.24','0','-2255.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(414,'228',NULL,NULL,'412','220309170648','','','0','0','0','0','0','0','0','1733.33','0','-1733.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(415,'228',NULL,NULL,'413','220312145319','','','0','0','0','0','0','0','0','2666.72','0','-2666.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(416,'228',NULL,NULL,'414','220312145543','','','0','0','0','0','0','0','0','3428.56','0','-3428.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(417,'228',NULL,NULL,'415','220328141849','','','0','0','0','0','0','0','0','1410.48','0','-1410.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(418,'228',NULL,NULL,'416','220328142306','','','0','0','0','0','0','0','0','1835.71','0','-1835.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(419,'228',NULL,NULL,'417','220513145004','','','0','0','0','0','0','0','0','2169.45','0','-2169.45','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(420,'228',NULL,NULL,'418','220513173812','','','0','0','0','0','0','0','0','3047.61','0','-3047.61','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(421,'228',NULL,NULL,'419','220519143649','','','0','0','0','0','0','0','0','2005.71','0','-2005.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(422,'228',NULL,NULL,'420','220519143803','','','0','0','0','0','0','0','0','3443.81','0','-3443.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(423,'228',NULL,NULL,'421','220525150235','','','0','0','0','0','0','0','0','1871.43','0','-1871.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(424,'228',NULL,NULL,'422','220526161842','','','0','0','0','0','0','0','0','1348.2','0','-1348.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(425,'228',NULL,NULL,'423','220526161939','','','0','0','0','0','0','0','0','1144.2','0','-1144.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(426,'228',NULL,NULL,'424','220526162025','','','0','0','0','0','0','0','0','2000','0','-2000.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(427,'228',NULL,NULL,'425','220603145520','','','0','0','0','0','0','0','0','5598.15','0','-5598.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(428,'228',NULL,NULL,'426','220603145640','','','0','0','0','0','0','0','0','6026.85','0','-6026.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(429,'228',NULL,NULL,'427','220624134430','','','0','0','0','0','0','0','0','1531.43','0','-1531.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(430,'228',NULL,NULL,'428','220624134545','','','0','0','0','0','0','0','0','1668.57','0','-1668.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(431,'228',NULL,NULL,'429','220715142349','','','0','0','0','0','0','0','0','3358','0','-3358.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(432,'228',NULL,NULL,'430','220716170627','','','0','0','0','0','0','0','0','2057.14','0','-2057.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(433,'228',NULL,NULL,'431','220718144355','','','0','0','0','0','0','0','0','1900','0','-1900.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(434,'228',NULL,NULL,'432','220722154013','','','0','0','0','0','0','0','0','2540','0','-2540.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(435,'228',NULL,NULL,'433','220722154200','','','0','0','0','0','0','0','0','1809.4','0','-1809.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(436,'228',NULL,NULL,'434','220726143431','','','0','0','0','0','0','0','0','2019.05','0','-2019.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(437,'228',NULL,NULL,'435','220730173341','','','0','0','0','0','0','0','0','2485.71','0','-2485.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(438,'228',NULL,NULL,'436','220810093649','','','0','0','0','0','0','0','0','3493.33','0','-3493.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(439,'228',NULL,NULL,'437','220829173902','','','0','0','0','0','0','0','0','2802','0','-2802.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(440,'228',NULL,NULL,'438','220907180008','','','0','0','0','0','0','0','0','1428.6','0','-1428.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(441,'228',NULL,NULL,'439','220920180214','','','0','0','0','0','0','0','0','2739.23','0','-2739.23','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(442,'228',NULL,NULL,'440','221004135323','','','0','0','0','0','3500','0','0','1685.71','0','-1685.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(443,'228',NULL,NULL,'441','221015061302','','','0','0','0','0','0','0','0','2533.33','0','-2533.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(444,'228',NULL,NULL,'442','221015063330','','','0','0','0','0','0','0','0','4873.07','0','-4873.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(445,'228',NULL,NULL,'443','221015063555','','','0','0','0','0','0','0','0','4512.42','0','-4512.42','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(446,'228',NULL,NULL,'444','221015063744','','','0','0','0','0','0','0','0','4223.67','0','-4223.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(447,'228',NULL,NULL,'445','221015063948','','','0','0','0','0','0','0','0','4160.46','0','-4160.46','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(448,'228',NULL,NULL,'446','221015064120','','','0','0','0','0','0','0','0','6726.5','0','-6726.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(449,'228',NULL,NULL,'447','221015064400','','','0','0','0','0','0','0','0','4873.07','0','-4873.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(450,'228',NULL,NULL,'448','221015064516','','','0','0','0','0','0','0','0','4512.32','0','-4512.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(451,'228',NULL,NULL,'449','221015064652','','','0','0','0','0','0','0','0','4223.67','0','-4223.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(452,'228',NULL,NULL,'450','221015064816','','','0','0','0','0','0','0','0','4160.46','0','-4160.46','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(453,'228',NULL,NULL,'451','221015065009','','','0','0','0','0','0','0','0','3158.57','0','-3158.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(454,'228',NULL,NULL,'452','221015065148','','','0','0','0','0','0','0','0','5099.19','0','-5099.19','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(455,'228',NULL,NULL,'453','221015065322','','','0','0','0','0','0','0','0','5008.79','0','-5008.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(456,'228',NULL,NULL,'454','221024040605','','','0','0','0','0','0','0','0','5711.1','0','-5711.10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(457,'228',NULL,NULL,'455','221024041006','','','0','0','0','0','0','0','0','5609.85','0','-5609.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(458,'228',NULL,NULL,'456','221026025153','','','0','0','0','0','0','0','0','2380.95','0','-2380.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(459,'228',NULL,NULL,'457','221117145453','','','0','0','0','0','0','0','0','2354.4','0','-2354.40','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(460,'228',NULL,NULL,'458','221117183428','','','0','0','0','0','0','0','0','2610.48','0','-2610.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(461,'228',NULL,NULL,'459','221118150407','','','0','0','0','0','0','0','0','1914.29','0','-1914.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(462,'228',NULL,NULL,'460','221123181958','','','0','0','0','0','0','0','0','1714.29','0','-1714.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(463,'228',NULL,NULL,'461','221123182708','','','0','0','0','0','0','0','0','1773.58','0','-1773.58','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(464,'228',NULL,NULL,'462','221123182912','','','0','0','0','0','0','0','0','2019.28','0','-2019.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(465,'228',NULL,NULL,'463','221123183029','','','0','0','0','0','0','0','0','2889.3','0','-2889.30','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(466,'228',NULL,NULL,'464','221123183131','','','0','0','0','0','0','0','0','3532.2','0','-3532.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(467,'228',NULL,NULL,'465','221203174823','','','0','0','0','0','0','0','0','1557.14','0','-1557.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(468,'228',NULL,NULL,'466','221207160253','','','0','0','0','0','0','0','0','1857.14','0','-1857.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(469,'228',NULL,NULL,'467','221219161608','','','0','0','0','0','0','0','0','1714.29','0','-1714.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(470,'228',NULL,NULL,'468','230111153303','','','0','0','0','0','0','0','0','1328.55','0','-1328.55','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(471,'228',NULL,NULL,'469','230111153507','','','0','0','0','0','0','0','0','1923.81','0','-1923.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(472,'228',NULL,NULL,'470','230211171921','','','0','0','0','0','0','0','0','1328.55','0','-1328.55','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(473,'228',NULL,NULL,'471','230223161123','','','0','0','0','0','0','0','0','1904.76','0','-1904.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(474,'228',NULL,NULL,'472','230324153944','','','0','0','0','0','0','0','0','1648.57','0','-1648.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(475,'228',NULL,NULL,'473','230404184901','','','0','0','0','0','0','0','0','1328.57','0','-1328.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(476,'228',NULL,NULL,'474','230411161857','','','0','0','0','0','0','0','0','1607.2','0','-1607.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(477,'228',NULL,NULL,'475','230414150601','','','0','0','0','0','0','0','0','1809.52','0','-1809.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(478,'228',NULL,NULL,'476','230511153133','','','0','0','0','0','0','0','0','2279.24','0','-2279.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(479,'228',NULL,NULL,'477','230511181515','','','0','0','0','0','0','0','0','2773.8','0','-2773.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(480,'228',NULL,NULL,'478','230511181724','','','0','0','0','0','0','0','0','2820.24','0','-2820.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(481,'228',NULL,NULL,'479','230523153040','','','0','0','0','0','0','0','0','1782','0','-1782.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:29',NULL),(482,'228',NULL,NULL,'480','230523153217','','','0','0','0','0','0','0','0','1731.6','0','-1731.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(483,'228',NULL,NULL,'481','230603164147','','','0','0','0','0','0','0','0','1538.6','0','-1538.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(484,'228',NULL,NULL,'482','230603173925','','','0','0','0','0','0','0','0','1619.05','0','-1619.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(485,'228',NULL,NULL,'483','230605182342','','','0','0','0','0','0','0','0','1423.81','0','-1423.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(486,'228',NULL,NULL,'484','230612164859','','','0','0','0','0','0','0','0','1085.71','0','-1085.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(487,'228',NULL,NULL,'485','230622181759','','','0','0','0','0','0','0','0','1390.48','0','-1390.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(488,'228',NULL,NULL,'486','230622181903','','','0','0','0','0','0','0','0','1261.9','0','-1261.90','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(489,'228',NULL,NULL,'487','230710181026','','','0','0','0','0','0','0','0','7302.84','0','-7302.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(490,'228',NULL,NULL,'488','230710181148','','','0','0','0','0','0','0','0','9472.5','0','-9472.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(491,'228',NULL,NULL,'489','230710181329','','','0','0','0','0','0','0','0','9384.1','0','-9384.10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(492,'228',NULL,NULL,'490','230710181456','','','0','0','0','0','0','0','0','7679.46','0','-7679.46','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(493,'228',NULL,NULL,'491','230710181648','','','0','0','0','0','0','0','0','7612.5','0','-7612.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(494,'228',NULL,NULL,'492','230710181756','','','0','0','0','0','0','0','0','7538.83','0','-7538.83','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(495,'228',NULL,NULL,'493','230721150021','','','0','0','0','0','0','0','0','1447.62','0','-1447.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(496,'228',NULL,NULL,'494','230802175021','','','0','0','0','0','0','0','0','1517.86','0','-1517.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(497,'228',NULL,NULL,'495','231012181515','','','0','0','0','0','0','0','0','2605.71','0','-2605.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(498,'228',NULL,NULL,'496','231013091244','','','0','0','0','0','0','0','0','794.08','0','-794.08','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(499,'228',NULL,NULL,'497','231222161114','','','0','0','0','0','0','0','0','914.29','0','-914.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(500,'228',NULL,NULL,'498','240129151132','','','0','0','0','0','0','0','0','1874.29','0','-1874.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(501,'228',NULL,NULL,'499','240222160304','','','0','0','0','0','0','0','0','1157.1','0','-1157.10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(502,'228',NULL,NULL,'500','240403180805','','','0','0','0','0','0','0','0','2186.1','0','-2186.10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(503,'228',NULL,NULL,'501','240429155022','','','0','0','0','0','0','0','0','1523.81','0','-1523.81','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(504,'228',NULL,NULL,'502','240501161201','','','0','0','0','0','0','0','0','1128.6','0','-1128.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(505,'228',NULL,NULL,'503','240502155503','','','0','0','0','0','0','0','0','1128.57','0','-1128.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(506,'228',NULL,NULL,'504','240504174447','','','0','0','0','0','0','0','0','1040','0','-1040.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(507,'228',NULL,NULL,'505','240507165653','','','0','0','0','0','0','0','0','1528.5','0','-1528.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(508,'228',NULL,NULL,'506','240509160046','','','0','0','0','0','0','0','0','1904.8','0','-1904.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(509,'228',NULL,NULL,'507','240517153812','','','0','0','0','0','0','0','0','820','0','-820.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(510,'228',NULL,NULL,'508','240613180715','','','0','0','0','0','0','0','0','1409.52','0','-1409.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(511,'228',NULL,NULL,'509','240621155516','','','0','0','0','0','0','0','0','1485.72','0','-1485.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(512,'228',NULL,NULL,'510','240625153452','','','0','0','0','0','0','0','0','1709.52','0','-1709.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(513,'228',NULL,NULL,'511','240629164242','','','0','0','0','0','0','0','0','1480.95','0','-1480.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(514,'228',NULL,NULL,'512','240705143343','','','0','0','0','0','0','0','0','1900.05','0','-1900.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(515,'228',NULL,NULL,'513','240705143523','','','0','0','0','0','0','0','0','3276','0','-3276.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(516,'228',NULL,NULL,'514','240722185537','','','0','0','0','0','0','0','0','2419.05','0','-2419.05','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(517,'228',NULL,NULL,'515','240722185659','','','0','0','0','0','0','0','0','3009.52','0','-3009.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(518,'228',NULL,NULL,'516','240723183131','','','0','0','0','0','0','0','0','1448.57','0','-1448.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(519,'228',NULL,NULL,'517','240729145934','','','0','0','0','0','0','0','0','1157','0','-1157.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(520,'228',NULL,NULL,'518','240729183229','','','0','0','0','0','0','0','0','1557.14','0','-1557.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(521,'228',NULL,NULL,'519','240802144657','','','0','0','0','0','0','0','0','1114.29','0','-1114.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(522,'228',NULL,NULL,'520','240802161256','','','0','0','0','0','0','0','0','2152.38','0','-2152.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(523,'228',NULL,NULL,'521','240802161426','','','0','0','0','0','0','0','0','2026.67','0','-2026.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(524,'228',NULL,NULL,'522','240802161545','','','0','0','0','0','0','0','0','1965.71','0','-1965.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(525,'228',NULL,NULL,'523','240805181529','','','0','0','0','0','0','0','0','2000','0','-2000.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(526,'228',NULL,NULL,'524','240808164318','','','0','0','0','0','0','0','0','2114.29','0','-2114.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(527,'228',NULL,NULL,'525','240808164425','','','0','0','0','0','0','0','0','2209.52','0','-2209.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(528,'228',NULL,NULL,'526','240903183329','','','0','0','0','0','0','0','0','1142.74','0','-1142.74','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(529,'228',NULL,NULL,'527','240920175709','','','0','0','0','0','0','0','0','1828.56','0','-1828.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(530,'228',NULL,NULL,'528','240927165703','','','0','0','0','0','0','0','0','995.2','0','-995.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(531,'228',NULL,NULL,'529','240928165228','','','0','0','0','0','0','0','0','1828.57','0','-1828.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(532,'228',NULL,NULL,'530','240930181501','','','0','0','0','0','0','0','0','1972.38','0','-1972.38','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(533,'228',NULL,NULL,'531','241004184312','','','0','0','0','0','0','0','0','1857.15','0','-1857.15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(534,'228',NULL,NULL,'532','241005183212','','','0','0','0','0','0','0','0','1785.75','0','-1785.75','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(535,'228',NULL,NULL,'533','241005183312','','','0','0','0','0','0','0','0','1857','0','-1857.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(536,'228',NULL,NULL,'534','241007181526','','','0','0','0','0','0','0','0','1728.6','0','-1728.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(537,'228',NULL,NULL,'535','241009181448','','','0','0','0','0','0','0','0','2009.52','0','-2009.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(538,'228',NULL,NULL,'536','241010181630','','','0','0','0','0','0','0','0','2514.28','0','-2514.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(539,'228',NULL,NULL,'537','241014155313','','','0','0','0','0','0','0','0','1753.33','0','-1753.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(540,'228',NULL,NULL,'538','241016174802','','','0','0','0','0','0','0','0','1514.25','0','-1514.25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(541,'228',NULL,NULL,'539','241018160345','','','0','0','0','0','0','0','0','1932','0','-1932.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(542,'228',NULL,NULL,'540','241027161145','','','0','0','0','0','0','0','0','1942.8','0','-1942.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(543,'228',NULL,NULL,'541','241027161338','','','0','0','0','0','0','0','0','2457.16','0','-2457.16','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(544,'228',NULL,NULL,'542','241027161458','','','0','0','0','0','0','0','0','1900','0','-1900.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(545,'228',NULL,NULL,'543','241111154521','','','0','0','0','0','0','0','0','2047.62','0','-2047.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(546,'228',NULL,NULL,'544','241113152543','','','0','0','0','0','0','0','0','1699.95','0','-1699.95','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(547,'228',NULL,NULL,'545','241129162254','','','0','0','0','0','0','0','0','1851.43','0','-1851.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(548,'228',NULL,NULL,'546','250106172440','','','0','0','0','0','0','0','0','1699.5','0','-1699.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(549,'228',NULL,NULL,'547','250128142111','','','0','0','0','0','0','0','0','1771.5','0','-1771.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(550,'228',NULL,NULL,'548','250217165741','','','0','0','0','0','0','0','0','1523.43','0','-1523.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(551,'228',NULL,NULL,'190','1741418425511','','','0','0','0','0','0','0','0','1785.75','0','-1785.75','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(552,'228',NULL,NULL,'549','250415180625','','','0','0','0','0','0','0','0','1637.16','0','-1637.16','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(553,'228',NULL,NULL,'550','250415180842','','','0','0','0','0','0','0','0','1828.5','0','-1828.50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(554,'228',NULL,NULL,'551','250415181021','','','0','0','0','0','0','0','0','1728.6','0','-1728.60','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(555,'228',NULL,NULL,'552','250418091625','','','0','0','0','0','0','0','0','1714.32','0','-1714.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(556,'228',NULL,NULL,'553','250513153742','','','0','0','0','0','0','0','0','1478.55','0','-1478.55','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(557,'228',NULL,NULL,'554','250515094814','','','0','0','0','0','0','0','0','2982.84','0','-2982.84','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(558,'228',NULL,NULL,'555','250519165859','','','0','0','0','0','0','0','0','1828.57','0','-1828.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(559,'228',NULL,NULL,'556','250519170037','','','0','0','0','0','0','0','0','1733.33','0','-1733.33','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(560,'228',NULL,NULL,'557','250519170314','','','0','0','0','0','0','0','0','1485.71','0','-1485.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(561,'228',NULL,NULL,'558','250519170448','','','0','0','0','0','0','0','0','1388.57','0','-1388.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(562,'228',NULL,NULL,'559','250520160515','','','0','0','0','0','0','0','0','1979.03','0','-1979.03','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(563,'228',NULL,NULL,'560','250526160202','','','0','0','0','0','0','0','0','2031.24','0','-2031.24','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(564,'228',NULL,NULL,'561','250602094843','','','0','0','0','0','0','0','0','1177.14','0','-1177.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(565,'228',NULL,NULL,'562','250602150904','','','0','0','0','0','0','0','0','1342.8','0','-1342.80','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(566,'228',NULL,NULL,'563','250923094943','','','0','0','0','0','0','0','0','1714.2','0','-1714.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(567,'228',NULL,NULL,'564','250923095114','','','0','0','0','0','0','0','0','1657','0','-1657.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(568,'228',NULL,NULL,'565','250923095241','','','0','0','0','0','0','0','0','2209.2','0','-2209.20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(569,'228',NULL,NULL,'566','250923095447','','','0','0','0','0','0','0','0','3093','0','-3093.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(570,'228',NULL,NULL,'567','251017183303','','','0','0','0','0','0','0','0','4380','0','-4380.00','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(571,'228',NULL,NULL,'568','251115161714','','','0','0','0','0','0','0','0','7714.29','0','-7714.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(572,'228',NULL,NULL,'569','251115161858','','','0','0','0','0','0','0','0','6971.43','0','-6971.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(573,'228',NULL,NULL,'570','251115162054','','','0','0','0','0','0','0','0','8585.72','0','-8585.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL),(574,'228',NULL,NULL,'571','251115162219','','','0','0','0','-5','0','0','2352.3810','6502.86','0','-6502.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,0,'2026-04-14 10:13:30',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=575 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int(11) DEFAULT 0,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int(11) DEFAULT 0,
  `M_ROUND_OFF` int(11) DEFAULT 0,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL,
  `LITE_ID` varchar(50) DEFAULT '',
  `WEB_ID` varchar(50) DEFAULT '',
  `PROD_ID` int(11) NOT NULL,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` varchar(50) DEFAULT NULL,
  `PUR_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT` varchar(25) DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) DEFAULT '0',
  `PUR_CESS` varchar(25) DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) DEFAULT '0',
  `PACK` varchar(25) DEFAULT '0',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(25) DEFAULT '0',
  `DISC_PERCENT` varchar(25) DEFAULT '0',
  `DISC_AMOUNT` varchar(25) DEFAULT '0',
  `RETURN_QTY` varchar(25) DEFAULT '0',
  `FREE` varchar(25) DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) DEFAULT '0',
  `AMT` varchar(25) DEFAULT '0',
  `TAX_AMT` varchar(25) DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) DEFAULT '0',
  `RETURN` varchar(25) DEFAULT '0',
  `SR_NO` varchar(50) DEFAULT '',
  `CESS_AMT` varchar(25) DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) DEFAULT '0',
  `UI_DISP_BAG` varchar(50) DEFAULT '',
  `WEIGHT` varchar(25) DEFAULT '0',
  `PRICE_PER` varchar(25) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT NULL,
  `TE_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) DEFAULT '0',
  `MRP` varchar(25) DEFAULT '0',
  `DAMAGE` varchar(25) DEFAULT '0',
  `DAMAGE_AMT` varchar(25) DEFAULT '0',
  `REPLACE` varchar(25) DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) DEFAULT '0',
  `DMG_MRP` varchar(25) DEFAULT '0',
  `PUR_INSURANCE` varchar(25) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) DEFAULT '0',
  `CLOUD_SYNC` varchar(25) DEFAULT '0',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT current_timestamp(),
  `UPDATED_TS` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `FINAL_AMT` varchar(25) DEFAULT '0',
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `TCS_TAX` varchar(100) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `BROKER_ID` int(11) DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `IS_SUPERSTOCKIST` tinyint(4) NOT NULL DEFAULT 0,
  `SUPERSTOCKIST_ID` int(11) NOT NULL DEFAULT 0,
  `EXTRA_1` varchar(255) DEFAULT NULL,
  `EXTRA_2` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=345 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (344,'228','0','emROKelLsC','TIRUPATHI','emROKelLsC','santoshy@yopmail.com',NULL,'UYssF6n8AcWL','Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','',NULL,NULL,0,0,NULL,NULL,'344','1','',0,'2026-04-14 09:57:51','2026-04-14 10:00:53');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REMARKS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT 0,
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-04-14 09:57:46',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text DEFAULT NULL,
  `MAC_ID` int(11) DEFAULT 0,
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text DEFAULT NULL,
  `S_ADD2` text DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `DISCOUNT2` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'228',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(2,'228',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(3,'228',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(4,'228',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(5,'228',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(6,'228',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(7,'228',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(8,'228',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(9,'228',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(10,'228',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(11,'228',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(12,'228',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(13,'228',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(14,'228',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(15,'228',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(16,'228',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(17,'228',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(18,'228',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(19,'228',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(20,'228',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(21,'228',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(22,'228',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(23,'228',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(24,'228',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(25,'228',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(26,'228',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(27,'228',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(28,'228',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(29,'228',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(30,'228',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(31,'228',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(32,'228',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(33,'228',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(34,'228',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(35,'228',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(36,'228',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(37,'228',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(38,'228',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(39,'228',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(40,'228',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(41,'228',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(42,'228',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(43,'228',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(44,'228',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(45,'228',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(46,'228',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(47,'228',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(48,'228',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(49,'228',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(50,'228',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(51,'228',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(52,'228',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(53,'228',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(54,'228',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(55,'228',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(56,'228',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,'56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(57,'228',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(58,'228',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(59,'228',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,'59',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(60,'228',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,'60',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(61,'228',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,'61',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(62,'228',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(63,'228',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(64,'228',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(65,'228',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(66,'228',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(67,'228',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(68,'228',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(69,'228',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(70,'228',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(71,'228',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(72,'228',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(73,'228',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(74,'228',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(75,'228',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(76,'228',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(77,'228',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(78,'228',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(79,'228',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(80,'228',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(81,'228',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(82,'228',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(83,'228',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(84,'228',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(85,'228',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(86,'228',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(87,'228',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(88,'228',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(89,'228',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(90,'228',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(91,'228',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(92,'228',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(93,'228',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(94,'228',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(95,'228',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(96,'228',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(97,'228',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(98,'228',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-14 09:57:49','2026-04-14 09:57:49'),(99,'228',NULL,NULL,'R.R.FOODS',5,'0','DR','CHAWL NO 93,GROUD NO 6 TAGORE NAGAR','NEAR SHANI MANDIR VIKHROLI E','MUMBAI','21','400079',NULL,'8976593802','',NULL,'27','27NDNPS2602P1ZM','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,'21524013000646','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2827',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(100,'228',NULL,NULL,'VAISHNO SUPER MART',5,'0','DR','SHOP NO 1,2,3, MERCURY BULIDING','SUNCITY','MUMBAI','21','400083',NULL,'9930391617','',NULL,'27','27GCSPS6582R1ZZ','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,'11524013000005','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2742',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(101,'228',NULL,NULL,'SAFAL MULTIGRAIN SUPPLIER',5,'0','DR','GALA NO 23, KETANI INDUSTRIAL PREMISES CO OP SO.LTD','MAGAN NATHURAM ROAD KURLA W','MUMBAI','21','400070',NULL,'9967397482','',NULL,'27','27FRMPS8544D1Z6','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'101',NULL,NULL,NULL,NULL,NULL,'11518004000134','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2193',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(102,'228',NULL,NULL,'SUPREME AGARBATTI WORKS',5,'0','DR','SHOP NO 6, AASHA BHAVAN GAONDEVI ROAD','BHANDUP WEST','MUMBAI','21','400078',NULL,'8779890548','',NULL,'27','27EWYPS3511N1ZJ','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'102',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2911',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(103,'228',NULL,NULL,'ASHA CATERERS & DECORATORS',5,'0','DR','2/3, SHARAD VILA, J.M. ROAD,','BHANDUP W','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27EMPPS6782A1ZG','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'103',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1258',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(104,'228',NULL,NULL,'Nilakshi Sales',5,'0','DR','Sion','Sion','MUMBAI','21','',NULL,'','',NULL,'27','27DSBPM7259F1ZH','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'104',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1863',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(105,'228',NULL,NULL,'SHREEJI SUPER MARKET',5,'0','DR','SHOP NO 4,5,6,RAMDEV COMPLEX SECTOR-19','AIROLI NAVI MUMBAI','NAVI MUMBAI','21','400708',NULL,'8850108001','',NULL,'27','27DRAPP9617J1ZA','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'105',NULL,NULL,NULL,NULL,NULL,'11520015000135','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-10-29','0.00',NULL,'0','0',NULL,'0','2142',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(106,'228',NULL,NULL,'BAJRANG SUPER MARKET',5,'0','DR','SHOP NO6/7 SAFIYABI CHAWL','PRATAPNAGAR ROAD BHANDUP W','MUMBAI','21','400078',NULL,'7490048004','',NULL,'27','27DGVPB0245L1Z4','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'106',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2792',NULL,'0','0',NULL,0,'2026-04-14 10:25:35','2026-04-14 10:25:35'),(107,'228',NULL,NULL,'MAA ARBUDA KIRANA AND DRY FRUIT',5,'0','DR','AIROLI SEC-8','AIROLI','MUMBAI','21','400708',NULL,'9819591686','',NULL,'27','27CWLPP0259F1ZB','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'107',NULL,NULL,NULL,NULL,NULL,'11521015000344','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','702',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(108,'228',NULL,NULL,'SHRI CHIRAG ENTERPRISES',5,'0','DR','GADVANAKA BHANDUP','BHANDUP W','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27CRFPP7786J1ZW','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'108',NULL,NULL,NULL,NULL,NULL,'11517013000510','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1834',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(109,'228',NULL,NULL,'D.M. STORE',5,'0','DR','GADAVNAKA TEMBIPADA ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'9930477964','',NULL,'27','27CRFPP7786J1ZW','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'109',NULL,NULL,NULL,NULL,NULL,'11517013000510','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2699',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(110,'228',NULL,NULL,'LAXMI TRADERS',5,'0','DR','HUSAINIYA CHOWK RAJIVE GHANDHI NAGAR','DARGAH CROSS ROAD SONAPUR BHANDUP W','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27CIUPP4195B1ZR','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'110',NULL,NULL,NULL,NULL,NULL,'11517013000148','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-09-14','0.00',NULL,'0','0',NULL,'0','2121',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(111,'228',NULL,NULL,'LAXMAN OIL DEPOT',5,'0','DR','TEMBIPADA','BHANDUP W','MUMBAI','21','400078',NULL,'8779704263','',NULL,'27','27CFUPS1632F2Z2','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'111',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','496',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(112,'228',NULL,NULL,'SHIV TRADERS',5,'0','DR','A 3/3 BGTA GANGA BLDG NEAR INDIAN OIL PETROL','PUMP WADALA RTO MUMBAI','MUMBAI','21','400031',NULL,'9769464569','',NULL,'27','27CFMPM9317M1ZO','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'112',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2716',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(113,'228',NULL,NULL,'SADHANA STORE',5,'0','DR','KHINDIPADA','MULUND W','MUMBAI','21','400080',NULL,'9773846192','',NULL,'27','27CDKPB9578H1Z1','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'113',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','578',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(114,'228',NULL,NULL,'SWAMI SMARTH GEN STORES',5,'0','DR','PARK SITE','VIKHROLI W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27CCEPS2044C1ZV','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'114',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1808',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(115,'228',NULL,NULL,'SHREE CHAMUNDA KIRANA GHAR',5,'0','DR','SHOP NO.9 SHIV SHALTI JANTA SOCIETY','RAJAWADI GHATKOPER E','MUMBAI','21','',NULL,'9920369089','',NULL,'27','27BYOPB2585G1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'115',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2283',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(116,'228',NULL,NULL,'SHREE CHAMUNDA KIRANA GHAR',5,'0','DR','SHOP NO 9 SHIV SHAKTI HEIGHTS JANTA SOCIETY MARG','GHATKOPAR EAST','MUMBAI','21','400077',NULL,'','',NULL,'27','27BYOPB2585G1Z8','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'116',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2200',NULL,'0','0',NULL,0,'2026-04-14 10:25:36','2026-04-14 10:25:36'),(117,'228',NULL,NULL,'BHARAT PAN BEEDI GEN STORES',5,'0','DR','DIGHA BELAPUR ROAD DIGHA','DIGHA','MUMBAI','21','',NULL,'9892815122','',NULL,'27','27BXZPS8282F1ZE','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'117',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2534',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(118,'228',NULL,NULL,'SAHU TRADERS',5,'0','DR','PLOT NO.108 NITYANAND NAGAR','GHATKOPAR WEST','MUMBAI','21','400086',NULL,'9920887373','',NULL,'27','27BXSPS3075F1ZW','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'118',NULL,NULL,NULL,NULL,NULL,'11518008000684','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1151',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(119,'228',NULL,NULL,'JAY MAHARASHTRA DHANYA BHANDAR',5,'0','DR','MADHU CHANDRA CO.OP, SHOP NO.3, MATA MAHAKALI ROAD, BHATWADI MARKET','GHATKOPER W','MUMBAI','21','',NULL,'9820637261','',NULL,'27','27BVKPS1713E1ZL','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'119',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2276',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(120,'228',NULL,NULL,'RAJWADI SUPER MARKET',5,'0','DR','ROOM NO 8,C-4,MUNICIPAL COLONY','VIKHROLI W PARK SITE','MUMBAI','21','400086',NULL,'9920701998','',NULL,'27','27BTYPB0293C1ZN','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'120',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2839',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(121,'228',NULL,NULL,'BHOOMI MART',5,'0','DR','SHOP NO 14 MANNA SADAN TEMBIPADA GAVDEVI ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'8291966466','',NULL,'27','27BTEPG8597E1ZB','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'121',NULL,NULL,NULL,NULL,NULL,'11522013000074','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2569',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(122,'228',NULL,NULL,'SIDDHIVINAYAK WHOLESALE MART',5,'0','DR','SHOP NO 2 PLOT NO 91 BLDG C OM SAINATH','VIJAY NAGAR R H B ROAD MULUND W','MUMBAI','21','400080',NULL,'8898864446','',NULL,'27','27BSYPG3258H2Z6','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'122',NULL,NULL,NULL,NULL,NULL,'11522009000206','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1561',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(123,'228',NULL,NULL,'MAHAVIR MART',5,'0','DR','OPP KAMGAR NAGAR','KURLA EAST','','21','',NULL,'7238038026','',NULL,'27','27BRXPG5995F1ZY','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'123',NULL,NULL,NULL,NULL,NULL,'21521033000192','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2781',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(124,'228',NULL,NULL,'MAHARASHTRA GEN STORES',5,'0','DR','PANCHKUTIR','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27BRWPP6895A1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'124',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','236',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(125,'228',NULL,NULL,'KALASH CATERERS',5,'0','DR','A BLDG,2,SUBHASH NAGAR VILLAGE ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'9224620006','',NULL,'27','27BRDPR3298E1ZH','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'125',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2852',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(126,'228',NULL,NULL,'ATHARVA DISTRIBUTORS',5,'0','DR','194 A 7490, 2ND FLOOR, KANNAMWAR NAGAR 2, VIKHROLI E','','MUMBAI','21','',NULL,'','',NULL,'27','27BQKPK8952L1Z1','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'126',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1915',NULL,'0','0',NULL,0,'2026-04-14 10:25:37','2026-04-14 10:25:37'),(127,'228',NULL,NULL,'BALAJI  STORE',5,'0','DR','VILAGE ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27BQIPS7134Q1ZX','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'127',NULL,NULL,NULL,NULL,NULL,'11520013000137','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1344',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(128,'228',NULL,NULL,'NK RATNA MART',5,'0','DR','TAGORE NAGAR','VIKHROLI EAST','MUMBAI','21','',NULL,'','',NULL,'27','27BQCPP1399A1ZW','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'128',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2439',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(129,'228',NULL,NULL,'VIYA TRADING',5,'0','DR','KANJUR E','','MUMBAI','21','400042',NULL,'7738123456','',NULL,'27','27BPXPM9049E1Z5','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'129',NULL,NULL,NULL,NULL,NULL,'201210127102289441','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2185',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(130,'228',NULL,NULL,'SOCIETY GENRAL STORE',5,'0','DR','BHANDUP E','DEFAULT','MUMBAI','21','',NULL,'','',NULL,'27','27BPUPS8603F1ZA','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'130',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','593',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(131,'228',NULL,NULL,'GAMI GENERAL STORE',5,'0','DR','SHOP NO 33 SUPER MARKET AIROLI SECTOR 3','AIROLI','MUMBAI','21','400708',NULL,'7977417425','',NULL,'27','27BPGPP7734C1ZR','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'131',NULL,NULL,NULL,NULL,NULL,'11522015000275','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2461',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(132,'228',NULL,NULL,'SHAKTI OIL MART',5,'0','DR','STATION ROAD','MULUND EST','MUMBAI','21','400081',NULL,'9930045622','',NULL,'27','27BNMPM5001R1ZH','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'132',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1134',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(133,'228',NULL,NULL,'deluxe mart',5,'0','DR','bhatipada','','MUMBAI','21','400078',NULL,'9833929423','',NULL,'27','27BNEPP8329R1Z1','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'133',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2527',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(134,'228',NULL,NULL,'ASHAPURA TRADING',5,'0','DR','SECTOR 25 NOSIL NAKA TALAVALI','GHANSOLI','NAVI MUMBAI','21','400701',NULL,'9702451163','',NULL,'27','27BMOPB9860N1Z9','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'134',NULL,NULL,NULL,NULL,NULL,'21516074000133','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2848',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(135,'228',NULL,NULL,'ROMAN STORE',5,'0','DR','OPP: FIRE BRIAGDE PARKSITE','VIKHROLI W','MUMBAI','21','',NULL,'','',NULL,'27','27BMFPK7919E1ZW','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'135',NULL,NULL,NULL,NULL,NULL,'11515008000326','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2339',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(136,'228',NULL,NULL,'GAURAV CATERERS',5,'0','DR','1/18 ADARSH SOCIETY KRANTI NAGAR','T P ROAD BHANDUP W','MUMBAI','21','',NULL,'8275633011','',NULL,'27','27BLBPP8329Q1ZA','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'136',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2686',NULL,'0','0',NULL,0,'2026-04-14 10:25:38','2026-04-14 10:25:38'),(137,'228',NULL,NULL,'GAJRAJ SOAP CENTER',5,'0','DR','SURYA NAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27BJQPS3128B1Z4','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'137',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1449',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(138,'228',NULL,NULL,'TULSI TRADERS',5,'0','DR','SHOP NO 3637 CHAWAL NO 283','GROUP NO 2 TAGORE NAGAR','MUMBAI','21','',NULL,'','',NULL,'27','27BJFPS2303R2ZQ','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'138',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2015',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(139,'228',NULL,NULL,'BHAGWATI SUPER MARKET',5,'0','DR','LBS ROAD BHANDUP (W)','DEFAULT','MUMBAI','21','400078',NULL,'','',NULL,'27','27BJCPP8783K1ZF','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'139',NULL,NULL,NULL,NULL,NULL,'11516013000329','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1497',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(140,'228',NULL,NULL,'MANISHA DHANYA BHANDAR',5,'0','DR','MULUND E','DEFAULT','MUMBAI','21','400081',NULL,'9987406297','',NULL,'27','27BIOPK2449A1ZC','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'140',NULL,NULL,NULL,NULL,NULL,'11522009000324','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','543',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(141,'228',NULL,NULL,'FRESH POINT',5,'0','DR','SHOP NO 22,23,24, DEEPLAXMI CHS FAROOK SOOMERBHAY ROAD','AGRIPADA BYCULLA','MUMBAI','21','400011',NULL,'9820593989','',NULL,'27','27BHQPK6297M1ZA','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'141',NULL,NULL,NULL,NULL,NULL,'11525002000071','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2893',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(142,'228',NULL,NULL,'DEVANDAS VALLABHDAS',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','400080',NULL,'9930217756','',NULL,'27','27BHMPB1041E1ZW','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'142',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','563',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(143,'228',NULL,NULL,'SHRI SAMARTH AGRO INDUSTRIES',5,'0','DR','UNIT NO 2 NAV NANDANVAN INDUSTRIAL PREMISES SOC.','MULUND W','mumbai','21','400080',NULL,'9322254198','',NULL,'27','27BGWPS8158L1Z4','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'143',NULL,NULL,NULL,NULL,NULL,'11523009000287','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2899',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(144,'228',NULL,NULL,'D.N.OIL TRADERS',5,'0','DR','SHOP NO.2, VIJAY WADI NIWAS,','L.T. ROAD, MULUND EAST','MUMBAI','21','',NULL,'9782524436','',NULL,'27','27BGUPG2211G1ZJ','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'144',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2180',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(145,'228',NULL,NULL,'MAHAVEER GEN STORES',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'8369317220','',NULL,'27','27BENPP5188L1ZK','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'145',NULL,NULL,NULL,NULL,NULL,'11518013000323','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','185',NULL,'0','0',NULL,0,'2026-04-14 10:25:39','2026-04-14 10:25:39'),(146,'228',NULL,NULL,'JALARAM TRADERS',5,'0','DR','SHOP NO 1,2,3,4,5 SAI CHATRA APARTMENT BEHIND MAJIWADA BUS STOP','MAJIWADA THANE W','MUMBAI','21','400601',NULL,'9987640278','',NULL,'27','27BDRPR0203F1ZN','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'146',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2214',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(147,'228',NULL,NULL,'AMBIKA KIRANA GENERAL STORE',5,'0','DR','RAMABAI COLONY','GHATKOPAR EST','MUMBAI','21','400077',NULL,'9004238292','',NULL,'27','27BDNPC6533K1ZA','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'147',NULL,NULL,NULL,NULL,NULL,'2151704100068','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1084',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(148,'228',NULL,NULL,'HET TRADING',5,'0','DR','HARIYALI VILLAGE,TAGORE NAGAR','VIKHROLI EAST','MUMBAI','21','400079',NULL,'1234567890','',NULL,'27','27BDHPC2129P1ZE','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'148',NULL,NULL,NULL,NULL,NULL,'11519013000327','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1617',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(149,'228',NULL,NULL,'AMBIKA STORES',5,'0','DR','PASPOLI VILAGE SAKHI VIHAR ROAD','POWAI','MUMBAI','21','400087',NULL,'9167562524','',NULL,'27','27BDGPP7728C2ZD','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'149',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2735',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(150,'228',NULL,NULL,'SHREE DEV SUPER MARKET',5,'0','DR','MAHADA COLONY','NR: D MART','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27BDBPP4700P1ZA','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'150',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-02-24','0.00',NULL,'0','0',NULL,'0','2058',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(151,'228',NULL,NULL,'SHREE GANESH STORE',5,'0','DR','2/SANTOSHI MATA APATMENT BHATTWADI','GHATKOPER W','MUMBAI','21','',NULL,'9766867952','',NULL,'27','27BCWPK9639N1ZC','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'151',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2277',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(152,'228',NULL,NULL,'SHREE SAI DHAM TRADING',5,'0','DR','BHANDUPE','','MUMBAI','21','400042',NULL,'8779709243','',NULL,'27','27BCIPP1937N1Z0','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'152',NULL,NULL,NULL,NULL,NULL,'21519062000307','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2564',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(153,'228',NULL,NULL,'VIRAT ENTERPRISES',5,'0','DR','KANNAMWAR NAGAR 2','VIKHROLI E','MUMBAI','21','',NULL,'9167452126','',NULL,'27','27BCBPN3704Q1ZA','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'153',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2691',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(154,'228',NULL,NULL,'PRABHAT TRADING CO',5,'0','DR','SHOP NO-5, PLOTNO-234, SEJAL PARK','SECTOR-1, GHANSHOLI, NAVI MUMBAI','MUMBAI','21','',NULL,'','',NULL,'27','27BAUPKZ197P1ZN','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'154',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1796',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(155,'228',NULL,NULL,'NAGARAJ GEN STORES',5,'0','DR','SHOP NO.1-2,RAMKUBAI,ANTA GIRDHARI','CHAWL, BHATTIPADA ROAD,BHANDUP WEST','MUMBAI','21','400078',NULL,'9167594729','',NULL,'27','27BAOPP3444G1ZF','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'155',NULL,NULL,NULL,NULL,NULL,'11519013000088','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','431',NULL,'0','0',NULL,0,'2026-04-14 10:25:40','2026-04-14 10:25:40'),(156,'228',NULL,NULL,'S.N. MART',5,'0','DR','SHOP NO 8/9,SP CHAWL LUCKY NAGAR','J.M. ROAD NEAR SHIVAJI TALAV BHANDUP W','MUMBAI','21','',NULL,'9920958334','',NULL,'27','27BAMPN2457H2ZD','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'156',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2467',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(157,'228',NULL,NULL,'NEW DEVNARAYAN DHANYA BHANDAR',5,'0','DR','AIROLI','DEFAULT','NAVI MUMBAI','21','400708',NULL,'9594892811','',NULL,'27','27AZIPK9334Q1ZI','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'157',NULL,NULL,NULL,NULL,NULL,'11516015000203','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1155',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(158,'228',NULL,NULL,'KALYAN SUPER MARKET',5,'0','DR','ASIAN PAINT KE SAMNE','L.B.S. ROAD','MUMBAI','21','',NULL,'9930387469','',NULL,'27','27AZBPD5602K1ZL','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'158',NULL,NULL,NULL,NULL,NULL,'11520013000087','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','985',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(159,'228',NULL,NULL,'SOHAM SARTHAK ENTERPRISES',5,'0','DR','GROUND FLOOR SHOP NO 2&6, ADITYA TOWER, KANNANMVAR NAGAR ROAD,','VIKHROLI EAST BUS DEPOT,','MUMBAI','21','400083',NULL,'7039753115','',NULL,'27','27AYHPP1098A1ZG','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'159',NULL,NULL,NULL,NULL,NULL,'11523013000201','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2718',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(160,'228',NULL,NULL,'RAJ OIL & TEA DEPOT.',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','',NULL,'','',NULL,'27','27AYDPJ3596P2ZN','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'160',NULL,NULL,NULL,NULL,NULL,'11517013000537','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','191',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(161,'228',NULL,NULL,'Rajaram Dhanya Bhandar',5,'0','DR','Kanjur E','','MUMBAI','21','400042',NULL,'9833030537','',NULL,'27','27AXYPP9933C1ZP','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'161',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1844',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(162,'228',NULL,NULL,'RACHITA STORES',5,'0','DR','NR: VILAS STORE STATION ROAD','VIKHROLI E','MUMBAI','21','400079',NULL,'8369007892','',NULL,'27','27AXKPS0389P1ZH','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'162',NULL,NULL,NULL,NULL,NULL,'11521013000128','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2430',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(163,'228',NULL,NULL,'LUCKY KIRANA & GENRAL STORE.',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','400080',NULL,'7738111666','',NULL,'27','27AWQPB5608P1ZY','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'163',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','567',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(164,'228',NULL,NULL,'KRISH GEN. STORE',5,'0','DR','MAHAPE','NAVI MUMBAI','MUMBAI','21','',NULL,'','',NULL,'27','27AWMPP9735B1Z5','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'164',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1527',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(165,'228',NULL,NULL,'SIKING SUPER MARKET',5,'0','DR','SHOP NO.D/9-10, CHANDIWALI, POWAI','','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AWGPP5954L1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'165',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2365',NULL,'0','0',NULL,0,'2026-04-14 10:25:41','2026-04-14 10:25:41'),(166,'228',NULL,NULL,'CHEHAR ENTERPRISES',5,'0','DR','GALA NO.29, MADANI ESTATE MULUND GOREGAON LINK ROAD BEHIND HOTEL SUDARSHAN BHANDUP W','','MUMBAI','21','',NULL,'9987153329','',NULL,'27','27AWDPP4334G1ZM','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'166',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2554',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(167,'228',NULL,NULL,'RAMESH DHANYA BHANDAR',5,'0','DR','SHOP NO.10, SHIVSHAKTI NAGAR, SAKHI VIHAR ROAD TUNGA','POWAI','MUMBAI','21','400076',NULL,'9820992583','',NULL,'27','27AVVPP4781H1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'167',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2364',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(168,'228',NULL,NULL,'RAMESH DHANYA BHANDAR',5,'0','DR','POWAI NR: GANESH SUPER','','MUMBAI','21','400076',NULL,'8928161760','',NULL,'27','27AVVPP4781H1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'168',NULL,NULL,NULL,NULL,NULL,'11521007000528','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2778',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(169,'228',NULL,NULL,'SHIVKRIPA STORE',5,'0','DR','SAI HILL','BHANDUP W','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27AVPPK7236C1ZF','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'169',NULL,NULL,NULL,NULL,NULL,'21515063000003','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','481',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(170,'228',NULL,NULL,'MUKESH TRADERS',5,'0','DR','SHOP NO 7/8/9, NATRAJ MARKET SECTOR 17, NR POST OFFICE, AIROLI','NAVI MUMBAI','MUMBAI','21','400708',NULL,'8779663528','',NULL,'27','27AVFPS1385L1Z0','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'170',NULL,NULL,NULL,NULL,NULL,'11518015000245','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','736',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(171,'228',NULL,NULL,'ROYAL SUPER MARKET',5,'0','DR','RUNWAL FOREST CLUBHOSE SHOP NO 6/7 NEAR MANGATRAM','PETROL PUMP L.B.S ROAD KANJURMARG W','MUMBAI','21','400078',NULL,'7900192744','',NULL,'27','27AUMPP7952L1ZP','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'171',NULL,NULL,NULL,NULL,NULL,'11522013000151','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2802',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(172,'228',NULL,NULL,'VAISHNAVI TRADING',5,'0','DR','OPP: PARAS STORE','KANJUR E','MUMBAI','21','400042',NULL,'9967067062','',NULL,'27','27AUIPJ7689L1ZP','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'172',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1979',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(173,'228',NULL,NULL,'SHREE MOMAJI SUPAR MARKET',5,'0','DR','SHOP NO.6, RB KADAM MARG NR: JALARAM MANDIR BARVE NAGAR','GHATKOPER W','MUMBAI','21','',NULL,'9920175906','',NULL,'27','27AUAPC2180K1Z0','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'173',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2350',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(174,'228',NULL,NULL,'PRINT 2 MEDIA',5,'0','DR','C/126,GHATKOPAR IND ESTATE','BEHIND R CITY MALL','MUMBAI','21','',NULL,'9821441256','',NULL,'27','27ATUPP4931A1ZH','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'174',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1982',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(175,'228',NULL,NULL,'SHREE KARAN OIL TRADERS',5,'0','DR','46/370, MOTILAL NAGAR NO-1, ROAD NO.10,','GOREGAON','MUMBAI','21','400104',NULL,'','',NULL,'27','27ATOPD7978D1Z8','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'175',NULL,NULL,NULL,NULL,NULL,'11520009000273','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2183',NULL,'0','0',NULL,0,'2026-04-14 10:25:42','2026-04-14 10:25:42'),(176,'228',NULL,NULL,'S L AGARBATTI COMPANY',5,'0','DR','BHANDUP','','MUMBAI','21','',NULL,'','',NULL,'27','27ATCPS3236M1ZB','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'176',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-10-28','0.00',NULL,'0','0',NULL,'0','2141',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(177,'228',NULL,NULL,'GUPTA OIL DEPOT',5,'0','DR','TUNGA VILAGE','POWAI','MUMBAI','21','400076',NULL,'7977404525','',NULL,'27','27ASVPG9509M1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'177',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2576',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(178,'228',NULL,NULL,'NEW ANNPURTI BHANDAR',5,'0','DR','P.K ROAD   27950764804V','MULUND(W)','MUMBAI','21','400080',NULL,'9029824336','',NULL,'27','27ASKPG5149E1ZQ','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'178',NULL,NULL,NULL,NULL,NULL,'11517009000278','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','400',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(179,'228',NULL,NULL,'SADGURU TRADERS',5,'0','DR','16/1, MULCHAND NIWAS , UTKARSH','NAGAR,','MUMBAI','21','400078',NULL,'7738543848','',NULL,'27','27ARXPB5449G1ZD','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'179',NULL,NULL,NULL,NULL,NULL,'21519063000137','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-01-27','0.00',NULL,'0','0',NULL,'0','2051',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(180,'228',NULL,NULL,'MATESHWARI TRADERS',5,'0','DR','SHRAMA CHAWL PATHKAR COMPOUND','TULSETPADA GAVDEVI ROAD','MUMBAI','21','400042',NULL,'8856123456','',NULL,'27','27ARMPP8844J1ZY','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'180',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1643',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(181,'228',NULL,NULL,'ROYAL MARKETING',5,'0','DR','NR: JAIN MANDIR, GROUND FLOOR, PLOT NO 492B,','TURBHE GAON , SECTOR -22, TURBHE, NAVI MUMBAI','THANE','21','400705',NULL,'9324401825','',NULL,'27','27AQWPP4057C1ZG','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'181',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2707',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(182,'228',NULL,NULL,'GURU PRASAD FOODS',5,'0','DR','DUBEY COMPOUND OPP JAY SHASTRI NAGAR','NAER SAI BABA TEMPLE MULUND COLONY MULUND W','MUMBAI','21','400082',NULL,'9757439863','',NULL,'27','27AQUPK7847B1ZD','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'182',NULL,NULL,NULL,NULL,NULL,'11519009000647','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','790',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(183,'228',NULL,NULL,'MEGHDOOT GRAHAK BHANDAR',5,'0','DR','JOBDAYA LANE, 11-GIRIDHAR NAGAR,','NR MANGALAM STORE, BHATWADI  GHATKOPER WEST','MUMBAI','21','400086',NULL,'9326215205','',NULL,'27','27AQSPS8432N1ZR','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'183',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2249',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(184,'228',NULL,NULL,'R.R. TRADES',5,'0','DR','GADAVNAKA','BHANDUP W','MUMBAI','21','400078',NULL,'8097484798','',NULL,'27','27AQQPP8689L1ZH','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'184',NULL,NULL,NULL,NULL,NULL,'21521062000136','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','472',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(185,'228',NULL,NULL,'SHREE TRADERS',5,'0','DR','TUNGA POWAI','','MUMBAI','21','400076',NULL,'9324873428','',NULL,'27','27AQKPG4682Q1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'185',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2725',NULL,'0','0',NULL,0,'2026-04-14 10:25:43','2026-04-14 10:25:43'),(186,'228',NULL,NULL,'PREET TRADING',5,'0','DR','PRATAP NAGAR','BHANDUP W','MUMBAI','21','',NULL,'9987597712','',NULL,'27','27AQJPC3227G1Z4','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'186',NULL,NULL,NULL,NULL,NULL,'21518062000061','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2494',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(187,'228',NULL,NULL,'GOYAL TRADERS & GENERAL STORE',5,'0','DR','RABALE.','','MUMBAI','21','400708',NULL,'9867662892','',NULL,'27','27APYPG9833J1Z0','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'187',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2516',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(188,'228',NULL,NULL,'MITRASH MARKETING',5,'0','DR','8, KAILASH CASTLE , V.B LANE  OPP: ODEON SHOPING CENTER','GHATKOPER E','MUMBAI','21','',NULL,'9892966706','',NULL,'27','27APMPS0206F1Z0','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'188',NULL,NULL,NULL,NULL,NULL,'11517008000287','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2285',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(189,'228',NULL,NULL,'NEW PRAKASH GEN STORE',5,'0','DR','SHOP NO.10, GROUND FLOOR , GOMES TOWER SRA,','BEHIND NAAZ HOTEL KURLA W','MUMBAI','21','',NULL,'9594337244','',NULL,'27','27APBPB9360C1Z9','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'189',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2291',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(190,'228',NULL,NULL,'HARI OM SUPER MARKET',5,'0','DR','AIROLI SECTOR-3','','MUMBAI','21','400708',NULL,'9004723684','',NULL,'27','27AOVPB2238Q1ZB','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'190',NULL,NULL,NULL,NULL,NULL,'11519015000396','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1083',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(191,'228',NULL,NULL,'NEW SOCIETY CENTRE',5,'0','DR','UTTKARSH NAGAR','BHANDUP W','MUMBAI','21','',NULL,'','',NULL,'27','27AOUPG2059P1Z6','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'191',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1245',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(192,'228',NULL,NULL,'BHANU GENERAL STORES',5,'0','DR','PARK SITE','VIKHROLI W','MUMBAI','21','',NULL,'','',NULL,'27','27AOTPB9204N1ZF','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'192',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1075',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(193,'228',NULL,NULL,'ASHIRWAD GRAHAK BHANDAR',5,'0','DR','BHANDUP E','DEFAULT','MUMBAI','21','400078',NULL,'1564567890','',NULL,'27','27AOIPB5074M1ZO','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'193',NULL,NULL,NULL,NULL,NULL,'1151903000228','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','585',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(194,'228',NULL,NULL,'SUMMET GEN STORE',5,'0','DR','BUILDING NO 157 NAIDU COLONY','GHATKOPER E','MUMBAI','21','',NULL,'9821633752','',NULL,'27','27AOFPG1688F3ZV','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'194',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2346',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(195,'228',NULL,NULL,'SURYAVANSHI OIL DEPO',5,'0','DR','PARKSIDE','VIKHROLI WEST','MUMBAI','21','',NULL,'','',NULL,'27','27ANYPM5736E1ZF','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'195',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1379',NULL,'0','0',NULL,0,'2026-04-14 10:25:44','2026-04-14 10:25:44'),(196,'228',NULL,NULL,'SURYA GRAIN STORE',5,'0','DR','PARKSIDE','VIKRHOLI WEST','MUMBAI','21','400083',NULL,'9892748474','',NULL,'27','27ANYPM5735H1ZA','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'196',NULL,NULL,NULL,NULL,NULL,'11517008000278','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1377',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(197,'228',NULL,NULL,'RASHI OIL DEPOT',5,'0','DR','NR: MAHARASHTRA SOCIETY','KANJURMARG W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27ANYPD6575C1ZL','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'197',NULL,NULL,NULL,NULL,NULL,'21518064000069','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1973',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(198,'228',NULL,NULL,'BHARAT GENRAL STORE',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','400080',NULL,'8779709243','',NULL,'27','27ANSPS9717P1ZN','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'198',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','558',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(199,'228',NULL,NULL,'GURUKRIPA CATRING SERVICE.',5,'0','DR','DAYKORT COLONY','9892765233','MUMBAI','21','400083',NULL,'9892765233','',NULL,'27','27ANOPG1678H1ZO','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'199',NULL,NULL,NULL,NULL,NULL,'2151706500012','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1714',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(200,'228',NULL,NULL,'JAIN JAGRUTI STORE',5,'0','DR','TANK ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'8965242613','',NULL,'27','27ANLPS6380B1ZQ','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'200',NULL,NULL,NULL,NULL,NULL,'11518013000111','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','791',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(201,'228',NULL,NULL,'NEW MAHAVIR TRADERS',5,'0','DR','GALA NO B1 NR: JANGLESHWAR MANDIR ROAD','ASALFA VILAGE','MUMBAI','21','',NULL,'9702635687','',NULL,'27','27ANLPJ5171FIZW','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'201',NULL,NULL,NULL,NULL,NULL,'11518007000336','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2191',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(202,'228',NULL,NULL,'NEW MAHALAXMI GEN STORES',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7506493014','',NULL,'27','27ANGPS2358Q1Z6','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'202',NULL,NULL,NULL,NULL,NULL,'21512023001168','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','184',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(203,'228',NULL,NULL,'Om Shri Arihant Store',5,'0','DR','Shop No 2 Swami Suvidha Chsl R.r.t. Road Mulund W','','MUMBAI','21','400080',NULL,'','',NULL,'27','27ANAPB3371J1Z8','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'203',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1877',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(204,'228',NULL,NULL,'Om Shri Arihant Store',5,'0','DR','SHOP NO 6 RAMESHWAR APT ,MURAR ROAD, OPP ANTRIKSH TOWER','MULUND W','MUMBAI','21','400080',NULL,'9769598999','',NULL,'27','27ANAPB3371J1Z8','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'204',NULL,NULL,NULL,NULL,NULL,'11519009000032','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1878',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(205,'228',NULL,NULL,'VAMIKA TRADERS',5,'0','DR','ROOM NO 65 PIPARMENT ESTATE APP DOMINOS PIZZA','L B S ROAD BHANDUP W','MUMBAI','21','400078',NULL,'9892161212','',NULL,'27','27AMUPB3626R1ZC','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'205',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2589',NULL,'0','0',NULL,0,'2026-04-14 10:25:45','2026-04-14 10:25:45'),(206,'228',NULL,NULL,'SHREE SIDHIVINAYAK TRADERS',5,'0','DR','DINABAMA PATIL STATE STN ROAD','BHANDUP (W)','MUMBAI','21','400078',NULL,'','',NULL,'27','27AMUPB3626R1ZC','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'206',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1490',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(207,'228',NULL,NULL,'M.S. TRADERS CO.',5,'0','DR','AIROLI SEC-8','AIROLI','MUMBAI','21','',NULL,'','',NULL,'27','27AMTPD4014A2ZH','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'207',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1452',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(208,'228',NULL,NULL,'MANILALS PREMIUM GROCERY SHOP',5,'0','DR','SHOP NO 2 , OPP: BLDG NO.8, TAGORE, NAGAR ,','VIKHROLI EAST','MUMBAI','21','400079',NULL,'9769319931','',NULL,'27','27AMOPS5678N1ZT','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'208',NULL,NULL,NULL,NULL,NULL,'11525013000074','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2388',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(209,'228',NULL,NULL,'JANTA PROVISION STORE',5,'0','DR','KANJUR E','27350691511V','MUMBAI','21','400042',NULL,'9773581492','',NULL,'27','27AMJPD6227B1ZF','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'209',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','616',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(210,'228',NULL,NULL,'BHAVESH GEN STORES',5,'0','DR','RAMGHAD NAGAR,GOSALA ROAD','MULUND W','MUMBAI','21','400080',NULL,'9833152290','',NULL,'27','27AMHPG7044F1Z5','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'210',NULL,NULL,NULL,NULL,NULL,'11519009000725','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1703',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(211,'228',NULL,NULL,'KAMDHENU SUPER SHOPPY',5,'0','DR','MULUND EAST','DEFAULT','MUMBAI','21','400081',NULL,'1234567890','',NULL,'27','27AMGPR3521F1Z5','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'211',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1457',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(212,'228',NULL,NULL,'SHRI DEV SUPER MARKET',5,'0','DR','OPP SHIV SAGAR SWEET','HIRANANDANI POWAI VIHAR POWAI','MUMBAI','21','400076',NULL,'9833576060','',NULL,'27','27AMEPC4721A2ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'212',NULL,NULL,NULL,NULL,NULL,'11521013000226','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2763',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(213,'228',NULL,NULL,'SHREE DEV SUPER MARKET',5,'0','DR','POWAI VIHAR','OPP. SAGAR SWEET','MUMBAI','21','400072',NULL,'9773846192','',NULL,'27','27AMEPC4721A2ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'213',NULL,NULL,NULL,NULL,NULL,'11521013000226','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','895',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(214,'228',NULL,NULL,'RAJPAL PRODUCT',5,'0','DR','SHOP NO 9 JAYANTI APT OPP TMT BUS STOP','J.S.D.ROAD MULUND W','MUMBAI','21','400080',NULL,'9930670044','',NULL,'27','27AMBPR8745E1ZS','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'214',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2719',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(215,'228',NULL,NULL,'PRABHAT SUPER BAZAR',5,'0','DR','POWAI VIHAR','POWAI','MUMBAI','21','400076',NULL,'8208889590','',NULL,'27','27ALXPV6431A1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'215',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','882',NULL,'0','0',NULL,0,'2026-04-14 10:25:46','2026-04-14 10:25:46'),(216,'228',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','VIDHYALAY ROAD  MOB.9967871386','OPP.T.P.JAIN','MUMBAI','21','400081',NULL,'9967871386','',NULL,'27','27ALVPG8506H1Z0','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'216',NULL,NULL,NULL,NULL,NULL,'21521045000462','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1544',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(217,'228',NULL,NULL,'NEW MAHAVIR GENERAL STORES',5,'0','DR','RAMABAI COLONY','GHATKOPAR','MUMBAI','21','400077',NULL,'9773846192','',NULL,'27','27ALUPC6272B1Z2','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'217',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1754',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(218,'228',NULL,NULL,'MILLENIUM  STORES',5,'0','DR','TUNGA VILLAGE','POWAI 27210699348V','MUMBAI','21','400072',NULL,'9773853474','',NULL,'27','27ALRPP9982G1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'218',NULL,NULL,NULL,NULL,NULL,'21519031000924','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','258',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(219,'228',NULL,NULL,'SIRVI BANDU SUPER MARKET',5,'0','DR','AIROLI SEC-8','AIROLI','MUMBAI','21','400708',NULL,'9870704540','',NULL,'27','27ALRPC0580F1Z6','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'219',NULL,NULL,NULL,NULL,NULL,'11517015000135','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','706',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(220,'228',NULL,NULL,'ATMARAM KIRANA STORES',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7456321450','',NULL,'27','27ALQPK5963M1Z7','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'220',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','183',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(221,'228',NULL,NULL,'BALAJI MART',5,'0','DR','SHOP NO 11,PLOT NO 14/15 SHIV COMPLEX SEC 3','GHANSOLI NAVI MUMBAI','NAVI MUMBAI','21','400701',NULL,'7021199253','',NULL,'27','27ALOPC4039J1ZY','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'221',NULL,NULL,NULL,NULL,NULL,'11521015000387','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2867',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(222,'228',NULL,NULL,'MAHIMA AGENCY 9820658356',5,'0','DR','TANK ROAD, OPP-: SAVLA STORES','SHANKAR MANDIR,BHANDUP W','MUMBAI','21','',NULL,'','',NULL,'27','27ALJPG2192B1ZE','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'222',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1829',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(223,'228',NULL,NULL,'OM SUPER MARKET',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9004995220','',NULL,'27','27ALGPC1407Q1Z2','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'223',NULL,NULL,NULL,NULL,NULL,'11521008000197','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','193',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(224,'228',NULL,NULL,'JAISWAL BROTHERS',5,'0','DR','ANTOP HILL','','MUMBAI','21','',NULL,'','',NULL,'27','27ALAPJ1011B1Z4','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'224',NULL,NULL,NULL,NULL,NULL,'11518003000036','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1934',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(225,'228',NULL,NULL,'MAHAVIR OIL AND SOAP',5,'0','DR','NEELYOG APARTMENT B-1 SHOP NO7','GAURI SHANKAR WADI NO.2 PANT NAGAR','MUMBAI','21','400075',NULL,'9769573713','',NULL,'27','27AKZPD0244J1ZX','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'225',NULL,NULL,NULL,NULL,NULL,'11517008000142','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2441',NULL,'0','0',NULL,0,'2026-04-14 10:25:47','2026-04-14 10:25:47'),(226,'228',NULL,NULL,'ORCHID SUPER MARKET',5,'0','DR','SHOP NO.3, PIONER GLASS BULDING KURLA ROAD','GHATKOPER W','MUMBAI','21','',NULL,'7710808353','',NULL,'27','27AKUPA4676L1ZH','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'226',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2261',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(227,'228',NULL,NULL,'JAI AMBE GEN STORES',5,'0','DR','MORAJI NAGAR AREY COLONY ROAD','','POWAI','21','400087',NULL,'9702305088','',NULL,'27','27AKOPP3487E1ZO','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'227',NULL,NULL,NULL,NULL,NULL,'21519065000019','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2722',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(228,'228',NULL,NULL,'LAXMI GEN STORES',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7455898941','',NULL,'27','27AKMPP2036R1ZG','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'228',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','170',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(229,'228',NULL,NULL,'ARADHANA STORES',5,'0','DR','HARIYALI VILLAGE','VIKHROLI(E)','MUMBAI','21','400079',NULL,'8779709243','',NULL,'27','27AKJPG8306N1ZR','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'229',NULL,NULL,NULL,NULL,NULL,'11519013000343','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','324',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(230,'228',NULL,NULL,'HARI OM MASALA CENTER',5,'0','DR','VILLAGE ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27AKGPS9349L1Z9','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'230',NULL,NULL,NULL,NULL,NULL,'11517013000236','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','923',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(231,'228',NULL,NULL,'SHREE GANESH KRIPA KIRANA',5,'0','DR','GHANSOLI','DEFAULT','NAVI MUMBAI','21','400701',NULL,'9702763962','',NULL,'27','27AKFPD8097F1ZZ','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'231',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1213',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(232,'228',NULL,NULL,'SHREE HARI ENTERPRISES',5,'0','DR','SHOP NO.5, TALVALI NAKA , PATIL COMPOUND, STAION ROAD RABALE .','','THANE','21','400701',NULL,'8422018919','',NULL,'27','27AKDPP6839M1ZG','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'232',NULL,NULL,NULL,NULL,NULL,'11522015000254','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2766',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(233,'228',NULL,NULL,'JEBA TRADERS',5,'0','DR','P.K. ROAD OPP: BAKTH SANGAM MULUND W','','MUMBAI','21','400080',NULL,'1234567890','',NULL,'27','27AKCPN0725F1ZH','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'233',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1907',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(234,'228',NULL,NULL,'A.S.SUPARI',5,'0','DR','HARIYALI VILLAGE','VIKHROLI E','MUMBAI','21','400083',NULL,'9594292927','',NULL,'27','27AKBPS6217Q1ZJ','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'234',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','921',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(235,'228',NULL,NULL,'RAMDEV DHANYA BHANDAR',5,'0','DR','RAMABAI, GHATKOPER','DEFAULT','MUMBAI','21','400077',NULL,'9082449105','',NULL,'27','27AKBPC2839A1ZS','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'235',NULL,NULL,NULL,NULL,NULL,'11521008000309','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1832',NULL,'0','0',NULL,0,'2026-04-14 10:25:48','2026-04-14 10:25:48'),(236,'228',NULL,NULL,'MAHARASHTRA KIRANA STORE',5,'0','DR','SURYA NAGAR-2','VIKHROLI W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AKAPB8171B1ZN','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'236',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','632',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(237,'228',NULL,NULL,'KANAIYA MASALA',5,'0','DR','21,SAI INFOTECH PATEL CHOWK','GHATKOPAR EAST','MUMBAI','21','400077',NULL,'9773846192','',NULL,'27','27AJYPR7775C1ZB','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'237',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2202',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(238,'228',NULL,NULL,'SAHYOG OIL & CHEMICAL INDUSTRY',5,'0','DR','KHINDIPADA','MULUND WEST','MUMBAI','21','400080',NULL,'9004445580','',NULL,'27','27AJRPP5535D1ZW','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'238',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1123',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(239,'228',NULL,NULL,'MANISH ENTERPRISE',5,'0','DR','L.B.S. ROAD','NR. THANE SAHAKARI BANK','MUMBAI','21','400078',NULL,'9594102580','',NULL,'27','27AJPPD7230H1Z6','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'239',NULL,NULL,NULL,NULL,NULL,'11519013000360','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','757',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(240,'228',NULL,NULL,'JEEL PROVISION STORES',5,'0','DR','LBS MARG','BHANDUP(W)','MUMBAI','21','',NULL,'8424927573','',NULL,'27','27AJKPM2085J1ZU','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'240',NULL,NULL,NULL,NULL,NULL,'11518013000003','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','428',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(241,'228',NULL,NULL,'R.L. SHAH',5,'0','DR','MULUND E','DEFAULT','MUMBAI','21','',NULL,'','',NULL,'27','27AJKPB1588P1ZN','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'241',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','529',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(242,'228',NULL,NULL,'KIRTI SUPER MARKET',5,'0','DR','MHADHA COLONY','POWAI','MUMBAI','21','',NULL,'','',NULL,'27','27AJFPC3643K1Z9','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'242',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','248',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(243,'228',NULL,NULL,'CLASSIC SUPER STORES',5,'0','DR','POWAI','DEFAULT','MUMBAI','21','400076',NULL,'9224415523','',NULL,'27','27AIYPD2656B1Z7','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'243',NULL,NULL,NULL,NULL,NULL,'11519013000364','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1741',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(244,'228',NULL,NULL,'SAI DHANYA BHANDAR',5,'0','DR','BHANDUP E','DEFAULT','MUMBAI','21','400042',NULL,'4567891230','',NULL,'27','27AIWPT0388A1ZU','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'244',NULL,NULL,NULL,NULL,NULL,'11519013000374','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','598',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(245,'228',NULL,NULL,'NEELKANTH SUPER MARKET',5,'0','DR','SHOP NO3/4 KANAN APARTMENT PMC BANK','NR AMRUT NAGAR  GHATKOPER W','MUMBAI','21','',NULL,'7039336697','',NULL,'27','27AIWPB2784Q2ZA','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'245',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2242',NULL,'0','0',NULL,0,'2026-04-14 10:25:49','2026-04-14 10:25:49'),(246,'228',NULL,NULL,'NILKANTH SUPER MARKET',5,'0','DR','GROUND FLOOR UNIT NO A/128/02,JANGLESHWAR','INDUSTRIES PREMISES CHANDIVALI SANGHARSH NAGAR','MUMBAI','21','400072',NULL,'7400279812','',NULL,'27','27AIWPB2784Q1ZB','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'246',NULL,NULL,NULL,NULL,NULL,'11521007000361','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2834',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(247,'228',NULL,NULL,'SANDIP OIL DEPOT.',5,'0','DR','SURYANAGAR 2','OPP RAJESH STORE','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AITPN8086G1ZG','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'247',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1295',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(248,'228',NULL,NULL,'NEW MAHARASHTRA GRAIN STORE',5,'0','DR','HARIYALI VILLAGE','VIKHROLI EST','MUMBAI','21','400079',NULL,'9968123456','',NULL,'27','27AIOPG7089F1ZT','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'248',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1204',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(249,'228',NULL,NULL,'JAI AMBE STORE',5,'0','DR','SURYANAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AIJPG1386L1ZX','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'249',NULL,NULL,NULL,NULL,NULL,'11513013003229','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','652',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(250,'228',NULL,NULL,'GANESH SUPER MARKET',5,'0','DR','OPP: SHANTI SAMRUTI BLDG','S.V. ROAD','MUMBAI','21','400072',NULL,'7977715211','',NULL,'27','27AIHPR3216L2ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'250',NULL,NULL,NULL,NULL,NULL,'11521007000272','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2160',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(251,'228',NULL,NULL,'PUNAGIRI SUPER MARKET',5,'0','DR','HARIYALI VILLAGE','VIKHROLI(E)','MUMBAI','21','',NULL,'','',NULL,'27','27AIGPD1423Q1Z7','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'251',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','318',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(252,'228',NULL,NULL,'D.S.ENTERPRIES',5,'0','DR','GALA NO 6 KOYLA COMPOUND','PARSI PANCHAYAT ROAD,PUMP HOUSE','MUMBAI','21','',NULL,'','',NULL,'27','27AIFPP5245H1Z3','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'252',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1787',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(253,'228',NULL,NULL,'RAM PRATAP GRAIN & GEN STORES',5,'0','DR','SHOP NO 2&3,SHANTI COMPLEX, SHIVSHAKTI NAGAR','POWAI','MUMBAI','21','400072',NULL,'9004126751','',NULL,'27','27AIBPG1407A1Z6','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'253',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2844',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(254,'228',NULL,NULL,'CHAMUNDA TRADERS',5,'0','DR','GHANSHOLI SECTOR 4','','MUMBAI','21','400701',NULL,'9082253856','',NULL,'27','27AIAPD5652R1ZW','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'254',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2627',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(255,'228',NULL,NULL,'SANTOSHI GRAIN STORE',5,'0','DR','SURYANAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AHZPG2709E1Z6','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'255',NULL,NULL,NULL,NULL,NULL,'21517062000058','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','646',NULL,'0','0',NULL,0,'2026-04-14 10:25:50','2026-04-14 10:25:50'),(256,'228',NULL,NULL,'ROSHAN FOODS',5,'0','DR','J.N. ROAD','MULUND W','MUMBAI','21','',NULL,'9820647407','',NULL,'27','27AHYPA6004B1ZN','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'256',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2487',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(257,'228',NULL,NULL,'SHREE BAUCHAR JI TRADERS',5,'0','DR','SECTOR 3','GHANSHOLI','MUMBAI','21','400701',NULL,'9987871585','',NULL,'27','27AHXPP1592L1ZD','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'257',NULL,NULL,NULL,NULL,NULL,'11520015000259','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1106',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(258,'228',NULL,NULL,'HITESH DHANYA BHANDAR',5,'0','DR','GAVDEVI','BHANDUP W','MUMBAI','21','',NULL,'','',NULL,'27','27AHRPV7879C1ZE','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'258',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','825',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(259,'228',NULL,NULL,'NEW MAYUR STORES',5,'0','DR','VILLAGE ROAD','BHANDUP(W)','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27AHQPM9184N1Z7','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'259',NULL,NULL,NULL,NULL,NULL,'21517063000043','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','410',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(260,'228',NULL,NULL,'KRUSHNA SUPER MARKET',5,'0','DR','GHANSHOLI','NEW MUMBAI','MUMBAI','21','400701',NULL,'9833828642','',NULL,'27','27AHQPC5263N1ZT','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'260',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','773',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(261,'228',NULL,NULL,'BHARAT GRAIN STORES',5,'0','DR','BHANDUP(W)','DEFAULT','MUMBAI','21','400078',NULL,'9082186059','',NULL,'27','27AHJPB2374A1ZU','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'261',NULL,NULL,NULL,NULL,NULL,'11517013000093','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','433',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(262,'228',NULL,NULL,'A1 SUPER STORE',5,'0','DR','VINA NAGAR','MULUND W','MUMBAI','21','400080',NULL,'9819094196','',NULL,'27','27AHDPR0544G1ZG','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'262',NULL,NULL,NULL,NULL,NULL,'11516009000521','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1519',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(263,'228',NULL,NULL,'LAXMI STORE',5,'0','DR','MAHADA COLONY','MULUND E','MUMBAI','21','400081',NULL,'1234567890','',NULL,'27','27AHDPB1711D1Z7','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'263',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','518',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(264,'228',NULL,NULL,'BAGDAD OIL DEPOT',5,'0','DR','PARKSITE','VIKHROLI(W)','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AGZPC4370L1ZS','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'264',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','113',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(265,'228',NULL,NULL,'KHANDOBHA STORE',5,'0','DR','KANJUR E','9870830412','MUMBAI','21','',NULL,'','',NULL,'27','27AGVPP2265F1ZW','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'265',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1822',NULL,'0','0',NULL,0,'2026-04-14 10:25:51','2026-04-14 10:25:51'),(266,'228',NULL,NULL,'NEW MAHARASTRA GRAIN STORES',5,'0','DR','SURYANAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'9772515662','',NULL,'27','27AGVPG4337P1ZC','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'266',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','812',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(267,'228',NULL,NULL,'BECHAN BADU GUPTA',5,'0','DR','TUNGA VILLAGE','POWAI','MUMBAI','21','',NULL,'','',NULL,'27','27AGUPG9234G1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'267',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1310',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(268,'228',NULL,NULL,'MAHARAJA TRADERS',5,'0','DR','BLDG. NO. 108, GALA NO. 10 GROUND FLOOR INDIAN CORPORATION COMPOUND OPP GAJANAN PETROL PUMP','BIWANDI THANE','MUMBAI','21','421302',NULL,'9867080079','',NULL,'27','27AGQPJ9920N1ZK','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'268',NULL,NULL,NULL,NULL,NULL,'11521013000009','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2207',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(269,'228',NULL,NULL,'SHREE DATTAKRUPA GENERAL',5,'0','DR','HARIYALI VILLAGE','VIKHROLI EAST','MUMBAI','21','400079',NULL,'9963123456','',NULL,'27','27AGNPP1592M1ZN','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'269',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1761',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(270,'228',NULL,NULL,'JAI AMBE KIRANA AND GENERAL STORE',5,'0','DR','AIROLI SEC-8','AIROLI','MUMBAI','21','400708',NULL,'8080671533','',NULL,'27','27AGMPT3487E1ZV','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'270',NULL,NULL,NULL,NULL,NULL,'11516015000250','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1463',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(271,'228',NULL,NULL,'MAHADEV TRADING CO.',5,'0','DR','VISHWAKARMA CHAWL R.P.ROAD JAWAHAR','MULUND W 02264640093','MUMBAI','21','',NULL,'','',NULL,'27','27AGLPV2957Q1Z8','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'271',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1645',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(272,'228',NULL,NULL,'RAJESH DRYA FRUT',5,'0','DR','NEAR OSWAL SUPER MARKET','MULUND W','MUMBAI','21','',NULL,'','',NULL,'27','27AGKPR4573R1ZB','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'272',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1917',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(273,'228',NULL,NULL,'SHREE ASHAPURA OIL TRADING CO.',5,'0','DR','GALA NO 2,SUBHASH NAGAR J.M.MANDIR ROAD','ASALPHA VILLAGE GATKOPAR W','MUMBAI','21','',NULL,'022025145439','',NULL,'27','27AGKPK4844N1ZS','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'273',NULL,NULL,NULL,NULL,NULL,'11518007000094','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2182',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(274,'228',NULL,NULL,'BHAVESH GEN STORES',5,'0','DR','S.L.ROAD','MULUND(W)','MUMBAI','21','400080',NULL,'9773846192','',NULL,'27','27AGKPK2411M1ZB','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'274',NULL,NULL,NULL,NULL,NULL,'11516009000054','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','437',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(275,'228',NULL,NULL,'DHANIYAN SWEETS & FARSAN',5,'0','DR','SHOP NO3, BLDG NO.25, NR: KOTAK MAHINDRA BANK,','TILAK NAGAR, CHEMBUR , MUMBAI','MUMBAI','21','400077',NULL,'9702017058','',NULL,'27','27AGJPP4726B1ZG','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'275',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2694',NULL,'0','0',NULL,0,'2026-04-14 10:25:52','2026-04-14 10:25:52'),(276,'228',NULL,NULL,'GUPTA CORNER',5,'0','DR','MORAJI NAGAR, AARE ROAD,','NR:PIMPLESHWAR MANDIR ,','POWAI','21','400076',NULL,'9892778368','',NULL,'27','27AGHPG4502G1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'276',NULL,NULL,NULL,NULL,NULL,'1152101300027','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2728',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(277,'228',NULL,NULL,'J.J. AGRAWAL',5,'0','DR','AIROLI NAKA SECTOR 01.','','MUMBAI','21','400708',NULL,'9768393814','',NULL,'27','27AGCPA4205B1ZC','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'277',NULL,NULL,NULL,NULL,NULL,'11520015000102','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2771',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(278,'228',NULL,NULL,'PARAS GRAIN STORES',5,'0','DR','KANJUR E','DEFAULT','MUMBAI','21','400042',NULL,'8777970924','',NULL,'27','27AFXPG3171N1ZR','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'278',NULL,NULL,NULL,NULL,NULL,'11517013000066','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','614',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(279,'228',NULL,NULL,'AVANTI DRY FRUIT',5,'0','CR','R.R.T ROAD OPP DENA BANK','MULUND W','MUMBAI','21','400080',NULL,'9757411822','',NULL,'27','27AFSPM2714E1ZE','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'279',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1255',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(280,'228',NULL,NULL,'MOMAI ENTERPRISES',5,'0','DR','LINK TOWER SHOP NO.5, HIRA NAGAR','MULUND W','MUMBAI','21','400080',NULL,'9833937243','',NULL,'27','27AFRPP7858M1Z8','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'280',NULL,NULL,NULL,NULL,NULL,'11518009000346','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1147',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(281,'228',NULL,NULL,'SHREE SACHHA MAA KIRANA BHANDAR',5,'0','DR','JANGAL MANGAL ROAD','BHATTI PADA','MUMBAI','21','',NULL,'','',NULL,'27','27AFOPM4582L1ZP','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'281',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1266',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(282,'228',NULL,NULL,'NILESH OIL DEPOT',5,'0','DR','SURYANAGAR-2','VIKHROLI W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AFOPD4266Q1ZR','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'282',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','650',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(283,'228',NULL,NULL,'VORA PROVISAN & DRY FRUIET',5,'0','DR','SAPNA NAGARI','MULUND W','MUMBAI','21','',NULL,'','',NULL,'27','27AFMPC4625A1ZW','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'283',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1938',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(284,'228',NULL,NULL,'SUPER BAZAR GEN STORES',5,'0','DR','SHIVAJI CHOWK','VIKHROLI(E)','MUMBAI','21','400079',NULL,'8779770970','',NULL,'27','27AFHPV4778A1Z4','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'284',NULL,NULL,NULL,NULL,NULL,'11519013000367','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','346',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(285,'228',NULL,NULL,'CHAMUNDA GRAIN STORE',5,'0','DR','SHOP NO.7/90 FEET ROAD','GHTKOPER E NAIDU COLONY','MUMBAI','21','',NULL,'7710978891','',NULL,'27','27AFFPC0085B1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'285',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2272',NULL,'0','0',NULL,0,'2026-04-14 10:25:53','2026-04-14 10:25:53'),(286,'228',NULL,NULL,'SHREE GURUKRUPA TRADERS',5,'0','DR','TAGORE NAGAR','VIKHROLI EAST','MUMBAI','21','400079',NULL,'9224442718','',NULL,'27','27AEZPC5120Q2ZV','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'286',NULL,NULL,NULL,NULL,NULL,'11522013000297','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2688',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(287,'228',NULL,NULL,'HARI OM SUPER MARKET',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9869762528','',NULL,'27','27AEXPC6823L1ZW','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'287',NULL,NULL,NULL,NULL,NULL,'11518013000077','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','231',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(288,'228',NULL,NULL,'S P TRADERS',5,'0','DR','C-3,PARAS MILL COMPOUND,L.B.S ROAD NEAR JOY HOMES','BHANDUP WEST','MUMBAI','21','400078',NULL,'9867265672','',NULL,'27','27AEXFS7639J1ZX','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'288',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2679',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(289,'228',NULL,NULL,'OSWAL SUPER MARKET',5,'0','DR','S.L.ROAD','MULUND (W)','MUMBAI','21','400080',NULL,'8879410105','',NULL,'27','27AEWPC7543J1ZY','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'289',NULL,NULL,NULL,NULL,NULL,'11517009000264','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1635',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(290,'228',NULL,NULL,'NEELKAMAL STORE',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AEUPD5876K1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'290',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','229',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(291,'228',NULL,NULL,'DAKSH SUPER MARKET',5,'0','DR','VIKHROLI(E)','NR.BUS DEPOT','MUMBAI','21','400079',NULL,'7424567890','',NULL,'27','27AETPG9116N1ZS','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'291',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','366',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(292,'228',NULL,NULL,'SLOK TRADERS',5,'0','DR','P.K ROAD','MULUND(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AETPB2541N1Z6','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'292',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','399',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(293,'228',NULL,NULL,'ISHWAR OIL DEPOT.',5,'0','DR','SHOP NO.2, NAKODA BHIRAV CHS DEVI DAS ROAD, WHOLESALE MARKET THANE.','','MUMBAI','21','',NULL,'9892551831','',NULL,'27','27AEQPB1195K1Z7','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'293',NULL,NULL,NULL,NULL,NULL,'11515014000885','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2500',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(294,'228',NULL,NULL,'S B FOOD PRODUCTS',5,'0','DR','LAKE ROAD BHANDUP W','','MUMBAI','21','',NULL,'8779709243','',NULL,'27','27AEQFS0896C1ZM','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'294',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2675',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(295,'228',NULL,NULL,'SHRI SAI SIDDHI GEN STORES',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7474562310','',NULL,'27','27AEPPG1742J1ZC','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'295',NULL,NULL,NULL,NULL,NULL,'11517013000502','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','171',NULL,'0','0',NULL,0,'2026-04-14 10:25:54','2026-04-14 10:25:54'),(296,'228',NULL,NULL,'SHREE DADAL MAA DHANYA BHANDAR',5,'0','DR','BHANDUP(W)','DEFAULT','MUMBAI','21','',NULL,'','',NULL,'27','27AENPG3627E1Z9','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'296',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','432',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(297,'228',NULL,NULL,'VIMAL INDUSTRIES',5,'0','DR','GALA NO. 28,','KANJURMARG W, HIRANADANI INDUSTRAIL','MUMBAI','21','',NULL,'','',NULL,'27','27AELPG3378N1ZW','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'297',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1720',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(298,'228',NULL,NULL,'VAGAD SUPER MARKET',5,'0','DR','AIROLI SEC 19','','NNAVI MUMBAI','21','400708',NULL,'9820379468','',NULL,'27','27AEKPM6429D1ZE','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'298',NULL,NULL,NULL,NULL,NULL,'11515015000211','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2745',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(299,'228',NULL,NULL,'HINGLAJ GRAIN STORES',5,'0','DR','PARKSITE','VIKHROLI(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AEGPR5568G1Z1','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'299',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','130',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(300,'228',NULL,NULL,'TANVI HOSPITALITY',5,'0','DR','STATION ROAD BHNADUP W','BHANDUP W','MUMBAI','21','',NULL,'','',NULL,'27','27AEFPV5904B1ZK','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'300',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2362',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(301,'228',NULL,NULL,'RAJESH STORE',5,'0','DR','SURYANAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'9892042733','',NULL,'27','27AEFPC1084F1ZW','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'301',NULL,NULL,NULL,NULL,NULL,'11518013000175','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','649',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(302,'228',NULL,NULL,'SIRVI STORE',5,'0','DR','SURYANAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'9969537862','',NULL,'27','27AEFPC1062H1ZY','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'302',NULL,NULL,NULL,NULL,NULL,'11516013000098','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','648',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(303,'228',NULL,NULL,'SAHU GEN STORES',5,'0','DR','TUNGA VILLAGE','POWAI','MUMBAI','21','400072',NULL,'9004446275','',NULL,'27','27AECPS3045M1Z7','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'303',NULL,NULL,NULL,NULL,NULL,'21520031000455','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','254',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(304,'228',NULL,NULL,'P.B.TRADERS',5,'0','DR','MULUND(W)','DEFAULT','MUMBAI','21','',NULL,'','',NULL,'27','27AECPJ8931R1ZT','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'304',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','449',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(305,'228',NULL,NULL,'ASHTVINAYAK SWEETS & FARSAN MART',5,'0','DR','bhandup w','T.P ROAD GADAVNAKA','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27ADUPG9488K1ZG','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'305',NULL,NULL,NULL,NULL,NULL,'11522013000255','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','666',NULL,'0','0',NULL,0,'2026-04-14 10:25:55','2026-04-14 10:25:55'),(306,'228',NULL,NULL,'UMESH  STORE',5,'0','DR','SONAPUR','BHANDUP WEST','MUMBAI','21','',NULL,'','',NULL,'27','27ADUPG9366J1ZP','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'306',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1038',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(307,'228',NULL,NULL,'LOKPRIYA GEN STORES',5,'0','DR','VILLAGE ROAD','BHANDUP(W)','MUMBAI','21','',NULL,'','',NULL,'27','27ADSPC2464K1Z8','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'307',NULL,NULL,NULL,NULL,NULL,'11512013002194','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','418',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(308,'228',NULL,NULL,'VIJAY GRAIN STORE',5,'0','DR','NARENDRA BHAVAN SHOP NO 1&2','OPP PROFESSIONAL COURIER','MUMBAI','21','400083',NULL,'9820260180','',NULL,'27','27ADQPD3963Q1ZR','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'308',NULL,NULL,NULL,NULL,NULL,'11519010000039','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1436',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(309,'228',NULL,NULL,'DURGA STORES',5,'0','DR','SHOP NO 5 DR DAMJI SADAN JETHABHAN LANE','RAIGAD CHK GHATKOPAR EAST','MUMBAI','21','400077',NULL,'8425908807','',NULL,'27','27ADQPB8843B1ZJ','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'309',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2201',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(310,'228',NULL,NULL,'SHIVRAJ (MULUND)',5,'0','DR','M.G.ROAD NEAR AMBAJI DHAM TEMPLE','MULUND W','MUMBAI','21','400080',NULL,'8268832062','',NULL,'27','27ADLFS4359N1Z8','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'310',NULL,NULL,NULL,NULL,NULL,'11520003000009','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2928',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(311,'228',NULL,NULL,'SHIVRAJ',5,'0','DR','SHOP NO.2, TRAFFIC LITE BUILDING NR BANK OF BARODA ,','MG ROAD NAVPADA GHATKOPER W','MUMBAI','21','400086',NULL,'9819068984','',NULL,'27','27ADLFS4359N1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'311',NULL,NULL,NULL,NULL,NULL,'11519008000481','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2290',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(312,'228',NULL,NULL,'SHIVRAJ',5,'0','DR','SHOP NO 2 ,TRAFFICLITE BULDING,NEAR BANK OF BARODA M.G. ROAD','GHATKOPAR W','MUMBAI','21','400086',NULL,'9819068984','',NULL,'27','27ADLFS4359N1Z8','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'312',NULL,NULL,NULL,NULL,NULL,'11519008000481','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2190',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(313,'228',NULL,NULL,'SHIVRAJ',5,'0','DR','GROUND FLOOR R ODEON MALL ,ODEON CINEMA','NEAR VALLABH BHAG LANE GHATKOPAR E MUMBAI 400077','MUMBAI','21','400086',NULL,'8779709243','',NULL,'27','27ADLFS4359N1Z8','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'313',NULL,NULL,NULL,NULL,NULL,'11518008000013','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-01-17','0.00',NULL,'0','0',NULL,'0','2046',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(314,'228',NULL,NULL,'SHIVRAJ',5,'0','DR','R NO 3227/234, GROUND FLOOR VIKHROLI GURU DARSHAN CHS LTD NEAR BMC SCHOOL','TAGORE NAGAR VIKHROLI EAST','MUMBAI','21','400083',NULL,'8828619377','',NULL,'27','27ADLFS4359N1Z8','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'314',NULL,NULL,NULL,NULL,NULL,'11525008000252','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2926',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(315,'228',NULL,NULL,'SHIVRAJ',5,'0','DR','SHOP NO 10 GROUND FLOOR R MALL L.B.S. MARG','MULUND W','MUMBAI','21','400080',NULL,'8828619377','',NULL,'27','27ADLFS4359N1Z8','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'315',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2678',NULL,'0','0',NULL,0,'2026-04-14 10:25:56','2026-04-14 10:25:56'),(316,'228',NULL,NULL,'Siddhi Sweet & Snacks',5,'0','DR','Airoli','','MUMBAI','21','',NULL,'','',NULL,'27','27ADLFS2263F1ZY','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'316',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1838',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(317,'228',NULL,NULL,'KISHORE OIL CENTER',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7474561236','',NULL,'27','27ADKPJ0969J1Z5','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'317',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','169',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(318,'228',NULL,NULL,'A1 SWEET AND FARSHAN',5,'0','DR','STATION ROAD','','MUMBAI','21','400079',NULL,'9773846192','',NULL,'27','27ADIPJ4581C1ZM','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'318',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2177',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(319,'228',NULL,NULL,'SHREE MAHAVIR OIL INDUSTRIES',5,'0','DR','PARASNATH COMPLEX,','BLDG NO B-13, GALA NO12','MUMBAI','21','',NULL,'','',NULL,'27','27ADIFS7945P1Z1','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'319',NULL,NULL,NULL,NULL,NULL,'11518018000596','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2019-12-08','0.00',NULL,'0','0',NULL,'0','2038',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(320,'228',NULL,NULL,'GAYATRI GENERAL STORES',5,'0','DR','SHOP-04,PIOT-21,SHREE AMBIKA DARSAN','SOCITY,GHANSOLI SECTOR-3','MUMBAI','21','',NULL,'','',NULL,'27','27ADHPP2520J1ZJ','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'320',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1109',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(321,'228',NULL,NULL,'NEW GANESH DAIRY',5,'0','DR','NEAR CHARAN STORES','SAI HILL','MUMBAI','21','',NULL,'','',NULL,'27','27ADGPK430Q1Z3','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'321',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1619',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(322,'228',NULL,NULL,'GANESH OIL CO.',5,'0','DR','GALA NO.4, SAINATH NAGAR, RETIBUNDER','PARSIK NAGAR, KALWA','THANE','21','400605',NULL,'9768666664','',NULL,'27','27ACZPY3997M1ZX','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'322',NULL,NULL,NULL,NULL,NULL,'11520014000396','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2711',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(323,'228',NULL,NULL,'PRATIK AGENCY',5,'0','DR','MULUND COLONY','MULUND WEST','MUMBAI','21','400080',NULL,'9653300896','',NULL,'27','27ACYPA1424A1Z1','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'323',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2549',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(324,'228',NULL,NULL,'ASHAPURA GRAIN STORES',5,'0','DR','SHOP NO 4 KALLU SHETH CHAWL DHOBI GHAT','OPP HINDI BAL MANDIR GHATKOPAR W','MUMBAI','21','400072',NULL,'9022655698','',NULL,'27','27ACXPB9953A1ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'324',NULL,NULL,NULL,NULL,NULL,'21522031000035','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2712',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(325,'228',NULL,NULL,'EKVIRA GRAIN STORE',5,'0','DR','NANEPADA','MULUND E','MUMBAI','21','400081',NULL,'9323613586','',NULL,'27','27ACLPJ1285D1ZO','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'325',NULL,NULL,NULL,NULL,NULL,'11521009008606','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','533',NULL,'0','0',NULL,0,'2026-04-14 10:25:57','2026-04-14 10:25:57'),(326,'228',NULL,NULL,'S.S.SALES',5,'0','DR','4.LAXMI NIWAS, JAI MAHARASHTRA SOCIETY','PRATAP NAGAR ROAD BHANDUP W','MUMBAI','21','400078',NULL,'9892366671','',NULL,'27','27ACIFS0012Q1ZX','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'326',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2596',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(327,'228',NULL,NULL,'SHREE LAXMINARAYAN TRADING CO.',5,'0','DR','SHOP NO.33 , OPP: PAPER MILL','SURYANAGAR','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27ACGFS8232G1ZY','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'327',NULL,NULL,NULL,NULL,NULL,'11519013000330','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2013',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(328,'228',NULL,NULL,'A1 SUPER MARKET',5,'0','DR','SURYANAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'7021217126','',NULL,'27','27ACEPF8513B1Z2','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'328',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1286',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(329,'228',NULL,NULL,'PRAKASH STORE',5,'0','DR','SAI HILL','BHANDUP W','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27ACDPJ6360R1Z1','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'329',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','480',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(330,'228',NULL,NULL,'SAHKAR DHANYA BHANDAR',5,'0','DR','MULUND EST','DEFAULT','MUMBAI','21','400081',NULL,'9820304086','',NULL,'27','27ACCPB7678P1ZZ','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'330',NULL,NULL,NULL,NULL,NULL,'11516009000543','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1422',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(331,'228',NULL,NULL,'ARVENIKA ENTERPRISE',5,'0','DR','SHOP NO 2&3,BLDG NO 34 GURU KRIPA CHS','TAGORE NAGAR VIKHROLI EAST','MUMBAI','21','400079',NULL,'9833161654','',NULL,'27','27ACBFA4422B1Z3','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'331',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2695',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(332,'228',NULL,NULL,'A 1 SALES',5,'0','DR','19-1 SAMRAT SLIK MILL COMPOUND','L.B.S.ROAD .','MUMBAI','21','400083',NULL,'8657811452','',NULL,'27','27ACAPV2528G1ZL','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'332',NULL,NULL,NULL,NULL,NULL,'1152100800384','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2680',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(333,'228',NULL,NULL,'ASMITA GEN STORES',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','',NULL,'','',NULL,'27','27ABZPN8054F1ZZ','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'333',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','187',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(334,'228',NULL,NULL,'MAHARASHTRA DHANYA BHANDAR',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27ABYPP7065P2ZB','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'334',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','200',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(335,'228',NULL,NULL,'MAYUR GEN STORES',5,'0','DR','SHIVAJI CHOWK','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9820242333','',NULL,'27','27ABQPV0030J1ZF','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'335',NULL,NULL,NULL,NULL,NULL,'11517013000514','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','360',NULL,'0','0',NULL,0,'2026-04-14 10:25:58','2026-04-14 10:25:58'),(336,'228',NULL,NULL,'ANKITA STORES',5,'0','DR','DEVI DAYAL ROAD','MULUND W','MUMBAI','21','400080',NULL,'9137027639','',NULL,'27','27ABQPT0863K1ZY','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'336',NULL,NULL,NULL,NULL,NULL,'30210903108676343','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','955',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(337,'228',NULL,NULL,'NANDU OIL TRADERS',5,'0','DR','2 VIJAY WADI OPP: OMKAR HOSPITAL','HANUMAN CHOWK LT ROAD','MUMBAI','21','400081',NULL,'7666666172','',NULL,'27','27ABQPN9437P1ZI','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'337',NULL,NULL,NULL,NULL,NULL,'11519009000632','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','541',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(338,'228',NULL,NULL,'SARGAM STORES',5,'0','DR','M.G.ROAD','MULUND WEST','MUMBAI','21','400080',NULL,'8779709243','',NULL,'27','27ABPFS4594M1Z5','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'338',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1124',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(339,'228',NULL,NULL,'MY TRAGET CORP',5,'0','DR','NOOR MOHU CHAWL , LBS MARG ,\\\'','GHATKOPER W','MUMBAI','21','',NULL,'','',NULL,'27','27ABPFM3482L1ZK','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'339',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2447',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(340,'228',NULL,NULL,'Apna Star Parivaar Enterprises Lip',5,'0','DR','shop no 621/622,gokhale road,','Near Mulund Railway Station Mulund E','MUMBAI','21','',NULL,'8692870453','',NULL,'27','27ABOFA6395D1Z4','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'340',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1959',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(341,'228',NULL,NULL,'asia grain center',5,'0','DR','a/7/8/9 nehru nagar','kurla E','MUMBAI','21','',NULL,'','',NULL,'27','27ABNFA3414E1ZP','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'341',NULL,NULL,NULL,NULL,NULL,'11517007000270','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2217',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(342,'228',NULL,NULL,'LAXMI GEN STORES',5,'0','DR','SHOP NO 5 PARABH SHOPPING CENTER','KOKAN NAGAR BHANDUP W','MUMBAI','21','400078',NULL,'9920584980','',NULL,'27','27ABKPR4081R2ZP','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'342',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1157',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(343,'228',NULL,NULL,'SHIV SHAKTI GENERAL TORE',5,'0','DR','THANE','','MUMBAI','21','',NULL,'','',NULL,'27','27ABDPD2742E1Z6','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'343',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1891',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(344,'228',NULL,NULL,'MAXOIL ENTERPRISES',5,'0','DR','F/07 SINDHI PLAZA PADWAL NAGAR FISH MARKET','THANE WEST','MUMBAI','21','400604',NULL,'9987187013','',NULL,'27','27AAZFM8713H3ZJ','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'344',NULL,NULL,NULL,NULL,NULL,'11518007000642','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2229',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(345,'228',NULL,NULL,'BHARAT KUMAR VINOD CHANDRA & CO.',5,'0','DR','R.R.T.ROAD','MULUND(W)','MUMBAI','21','400080',NULL,'9869054690','',NULL,'27','27AAYFB9581D1ZT','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'345',NULL,NULL,NULL,NULL,NULL,'11522009000143','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','435',NULL,'0','0',NULL,0,'2026-04-14 10:25:59','2026-04-14 10:25:59'),(346,'228',NULL,NULL,'RATNA SUPER MARKET',5,'0','DR','NEAR ST. PIUS CHURCH P.K.ROAD MULUND W','','MUMBAI','21','400080',NULL,'7452412460','',NULL,'27','27AAWFR0187M1ZC','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'346',NULL,NULL,NULL,NULL,NULL,'11517009000650','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1901',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(347,'228',NULL,NULL,'JALARAM  OIL CENTRE',5,'0','DR','M.G ROAD','MULUND(W)','MUMBAI','21','400080',NULL,'9820505748','',NULL,'27','27AAVPH7153A1ZN','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'347',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','405',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(348,'228',NULL,NULL,'VISHAL SUPER MARKET',5,'0','DR','SHOP NO.8,9,10, NEELIMA APARTMENT, J.M. ROAD,','NR: ABHYUDAYA BANK BHANDUP W, MUMBAI 400078','MUMBAI','21','400078',NULL,'8828619377','',NULL,'27','27AAUFV2731M1ZG','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'348',NULL,NULL,NULL,NULL,NULL,'11521013000202','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2469',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(349,'228',NULL,NULL,'KAVYA SUPER MARKET',5,'0','DR','AIROLI SEC 8','','MUMBAI','21','400708',NULL,'8779709248','',NULL,'27','27AAUFK9332P1ZA','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'349',NULL,NULL,NULL,NULL,NULL,'11519015000347','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2777',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(350,'228',NULL,NULL,'AARDEE SUPER MART (PVT)  LTD',5,'0','DR','AMBEDAKAR ROAD MULUND W','','MUMBAI','21','',NULL,'','',NULL,'27','27AATCA6580D1ZC','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'350',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-10-05','0.00',NULL,'0','0',NULL,'0','2129',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(351,'228',NULL,NULL,'TANISHA SUPER MARKET',5,'0','DR','NR: DMART','POWAI','MUMBAI','21','',NULL,'','',NULL,'27','27AASHS4031D1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'351',NULL,NULL,NULL,NULL,NULL,'11519007000684','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1928',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(352,'228',NULL,NULL,'SHIVSHAKTI GENRAL STORE',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','400080',NULL,'9370266305','',NULL,'27','27AARPT1758K1ZV','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'352',NULL,NULL,NULL,NULL,NULL,'11516009000016','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','551',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(353,'228',NULL,NULL,'AMRUT AYURVEDIC AUSHADHALAY',5,'0','DR','STATION ROAD MULUND W','','MUMBAI','21','400080',NULL,'8779709243','',NULL,'27','27AAQHP2565R1Z4','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'353',NULL,NULL,NULL,NULL,NULL,'21521045000196','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2682',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(354,'228',NULL,NULL,'SORATHIYA & CO.',5,'0','DR','RAMESH GHAR,138 T.H. KATARIYA MARG','MATUNGA ROAD W','MUMBAI','21','400016',NULL,'9819024097','',NULL,'27','27AAQFS7068G1ZK','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'354',NULL,NULL,NULL,NULL,NULL,'11517004000787','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2701',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(355,'228',NULL,NULL,'SUPERMARKET GROCERY SUPPLIES PVT.LTD.',5,'0','DR','ABC GODOWN, MINERVA INDUSTRIAL ESTATE, PK ROAD, MULUND W','','MUMBAI','21','400080',NULL,'','',NULL,'27','27AAQCS4503H1Z6','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'355',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1895',NULL,'0','0',NULL,0,'2026-04-14 10:26:00','2026-04-14 10:26:00'),(356,'228',NULL,NULL,'PAYAL ENTERPRISES',5,'0','DR','105,1ST FLOOR SHIVAJI MARKET PLOT NO 8 & 9','SECTOR 19-D VASHI','NAVI MUMBAI','21','400703',NULL,'9892177585','',NULL,'27','27AAPFP8500P1ZI','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'356',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2845',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(357,'228',NULL,NULL,'JASHMIN SUPER MARKET',5,'0','DR','KANJUR E','DEFAULT','MUMBAI','21','400042',NULL,'8657614161','',NULL,'27','27AAPFJ5140H1Z7','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'357',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','622',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(358,'228',NULL,NULL,'GEETA SUPER MARKET',5,'0','DR','3/SHIV CO.HSG.SOC.LTD TANDON NIWAS','J M ROAD BHANDUP W 9619106968','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27AAPFG4027Q1ZR','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'358',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1427',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(359,'228',NULL,NULL,'NEW TAJ OIL DEPOT',5,'0','DR','STATION ROAD','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7456891230','',NULL,'27','27AAOFN5643E1Z2','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'359',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','344',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(360,'228',NULL,NULL,'JAI RUSHBH ENTERPRISES',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','',NULL,'','',NULL,'27','27AANPS1369P1ZR','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'360',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1742',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(361,'228',NULL,NULL,'JASH ENTERPRISES',5,'0','DR','SHOP NO 1,ANANDI HEIGHTS ,G.G.ROAD,MULUND W','','MUMBAI','21','400080',NULL,'','',NULL,'27','27AANFJ0713C1ZQ','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'361',NULL,NULL,NULL,NULL,NULL,'11517009000416','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1896',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(362,'228',NULL,NULL,'JANTA GARIN STORE',5,'0','DR','GAWANPADA','MULUND E','MUMBAI','21','400081',NULL,'9820577583','',NULL,'27','27AAMPS3545C1ZL','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'362',NULL,NULL,NULL,NULL,NULL,'11516009000109','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','547',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(363,'228',NULL,NULL,'SACHAMA GEN STORES',5,'0','DR','PRATAP NAGAR','BHANDUP(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AAMPG2526K1ZL','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'363',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','281',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(364,'228',NULL,NULL,'MULUND DHANYA BHANDAR',5,'0','DR','J.N.ROAD','MULUND(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AALFM8429Q1ZB','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'364',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','444',NULL,'0','0',NULL,0,'2026-04-14 10:26:01','2026-04-14 10:26:01'),(365,'228',NULL,NULL,'VISHAL TRADERS',5,'0','DR','JANGAL MANGAL ROAD','BHANDUP WEST','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27AAKFM0066A1ZO','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'365',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1267',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(366,'228',NULL,NULL,'JAI PARMA MAA SUPERMARKET',5,'0','DR','AIROLI','AIROLI','MUMBAI','21','400708',NULL,'9773846192','',NULL,'27','27AAKFJ6700C1ZM','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'366',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1219',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(367,'228',NULL,NULL,'HOME FOODS SUPERMARKET',5,'0','DR','GROUND FLOOR GALA NO-43 TO 50 KOHINOOR','CITY MALL PREMIER ROAD KURLA WEST','MUMBAI','21','400070',NULL,'7777020058','',NULL,'27','27AAKFH4284P1ZM','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'367',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2854',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(368,'228',NULL,NULL,'LINK SUPER MARKET',5,'0','DR','SHOP NO.1, GROUND FLOOR, FATIMA MANZIL, ASALFA VILAGE , LINK ROAD','GHATKOPER W','MUMBAI','21','',NULL,'8828533512','',NULL,'27','27AAJFL4159J1ZX','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'368',NULL,NULL,NULL,NULL,NULL,'20210504102532607','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2299',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(369,'228',NULL,NULL,'HARIYA SUPER MART',5,'0','DR','VINA NAGAR','MULUND W','MUMBAI','21','400080',NULL,'9619137813','',NULL,'27','27AAJFH6986P1ZA','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'369',NULL,NULL,NULL,NULL,NULL,'11516009000522','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1520',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(370,'228',NULL,NULL,'SAI JYOTI GEN. STORE',5,'0','DR','SONAPUR','NR: MARUTI GEN. STORE','MUMBAI','21','',NULL,'','',NULL,'27','27AAIPP5199B1ZG','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'370',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1682',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(371,'228',NULL,NULL,'BALAJI SUPER MARKET',5,'0','DR','VINA NAGAR','MULUND W','MUMBAI','21','400080',NULL,'1234567890','',NULL,'27','27AAIPB5738J1ZK','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'371',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','583',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(372,'228',NULL,NULL,'PILLAI & IYERS ECOM PRIVATE LTD',5,'0','DR','SHOP NO 1,OPP DR SAMANT BANGLOW,HARE KRISHNA ROAD','CHAITANYA NAGAR IIT MARKET POWAI','MUMBAI','21','400076',NULL,'9930525850','',NULL,'27','27AAICP3697F1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'372',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-11-12','0.00',NULL,'0','0',NULL,'0','2147',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(373,'228',NULL,NULL,'SHAH JAYNTILAL VIRPAR',5,'0','DR','KANJUR E','DEFAULT','MUMBAI','21','400042',NULL,'1234567890','',NULL,'27','27AAHPS7110E1ZT','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'373',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','774',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(374,'228',NULL,NULL,'D BAZAR',5,'0','DR','VILLAGE ROAD','BHANDUP WEST','MUMBAI','21','400078',NULL,'8779709243','',NULL,'27','27AAHFD0113C1Z8','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'374',NULL,NULL,NULL,NULL,NULL,'11516013000080','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1361',NULL,'0','0',NULL,0,'2026-04-14 10:26:02','2026-04-14 10:26:02'),(375,'228',NULL,NULL,'NAGRIK STORE',5,'0','DR','STATION ROAD','MULUND WEST','MUMBAI','21','400080',NULL,'9322899766','',NULL,'27','27AAGPS5406A1ZZ','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'375',NULL,NULL,NULL,NULL,NULL,'11517009000192','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1289',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(376,'228',NULL,NULL,'GHELANI STORES',5,'0','DR','HINGWALA LANE','GHATKOPAR EAST','MUMBAI','21','400077',NULL,'9702939030','',NULL,'27','27AAGPS2642Q1Z2','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'376',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2199',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(377,'228',NULL,NULL,'GHELANI STORE',5,'0','DR','HONGWALA LANE SALIBHADRA BUILDING','RAJAWADI  GHATKOPER EAST','MUMBAI','21','400075',NULL,'9322212751','',NULL,'27','27AAGPS2642Q1Z2','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'377',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2251',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(378,'228',NULL,NULL,'BHAKTI SUPER MARKET',5,'0','DR','POWAI','','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AAGPP0036M1ZL','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'378',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-03-14','0.00',NULL,'0','0',NULL,'0','2071',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(379,'228',NULL,NULL,'SAHYOG BHANDAR NX',5,'0','DR','BHATIPADA','BAHNDUP W','MUMBAI','21','400078',NULL,'9821336333','',NULL,'27','27AAGHD1313M1ZG','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'379',NULL,NULL,NULL,NULL,NULL,'11518009000258','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1725',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(380,'228',NULL,NULL,'KHIMSIA GRAIN &PROVISION STORES',5,'0','DR','R.H.B.ROAD','MULUND(W)','MUMBAI','21','400080',NULL,'9820421777','',NULL,'27','27AAGFK5997E1ZW','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'380',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','463',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(381,'228',NULL,NULL,'ADI GANESH GEN STORES',5,'0','DR','J.N.ROAD','MULUND(W)','MUMBAI','21','400080',NULL,'8779709248','',NULL,'27','27AAGFA5586K1ZO','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'381',NULL,NULL,NULL,NULL,NULL,'11519009000219','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','439',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(382,'228',NULL,NULL,'CONCUNSMART MARKETING & SERVICES PVT L DAILY SHOP',5,'0','DR','KANTILAL MAGANLAL ESTATE','PANNALAL SILK MILLS COMPOUND L.B.S. MARG','MUMBAI','21','',NULL,'7715854746','',NULL,'27','27AAGCC3588E1ZJ','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'382',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2031',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(383,'228',NULL,NULL,'SHAH PREMJI VELJI',5,'0','DR','G G ROAD BHEEM WADI','MULUND W','MUMBAI','21','400080',NULL,'1234567890','',NULL,'27','27AAFPG5950N1ZC','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'383',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','957',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(384,'228',NULL,NULL,'RAJ ENTERPRISES',5,'0','DR','MULUND W','DEFAULT','MUMBAI','21','',NULL,'','',NULL,'27','27AAFFR3613R1ZQ','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'384',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1724',NULL,'0','0',NULL,0,'2026-04-14 10:26:03','2026-04-14 10:26:03'),(385,'228',NULL,NULL,'MOMAI MAA MASALA',5,'0','DR','MIRANI NAGAR','MULUND W','MUMBAI','21','400080',NULL,'8928178831','',NULL,'27','27AAFFM7907H1Z3','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'385',NULL,NULL,NULL,NULL,NULL,'11516009000135','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','822',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(386,'228',NULL,NULL,'SAVLA GRAIN STORE',5,'0','DR','KANJUR L.B.S. ROAD','KANJUR W','MUMBAI','21','400083',NULL,'9773846192','',NULL,'27','27AAEPS5131Q1Z6','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'386',NULL,NULL,NULL,NULL,NULL,'21518064000194','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','627',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(387,'228',NULL,NULL,'H.V.SAVLA PROVISION STORE',5,'0','DR','SHOPNO.8, KANJUR ESTATE,','STATION ROAD,','MUMBAI','21','400083',NULL,'9833766742','',NULL,'27','27AAEPS5121N1ZE','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'387',NULL,NULL,NULL,NULL,NULL,'11518013000324','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','628',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(388,'228',NULL,NULL,'DHEDIYA GENRAL STORE',5,'0','DR','KANJUR E','DEFAULT','MUMBAI','21','400042',NULL,'8108951944','',NULL,'27','27AAEPD8794J1Z8','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'388',NULL,NULL,NULL,NULL,NULL,'11517013000381','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','619',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(389,'228',NULL,NULL,'MANOJ DHANYA BHANDAR',5,'0','DR','GADAVNAKA','BHANDUP W','MUMBAI','21','400078',NULL,'9892886099','',NULL,'27','27AAEPB3746N1ZK','','',NULL,NULL,'','19',NULL,NULL,NULL,NULL,NULL,'389',NULL,NULL,NULL,NULL,NULL,'21519062000369','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','678',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(390,'228',NULL,NULL,'URVI FOODS',5,'0','DR','MIDC RABALE, 9967710156','DEFAULT','MUMBAI','21','',NULL,'','',NULL,'27','27AAEFU3329E1ZA','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'390',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1737',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(391,'228',NULL,NULL,'MAHARASHTRA GRAIN STORE',5,'0','DR','STATION ROAD','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7456982655','',NULL,'27','27AAEFM8768K1ZK','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'391',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','354',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(392,'228',NULL,NULL,'HARIRAM JAWHARMAL',5,'0','DR','SHOP NO.41, 42, NR: BUILDING NO.1,','KOPRI COLONY , TAHNE EAST','MUMBAI','21','400603',NULL,'9969260082','',NULL,'27','27AAEFH1748Q1ZV','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'392',NULL,NULL,NULL,NULL,NULL,'11519014000395','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2550',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(393,'228',NULL,NULL,'CHANDAN STORE DD',5,'0','DR','SHOP NO 5&6 , GROUND FLOOR','B WING HOTEL PEARL BLDG 19 TH ROAD CHEMBUR','MUMBAI','21','400071',NULL,'9867969001','',NULL,'27','27AAEFC5841P1Z0','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'393',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-09-26','0.00',NULL,'0','0',NULL,'0','2128',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(394,'228',NULL,NULL,'OSCAR SUPER MARKET',5,'0','DR','M.G.ROAD,NEAR SHIV SENA SAKHA','MULUND W','MUMBAI','21','',NULL,'','',NULL,'27','27AAEF05103G1ZK','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'394',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1339',NULL,'0','0',NULL,0,'2026-04-14 10:26:04','2026-04-14 10:26:04'),(395,'228',NULL,NULL,'EMPYREAL LINEAGE PVT LTD',5,'0','DR','NS ROAD NR: POLICE STATION','MULUND W','MUMBAI','21','',NULL,'8779709243','',NULL,'27','27AAECE8590L1Z0','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'395',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2583',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(396,'228',NULL,NULL,'VASANT OIL DEPOT',5,'0','DR','J.N.ROAD','MULUND(W)','MUMBAI','21','400080',NULL,'9833680995','',NULL,'27','27AADPS1241A1Z9','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'396',NULL,NULL,NULL,NULL,NULL,'11521009000376','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','448',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(397,'228',NULL,NULL,'DEEPAK PROVISON STORE.',5,'0','DR','BHANDUP(W)','DEFAULT','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27AADPM8564A1ZR','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'397',NULL,NULL,NULL,NULL,NULL,'11515013000023','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','434',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(398,'228',NULL,NULL,'SANGAM GEN STORES',5,'0','DR','VILLAGE ROAD','BHANDUP(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AADPJ0438Q1ZG','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'398',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','412',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(399,'228',NULL,NULL,'SHREE ODHAVRAM STORES',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846193','',NULL,'27','27AADPG0179M1ZL','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'399',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','205',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(400,'228',NULL,NULL,'MATESHRI FOODS',5,'0','DR','SANGEETA ENCLAVE,SHOP NO 8.OPP DATTA MANDIR SARVODAYA NAGAR','MULUND WEST','MUMBAI','21','400080',NULL,'9167433127','',NULL,'27','27AADHJ5469F1Z3','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'400',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2519',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(401,'228',NULL,NULL,'KUVARJI KHIMRAJ &CO',5,'0','DR','NULLBAZAR MARKET , MUMBAI 132/134 APPA BUILDING, S.V. ROAD ,','NULL BAZAR-','MUMBAI','21','400003',NULL,'9819408666','',NULL,'27','27AADFK9069Q1ZF','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'401',NULL,NULL,NULL,NULL,NULL,'11519001000312','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2555',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(402,'228',NULL,NULL,'OYE BAZZAR SUPER MARTS PVT LTD',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','',NULL,'8291532297','',NULL,'27','27AADCO5094J1Z2','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'402',NULL,NULL,NULL,NULL,NULL,'21521045000434','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2575',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(403,'228',NULL,NULL,'ATUL GRAIN AND PROVISION STORE',5,'0','DR','KHINDIPADA','MULUND W','MUMBAI','21','',NULL,'','',NULL,'27','27AACPS7236G1ZJ','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'403',NULL,NULL,NULL,NULL,NULL,'21512024000159','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','577',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(404,'228',NULL,NULL,'NEELAM STORES',5,'0','DR','KOKAN NAGAR','BHANDUP W','MUMBAI','21','400078',NULL,'9969119209','',NULL,'27','27AACPP6551H1ZK','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'404',NULL,NULL,NULL,NULL,NULL,'21517063000107','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1243',NULL,'0','0',NULL,0,'2026-04-14 10:26:05','2026-04-14 10:26:05'),(405,'228',NULL,NULL,'N.B. SHAH & COM.',5,'0','DR','DAKYORT COLONY','','MUMBAI','21','400078',NULL,'9773846192','',NULL,'27','27AACPN3814F1ZY','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'405',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','629',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(406,'228',NULL,NULL,'MEERA GEN STORES',5,'0','DR','HARIYALI VILLAGE','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9819532605','',NULL,'27','27AACPK3381N1ZE','','',NULL,NULL,'','18',NULL,NULL,NULL,NULL,NULL,'406',NULL,NULL,NULL,NULL,NULL,'11520013000219','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','319',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(407,'228',NULL,NULL,'JANTA BRIJWASI SWEETS',5,'0','DR','STATION ROAD','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9867476817','',NULL,'27','27AACPG6666Q1Z2','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'407',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','348',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(408,'228',NULL,NULL,'SHAH SOAMCHAND VEERPAR',5,'0','DR','KANJUR E','VAT NO 27250196284V','MUMBAI','21','400042',NULL,'1256478900','',NULL,'27','27AACPG6535E1ZZ','','',NULL,NULL,'','17',NULL,NULL,NULL,NULL,NULL,'408',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','610',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(409,'228',NULL,NULL,'HEERA GRAIN STORE',5,'0','DR','SURYA NAGAR','VIKHROLI W','MUMBAI','21','400083',NULL,'8779709243','',NULL,'27','27AACPG2528H1Z0','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'409',NULL,NULL,NULL,NULL,NULL,'11519013000268','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','638',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(410,'228',NULL,NULL,'ASIAD MEDICAL & GEN STORES',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AACPG1027B1ZK','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'410',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','203',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(411,'228',NULL,NULL,'DIAMOND OIL CENTER',5,'0','DR','STATION ROAD','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9967435044','',NULL,'27','27AACPB6730A1ZF','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'411',NULL,NULL,NULL,NULL,NULL,'11519013000240','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','345',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(412,'228',NULL,NULL,'Z MART GROCERIES',5,'0','DR','SHOP NO.3, BUILDING NO.13, MAHADA COLONY , CHANDIVALI ,','','MUMBAI','21','400076',NULL,'9769821517','',NULL,'27','27AACFZ6509R1ZC','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'412',NULL,NULL,NULL,NULL,NULL,'21520031000582','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2305',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(413,'228',NULL,NULL,'YASHASVI AGENCIES',5,'0','DR','SHOP NO-G.17.APMC MARKET -1, PHASE-2 SECTOR19, VASHI','','MUMBAI','21','400705',NULL,'8097717777','',NULL,'27','27AACFY2258C1ZA','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'413',NULL,NULL,NULL,NULL,NULL,'11521017000482','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2557',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(414,'228',NULL,NULL,'WALK 2 MART SUPERMARKET',5,'0','DR','SHOP NOI.9, ZAHOOR PALACE, OPP: L&T GATE NO6, SAKHI VIHAR ROAD POWAI.','','MUMBAI','21','400072',NULL,'9930121565','',NULL,'27','27AACFW8943N1ZD','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'414',NULL,NULL,NULL,NULL,NULL,'1151007000276','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2823',NULL,'0','0',NULL,0,'2026-04-14 10:26:06','2026-04-14 10:26:06'),(415,'228',NULL,NULL,'WELCOME SUPER MARKET',5,'0','DR','BIREN BLDG, J.V. ROAD , KHOT LANE, NR: BK MART','GHATKOPER W','MUMBAI','21','',NULL,'8291250840','',NULL,'27','27AACFW3808N1ZR','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'415',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2287',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(416,'228',NULL,NULL,'CENTRAL STORE',5,'0','DR','1-2-3, RATAN MAHAL, STATION ROAD , OPP: SHIVRAJ','GHATKOPER W','MUMBAI','21','',NULL,'7021355300','',NULL,'27','27AACFC7928B1ZN','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'416',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2294',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(417,'228',NULL,NULL,'POOJA BEVERAGES AND FOOD.PVT LTD',5,'0','DR','UNIT.142 MAROL CO.OP SOCITY','ANDHARI KURLA ROAD','MUMBAI','21','400059',NULL,'7738786056','',NULL,'27','27AACCP7811M1Z3','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'417',NULL,NULL,NULL,NULL,NULL,'11517005000240','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2859',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(418,'228',NULL,NULL,'PRAVINS MART',5,'0','DR','SHOP NO 7,8,9,MADA SHOPPING CENTRE','OPP BLDG.NON 32','MUMBAI','21','400083',NULL,'9867568027','',NULL,'27','27AABPV7415R1ZX','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'418',NULL,NULL,NULL,NULL,NULL,'11518013000246','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1280',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(419,'228',NULL,NULL,'POOJA BENGALI SWEET',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'8850117382','',NULL,'27','27AABPU3691C1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'419',NULL,NULL,NULL,NULL,NULL,'11517013000280','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','201',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(420,'228',NULL,NULL,'SAHYOG DHANYA BHANDAR',5,'0','DR','BHATIPADA','BHANDUP W\\\'','MUMBAI','21','400078',NULL,'9821336333','',NULL,'27','27AABPR1921Q1ZC','','',NULL,NULL,'','16',NULL,NULL,NULL,NULL,NULL,'420',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','751',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(421,'228',NULL,NULL,'UDYA STORE',5,'0','DR','SHREE MAHALAXMI APARTMENTS, SHOP NO.3, CAMA LANE , NR SNDT GIRLS COLLEGE ,','GHATKOPER W','MUMBAI','21','',NULL,'9321028487','',NULL,'27','27AABPP7971N1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'421',NULL,NULL,NULL,NULL,NULL,'11516008000166','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2293',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(422,'228',NULL,NULL,'UDAY STORES',5,'0','DR','SHREE MAHALAXMI APARTMENT SHOP NO 3','CAMA LANE GHATKOPAR W','MUMBAI','21','400086',NULL,'9773846192','',NULL,'27','27AABPP7071N1ZY','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'422',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2194',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(423,'228',NULL,NULL,'ARIHANT general& provision store',5,'0','DR','NR. PANCH RASTA','MULUND W','MUMBAI','21','',NULL,'','',NULL,'27','27AABPN1507C1ZB','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'423',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','838',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(424,'228',NULL,NULL,'VARDHMAN DHANYA BHANDAR',5,'0','DR','KOKAN NAGAR','BHANDUP W','MUMBAI','21','400078',NULL,'9930121480','',NULL,'27','27AABPG8111F1Z6','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,NULL,'424',NULL,NULL,NULL,NULL,NULL,'11519013000174','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','863',NULL,'0','0',NULL,0,'2026-04-14 10:26:07','2026-04-14 10:26:07'),(425,'228',NULL,NULL,'L. K. KIRANA&GEN STORES',5,'0','DR','MULUND COLONY','MULUND W','MUMBAI','21','400080',NULL,'9967486450','',NULL,'27','27AABPG6652K1ZL','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,NULL,'425',NULL,NULL,NULL,NULL,NULL,'1152400900097','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','549',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(426,'228',NULL,NULL,'ARUNA SUPER MARKET',5,'0','DR','POWAI','POWAI','MUMBAI','21','400076',NULL,'9820274150','',NULL,'27','27AABPG4719M2ZK','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'426',NULL,NULL,NULL,NULL,NULL,'11521013000299','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-10-25','0.00',NULL,'0','0',NULL,'0','2138',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(427,'228',NULL,NULL,'GANGAR GEN. STORE',5,'0','DR','VILLAGE ROAD','BHANDUP WEST','MUMBAI','21','',NULL,'','',NULL,'27','27AABPG2883A1ZD','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'427',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1142',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(428,'228',NULL,NULL,'PADMAVATI ENTERPRISES',5,'0','DR','D/2,303,SHEETAL APT,','SARVODAYA NAGAR,JAIN MANDIR ROAD','MUMBAI','21','',NULL,'','',NULL,'27','27AABPG1565B1ZA','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'428',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1711',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(429,'228',NULL,NULL,'PADMAVANTI ENTERPRISES',5,'0','DR','D/2, 303, SHEETAL APT. SARVODAYA NA','GAR, JAIN MANDIR ROAD, MULUND','MUMBAI','21','',NULL,'','',NULL,'27','27AABPG1565B1ZA','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'429',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1710',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(430,'228',NULL,NULL,'POWAI GRAIN STORES',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AABPG1407G1ZB','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'430',NULL,NULL,NULL,NULL,NULL,'11516013000146','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','228',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(431,'228',NULL,NULL,'M.K. DAL MILL',5,'0','DR','SHOP NO.6, RADHA KUNJ BUILDING , PLOT NO-33,','PESTOM SAGAR , OAD NO 4, CHEMBUR , MUMBAI 400089','MUMBAI','21','400077',NULL,'7303042791','',NULL,'27','27AABPD5451H1Z0','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,NULL,'431',NULL,NULL,NULL,NULL,NULL,'11521007000070','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2674',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(432,'228',NULL,NULL,'BHARATKUMAR JETHALAL & CO.',5,'0','DR','GALA NO.15, GAUTAM UDYOG BHAVAN,','BEHIND DENA BANK, L.B.S. MARG, BHANDUP W, MUMBAI -400078.','MUMBAI','21','400078',NULL,'9870506929','',NULL,'27','27AABPD3610N1ZY','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'432',NULL,NULL,NULL,NULL,NULL,'11522013000160','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2653',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(433,'228',NULL,NULL,'LOW PRICE DEPARTMENT',5,'0','DR','SHOP NO.4 & 5, KISHOR BUILDING','MULUND E','MUMBAI','21','400081',NULL,'7452456890','',NULL,'27','27AABPD3186F1Z0','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'433',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1348',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(434,'228',NULL,NULL,'MATRUKRIPA STORES',5,'0','DR','PARKSITE','VIKHROLI(W)','MUMBAI','21','400083',NULL,'7425631256','',NULL,'27','27AABPC8142J1ZU','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'434',NULL,NULL,NULL,NULL,NULL,'11519008000450','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','138',NULL,'0','0',NULL,0,'2026-04-14 10:26:08','2026-04-14 10:26:08'),(435,'228',NULL,NULL,'BHANU GRAIN STORES',5,'0','DR','PANCHKUTIR','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AABPB7445F1ZO','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'435',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1252',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(436,'228',NULL,NULL,'CHHADVA SUPER MARKET',5,'0','DR','SHOP NO 01,APNA BAZAR ROAD OPP IIT MAIN GATE','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AABHN9058E1Z2','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'436',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','202',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(437,'228',NULL,NULL,'WHITE MAGIC',5,'0','DR','B.P.T. PLOT NO 2 ACHARYA DONDE MARG NEAR BUS DEPOT','SEWREE W','MUMBAI','21','400015',NULL,'9820593989','',NULL,'27','27AABFW9219J1ZR','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'437',NULL,NULL,NULL,NULL,NULL,'11517003000515','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2892',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(438,'228',NULL,NULL,'DIPTI VEGOILS LTD',5,'0','DR','MUMMY HOUSE GALA NO 2, VASHI','DEFAULT','MUMBAI','21','400703',NULL,'','',NULL,'27','27AABCS4359N1ZU','','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,NULL,'438',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1483',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(439,'228',NULL,NULL,'VARIYA SUPAR SHOPPY',5,'0','DR','GAWANPADA','MULUND E','MUMBAI','21','400081',NULL,'8169646361','',NULL,'27','27AAAPV7724N1Z2','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'439',NULL,NULL,NULL,NULL,NULL,'1152000900041','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1112',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(440,'228',NULL,NULL,'VORA STORES',5,'0','DR','SHOP NO 8 GELDA JYOT GELDA NAGAR','GOLIBAR ROAD GHATKOPAR W','MUMBAI','21','400086',NULL,'9819406057','',NULL,'27','27AAAPV5118N1ZA','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,NULL,'440',NULL,NULL,NULL,NULL,NULL,'11518008000616','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2829',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(441,'228',NULL,NULL,'RASHMI TRADERS',5,'0','DR','M.G ROAD','NR: AMBAJI DHAM MANDIR','MUMBAI','21','400080',NULL,'9773846192','',NULL,'27','27AAAPT9790J1ZY','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,NULL,'441',NULL,NULL,NULL,NULL,NULL,'11517009000477','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-02-18','0.00',NULL,'0','0',NULL,'0','2057',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(442,'228',NULL,NULL,'SHAH NENSI KANJI & CO.',5,'0','DR','GODREJ VILLAGE','VIKHROLI(E)','MUMBAI','21','',NULL,'','',NULL,'27','27AAAPR7981H1Z8','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'442',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','151',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(443,'228',NULL,NULL,'SELVA VINAYAGAR STORE',5,'0','DR','NR.CHINTAMANI GARDAN','MULUND E','MUMBAI','21','400081',NULL,'8779402162','',NULL,'27','27AAAPN4627Q1Z8','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,NULL,'443',NULL,NULL,NULL,NULL,NULL,'11521009000038','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','542',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(444,'228',NULL,NULL,'SOCIETY OIL & TEA',5,'0','DR','STATION ROAD','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9221463456','',NULL,'27','27AAAPL6496P1ZX','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'444',NULL,NULL,NULL,NULL,NULL,'11519013000450','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','352',NULL,'0','0',NULL,0,'2026-04-14 10:26:09','2026-04-14 10:26:09'),(445,'228',NULL,NULL,'MAHARAJA OIL TRADERS',5,'0','DR','KESHAVJIWADI VILLAGE ROAD','BHANDUP W','MUMBAI','21','400078',NULL,'8080065081','',NULL,'27','27AAAPJ7793F1ZI','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'445',NULL,NULL,NULL,NULL,NULL,'11521013000009','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2879',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(446,'228',NULL,NULL,'J.K. DAL MILL',5,'0','DR','RAJAWADI HOSPITAL VIDHYA VIHAR STAION ROAD','RAJAWADI  GHATKOPER EAST','MUMBAI','21','400075',NULL,'9819339221','',NULL,'27','27AAAPC8901A1ZF','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'446',NULL,NULL,NULL,NULL,NULL,'11518008000403','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2255',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(447,'228',NULL,NULL,'SHIVAY TRADING CO.',5,'0','DR','GALA NO 8,9,PLOT NO B SHUBHAM BLDG SQUARE IND PARK NR. TUNGARESHWAR FATA SATIVALI','VASAI EAST DIST PALGHAR','MUMBAI','21','401208',NULL,'8097148081','',NULL,'27','27AAAPB9053A1ZB','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'447',NULL,NULL,NULL,NULL,NULL,'11520019000355','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2209',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(448,'228',NULL,NULL,'JAGDISH GENS STORES',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846193','',NULL,'27','27AAAPB7752Q1ZC','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'448',NULL,NULL,NULL,NULL,NULL,'11517013000530','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','195',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(449,'228',NULL,NULL,'MUMBAI KAMGAR M.G.S.S.MARYADIT',5,'0','DR','J.N. ROAD','','MUMBAI','21','',NULL,'','',NULL,'27','27AAAJM0005H1Z0','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'449',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','2020-03-11','0.00',NULL,'0','0',NULL,'0','2069',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(450,'228',NULL,NULL,'KANNAMWAR NAGAR CONSUMER SOCIETY-2',5,'0','DR','KANNAMWAR NAGAR-2','VIKHROLI(E)','MUMBAI','21','400079',NULL,'9820716072','',NULL,'27','27AAAJK0496N1ZQ','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'450',NULL,NULL,NULL,NULL,NULL,'11517013000492','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','157',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(451,'228',NULL,NULL,'THAKKAR TRADING CO.',5,'0','DR','R.H.B.ROAD','MULUND(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AAAFT2304C1ZU','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'451',NULL,NULL,NULL,NULL,NULL,'2017012223159113','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','465',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(452,'228',NULL,NULL,'PRAVIN GENRAL STORE',5,'0','DR','KANJUR STATION ROAD','KANJUR W','MUMBAI','21','',NULL,'','',NULL,'27','27AAAFPO261E1ZQ','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'452',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','625',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(453,'228',NULL,NULL,'KANJI RAVJI & COMPANY',5,'0','DR','J.N.ROAD','MULUND W','MUMBAI','21','400080',NULL,'9773846192','',NULL,'27','27AAAFK1329G1ZO','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'453',NULL,NULL,NULL,NULL,NULL,'11515009000445','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','907',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(454,'228',NULL,NULL,'HAIKO SUPER MARKET',5,'0','DR','HIRANANDANI GARDENS POWAI','','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AAACL5523E1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'454',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1424',NULL,'0','0',NULL,0,'2026-04-14 10:26:10','2026-04-14 10:26:10'),(455,'228',NULL,NULL,'FRIGORIFICO ALLANA PVT . LTD',5,'0','DR','3 Rd Floor Sidhwa House N.A. SWANT MARG COLABA','MUMBAI','MUMBAI','21','400005',NULL,'9833183998','',NULL,'27','27AAACF0861F1ZY','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'455',NULL,NULL,NULL,NULL,NULL,'10013022002061','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2510',NULL,'0','0',NULL,0,'2026-04-14 10:26:11','2026-04-14 10:26:11'),(456,'228',NULL,NULL,'SAKINAKA CENTRAL CAN CO OP STORES',5,'0','DR','POWAI IIT','POWAI','MUMBAI','21','400076',NULL,'9773846192','',NULL,'27','27AAAAS8864M1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'456',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','225',NULL,'0','0',NULL,0,'2026-04-14 10:26:11','2026-04-14 10:26:11'),(457,'228',NULL,NULL,'KANNAMWAR NAGAR CONSUMER SOCIETY-1',5,'0','DR','KANNAMWAR NAGAR-1','VIKHROLI(E)','MUMBAI','21','400079',NULL,'7474568923','',NULL,'27','27AAAAK6784E1ZH','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'457',NULL,NULL,NULL,NULL,NULL,'21517062000029','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','156',NULL,'0','0',NULL,0,'2026-04-14 10:26:11','2026-04-14 10:26:11'),(458,'228',NULL,NULL,'CEAT EMPLOYEE\\\'S CO-OP.CR.STY.LTD',5,'0','DR','SUBHASH NAGAR','BHANDUP(W)','MUMBAI','21','',NULL,'','',NULL,'27','27AAAAC0547M1ZR','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'458',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','407',NULL,'0','0',NULL,0,'2026-04-14 10:26:11','2026-04-14 10:26:11'),(459,'228',NULL,NULL,'BEST BAZAR',5,'0','DR','NR GHATKOPER DEPOT. BEST COLONY','PANT NAGAR GHATKOPER E','MUMBAI','21','400075',NULL,'9326215205','',NULL,'27','27AAAAB0538M1ZT','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'459',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','2235',NULL,'0','0',NULL,0,'2026-04-14 10:26:11','2026-04-14 10:26:11');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int(11) NOT NULL DEFAULT 0,
  `ADDRESS1` text DEFAULT NULL,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=362 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `PG_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` int(11) DEFAULT 0,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
INSERT INTO `SALES` VALUES (1,'228',NULL,NULL,'2026-04-01',3,18,'','',406,'HARIYALI VILLAGE VIKHROLI(E) MUMBAI 27AACPK3381N1ZE 11520013000219',NULL,'TE00047',1,'TE','00047','',0,'7','7','23914.290','0','0','0','0','1195.72','597.86','597.86','0','0','0','-0.01','25110','25110.01','10/0','144.00','23914.29','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','344','344',NULL,0,0,'2026-04-14 10:29:38','2026-04-14 10:33:36');
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
INSERT INTO `SALES_ITEM` VALUES (1,'228',NULL,NULL,14,15,1,7,'2500',1955.2400,0,'5.00','2.5','2.5','0','0','0',1,NULL,'3.00','3','0','0',NULL,NULL,'0',0,'0','0','0','0','7142.86',0.0000,0.0000,'357.14','178.57','178.57','0',0,'0',0,'0',NULL,NULL,'','',0,'0',NULL,'13',7,'7','2380.9524','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',0,NULL,NULL,'344','344',NULL,1,'2026-04-14 10:29:38','2026-04-14 10:29:38'),(2,'228',NULL,NULL,130,131,1,7,'2630',2138.1000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'2.00','02','0','0',NULL,NULL,'0',0,'0','0','0','0','5009.5238',0.0000,0.0000,'250.48','125.24','125.24','0',0,'0',0,'0',NULL,NULL,'','',0,'5009.5238',NULL,'15',10,'7','2504.7619','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',0,NULL,NULL,'344','344',NULL,1,'2026-04-14 10:29:38','2026-04-14 10:29:38'),(3,'228',NULL,NULL,571,574,1,7,'2470',6502.8600,0,'5.00','2.5','2.5','0','0','0',1,NULL,'5.00','05','0','0',NULL,NULL,'0',0,'0','0','0','0','11761.9048',0.0000,0.0000,'588.10','294.05','294.05','0',0,'0',0,'0',NULL,NULL,'','',0,'11761.9050',NULL,'15',7,'7','2352.3810','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',0,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:33:36','2026-04-14 10:33:36'),(4,'228',NULL,NULL,14,15,1,7,'2500',1955.2400,0,'5.00','2.5','2.5','0','0','0',1,NULL,'3.00','3','0','0',NULL,NULL,'0',0,'0','0','0','0','7142.86',0.0000,0.0000,'357.14','178.57','178.57','0',0,'0',0,'0',NULL,NULL,'','',0,'0',NULL,'13',7,'7','2380.9524','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',0,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:33:36','2026-04-14 10:33:36'),(5,'228',NULL,NULL,130,131,1,7,'2630',2138.1000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'2.00','02','0','0',NULL,NULL,'0',0,'0','0','0','0','5009.5238',0.0000,0.0000,'250.48','125.24','125.24','0',0,'0',0,'0',NULL,NULL,'','',0,'5009.5238',NULL,'15',10,'7','2504.7619','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',0,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:33:36','2026-04-14 10:33:36');
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT NULL,
  `LITE_ID` varchar(50) DEFAULT NULL,
  `WEB_ID` varchar(50) DEFAULT NULL,
  `PROD_ID` varchar(20) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) DEFAULT NULL,
  `SALES_ID` varchar(20) DEFAULT NULL,
  `SALE_UNIT` varchar(20) DEFAULT NULL,
  `SALE_RATE` varchar(20) DEFAULT NULL,
  `PUR_RATE` varchar(20) DEFAULT NULL,
  `PROD_PACK` varchar(20) DEFAULT NULL,
  `PUR_VAT` varchar(20) DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_VAT` varchar(20) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_CESS` varchar(20) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) DEFAULT NULL,
  `PACK` varchar(20) DEFAULT NULL,
  `BOX` varchar(20) DEFAULT NULL,
  `QTY` varchar(20) DEFAULT NULL,
  `DISC_PERCENT` varchar(20) DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) DEFAULT NULL,
  `RETURN_QTY` varchar(20) DEFAULT NULL,
  `FREE` varchar(20) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) DEFAULT NULL,
  `AMT` varchar(20) DEFAULT NULL,
  `PUR_AMT` varchar(20) DEFAULT NULL,
  `PROFIT` varchar(20) DEFAULT NULL,
  `TAX_AMT` varchar(20) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) DEFAULT NULL,
  `DAMAGE` varchar(20) DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) DEFAULT NULL,
  `REPLACE` varchar(25) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) DEFAULT NULL,
  `RETURN` varchar(25) DEFAULT NULL,
  `SR_NO` varchar(50) DEFAULT NULL,
  `CESS_AMT` varchar(20) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) DEFAULT NULL,
  `WEIGHT` varchar(20) DEFAULT NULL,
  `PUR_UNIT` varchar(20) DEFAULT NULL,
  `PRICE_PER` varchar(20) DEFAULT NULL,
  `TE_RATE` varchar(20) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) DEFAULT NULL,
  `DMG_MRP` varchar(20) DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) DEFAULT NULL,
  `INV_ARR` varchar(255) DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` varchar(20) DEFAULT NULL,
  `UPDATED_BY` varchar(20) DEFAULT NULL,
  `SECURITY_KEY` varchar(100) DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(20) DEFAULT NULL,
  `SALES_MAN` varchar(100) DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(20) DEFAULT NULL,
  `PARTY_CODE` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(20) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) DEFAULT NULL,
  `BATCH_NO` varchar(50) DEFAULT NULL,
  `MFG_DATE` varchar(20) DEFAULT NULL,
  `EXP_DATE` varchar(20) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int(11) DEFAULT 0,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int(11) DEFAULT 0,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int(11) DEFAULT 0,
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SMAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYNC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text DEFAULT NULL,
  `UPDATED_VALUE` text DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text DEFAULT NULL,
  `DIACM` text DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int(11) DEFAULT 0,
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int(11) DEFAULT 0,
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-04-14 09:57:46','2026-04-14 09:57:46');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UOM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT 0,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (1,'228',NULL,NULL,'SalesZeroStock','1',344,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:27:12','2026-04-14 10:27:12'),(2,'228',NULL,NULL,'SalesReverseCalculation','1',344,NULL,NULL,NULL,'344','344',NULL,0,'2026-04-14 10:27:12','2026-04-14 10:27:12');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WEB_ID` int(11) NOT NULL DEFAULT 0,
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-04-14 09:57:51');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-16 11:01:07
