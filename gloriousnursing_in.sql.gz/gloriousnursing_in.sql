-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: gloriousnursing_in
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `record_id` int(11) NOT NULL DEFAULT 0,
  `table_name` varchar(255) DEFAULT NULL,
  `record_name` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admissions`
--

DROP TABLE IF EXISTS `admissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admissions` (
  `admission_id` int(11) NOT NULL AUTO_INCREMENT,
  `enrollment_no` varchar(255) DEFAULT NULL,
  `admission_year` varchar(255) DEFAULT NULL,
  `annual_tuition_fees` varchar(255) DEFAULT NULL,
  `annual_overall_fees` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `student_photo` varchar(255) DEFAULT NULL,
  `student_guardian_name` varchar(255) DEFAULT NULL,
  `student_birth_date` varchar(255) DEFAULT NULL,
  `student_gender` varchar(255) DEFAULT NULL,
  `student_mobile_number` varchar(255) DEFAULT NULL,
  `parent_mobile_number` varchar(255) DEFAULT NULL,
  `student_email_id` varchar(255) DEFAULT NULL,
  `student_religion` varchar(255) DEFAULT NULL,
  `student_cast` varchar(255) DEFAULT NULL,
  `student_guardian_occupation` varchar(255) DEFAULT NULL,
  `per_add1` varchar(255) DEFAULT NULL,
  `per_add2` varchar(255) DEFAULT NULL,
  `per_district` varchar(255) DEFAULT NULL,
  `per_state` varchar(255) DEFAULT NULL,
  `per_pincode` varchar(255) DEFAULT NULL,
  `corr_add1` varchar(255) DEFAULT NULL,
  `corr_add2` varchar(255) DEFAULT NULL,
  `corr_district` varchar(255) DEFAULT NULL,
  `corr_state` varchar(255) DEFAULT NULL,
  `corr_pincode` varchar(255) DEFAULT NULL,
  `ssc_board` varchar(255) DEFAULT NULL,
  `ssc_subject` varchar(255) DEFAULT NULL,
  `ssc_passing_year` varchar(255) DEFAULT NULL,
  `ssc_roll_no` varchar(255) DEFAULT NULL,
  `ssc_obtained_marks` varchar(255) DEFAULT NULL,
  `ssc_total_marks` varchar(255) DEFAULT NULL,
  `ssc_percentage_marks` varchar(255) DEFAULT NULL,
  `ssc_certificate` varchar(255) DEFAULT NULL,
  `hsc_board` varchar(255) DEFAULT NULL,
  `hsc_subject` varchar(255) DEFAULT NULL,
  `hsc_passing_year` varchar(255) DEFAULT NULL,
  `hsc_roll_no` varchar(255) DEFAULT NULL,
  `hsc_obtained_marks` varchar(255) DEFAULT NULL,
  `hsc_total_marks` varchar(255) DEFAULT NULL,
  `hsc_percentage_marks` varchar(255) DEFAULT NULL,
  `hsc_certificate` varchar(255) DEFAULT NULL,
  `student_leaving_certificate` varchar(255) DEFAULT NULL,
  `student_cast_certificate` varchar(255) DEFAULT NULL,
  `student_passing_certificate` varchar(255) DEFAULT NULL,
  `student_income_certificate` varchar(255) DEFAULT NULL,
  `student_aadhar` varchar(255) DEFAULT NULL,
  `student_pan` varchar(255) DEFAULT NULL,
  `student_passport` varchar(255) DEFAULT NULL,
  `extra_document_1` varchar(255) DEFAULT NULL,
  `extra_document_2` varchar(255) DEFAULT NULL,
  `extra_document_3` varchar(255) DEFAULT NULL,
  `extra_document_4` varchar(255) DEFAULT NULL,
  `extra_document_5` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `admission_status` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`admission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admissions`
--

LOCK TABLES `admissions` WRITE;
/*!40000 ALTER TABLE `admissions` DISABLE KEYS */;
INSERT INTO `admissions` VALUES (1,'E100','2026-27','80000','120000','ANM','Mayank','1788585497_student_photo_8607.png','Patel','2026-09-05','male','9383838383','9393939393','mayankp@yopmail.com','Hindu','Open','Business','','','','Gujarat','','','','','Gujarat','','','','2027','','','','0',NULL,'','','2027','','','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Y','Confirmed',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 05:17:24','2026-09-05 05:18:17'),(2,'E101','2026-27','80000','150000','ANM','Ravindra','1788585560_student_photo_9721.png','HN','2026-09-03','male','9393938383','9282829292','ravindrahn@yopmail.com','Hindu','Open','Job','','','','Gujarat','','','','','Gujarat','','','','2027','','','','0',NULL,'','','2027','','','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Y','Confirmed',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 05:18:23','2026-09-05 05:19:20'),(3,'E103','2026-27','100000','150000','GNM','Jay','1788585621_student_photo_3930.png','Ptl','2026-09-04','male','9292929292','8282828282','jayp@yopmail.com','Hindu','Hindu','Job','','','','Gujarat','','','','','Gujarat','','','','2027','','','','0',NULL,'','','2027','','','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Y','Confirmed',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 05:19:27','2026-09-05 05:20:21'),(4,'E104','2026-27','80000','120000','GNM','Ajay','1788585694_student_photo_1750.png','ptl','2024-01-01','male','9292929292','9292929292','ajayp@yopmail.com','Hindu','Hindu','Job','','','','Gujarat','','','','','Gujarat','','','','2027','','','','0',NULL,'','','2027','','','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Y','Confirmed',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 05:20:57','2026-09-05 05:21:34'),(5,'E105','2026-27','80000','150000','GNM','Vijay','1788585832_student_photo_2036.png','ptl','2020-01-01','male','9292929292','9229292992','vijayp@yopmail.com','Hindu','Hindu','Business','','','','Gujarat','','','','','Gujarat','','','','2027','','','','0',NULL,'','','2027','','','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Y','Confirmed',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 05:21:40','2026-09-05 05:23:52'),(6,'1111111','2026-27','11111','111111','ANM','1111','1789057932_student_photo_1956.jpeg','11','2021-01-01','female','11111111','11111111','11111111@a.com','Hindu','','11111','','','','Gujarat','','','','','Gujarat','','','','2027','','','','0',NULL,'','','2027','','','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Y','Confirmed',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-10 18:31:37','2026-09-10 22:02:12');
/*!40000 ALTER TABLE `admissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(191) NOT NULL,
  `email_address` varchar(191) NOT NULL,
  `contact_number` varchar(199) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id_pk` int(11) DEFAULT 0,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `customer_pin` int(11) NOT NULL DEFAULT 0,
  `pos_customer` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `guest_customer` varchar(1) NOT NULL DEFAULT '0',
  `access_token` varchar(255) DEFAULT NULL,
  `security_question_id` int(11) NOT NULL DEFAULT 0,
  `security_answer` varchar(191) DEFAULT NULL,
  `user_address1` varchar(191) DEFAULT NULL,
  `user_address2` varchar(191) DEFAULT NULL,
  `user_city` varchar(191) DEFAULT NULL,
  `user_state` varchar(191) DEFAULT NULL,
  `user_zipcode` varchar(191) DEFAULT NULL,
  `user_country` varchar(191) DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `web_token` varchar(255) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `item_type` varchar(25) NOT NULL DEFAULT 'users',
  `wallet_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `blocked` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `admission_id` int(11) NOT NULL DEFAULT 0,
  `enroll_for` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `invoice_no` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `total_paid_amount` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `payment_date` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(255) DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(255) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_for` varchar(255) DEFAULT NULL,
  `invoice_prefix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,1,'ANM','Cash','R1001','2026-04-01','2026-09-30','40000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:24:34','Tuition','1001'),(2,1,'ANM','OnlineTransfer','R1002','2026-10-01','2027-04-30','40000','1','2026-10-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:25:13','Tuition','1002'),(3,1,'ANM','UPI','R1003','2027-10-01','2028-04-30','40000','1','2027-10-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:26:42','Tuition','1003'),(4,1,'ANM','OnlineTransfer','UN1001','2026-04-01','2026-09-30','10000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:29:01','Uniform','1001'),(5,1,'ANM','Cash','RB1001','2026-04-01','2026-09-30','5000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:29:36','Record books','1001'),(6,1,'ANM','OnlineTransfer','TR1001','2026-04-01','2026-09-30','12000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:30:09','Transportation','1001'),(7,1,'ANM','Cheque','HA1001','2026-04-01','2026-09-30','25000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:30:45','Hostel accomadation','1001'),(8,1,'ANM','UPI','HF1001','2026-04-01','2026-09-30','20000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:31:13','Hostel Food','1001'),(9,1,'ANM','DemandDraft','SNA1001','2026-04-01','2026-09-30','3000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-05 05:31:36','SNA','1001'),(10,2,'ANM','Cash','R1004','2026-04-01','2026-09-30','40000','1','2026-04-08',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:03:22','Tuition','1004'),(11,2,'ANM','OnlineTransfer','UN1002','2026-04-01','2027-03-31','10000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:04:02','Uniform','1002'),(12,2,'ANM','UPI','RB1002','2026-04-01','2026-09-30','5000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:04:23','Record books','1002'),(13,2,'ANM','Cash','TR1002','2026-04-01','2026-06-30','20000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:04:55','Transportation','1002'),(14,2,'ANM','Cheque','HA1002','2026-04-01','2026-09-30','40000','1','2026-04-01',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:05:19','Hostel accomadation','1002'),(15,2,'ANM','DemandDraft','HF1002','2026-04-01','2026-09-30','20000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:05:44','Hostel Food','1002'),(16,2,'ANM','Cheque','SNA1002','2026-04-01','2026-09-30','5000','1','2026-04-06',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 06:06:06','SNA','1002'),(17,2,'ANM','Cash','RB1003','2026-09-01','2026-09-30','20100','1','2026-09-10',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-10 16:32:33','Record books','1003');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section`
--

DROP TABLE IF EXISTS `item_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section` (
  `item_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_section_parent_id` int(11) NOT NULL DEFAULT 0,
  `section_title` varchar(255) DEFAULT NULL,
  `section_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section`
--

LOCK TABLES `item_section` WRITE;
/*!40000 ALTER TABLE `item_section` DISABLE KEYS */;
INSERT INTO `item_section` VALUES (1,0,0,'Section1','section1','default','Section1','1779799317_isec_2676.png',0,'Section1','Section1',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:41:57','2026-05-26 12:41:57'),(2,0,0,'Section2','section2','default','Section2','1779799330_isec_6580.png',0,'Section2','Section2',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:10','2026-05-26 12:42:10'),(3,0,0,'Section3','section3','default','Section3',NULL,0,'Section3','Section3',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:21','2026-05-26 12:42:21'),(4,0,0,'Section4','section4','default','Section4',NULL,0,'Section4','Section4',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:32','2026-05-26 12:42:32'),(5,0,0,'Section5','section5','default','Section5',NULL,0,'Section5','Section5',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:44','2026-05-26 12:42:44'),(6,0,0,'Section6','section6','default','Section6',NULL,0,'Section6','Section6',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:42:55','2026-05-26 12:42:55'),(7,0,0,'Section7','section7','default','Section7',NULL,0,'Section7','Section7',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:07','2026-05-26 12:43:07'),(8,0,0,'Section8','section8','default','Section8',NULL,0,'Section8','Section8',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:18','2026-05-26 12:43:18'),(9,0,0,'Section9','section9','default','Section9',NULL,0,'Section9','Section9',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:33','2026-05-26 12:43:33'),(10,0,0,'Section10','section10','default','Section10',NULL,0,'Section10','Section10',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:44','2026-05-26 12:43:44'),(11,0,0,'Section11','section11','default','Section11',NULL,0,'Section11','Section11',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:43:54','2026-05-26 12:43:54'),(12,0,0,'Section12','section12','default','Section12',NULL,0,'Section12','Section12',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:06','2026-05-26 12:44:06'),(13,0,0,'Section13','section13','default','Section13',NULL,0,'Section13','Section13',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:17','2026-05-26 12:44:17'),(14,0,0,'Section14','section14','default','Section14',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:26','2026-05-26 12:44:26'),(15,0,0,'Section15','section15','default','Section15',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:34','2026-05-26 12:44:34'),(16,0,0,'Section16','section16','default','Section16',NULL,0,'','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:44:42','2026-05-26 12:44:42'),(17,0,0,'Section 17','section-17','default','Section 17',NULL,0,'Section 17','Section 17',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-06-13 10:58:59','2026-06-13 14:28:59'),(18,0,0,'Section 18','section-18','default','Section 18',NULL,0,'Section 18','Section 18',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-06-13 11:02:57','2026-06-13 14:32:57'),(19,0,0,'Section 18','section-18-1781341611','default','Section 18',NULL,0,'Section 18','Section 18',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 14:53:37','2026-06-13 11:06:51','2026-06-13 14:36:51'),(20,0,0,'Section 18','section-18-1781341631','default','Section 18',NULL,0,'Section 18','Section 18',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 14:48:18','2026-06-13 11:07:11','2026-06-13 14:37:11'),(21,0,0,'Section 18','section-18-1781341922','default','Section 18',NULL,0,'Section 18','Section 18',0,'N',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 14:47:30','2026-06-13 11:12:02','2026-06-13 14:42:02'),(22,0,0,'Section 19','section-19','default','Section 19',NULL,0,'Section 19','Section 19',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:04:24','2026-06-13 11:26:11','2026-06-13 14:56:11'),(23,0,0,'Section 20','section-20','default','Section 20',NULL,0,'Section 20','Section 20',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:03:27','2026-06-13 14:20:26','2026-06-13 17:50:26'),(24,0,0,'Technolog z','technology','default','All technology-related articles and resources','28b7708bd5074701956179bc37b7c2b9_Screenshot_from_2026-07-09_17-47-21.png',0,'Technology Section','Explore the latest technology updates and tutorial',1,'Y',1,'',1,'N',0,NULL,NULL,'2026-07-10 18:21:00','2026-07-10 18:52:27'),(25,0,0,'Independence Day 2026','independence-day-2026','gallery','','',0,'','',0,'',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 15:45:51','2026-08-21 19:15:51'),(26,0,0,'Achivements','achivements','gallery','','',0,'','',0,'',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:21:57','2026-08-21 21:51:57');
/*!40000 ALTER TABLE `item_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section_relation`
--

DROP TABLE IF EXISTS `item_section_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section_relation` (
  `item_section_relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_id` bigint(20) NOT NULL DEFAULT 0,
  `section_id` bigint(20) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section_relation`
--

LOCK TABLES `item_section_relation` WRITE;
/*!40000 ALTER TABLE `item_section_relation` DISABLE KEYS */;
INSERT INTO `item_section_relation` VALUES (1,0,38,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:03:20','2026-08-21 19:33:20'),(2,0,39,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:08:37','2026-08-21 19:38:37'),(3,0,40,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:08:50','2026-08-21 19:38:50'),(4,0,41,25,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 16:10:21','2026-08-21 19:40:21'),(5,0,42,26,0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-08-21 18:22:22','2026-08-21 21:52:22');
/*!40000 ALTER TABLE `item_section_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_parent` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) DEFAULT NULL,
  `item_sections_id` varchar(255) DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `attachment2` varchar(255) DEFAULT NULL,
  `item_shortdescription` text DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT 'index',
  `published_at` date DEFAULT NULL,
  `published_end_at` date DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,0,'Home','home',100,'page','24','description update','attachment1-1758612676875.png','attachment2-1758612676877.png','short description update',3,'controller','action','2026-05-26','2026-05-26','meta title update','meta description update',1,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(2,0,'About Us','about-us',0,'page','null','<section class=\"hero\">\r\n        <div class=\"container custom-container-width\">\r\n            <div class=\"row\">\r\n                <div class=\"col-lg-7 align-items-center section-padding\">\r\n                    <div class=\"hero-body aos-init aos-animate\" data-aos=\"fade-up\">\r\n                        <h1 class=\"text-uppercase sub-header\" style=\"color:#FBC238;\">About <span style=\"color:#FBC238;\" class=\"main_header main_clr sf-heavy\">Foundation</span></h1>\r\n                        <p class=\"mt-4 w-100 mw-50\">The Jitubhai Kalubhai Baria Foundation is a distinguished organization registered under the Ministry of Corporate Affairs, dedicated to advancing social welfare, healthcare, and educational opportunities in tribal areas across India. Founded with a vision to uplift underprivileged communities, the foundation is committed to addressing the unique challenges faced by tribal populations and contributing to the nation\'s inclusive development. With a focus on improving health and educational access, the foundation has a vision to carry out various initiatives, including healthcare camps, educational programs, and sustainable development projects that cater specifically to the needs of tribal regions. These programs aim to enhance healthcare access, promote preventive health measures, and provide learning resources and vocational training to empower local communities. The foundation’s work is guided by values of compassion, equity, and empowerment, aiming to bridge the socio-economic gap by creating lasting impacts in the lives of those it serves. Through collaborative efforts with local authorities, NGOs, and healthcare professionals, the Jitubhai Kalubhai Baria Foundation strives to foster resilience, self-sufficiency, and overall well-being in tribal areas, contributing to a stronger, healthier, and more educated nation.</p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </section>',NULL,'','',1,'','','2026-05-26','2026-05-26','About Us','About Us',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(3,0,'Terms & Conditions','terms-and-conditions',0,'page',NULL,'Terms & Conditions',NULL,'','',1,'','','2026-05-26','2026-05-26','Terms & Conditions','Terms & Conditions',2,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(4,0,'Privacy Policy','privacy-policy',0,'page',NULL,'Privacy Policy',NULL,'','',1,'','','2026-05-26','2026-05-26','Privacy Policy','Privacy Policy',3,'Y',1,'Demonstration',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(5,0,'Item1','item1',0,'default','1','Item1','1779799500_item1_4858.png',NULL,'Item1',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:00','2026-05-26 12:45:00'),(6,0,'Item2','item2',0,'default','1,2,3','Item2','1779799515_item1_2600.png',NULL,'Item2',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:15','2026-05-26 12:45:15'),(7,0,'Item3','item3',0,'default','1,2,3,4','Item3',NULL,NULL,'Item3',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:29','2026-05-26 12:45:29'),(8,0,'Item4','item4',0,'default','1,2,3,4','Item4','1779799547_item1_7270.png','1779799547_item2_6385.png','Item4',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:47','2026-05-26 12:45:47'),(9,0,'Item5','item5',0,'default','1,2,3,4,5','Item5',NULL,NULL,'Item5',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:45:59','2026-05-26 12:45:59'),(10,0,'Item6','item6',0,'default','1,2,3,4,5,6','Item6',NULL,NULL,'Item6',0,NULL,'index','2026-05-26','2031-05-26','Item6','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:13','2026-05-26 12:46:13'),(11,0,'Item7','item7',0,'default','5,6,7,8,9','Item7',NULL,NULL,'Item7',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:26','2026-05-26 12:46:26'),(12,0,'Item8','item8',0,'default','12,13,14,15,16','Item8',NULL,NULL,'Item8',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:40','2026-05-26 12:46:40'),(13,0,'Item9','item9',0,'default','1,2,3,4','Item9',NULL,NULL,'Item9',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:46:51','2026-05-26 12:46:51'),(14,0,'Item10','item10',0,'default','12,13,14,15,16','Item10',NULL,NULL,'Item10',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:02','2026-05-26 12:47:02'),(15,0,'Item11','item11',0,'default','4,5,6,7,8,9','Item11',NULL,NULL,'Item11',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:13','2026-05-26 12:47:13'),(16,0,'Item12','item12',0,'default','5,6,7,8,9','Item12',NULL,NULL,'Item12',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:24','2026-05-26 12:47:24'),(17,0,'Item13','item13',0,'default','5,6,7,8,9','Item12',NULL,NULL,'Item12',0,NULL,'index','2026-05-26','2031-05-26','Item12','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:37','2026-05-26 12:47:37'),(18,0,'Item14','item14',0,'default','8,9,10,11','Item14',NULL,NULL,'Item14',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:47:56','2026-05-26 12:47:56'),(19,0,'Item15','item15',0,'default','4,5,6,7,8','Item15',NULL,NULL,'Item15',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:09','2026-05-26 12:48:09'),(20,0,'Item16','item16',0,'default','1,2,3','Item16',NULL,NULL,'Item16',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:22','2026-05-26 12:48:22'),(21,0,'Item17','item17',0,'default','9,10,11,12,13','Item17',NULL,NULL,'Item17',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:34','2026-05-26 12:48:34'),(22,0,'Item18','item18',0,'default','7,8,9,10','Item18',NULL,NULL,'Item18',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:46','2026-05-26 12:48:46'),(23,0,'Item19','item19',0,'default','12,13,14,15','Item19',NULL,NULL,'Item19',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:48:57','2026-05-26 12:48:57'),(24,0,'Item20','item20',0,'default','4,5,6,7,8,9','Item20',NULL,NULL,'Item20',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:49:10','2026-05-26 12:49:10'),(25,0,'Item21','item21',0,'default','13,14','Item21',NULL,NULL,'Item21',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:49:25','2026-05-26 12:49:25'),(26,0,'Item22','item22',0,'default','2,3,4,5,6','Item22',NULL,NULL,'Item22',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:49:39','2026-05-26 12:49:39'),(27,0,'Item23','item23',0,'default','7,8,9,10,11','Item23',NULL,NULL,'Item23',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:50:02','2026-05-26 12:50:02'),(28,0,'Item24','item24',0,'default','3,4,5','Item24',NULL,NULL,'Item24',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:50:13','2026-05-26 12:50:13'),(29,0,'Item25','item25',0,'default','1,2,3,4','Item25',NULL,NULL,'Item25',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:50:25','2026-05-26 12:50:25'),(30,0,'dsf','dsf',0,'default','','<p>f</p><p>fdsf</p><p>dsf</p><p><br></p><p>fs</p><p>f</p><p>sdf</p><p>sdf</p><p>sf</p><p>sf</p><p>sfs</p><p>df</p><p>ds</p><p>ds</p><p>ds</p><p>f</p><p>sf</p><p>dsf</p><p>s</p><p>fsd</p><p>f</p><p>dsfd</p><p>sf</p><p>dsf</p><p>ds</p><p>fs</p><p>fdsfs</p>',NULL,NULL,'fds\r\nfds\r\nfds\r\nfs\r\ndfsa',0,NULL,'index','2026-05-26','2031-05-26','','',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 15:29:25','2026-05-26 18:59:25'),(31,0,'11111111','11111111',0,'default','1,2,3,4','<p>&nbsp; &nbsp; 111111111<br></p>',NULL,NULL,'3333333333',0,NULL,'index','2026-06-13','2031-06-13','11','22',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-06-13 12:17:54','2026-06-13 15:47:54'),(32,0,'11111111','11111111-1781346007',0,'default','1,2,3,4','<p>&nbsp; &nbsp; 111111111<br></p>',NULL,NULL,'3333333333',0,NULL,'index','2026-06-13','2031-06-13','11','22',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-06-13 12:20:07','2026-06-13 15:50:07'),(33,0,'11111111','11111111-1781346071',0,'default','1,2,3,4','<p>&nbsp; &nbsp; 111111111<br></p>',NULL,NULL,'3333333333',0,NULL,'index','2026-06-13','2031-06-13','11','22',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 16:34:30','2026-06-13 12:21:11','2026-06-13 15:51:11'),(34,0,'22222','22222',0,'default','1,2,3,4','<p>22222</p>',NULL,NULL,'22222',0,NULL,'index','2026-06-13','2031-06-13','22222','22222',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-06-13 14:21:02','2026-06-13 17:51:02'),(35,0,'3333333','3333333',0,'default','17,18,22','<p>    3333333<br></p>',NULL,NULL,'3333333',0,NULL,'index','2026-06-13','2031-06-13','3333333','3333333',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:04:49','2026-06-13 14:32:08','2026-06-13 18:02:08'),(36,0,'How to Build a REST API Updated','build-rest-api',0,'blog',NULL,'<p>This is a comprehensive guide to building REST APIs.</p>','api-guide.pdf','code-samples.zip','Step-by-step tutorial on REST API development.',0,'blog','view','2026-07-10','2026-12-31','REST API Tutorial | MySite','Learn how to build RESTful APIs with Python and Flask.',0,'Y',1,'',1,'Y',1,NULL,'2026-07-10 18:26:28','2026-07-10 18:25:18','2026-07-10 18:25:55'),(37,0,'How to Build a REST API 37','build-rest-api',0,'default','1,2,4','<p>This is a comprehensive guide to building REST APIs.</p>','da8d114c8f434d88b6f08aebde5bad5a_Screenshot_from_2026-07-10_12-17-01.png','9cacf33e7cf84d20b7783df8c2b2f57e_Screenshot_from_2026-07-09_17-47-44.png','11',1,'blog','view','2026-07-10','2026-11-10','REST API Tutorial | MySite','Learn how to build RESTful APIs with Python and Flask.',0,'Y',1,'',1,'N',0,NULL,NULL,'2026-07-10 18:35:12','2026-07-10 19:06:34'),(38,0,'AFD','afd',0,'gallery','25','','1787321000_item1_4512.png','','',0,NULL,'index','2026-08-21','2031-08-21','','',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:03:20','2026-08-21 19:33:20'),(39,0,'111','111',0,'gallery','25','','1787321317_item1_2888.png','','',0,NULL,'index','2026-08-21','2031-08-21','','',2,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:08:37','2026-08-21 19:38:37'),(40,0,'333333','333333',0,'gallery','25','','1787321330_item1_8295.png','','',0,NULL,'index','2026-08-21','2031-08-21','','',3,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:08:50','2026-08-21 19:38:50'),(41,0,'1111','1111',0,'gallery','25','','1787321421_item1_6185.png','','',0,NULL,'index','2026-08-21','2031-08-21','','',5,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 16:10:21','2026-08-21 19:40:21'),(42,0,'First','first',0,'gallery','26','','1787329342_item1_6975.png','','',0,NULL,'index','2026-08-21','2031-08-21','','',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-21 18:22:22','2026-08-21 21:52:22');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `location_address1` varchar(255) DEFAULT NULL,
  `location_address2` varchar(255) DEFAULT NULL,
  `location_city` varchar(255) DEFAULT NULL,
  `location_state` varchar(255) DEFAULT NULL,
  `location_pincode` varchar(255) DEFAULT NULL,
  `location_contact` varchar(255) DEFAULT NULL,
  `location_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Bodeli','Satnam Complex','Chachak','Bodeli','GJ','391135','+91 (908) 183-7454','info@gloriousnursing.in');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_details`
--

DROP TABLE IF EXISTS `meta_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_details` (
  `meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `end_points` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `sidebar_title` varchar(255) DEFAULT NULL,
  `sidebar_icon` varchar(255) DEFAULT NULL,
  `sidebar_order` int(11) NOT NULL DEFAULT 0,
  `params` varchar(255) DEFAULT NULL,
  `is_module` smallint(6) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_details`
--

LOCK TABLES `meta_details` WRITE;
/*!40000 ALTER TABLE `meta_details` DISABLE KEYS */;
INSERT INTO `meta_details` VALUES (1,0,0,'/dashboard','Dashboard','Dashboard','Dashboard','Dashboard','mdi-view-dashboard',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(2,0,0,'/users','Users','Users','Users','Users','mdi-account-box',104,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(3,0,0,'/change-password','Change Password','Change Password','Change Password','Change Password','mdi mdi-server-security',105,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(4,0,0,'/items?item_type=page','Pages','Pages','Pages','Pages','mdi-format-list-bulleted',3,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(5,0,0,'/configurations','Configurations','Configurations Meta','Desc','Configurations','mdi-view-headline',109,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(6,0,0,'/user_form','User Form','User Form','User Form','User Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(7,0,0,'/item_section_form','Section Form','Section Form','Section Form','Section Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(8,0,0,'/logout','Logout','Logout','Logout','Logout','mdi-logout-variant',201,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(9,0,0,'/login','Login','Login','Login','Login',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(10,0,0,'/metadetails','Meta Details','Meta Details','Meta Details','SEO','mdi-format-list-bulleted',108,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(11,0,0,'/item_form','Item Form','Item Form','Item Form','Item Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(12,0,0,'/forgot-password','Forgot Password','Forgot Password','Forgot Password','Forgot Password',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(13,0,0,'/password-token','Password Token','Password Token','Password Token','Password Token',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(14,0,0,'/reset-password','Reset Password','Reset Password','Reset Password','Reset Password',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(15,0,0,'/roles','Roles','Roles','Roles','Roles','mdi mdi-account',103,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(16,0,0,'/role_form','Role Form','Role Form','Role Form','Role Form',NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(17,0,0,'/item_form?item_type=blog','Blog Form','Blog Form','Blog Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(18,0,0,'/item_form?item_type=page','Page Form','Page Form','Page Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(19,0,0,'/item_section_form?item_type=default','Default Section Form','Default Section Form','Default Section Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(20,0,0,'/item_section_form?item_type=blog','Blog Category Form','Blog Category Form','Blog Category Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(21,0,0,'/items/default','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(22,0,0,'/database_table','Database Tables','Database Tables','Database Tables','Database Tables','mdi mdi-view-headline',200,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(23,0,0,'/item_section?item_type=blog','Blog Category','Blog Category','Blog Category','Blog Category','mdi mdi-view-headline',5,NULL,0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(24,0,0,'/items?item_type=blog','Blogs','Blogs','Blogs','Blogs','mdi-format-list-bulleted',5,NULL,0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(25,0,0,'/item_form?item_type=default','Default Form','Default Form','Default Form',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(26,0,0,'/item_section?item_type=default','Default Section','Default Section','Default','Default Section','mdi mdi-view-headline',1,NULL,0,0,'N',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(27,0,0,'/items?item_type=default','Default Item','Default','Default','Default Items','mdi-format-list-bulleted',1,NULL,0,0,'N',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(28,0,52,'/template/mdiicons','Demonstration Company','Demonstration Company','Demonstration Company Description','MDI Icons','mdi mdi-view-headline',404,'ui-basic',0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(29,0,52,'/template/formelement','Form Elements','Form Elements','Form Elements','Form Element','mdi mdi-view-headline',403,'ui-basic',0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(30,0,52,'/template/gallery','Gallery','Gallery','Gallery','Gallery','mdi mdi-view-headline',402,'ui-basic',0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(31,0,-1,'/template','Templates','Templates','Templates','Templates','ui-basic',401,NULL,0,0,'Y',0,NULL,0,'Y',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(32,0,0,'/items','Demonstration Company','Demonstration Company','Demonstration Company Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(41,0,0,'/role_form?item_type=role','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-06-13 16:38:34'),(42,0,0,'/roles?item_type=role','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-06-13 16:40:52'),(43,0,0,'/item_section?item_type=gallery','Gallery Category','Gallery Category','Gallery Category','Gallery Category','mdi mdi-view-headline',5,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(44,0,0,'/items?item_type=gallery','Gallery Photos','Gallery Photos','Gallery Photos','Gallery Photos','mdi mdi-library-books',5,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(45,0,0,'/admissions','Admissions','Admissions','Admissions','Admissions','mdi mdi-account-card-details',1,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(46,0,0,'/admission_form','Admission Form','Admission Form','Admission Form','Admission Form',NULL,1,NULL,0,1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(48,0,0,'/admissions?item_type=default','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-03 23:09:51'),(49,0,0,'/admissions?item_type=admission','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-03 23:10:00'),(50,0,0,'/fees','Fees','Fees','Fees','Fees','mdi mdi-currency-inr\n',1,NULL,1,1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(51,0,0,'/dashboard','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 08:00:46'),(52,0,0,'/','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-05 08:13:41'),(53,0,0,'/items?item_type=contact','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-09 21:33:01'),(55,0,0,'/inquiry','Inquiry','Inquiry','Inquiry','Inquiry','mdi mdi-account-box',1,NULL,0,1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(56,0,0,'/item_section_form?item_type=gallery','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-21 19:15:42'),(57,0,0,'/item_form?item_type=gallery','Default Page Title','Default Meta Title','Default Meta Description',NULL,NULL,0,NULL,0,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-08-21 19:19:27'),(58,0,0,'/results','Results','Results','Results','Results','mdi mdi mdi-calendar-text\n\n',2,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-03 07:03:42'),(59,0,0,'/reports','Reports','Reports','Reports','Reports','mdi mdi mdi mdi mdi-calendar-multiple-check\r\n\r\n\r\n',2,NULL,1,0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-03 07:03:42');
/*!40000 ALTER TABLE `meta_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `results_id` int(11) NOT NULL AUTO_INCREMENT,
  `admission_id` int(11) NOT NULL DEFAULT 0,
  `enroll_for` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `result_status` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `marksheet` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(255) DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(255) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`results_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results`
--

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES (1,1,'ANM','2026-27','1','pass','1','1788685112_mark_4592.csv',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-06 08:58:32'),(2,4,'GNM','2026-27','3','pass','1','1789057995_mark_3883.jpeg',0,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-09-10 16:33:15');
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'role',
  `display_on_listing` varchar(1) NOT NULL DEFAULT 'Y',
  `show_action_checkbox` varchar(1) NOT NULL DEFAULT 'Y',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,0,'Developer','developer','role','Y','Y','N',1,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(2,0,'Super Admin','superadmin','role','Y','Y','N',1,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(3,0,'Admin','admin','role','Y','Y','Y',1,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06'),(4,0,'RoleFormmmmmmm','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:36','2026-06-13 16:38:49'),(5,0,'RoleFormmmmmmm','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:08:36','2026-06-13 16:40:49'),(6,0,'New','','role','Y','Y','Y',0,'Y',0,NULL,0,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:24:55','2026-06-13 17:55:07'),(7,0,'New','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:24:55','2026-06-13 17:55:48'),(8,0,'New2','','role','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:29','2026-06-13 18:02:35'),(9,0,'Data Entry','','role','Y','Y','Y',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:04:41','2026-09-03 07:05:08'),(10,0,'Data Entry','','role','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:04:41','2026-09-03 07:05:46');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_access`
--

DROP TABLE IF EXISTS `role_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_access` (
  `role_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `role_id` int(11) DEFAULT 0,
  `module_id` int(11) DEFAULT 0,
  `grant_add` varchar(1) NOT NULL DEFAULT 'N',
  `grant_edit` varchar(1) NOT NULL DEFAULT 'N',
  `grant_delete` varchar(1) NOT NULL DEFAULT 'N',
  `grant_view` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_access`
--

LOCK TABLES `role_access` WRITE;
/*!40000 ALTER TABLE `role_access` DISABLE KEYS */;
INSERT INTO `role_access` VALUES (18,0,4,1,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(19,0,4,2,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(20,0,4,3,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(21,0,4,4,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(22,0,4,5,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(23,0,4,8,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(24,0,4,10,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(25,0,4,15,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(26,0,4,22,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(27,0,4,23,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(28,0,4,24,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(29,0,4,26,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(30,0,4,27,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(31,0,4,28,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(32,0,4,29,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(33,0,4,30,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(34,0,4,31,'Y','Y','Y','Y',0,'Y',0,NULL,0,'Y',1,'Developer Account','2026-06-13 17:02:13','2026-06-13 13:08:49','2026-06-13 16:38:49'),(35,0,5,1,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(36,0,5,2,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(37,0,5,3,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(38,0,5,4,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(39,0,5,5,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(40,0,5,8,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(41,0,5,10,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(42,0,5,15,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(43,0,5,22,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(44,0,5,23,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(45,0,5,24,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(46,0,5,26,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(47,0,5,27,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(48,0,5,28,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(49,0,5,29,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(50,0,5,30,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(51,0,5,31,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 17:01:49','2026-06-13 13:10:49','2026-06-13 16:40:49'),(52,0,7,1,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(53,0,7,2,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(54,0,7,3,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(55,0,7,4,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(56,0,7,5,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(57,0,7,8,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(58,0,7,10,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(59,0,7,15,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(60,0,7,22,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(61,0,7,23,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(62,0,7,24,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(63,0,7,26,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(64,0,7,27,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(65,0,7,28,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(66,0,7,29,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(67,0,7,30,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(68,0,7,31,'Y','N','N','Y',0,'Y',1,'Developer Account',1,'Y',2,'Administrator User','2026-08-03 12:00:05','2026-06-13 14:25:48','2026-06-13 17:55:48'),(69,0,8,1,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(70,0,8,2,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(71,0,8,3,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(72,0,8,4,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(73,0,8,5,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(74,0,8,8,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(75,0,8,10,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(76,0,8,15,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(77,0,8,22,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(78,0,8,23,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(79,0,8,24,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(80,0,8,26,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(81,0,8,27,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(82,0,8,28,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(83,0,8,29,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(84,0,8,30,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(85,0,8,31,'N','N','N','Y',0,'Y',1,'Developer Account',1,'Y',1,'Developer Account','2026-06-13 18:05:19','2026-06-13 14:32:35','2026-06-13 18:02:35'),(86,0,1,1,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(87,0,1,2,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(88,0,1,3,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(89,0,1,4,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(90,0,1,5,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(91,0,1,8,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(92,0,1,10,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(93,0,1,15,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(94,0,1,22,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(95,0,1,23,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(96,0,1,24,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(97,0,1,26,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(98,0,1,27,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(99,0,1,28,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(100,0,1,29,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(101,0,1,30,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(102,0,1,31,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(103,0,1,43,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(104,0,1,44,'Y','Y','Y','Y',0,'Y',1,'Developer Account',1,'N',0,NULL,NULL,'2026-08-03 08:24:17','2026-08-03 11:54:17'),(206,0,2,1,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(207,0,2,2,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(208,0,2,3,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(209,0,2,4,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(210,0,2,5,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(211,0,2,8,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(212,0,2,10,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(213,0,2,15,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(214,0,2,22,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(215,0,2,23,'Y','Y','Y','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(216,0,2,24,'Y','Y','Y','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(217,0,2,26,'Y','Y','Y','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(218,0,2,27,'Y','Y','Y','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(219,0,2,28,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(220,0,2,29,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(221,0,2,30,'Y','Y','Y','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(222,0,2,31,'Y','Y','Y','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(223,0,2,43,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(224,0,2,44,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(225,0,2,45,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(226,0,2,50,'Y','Y','Y','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(227,0,2,55,'Y','Y','N','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-08-09 18:07:31','2026-08-09 21:37:31'),(250,0,9,1,'N','N','N','Y',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(251,0,9,2,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(252,0,9,3,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(253,0,9,4,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(254,0,9,5,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(255,0,9,8,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(256,0,9,10,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(257,0,9,15,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(258,0,9,22,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(259,0,9,23,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(260,0,9,24,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(261,0,9,26,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(262,0,9,27,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(263,0,9,28,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(264,0,9,29,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(265,0,9,30,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(266,0,9,31,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(267,0,9,43,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(268,0,9,44,'N','N','N','N',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(269,0,9,45,'N','N','N','Y',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(270,0,9,50,'N','N','N','Y',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(271,0,9,55,'N','N','N','Y',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(272,0,9,58,'N','N','N','Y',0,'Y',2,'Administrator User',3,'Y',2,'Administrator User','2026-09-03 07:06:25','2026-09-03 07:05:08','2026-09-03 07:05:08'),(273,0,10,1,'N','N','N','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(274,0,10,2,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(275,0,10,3,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(276,0,10,4,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(277,0,10,5,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(278,0,10,8,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(279,0,10,10,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(280,0,10,15,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(281,0,10,22,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(282,0,10,23,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(283,0,10,24,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(284,0,10,26,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(285,0,10,27,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(286,0,10,28,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(287,0,10,29,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(288,0,10,30,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(289,0,10,31,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(290,0,10,43,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(291,0,10,44,'N','N','N','N',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(292,0,10,45,'N','N','N','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(293,0,10,50,'N','N','N','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(294,0,10,55,'N','N','N','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(295,0,10,58,'N','N','N','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:05:46','2026-09-03 07:05:46'),(296,0,3,1,'Y','Y','Y','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(297,0,3,2,'Y','Y','Y','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(298,0,3,3,'Y','Y','Y','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(299,0,3,4,'Y','Y','Y','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(300,0,3,8,'Y','Y','Y','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(301,0,3,45,'N','N','N','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(302,0,3,50,'N','N','N','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(303,0,3,58,'N','N','N','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27'),(304,0,3,59,'N','N','N','Y',0,'Y',32,'Data Entry',10,'N',0,NULL,NULL,'2026-09-05 02:44:27','2026-09-05 02:44:27');
/*!40000 ALTER TABLE `role_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `config_title` varchar(1024) DEFAULT NULL,
  `config_name` varchar(1024) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `input_type` varchar(15) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 100,
  `maxlength` int(11) NOT NULL DEFAULT 100,
  `input_type_title` varchar(100) DEFAULT NULL,
  `classname` varchar(100) DEFAULT 'textbox',
  `required` varchar(1) DEFAULT 'O',
  `comments` varchar(255) DEFAULT NULL,
  `additional` varchar(100) DEFAULT NULL,
  `display_on_dashboard` varchar(1) NOT NULL DEFAULT 'N',
  `display_on_third_party` varchar(1) NOT NULL DEFAULT 'N',
  `site_config_parent_id` smallint(6) NOT NULL DEFAULT 0,
  `root_user_only` varchar(1) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,0,'Application Title','FRONT_APPLICATION_TITLE','Gopi Kids','text',100,100,'Please enter your application name for display on frontend side as title','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2026-01-30 09:34:40'),(2,0,'Records per page','FRONT_RECORD_PER_PAGE','16','select',100,60,'Records per page','form-control','Y','8@=16@=24@=32@=40@=80',NULL,'Y','Y',1,'N',5,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(3,0,'Maintenance Mode','SITE_CONSTRUCTION','No','select',100,60,'Site Under Construction Status','form-control','Y','Yes@=No',NULL,'Y','N',1,'N',12,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-12-07 22:07:04'),(4,0,'Default Timezone','FRONT_DEFAULT_TIMEZONE','Asia/Kolkata','select',100,60,'Default Timezone','form-control','Y','America/Chicago@=Asia/Kolkata@=Europe/London@=Australia/Perth',NULL,'Y','Y',1,'N',13,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(5,0,'Backend application Title','BACKEND_APPLICATION_TITLE','Gopi Kids :: Administrator','text',100,60,'Application Title','form-control','Y',NULL,NULL,'Y','N',2,'N',14,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:08:57'),(6,0,'Meta Description','FRONT_META_DESCRIPTION','Education center','text',100,60,'Meta Description','form-control','Y',NULL,NULL,'N','N',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2020-04-17 01:06:07'),(7,0,'Default Robots','FRONT_DEFAULT_ROBOTS','INDEX,FOLLOW','select',100,60,'Default Robots','form-control','Y','INDEX,FOLLOW@=NOINDEX@=NOFOLLOW@=NOINDEX,NOFOLLOW',NULL,'Y','Y',3,'N',25,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-17 08:06:12'),(8,0,'Company Name','COMPANY_NAME','Gopi Kids','text',100,60,'Company Name','form-control','Y',NULL,NULL,'N','Y',5,'N',64,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-11-07 22:26:19'),(9,0,'Company Address','COMPANY_ADDRESS1','A-2 Springfield, Opp. Gayatri Temple,','text',100,60,'Company Address','form-control','Y',NULL,NULL,'N','Y',5,'N',65,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(10,0,'Company Address 2','COMPANY_ADDRESS2','New Waghodia Road','text',100,60,'Company Address 2','form-control','Y',NULL,NULL,'N','Y',5,'N',66,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 08:43:53'),(11,0,'City','COMPANY_CITY','Vadodara','text',100,60,'City','form-control','Y',NULL,NULL,'N','Y',5,'N',67,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(12,0,'State','COMPANY_STATE','GJ','text',100,60,'State','form-control','Y',NULL,NULL,'N','Y',5,'N',68,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(13,0,'Country','COMPANY_COUNTRY','INN','text',100,60,'Country','form-control','Y',NULL,NULL,'N','Y',5,'N',69,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(14,0,'Zipcode','COMPANY_ZIPCODE','390009','text',100,60,'Zipcode','form-control','Y','max six digits',NULL,'N','Y',5,'N',70,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(15,0,'Contact Number','COMPANY_CONTACT_NUMBER','7698980699','text',100,60,'Contact Number','form-control','Y',NULL,NULL,'N','Y',5,'N',71,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2020-04-13 11:50:21'),(16,0,'Contact us email address','COMPANY_EMAIL','info@gopikids.in','email',100,60,'Contact us email address','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-08-13 00:40:23'),(17,0,'Contact us person name','COMPANY_CONTACT_PERSON','Sangita Gohil','text',100,60,'Contact us person name','form-control','Y',NULL,NULL,'N','Y',8,'N',75,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-08-13 01:15:54'),(18,0,'Allow Sending emails','ALLOW_SENDING_EMAIL','Yes','select',100,5,'Allow to send email throughout site? If no, not a single email will execute in this project.','form-control','Y','Yes@=No',NULL,'N','N',8,'N',82,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(19,0,'Order email name','ORDER_CONTACT_PERSON','Jayesh Gohil','text',100,60,'order person name','form-control','Y',NULL,NULL,'N','N',8,'N',75,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-11-18 20:14:30'),(20,0,'From email address','FROM_EMAIL_ADDRESS','support@gopikids.in','email',100,60,'from email address','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2021-06-21 21:54:54'),(21,0,'Backend Logo title display','BACKEND_LOGO_TITLE_DISPLAY','Administrator','text',100,60,'backend_logo_title_display','form-control','Y','',NULL,'N','Y',2,'N',8,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(22,0,'Content to display before end of body tag','CONTENT_BEFORE_BODY_TAG','','textarea',100,6000,'Please enter content that will before close of body tag.','form-control','N',NULL,NULL,'N','Y',6,'N',26,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 09:24:46'),(23,0,'Script after begin head tag','AFTER_HEAD_TAG','','text',100,60,'After head tag javacript script','form-control','N',NULL,NULL,'N','Y',3,'N',39,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 08:43:53'),(24,0,'Application json script','APPLICATION_JSON_SCRIPT','','textarea',100,6000,'Application json script','form-control','N',NULL,NULL,'N','Y',3,'N',26,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-09-24 09:24:46'),(25,0,'Upload Max Size','UPLOAD_MAX_FILESIZE','2M','select',100,60,'Upload Max Size','form-control','Y','2M@=8M@=16M@=24M',NULL,'N','N',4,'N',44,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(26,0,'Facebook','FACEBOOK_URL','https://www.facebook.com/cloudswiftsolutions/','text',100,60,'Please enter your facebook page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:58:52'),(27,0,'Twitter','TWITTER_URL','https://twitter.com/cloudswiftsolutions','text',100,60,'Please enter your twitter page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:59:00'),(28,0,'Linkedin','LINKEDIN_URL','https://www.linkedin.com/company/cloudswiftsolutions/','text',100,60,'Please enter your Linkedin page url','form-control','N',NULL,NULL,'N','Y',7,'N',40,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-10-14 07:59:06'),(29,0,'Allow to sent email to admin for contact,feedback,etc.','ALLOW_CONTACT_EMAIL','Y','select',100,60,'Please select option','form-control','Y','Y@=N',NULL,'Y','N',8,'N',5,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 13:00:00','2019-04-11 21:45:59'),(30,0,'Application Name','FRONT_APPLICATION_NAME','Demonstration Project','text',100,100,'Please enter your application name for display on frontend side as name','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2019-10-14 13:22:59'),(31,0,'Closed Store Status','CLOSED_STORE_STATUS','N','select',100,100,'This store is closed at present.','form-control','Y','Y@=N',NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-02 10:54:46'),(32,0,'Closed Store Message','CLOSED_STORE_MESSAGE','Store is Under Construction','text',100,100,'Closed Store Message','form-control','Y',NULL,NULL,'Y','Y',1,'N',1,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-02 10:52:45'),(33,0,'BCC Email 1','BCC_EMAIL_1','bcc@yopmail.com','email',100,60,'BCC Email','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2026-01-29 15:39:46'),(34,0,'SMTP HOST','SMTP_HOST','smtp.hostinger.com','text',100,60,'SMTP HOST','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-13 06:20:26'),(35,0,'SMTP PORT','SMTP_PORT','587','text',100,60,'SMTP Port','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2023-09-16 22:32:56'),(36,0,'SMTP PASSWORD','SMTP_PASSWORD','Cloud@112018','email',100,60,'SMTP PASSWORD','form-control','Y',NULL,NULL,'N','Y',8,'N',74,'Y',0,NULL,0,'N',0,NULL,NULL,'2019-04-11 18:30:00','2021-08-13 06:20:26');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config_parent`
--

DROP TABLE IF EXISTS `site_config_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config_parent` (
  `site_config_parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `site_config_title` varchar(191) NOT NULL,
  `classname` varchar(191) NOT NULL,
  `root_user_only` varchar(1) NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`site_config_parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config_parent`
--

LOCK TABLES `site_config_parent` WRITE;
/*!40000 ALTER TABLE `site_config_parent` DISABLE KEYS */;
INSERT INTO `site_config_parent` VALUES (1,0,'Frontend Settings','collapseOne','N',1,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(2,0,'Backend Settings','collapseTwo','N',2,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(3,0,'SEO Settings','collapseThree','N',3,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(4,0,'Security Settings','collapseFour','Y',4,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(5,0,'Site Details','collapseSeven','N',7,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(6,0,'Privacy Settings','collapseNine','Y',9,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(7,0,'Follow Us','collapseTen','Y',10,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06'),(8,0,'Email Settings','collapseEight','N',8,'Y',0,NULL,0,'N',0,NULL,NULL,NULL,'2026-05-26 12:32:06');
/*!40000 ALTER TABLE `site_config_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `site_db` varchar(255) DEFAULT NULL,
  `user_firstname` varchar(255) DEFAULT NULL,
  `user_lastname` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_token` varchar(255) DEFAULT NULL,
  `user_photo` varchar(255) DEFAULT NULL,
  `user_role_id` smallint(6) NOT NULL DEFAULT 0,
  `is_developer_account` varchar(1) NOT NULL DEFAULT 'N',
  `allow_delete` varchar(1) NOT NULL DEFAULT 'Y',
  `web_or_app` varchar(4) NOT NULL DEFAULT 'App',
  `active_status` varchar(25) NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` varchar(1) NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_by_role` int(11) NOT NULL DEFAULT 0,
  `deleted_status` varchar(1) NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `add_1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'nodejsframework','Developer','Account','developer','developer112018@yopmail.com','$2b$12$A1kkSLpFoyNxFpl9LRiWfOhfSf3t61UGw72tYIWtaZtBuo3tFBHJW',NULL,NULL,1,'Y','N','Web','Y',0,'Y',0,NULL,0,'N',0,NULL,NULL,'2026-05-26 12:32:06','2026-05-26 12:32:06',NULL),(2,1,'nodejsframework','Administrator','User','ravindrahn','glorious082026@yopmail.com','$2a$10$kJTPNZHNRH8L.YWfYLqsX.eZNpNRvzW/6ZnqD0nauEpxObP2kDw26','511882',NULL,3,'N','N','App','Y',0,'Y',0,NULL,0,'N',0,NULL,'2026-07-10 18:11:23','2026-05-26 12:32:06','2026-05-26 12:32:06',NULL),(31,0,NULL,'John 31','Doe',NULL,'john@example.com','$2b$12$bS55o0.lbacsuS2sZUL4t.gSUH6MPLkwNINI8MKIZMO.htznhPRoq',NULL,NULL,3,'N','Y','App','Y',0,'Y',1,'',1,'N',0,NULL,NULL,'2026-07-10 18:12:31','2026-07-10 18:13:08',NULL),(32,0,'u797036281_glocollege','Data','Entry','dataentry','dataentry@yopmail.com','c671cf1dc2975aa97094dcb4cc74dd2a','',NULL,10,'N','Y','App','Y',0,'Y',2,'Administrator User',3,'N',0,NULL,NULL,'2026-09-03 07:06:42','2026-09-03 07:06:55',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-23 11:00:05
