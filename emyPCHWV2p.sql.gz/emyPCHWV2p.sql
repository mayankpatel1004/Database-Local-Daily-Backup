-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emyPCHWV2p
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AREA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text DEFAULT NULL,
  `MASTER` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint(20) DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'243','0','emyPCHWV2p',243,'','','','2026-05-06 10:44:32','2026-05-06 10:44:32','','','','','','','','','2026-05-06 10:44:32','391','391','',0,'2026-05-06 10:44:32','2026-05-06 10:44:32');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text DEFAULT NULL,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (243,NULL,NULL,'1','temptemp','2025-04-01','2026-03-31','temp','','temp','21','2222222222','','','','','','','','','','','','','','',NULL,'0',NULL,NULL,'27','','','temptemp@yopmail.com','','222222',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-05-06 10:44:32','2026-05-06 10:46:07',NULL,'','','temptemp','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `CREATED_TS` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `BATCH_ID` int(11) DEFAULT 0,
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DISP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text DEFAULT NULL,
  `DELETED` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text DEFAULT NULL,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int(11) DEFAULT 0,
  `TAX_ID` int(11) DEFAULT 0,
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `INV_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'243',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'243',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'243',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'243',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'243',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'243',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'243',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'243',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'243',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'243',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'243',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'243',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'243',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'243',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LEDGER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `MAC_ID` int(11) DEFAULT 0,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int(11) DEFAULT 0,
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int(11) DEFAULT 0,
  `ROOT_PARENT_ID` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text DEFAULT NULL,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `SAC_ID` int(11) NOT NULL DEFAULT 0,
  `REMOTE_ID` int(11) NOT NULL DEFAULT 0,
  `PENDING_AMT` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `PROD_ID` int(11) NOT NULL DEFAULT 0,
  `PACK` int(11) NOT NULL DEFAULT 0,
  `PROD_BATCH_ID` int(11) NOT NULL DEFAULT 0,
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_RET_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `PUR_TOTAL` int(11) NOT NULL DEFAULT 0,
  `SALE_QTY` int(11) DEFAULT 0,
  `SALE_RET_QTY` int(11) DEFAULT 0,
  `SALE_CHALLAN_QTY` int(11) NOT NULL DEFAULT 0,
  `SALE_TOTAL` int(11) NOT NULL DEFAULT 0,
  `OP_STOCK` int(11) NOT NULL DEFAULT 0,
  `CLOSING_STOCK` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'243',NULL,NULL,'101',NULL,'','CH MANGO PICKLE JAR 200 GM','CH MANGO PICKLE JAR 200 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:46:40',NULL),(2,'243',NULL,NULL,'101A',NULL,'','CH MANGO PET JAR 100 G','CH MANGO PET JAR 100 G','2001','100','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:46:47',NULL),(3,'243',NULL,NULL,'102',NULL,'','CH MIXED PICKLE JAR 200 GM','CH MIXED PICKLE JAR 200 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:46:53',NULL),(4,'243',NULL,NULL,'102A',NULL,'','CH MIXED PET JAR 100 G','CH MIXED PET JAR 100 G','2001','100','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:02',NULL),(5,'243',NULL,NULL,'103',NULL,'','CH LIME PICKLE JAR 200 GM','CH LIME PICKLE JAR 200 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:08',NULL),(6,'243',NULL,NULL,'104',NULL,'','CH CHILLY PICKLE JAR 200 GM','CH CHILLY PICKLE JAR 200 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:16',NULL),(7,'243',NULL,NULL,'105',NULL,'','CH SWEET MANGO PICKLE 200 GM','CH SWEET MANGO PICKLE 200 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:24',NULL),(8,'243',NULL,NULL,'106',NULL,'','CH SWEET LEMON PICKLE 200 GM','CH SWEET LEMON PICKLE 200 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:31',NULL),(9,'243',NULL,NULL,'107',NULL,'','CH MANGO PICKLE JAR 500 GM','CH MANGO PICKLE JAR 500 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:38',NULL),(10,'243',NULL,NULL,'108',NULL,'','CH MIXED PICKLE JAR 500 GM','CH MIXED PICKLE JAR 500 GM','2001','1','2',NULL,'1','CHANDRADEEP','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:46',NULL),(11,'243',NULL,NULL,'109',NULL,'','CH MANGO PICKLE JAR 1 KG','CH MANGO PICKLE JAR 1 KG','2001','1','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:47:53',NULL),(12,'243',NULL,NULL,'110',NULL,'','CH MIXED PICKLE JAR 1 KG','CH MIXED PICKLE JAR 1 KG','2001','1','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:01',NULL),(13,'243',NULL,NULL,'110A',NULL,'','CH CHILLY PICKLE 1 KG','CH CHILLY PICKLE 1 KG','2001','1','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:07',NULL),(14,'243',NULL,NULL,'111',NULL,'','CH MANGO PICKLE JAR 5 KG','CH MANGO PICKLE JAR 5 KG','2001','1','2',NULL,'1','CHANDRADEEP','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:10',NULL),(15,'243',NULL,NULL,'112',NULL,'','CH.SUPER MANGO PICKLE 5 KG','CH.SUPER MANGO PICKLE 5 KG','2001','1','2',NULL,'1','CHANDRADEEP','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:16',NULL),(16,'243',NULL,NULL,'113',NULL,'','CH KOKAM SYRUP 500 ML','CH KOKAM SYRUP 500 ML','200899','500','2',NULL,'1','CHANDRADEEP','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:22',NULL),(17,'243',NULL,NULL,'113A',NULL,'','CH KOKAM SYRUP 1 LIT','CH KOKAM SYRUP 1 LIT','200899','1','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:28',NULL),(18,'243',NULL,NULL,'113B',NULL,'','CH KOKUM SYRUP 5 LIT','CH KOKUM SYRUP 5 LIT','2106','5','2',NULL,'1','CHANDRADEEP','7','7','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:37',NULL),(19,'243',NULL,NULL,'114',NULL,'','CH KOKAM AAGAL 500 ML','CH KOKAM AAGAL 500 ML','200931','500','2',NULL,'1','CHANDRADEEP','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:39',NULL),(20,'243',NULL,NULL,'114A',NULL,'','CH KOKAM AAGAL 1 LIT','CH KOKAM AAGAL 1 LIT','200931','1','2',NULL,'1','CHANDRADEEP','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:51',NULL),(21,'243',NULL,NULL,'115',NULL,'','ROOH AFZA 750 ML','ROOH AFZA 750 ML','21069011','750','2',NULL,'2','ROOH AFZA','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','ROOH AFZA',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:48:59',NULL),(22,'243',NULL,NULL,'115A',NULL,'','CLAIM','CLAIM','NULL','1','2',NULL,'1','CHANDRADEEP','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:03',NULL),(23,'243',NULL,NULL,'115B',NULL,'','ROOH AFZA 250 ML','ROOH AFZA 250 ML','21069011','250','2',NULL,'2','ROOH AFZA','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','ROOH AFZA',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:05',NULL),(24,'243',NULL,NULL,'116',NULL,'','ELEPHANT PLAIN SEVAI 250 GM','ELEPHANT PLAIN SEVAI 250 GM','19024090','1','2',NULL,'3','ELEPHANT','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','ELEPHANT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:07',NULL),(25,'243',NULL,NULL,'116A',NULL,'','ELEPHANT PLAIN SEVAI ROLL 500 G','ELEPHANT PLAIN SEVAI ROLL 500 G','19024090','500','2',NULL,'3','ELEPHANT','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','ELEPHANT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:16',NULL),(26,'243',NULL,NULL,'117',NULL,'','ELEPHANT ROASTED SEVAI 250 GM','ELEPHANT ROASTED SEVAI 250 GM','19024090','1','2',NULL,'3','ELEPHANT','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','ELEPHANT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:18',NULL),(27,'243',NULL,NULL,'118',NULL,'','ELEPHANT ROSTED SEVAI POLLY 150 GM','ELEPHANT ROSTED SEVAI POLLY 150 GM','19024090','150','2',NULL,'3','ELEPHANT','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','ELEPHANT',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:30',NULL),(28,'243',NULL,NULL,'119',NULL,'','OTHER SERVICES','OTHER SERVICES','998599','1','2',NULL,'1','CHANDRADEEP','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:36',NULL),(29,'243',NULL,NULL,'120',NULL,'','CONCORD RICE SEVAI 200 GM','CONCORD RICE SEVAI 200 GM','19023090','1','2',NULL,'4','CONCORD','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','CONCORD',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:38',NULL),(30,'243',NULL,NULL,'121',NULL,'','CONCORD RICE SEVAI 500 GM','CONCORD RICE SEVAI 500 GM','19023090','1','2',NULL,'4','CONCORD','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','CONCORD',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:44',NULL),(31,'243',NULL,NULL,'122',NULL,'','JGD NAGALI BISCUITS 150 G','JGD NAGALI BISCUITS 150 G','19053100','150','2',NULL,'5','JAHAGIRDAR','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:50',NULL),(32,'243',NULL,NULL,'122A',NULL,'','JGD DIBICHECK BISCUITS 150 G','JGD DIBICHECK BISCUITS 150 G','19053100','150','2',NULL,'5','JAHAGIRDAR','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:49:54',NULL),(33,'243',NULL,NULL,'122B',NULL,'','JGD KANIK BISCUITS 150 G','JGD KANIK BISCUITS 150 G','19053100','150','2',NULL,'5','JAHAGIRDAR','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:00',NULL),(34,'243',NULL,NULL,'122C',NULL,'','JGD NAGALI NO SUGAR BISCUITS 150 G','JGD NAGALI NO SUGAR BISCUITS 150 G','19053100','150','2',NULL,'5','JAHAGIRDAR','7','7','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:02',NULL),(35,'243',NULL,NULL,'122D',NULL,'','JGD NASHIK CHIVDA 200 G','JGD NASHIK CHIVDA 200 G','21069099','200','2',NULL,'5','JAHAGIRDAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:08',NULL),(36,'243',NULL,NULL,'122E',NULL,'','JGD JOWAR CHIVDA 200 G','JGD JOWAR CHIVDA 200 G','21069099','200','2',NULL,'5','JAHAGIRDAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:15',NULL),(37,'243',NULL,NULL,'122F',NULL,'','JGD PATAL POHE CHIWDA 200 G','JGD PATAL POHE CHIWDA 200 G','21069099','200','2',NULL,'5','JAHAGIRDAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:21',NULL),(38,'243',NULL,NULL,'122G',NULL,'','JGD RAGI MILLET  CHIWDA 200 G','JGD RAGI MILLET  CHIWDA 200 G','21069099','200','2',NULL,'5','JAHAGIRDAR','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:27',NULL),(39,'243',NULL,NULL,'122H',NULL,'','JGD CREAM ROLL (4 PEC)','JGD CREAM ROLL (4 PEC)','19054000','200','2',NULL,'5','JAHAGIRDAR','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','JAHAGIRDAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:33',NULL),(40,'243',NULL,NULL,'123',NULL,'','LTS MAKHANA POPS MASALA MUNCH 50 G','LTS MAKHANA POPS MASALA MUNCH 50 G','19059030','50','2',NULL,'6','LG','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:35',NULL),(41,'243',NULL,NULL,'123A',NULL,'','LTS MAKHANA POPS CREAM & ONION 50 G','LTS MAKHANA POPS CREAM & ONION 50 G','19059030','50','2',NULL,'6','LG','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:38',NULL),(42,'243',NULL,NULL,'123B',NULL,'','LTS MAKHANA POPS BBQ 50 G','LTS MAKHANA POPS BBQ 50 G','19059030','50','2',NULL,'6','LG','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:40',NULL),(43,'243',NULL,NULL,'123C',NULL,'','LTS MAKHANA POPS HOT N SWEET 50 G','LTS MAKHANA POPS HOT N SWEET 50 G','19059030','50','2',NULL,'6','LG','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:42',NULL),(44,'243',NULL,NULL,'123O',NULL,'','LTS MAKHANA POPS TOMATO 50 G','LTS MAKHANA POPS TOMATO 50 G','19059030','50','2',NULL,'6','LG','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:44',NULL),(45,'243',NULL,NULL,'124',NULL,'','L.G.HING POWDER 50 GM','L.G.HING POWDER 50 GM','13019013','1','2',NULL,'6','LG','7','7','200',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','200','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:46',NULL),(46,'243',NULL,NULL,'124A',NULL,'','L.G HING POWDER 15 G','L.G HING POWDER 15 G','13019013','15','2',NULL,'6','LG','7','7','600',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','600','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:53',NULL),(47,'243',NULL,NULL,'125',NULL,'','L.G.HING POWDER 100 GM','L.G.HING POWDER 100 GM','13019013','1','2',NULL,'6','LG','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:50:55',NULL),(48,'243',NULL,NULL,'126',NULL,'','L.G.HING POWDER 200 GM','L.G.HING POWDER 200 GM','13019013','1','2',NULL,'6','LG','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:01',NULL),(49,'243',NULL,NULL,'127',NULL,'','L.G.HING POWDER 500 GM','L.G.HING POWDER 500 GM','13019013','1','2',NULL,'6','LG','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:08',NULL),(50,'243',NULL,NULL,'128',NULL,'','L.G.HING KHADA 100 GM','L.G.HING KHADA 100 GM','13019013','1','2',NULL,'6','LG','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:16',NULL),(51,'243',NULL,NULL,'128A',NULL,'','L.G HING EXTRA SCHEME 50 G','L.G HING EXTRA SCHEME 50 G','13019013','50','2',NULL,'6','LG','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:22',NULL),(52,'243',NULL,NULL,'128B',NULL,'','LTS PRIMIUM RAW MAKHANA 250 G','LTS PRIMIUM RAW MAKHANA 250 G','08129090','250','2',NULL,'6','LG','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:25',NULL),(53,'243',NULL,NULL,'129',NULL,'','MAKHANA POPS TOMATO TWIST 25 G','MAKHANA POPS TOMATO TWIST 25 G','19059030','25','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:27',NULL),(54,'243',NULL,NULL,'129A',NULL,'','MQAKHANA POPS CREAM ONION 25 G','MQAKHANA POPS CREAM ONION 25 G','19059030','25','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:29',NULL),(55,'243',NULL,NULL,'129B',NULL,'','MAKHANA POPS INDIAN BBQ 25 G','MAKHANA POPS INDIAN BBQ 25 G','19059030','25','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:31',NULL),(56,'243',NULL,NULL,'129C',NULL,'','MAKHANA POPS HOT N SWEET 25 G','MAKHANA POPS HOT N SWEET 25 G','19059030','25','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:33',NULL),(57,'243',NULL,NULL,'129D',NULL,'','MAKHANA POPS MASALA MUNCH 25 G','MAKHANA POPS MASALA MUNCH 25 G','19059030','1','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:35',NULL),(58,'243',NULL,NULL,'130A',NULL,'','CHITALE SPECIAL BAKARWADI 250 G','CHITALE SPECIAL BAKARWADI 250 G','21069091','250','2',NULL,'6','LG','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:37',NULL),(59,'243',NULL,NULL,'130B',NULL,'','CHITALE SPECIAL BAKARWADI 500 G','CHITALE SPECIAL BAKARWADI 500 G','21069091','500','2',NULL,'6','LG','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:40',NULL),(60,'243',NULL,NULL,'131',NULL,'','LOTUS MAKHANA CREAM & ONION 20 G','LOTUS MAKHANA CREAM & ONION 20 G','21069099','20','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:42',NULL),(61,'243',NULL,NULL,'131A',NULL,'','LOTUS RAW MAKHANA 100 G','LOTUS RAW MAKHANA 100 G','08129090','100','2',NULL,'6','LG','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:44',NULL),(62,'243',NULL,NULL,'131B',NULL,'','LOTUS RAW MAKHANA 250 G','LOTUS RAW MAKHANA 250 G','08129090','250','2',NULL,'6','LG','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:46',NULL),(63,'243',NULL,NULL,'131C',NULL,'','LOTUS MAKHANA PUDINA 20 G','LOTUS MAKHANA PUDINA 20 G','21069099','20','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:48',NULL),(64,'243',NULL,NULL,'131D',NULL,'','LOTUS MAKHANA SPANISH TOMATO 20 G','LOTUS MAKHANA SPANISH TOMATO 20 G','21069099','20','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:51',NULL),(65,'243',NULL,NULL,'131E',NULL,'','LOTUS MAKHANA ITALIAN CHEESE 20 G','LOTUS MAKHANA ITALIAN CHEESE 20 G','21069099','20','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:53',NULL),(66,'243',NULL,NULL,'131F',NULL,'','LOTUS MAKHANA PERI PERI 20 G','LOTUS MAKHANA PERI PERI 20 G','21069099','20','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:55',NULL),(67,'243',NULL,NULL,'131G',NULL,'','LOTUS HIMALAYAN SALT 20 G','LOTUS HIMALAYAN SALT 20 G','21069099','20','2',NULL,'6','LG','7','7','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:51:58',NULL),(68,'243',NULL,NULL,'131H',NULL,'','LOTUS MAKHANA CREAM & ONION 55 G','LOTUS MAKHANA CREAM & ONION 55 G','21069099','55','2',NULL,'6','LG','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:00',NULL),(69,'243',NULL,NULL,'131I',NULL,'','LOTUS MAKHANA PUDINA 55 G','LOTUS MAKHANA PUDINA 55 G','21069099','55','2',NULL,'6','LG','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:02',NULL),(70,'243',NULL,NULL,'131J',NULL,'','LOTUS MAKHANA SPANISH TOMATO 55 G','LOTUS MAKHANA SPANISH TOMATO 55 G','21069099','55','2',NULL,'6','LG','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:04',NULL),(71,'243',NULL,NULL,'131K',NULL,'','LOTUS MAKHANA ITALIAN CHEESE 55 G','LOTUS MAKHANA ITALIAN CHEESE 55 G','21069099','55','2',NULL,'6','LG','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:07',NULL),(72,'243',NULL,NULL,'131L',NULL,'','LOTUS MAKHANA PERI PERI 55 G','LOTUS MAKHANA PERI PERI 55 G','21069099','55','2',NULL,'6','LG','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:09',NULL),(73,'243',NULL,NULL,'131M',NULL,'','LOTUS MAKHANA HIMALAYAN SALT 55 G','LOTUS MAKHANA HIMALAYAN SALT 55 G','21069099','55','2',NULL,'6','LG','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:11',NULL),(74,'243',NULL,NULL,'132',NULL,'','JALANI JALJIRA POWDER RS.2','JALANI JALJIRA POWDER RS.2','9109100','1','2',NULL,'7','JALANI','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','JALANI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:14',NULL),(75,'243',NULL,NULL,'133',NULL,'','JYOTI DELUXE SOAP 700 GM','JYOTI DELUXE SOAP 700 GM','34011942','700','2',NULL,'8','JYOTI','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:16',NULL),(76,'243',NULL,NULL,'134',NULL,'','AQUSA WASHING SOAP 900 GM','AQUSA WASHING SOAP 900 GM','34011942','900','2',NULL,'8','JYOTI','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:20',NULL),(77,'243',NULL,NULL,'135',NULL,'','JYOTI SUPREME SOAP 850 GM','JYOTI SUPREME SOAP 850 GM','34011942','1','2',NULL,'8','JYOTI','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:23',NULL),(78,'243',NULL,NULL,'136',NULL,'','JYOTI WASHING SOAP 850 GM','JYOTI WASHING SOAP 850 GM','34011942','1','2',NULL,'8','JYOTI','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:25',NULL),(79,'243',NULL,NULL,'137',NULL,'','DOLLER SUPER WASHING SOAP 700 G','DOLLER SUPER WASHING SOAP 700 G','34011942','700','2',NULL,'8','JYOTI','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:31',NULL),(80,'243',NULL,NULL,'137A',NULL,'','JYOTI ULTRA WASH CLOTH 500 ML','JYOTI ULTRA WASH CLOTH 500 ML','34022010','500','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:36',NULL),(81,'243',NULL,NULL,'137B',NULL,'','JYOTI ULTRA WASH CLOTH 1 LTR','JYOTI ULTRA WASH CLOTH 1 LTR','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:38',NULL),(82,'243',NULL,NULL,'137C',NULL,'','JYT ULTRA WASH CLOTH 5 LIT','JYT ULTRA WASH CLOTH 5 LIT','34022010','5','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:40',NULL),(83,'243',NULL,NULL,'138',NULL,'','JYOTI DETERGENT POWDER 110 G','JYOTI DETERGENT POWDER 110 G','34029011','110','2',NULL,'8','JYOTI','7','7','125',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','125','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:43',NULL),(84,'243',NULL,NULL,'138A',NULL,'','JYOTI DETERGENT POWDER 500 G','JYOTI DETERGENT POWDER 500 G','34029011','500','2',NULL,'8','JYOTI','7','7','50',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:45',NULL),(85,'243',NULL,NULL,'138B',NULL,'','JYOTI DETERGENT POWDER 1 KG','JYOTI DETERGENT POWDER 1 KG','34029011','1','2',NULL,'8','JYOTI','7','7','25',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','25','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:47',NULL),(86,'243',NULL,NULL,'139',NULL,'','JYOTI RED LIQUID SOAP 900 ML','JYOTI RED LIQUID SOAP 900 ML','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:52:52',NULL),(87,'243',NULL,NULL,'140',NULL,'','JYOTI YELLOW LIQUID SOAP 900ML','JYOTI YELLOW LIQUID SOAP 900ML','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:01',NULL),(88,'243',NULL,NULL,'141',NULL,'','JYOTI GREEN LIQUID SOAP 900 ML','JYOTI GREEN LIQUID SOAP 900 ML','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:06',NULL),(89,'243',NULL,NULL,'142',NULL,'','JYOTI BLUE LIQUID SOAP 900 ML','JYOTI BLUE LIQUID SOAP 900 ML','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:15',NULL),(90,'243',NULL,NULL,'143',NULL,'','JYOTI RED LIQUID SOAP 4.5 LTR','JYOTI RED LIQUID SOAP 4.5 LTR','34022010','1','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:22',NULL),(91,'243',NULL,NULL,'144',NULL,'','JYOTI YELLOW LIQUID SOAP 4.5ML','JYOTI YELLOW LIQUID SOAP 4.5ML','34022010','1','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:27',NULL),(92,'243',NULL,NULL,'145',NULL,'','JYOTI GREEN LIQUID SOAP 4.5LTR','JYOTI GREEN LIQUID SOAP 4.5LTR','34022010','1','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:31',NULL),(93,'243',NULL,NULL,'146',NULL,'','JYOTI BLUE LIQUID SOAP 4.5 LTR','JYOTI BLUE LIQUID SOAP 4.5 LTR','34022010','1','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:36',NULL),(94,'243',NULL,NULL,'147',NULL,'','JYOTI GREEN PINE CLEANER 200ML','JYOTI GREEN PINE CLEANER 200ML','34022010','1','2',NULL,'8','JYOTI','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:40',NULL),(95,'243',NULL,NULL,'148',NULL,'','JYOTI GREEN PINE CLEANER 500ML','JYOTI GREEN PINE CLEANER 500ML','34022010','1','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:53:57',NULL),(96,'243',NULL,NULL,'149',NULL,'','JYOTI GREEN PINE CLEANER 1LTR','JYOTI GREEN PINE CLEANER 1LTR','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:06',NULL),(97,'243',NULL,NULL,'150',NULL,'','JYOTI GREEN PINE CLEANER 5 LTR','JYOTI GREEN PINE CLEANER 5 LTR','34022010','1','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:15',NULL),(98,'243',NULL,NULL,'150A',NULL,'','ECO LEMONGRASS F.C 200 ML','ECO LEMONGRASS F.C 200 ML','34022010','1','2',NULL,'8','JYOTI','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:20',NULL),(99,'243',NULL,NULL,'150B',NULL,'','ECO LEMONGRASS F.C 500 ML','ECO LEMONGRASS F.C 500 ML','34022010','1','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:22',NULL),(100,'243',NULL,NULL,'150C',NULL,'','ECO LEMONGRASS F.C 1-LIT','ECO LEMONGRASS F.C 1-LIT','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:25',NULL),(101,'243',NULL,NULL,'150D',NULL,'','ECO LEMONGRASS F.C 5 LIT','ECO LEMONGRASS F.C 5 LIT','34022010','1','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:27',NULL),(102,'243',NULL,NULL,'151',NULL,'','JYOTI DISHWASH ROUND 220 G','JYOTI DISHWASH ROUND 220 G','34054000','1','2',NULL,'8','JYOTI','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:30',NULL),(103,'243',NULL,NULL,'152',NULL,'','JYOTI DISHWASH ROUND 450 G','JYOTI DISHWASH ROUND 450 G','34011942','1','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:37',NULL),(104,'243',NULL,NULL,'153',NULL,'','JYOTI DISHWASH GEL 500 ML','JYOTI DISHWASH GEL 500 ML','34022010','1','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:39',NULL),(105,'243',NULL,NULL,'153A',NULL,'','JYOTI DISH WASH GEL-1 LIT','JYOTI DISH WASH GEL-1 LIT','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:44',NULL),(106,'243',NULL,NULL,'153B',NULL,'','JYT DISHWASH GEL 250 ML','JYT DISHWASH GEL 250 ML','34022010','250','2',NULL,'8','JYOTI','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:46',NULL),(107,'243',NULL,NULL,'153C',NULL,'','JYT DISHWASH GEL 250 ML','JYT DISHWASH GEL 250 ML','34022010','250','2',NULL,'8','JYOTI','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:49',NULL),(108,'243',NULL,NULL,'153D',NULL,'','JYOTI GLASS CLEANER 500 ML','JYOTI GLASS CLEANER 500 ML','34022020','500','2',NULL,'8','JYOTI','7','7','30',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:51',NULL),(109,'243',NULL,NULL,'154',NULL,'','JYOTI PINK SURFACE CLEANER 500 ML','JYOTI PINK SURFACE CLEANER 500 ML','34022010','500','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:53',NULL),(110,'243',NULL,NULL,'154A',NULL,'','JYOTI PINK SURFACE CLEANER 5 LIT','JYOTI PINK SURFACE CLEANER 5 LIT','34022010','5','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:54:58',NULL),(111,'243',NULL,NULL,'155',NULL,'','JYOTI YELLOW SURFACE CLEANER 500 ML','JYOTI YELLOW SURFACE CLEANER 500 ML','34022010','500','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:01',NULL),(112,'243',NULL,NULL,'155A',NULL,'','JYOTI YELLOW SURFACE CLEANER 5 LIT','JYOTI YELLOW SURFACE CLEANER 5 LIT','34022010','5','2',NULL,'8','JYOTI','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:05',NULL),(113,'243',NULL,NULL,'155B',NULL,'','JYOTI TOILET CLEANER 01 LIT','JYOTI TOILET CLEANER 01 LIT','34022020','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:08',NULL),(114,'243',NULL,NULL,'155C',NULL,'','JYOTI TOILET CLEANER 5 LIT','JYOTI TOILET CLEANER 5 LIT','34022020','5','2',NULL,'8','JYOTI','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:10',NULL),(115,'243',NULL,NULL,'155D',NULL,'','JYOTI TOILET CLEANER 250 ML','JYOTI TOILET CLEANER 250 ML','34022010','250','2',NULL,'8','JYOTI','7','7','35',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','35','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:13',NULL),(116,'243',NULL,NULL,'156',NULL,'','JYOTI TOILET CLEANER 500 ML','JYOTI TOILET CLEANER 500 ML','34022020','1','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:15',NULL),(117,'243',NULL,NULL,'156A',NULL,'','JYOTI BATHROOM CLEANER 500 ML','JYOTI BATHROOM CLEANER 500 ML','34022010','500','2',NULL,'8','JYOTI','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:20',NULL),(118,'243',NULL,NULL,'156B',NULL,'','JYOTI BATHROOMCLEANER 1 LIT','JYOTI BATHROOMCLEANER 1 LIT','34022010','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:23',NULL),(119,'243',NULL,NULL,'157',NULL,'','JY HANDWASH AQUA COMBO 250 ML','JY HANDWASH AQUA COMBO 250 ML','34013019','1','2',NULL,'8','JYOTI','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:25',NULL),(120,'243',NULL,NULL,'157A',NULL,'','JYOTI HANDWASH AQUA 5 LIT','JYOTI HANDWASH AQUA 5 LIT','34013019','1','2',NULL,'8','JYOTI','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:28',NULL),(121,'243',NULL,NULL,'158',NULL,'','JY HANDWASH LIME COMBO 250 ML','JY HANDWASH LIME COMBO 250 ML','34013019','1','2',NULL,'8','JYOTI','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:30',NULL),(122,'243',NULL,NULL,'158A',NULL,'','JYOTI HANDWASH LIME 5 LIT','JYOTI HANDWASH LIME 5 LIT','34013019','5','2',NULL,'8','JYOTI','7','7','2',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:32',NULL),(123,'243',NULL,NULL,'159',NULL,'','JYOTI HANDWASH AQUA 1-LTR','JYOTI HANDWASH AQUA 1-LTR','34013019','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:35',NULL),(124,'243',NULL,NULL,'160',NULL,'','JYOTI HANDWASH LIME 1-LIT','JYOTI HANDWASH LIME 1-LIT','34013019','1','2',NULL,'8','JYOTI','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:37',NULL),(125,'243',NULL,NULL,'161',NULL,'','JYOTI STEEL SCRUBER CARD','JYOTI STEEL SCRUBER CARD','7323','1','2',NULL,'8','JYOTI','7','7','288',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:40',NULL),(126,'243',NULL,NULL,'162',NULL,'','JYOTI HARD BLACK SCRUB 32 MRP','JYOTI HARD BLACK SCRUB 32 MRP','7323','1','2',NULL,'8','JYOTI','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:42',NULL),(127,'243',NULL,NULL,'163',NULL,'','JYOTI SPONGE GREEN SCRUB 30/-','JYOTI SPONGE GREEN SCRUB 30/-','73231000','1','2',NULL,'8','JYOTI','7','7','144',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:47',NULL),(128,'243',NULL,NULL,'164',NULL,'','JYOTI SUPLI','JYOTI SUPLI','NULL','1','2',NULL,'8','JYOTI','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:50',NULL),(129,'243',NULL,NULL,'165',NULL,'','BOUL','BOUL','NULL','1','2',NULL,'8','JYOTI','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:53',NULL),(130,'243',NULL,NULL,'166',NULL,'','DABBA','DABBA','NULL','1','2',NULL,'8','JYOTI','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:55',NULL),(131,'243',NULL,NULL,'167',NULL,'','JYOTI GREEN SCRUBBER RS.10','JYOTI GREEN SCRUBBER RS.10','9603','1','2',NULL,'8','JYOTI','7','7','360',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:55:58',NULL),(132,'243',NULL,NULL,'168',NULL,'','CYCLE ZOLA JYOTI','CYCLE ZOLA JYOTI','NULL','1','2',NULL,'8','JYOTI','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:00',NULL),(133,'243',NULL,NULL,'168A',NULL,'','CYCLE ZOLA L.G HING','CYCLE ZOLA L.G HING','NULL','1','2',NULL,'6','LG','7','7','50',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','LG',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:03',NULL),(134,'243',NULL,NULL,'168B',NULL,'','JALANI ZOLA','JALANI ZOLA','NULL','1','2',NULL,'7','JALANI','7','7','50',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','JALANI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:05',NULL),(135,'243',NULL,NULL,'168C',NULL,'','SALERY','SALERY','NULL','1','2',NULL,'1','CHANDRADEEP','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:08',NULL),(136,'243',NULL,NULL,'168D',NULL,'','SAMPLING','SAMPLING','NULL','1','2',NULL,'1','CHANDRADEEP','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CHANDRADEEP',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:10',NULL),(137,'243',NULL,NULL,'169',NULL,'','JYT DISHWASH GREEN BAR 80 G','JYT DISHWASH GREEN BAR 80 G','34054000','1','2',NULL,'8','JYOTI','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:13',NULL),(138,'243',NULL,NULL,'1690616061557',NULL,'','VAATAN MUTON KHEEMA 80 G','VAATAN MUTON KHEEMA 80 G','21039010','80','2',NULL,'9','VAATAN COMPANY','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','VAATAN COMPANY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:15',NULL),(139,'243',NULL,NULL,'1690616078231',NULL,'','VAATAN PUNERI MUTTON 80 G','VAATAN PUNERI MUTTON 80 G','21039010','80','2',NULL,'9','VAATAN COMPANY','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','VAATAN COMPANY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:18',NULL),(140,'243',NULL,NULL,'170',NULL,'','JYT DISHWASH GREEN BAR 160 G','JYT DISHWASH GREEN BAR 160 G','34054000','1','2',NULL,'8','JYOTI','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:21',NULL),(141,'243',NULL,NULL,'1704884767182',NULL,'','SLIM SPINNY RAGI 26 G','SLIM SPINNY RAGI 26 G','19059090','26','2',NULL,'10','MANIYAR','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','MANIYAR',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:23',NULL),(142,'243',NULL,NULL,'171',NULL,'','JYT  DETERGENT BLUE  CAKE 100 G','JYT  DETERGENT BLUE  CAKE 100 G','34011190','1','2',NULL,'8','JYOTI','7','7','96',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:25',NULL),(143,'243',NULL,NULL,'1713451626002',NULL,'','CHK DETERGENT POWDER 1 KG','CHK DETERGENT POWDER 1 KG','34022010','1','2',NULL,'11','CHOKRA','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','CHOKRA',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:28',NULL),(144,'243',NULL,NULL,'172',NULL,'','JYT DETERGENT BLUE CAKE 200 G','JYT DETERGENT BLUE CAKE 200 G','34011190','1','2',NULL,'8','JYOTI','7','7','48',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:30',NULL),(145,'243',NULL,NULL,'173',NULL,'','JYOTI GREEN GOTA  SOAP 90 G','JYOTI GREEN GOTA  SOAP 90 G','34011942','100','2',NULL,'8','JYOTI','7','7','50',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','JYOTI',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:33',NULL),(146,'243',NULL,NULL,'174',NULL,'','KARACHI FRUIT BISC 200 GM','KARACHI FRUIT BISC 200 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','67',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','67','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:35',NULL),(147,'243',NULL,NULL,'174A',NULL,'','KCH OSMANIA BISCUIT 200 G','KCH OSMANIA BISCUIT 200 G','19053100','200','2',NULL,'12','KARACHI BISCUITS','7','7','67',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','67','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:43',NULL),(148,'243',NULL,NULL,'175',NULL,'','KARACHI PREMIUM FRUIT BISC 400','KARACHI PREMIUM FRUIT BISC 400','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:56:59',NULL),(149,'243',NULL,NULL,'1760530524385',NULL,'','GOLDEN GLOW GIFT 1050 G','GOLDEN GLOW GIFT 1050 G','19053100','1050','2',NULL,'13','KARACHI GIFT BOX','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI GIFT BOX',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:06',NULL),(150,'243',NULL,NULL,'177',NULL,'','KARACHI CASHEW BISC 200 GM','KARACHI CASHEW BISC 200 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','67',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','67','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:09',NULL),(151,'243',NULL,NULL,'1775031634790',NULL,'','BS SALT & PEPPER 26 G','BS SALT & PEPPER 26 G','210690','26','2',NULL,'14','BEYOND SNAX WAFER','7','7','90',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','BEYOND SNAX WAFER',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:17',NULL),(152,'243',NULL,NULL,'178',NULL,'','KARACHI CASHEW BISC 400 GM','KARACHI CASHEW BISC 400 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:19',NULL),(153,'243',NULL,NULL,'178A',NULL,'','KCH BADAM BISCUITS (5 RS*30 P) 400G','KCH BADAM BISCUITS (5 RS*30 P) 400G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:29',NULL),(154,'243',NULL,NULL,'178B',NULL,'','KCH KAJU PISTA (5 RS*30 P)400G','KCH KAJU PISTA (5 RS*30 P)400G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:32',NULL),(155,'243',NULL,NULL,'178C',NULL,'','KCH CHOCOLAVA (5 RS*30 P) 400 G','KCH CHOCOLAVA (5 RS*30 P) 400 G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:34',NULL),(156,'243',NULL,NULL,'178D',NULL,'','KCH PISTACHIO (5 RS*30 P) 400 G','KCH PISTACHIO (5 RS*30 P) 400 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:37',NULL),(157,'243',NULL,NULL,'178E',NULL,'','KCH KAJU NANKATAI (5 RS*30 P) 400 G','KCH KAJU NANKATAI (5 RS*30 P) 400 G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:39',NULL),(158,'243',NULL,NULL,'178F',NULL,'','KCH BADAM NANKATAI (5 RS*30 P) 400 G','KCH BADAM NANKATAI (5 RS*30 P) 400 G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:42',NULL),(159,'243',NULL,NULL,'179',NULL,'','KARACHI PISTA BISC 200 GM','KARACHI PISTA BISC 200 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','67',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','67','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:44',NULL),(160,'243',NULL,NULL,'179A',NULL,'','KCH CHAI TOAST RUSK  68 G','KCH CHAI TOAST RUSK  68 G','19054000','68','2',NULL,'12','KARACHI BISCUITS','7','7','64',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:55',NULL),(161,'243',NULL,NULL,'179B',NULL,'','KCH CHAI TOAST RUSK 182 G','KCH CHAI TOAST RUSK 182 G','19054000','182','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:57:57',NULL),(162,'243',NULL,NULL,'180',NULL,'','KARACHI PISTA BISC 400 GM','KARACHI PISTA BISC 400 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:00',NULL),(163,'243',NULL,NULL,'180A',NULL,'','KARACHI CHOCOLATE CASHEW 200 G','KARACHI CHOCOLATE CASHEW 200 G','19059020','1','2',NULL,'12','KARACHI BISCUITS','7','7','67',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','67','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:13',NULL),(164,'243',NULL,NULL,'180B',NULL,'','KARACHI CHOCOLATE CASHEW 400 G','KARACHI CHOCOLATE CASHEW 400 G','19059020','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:23',NULL),(165,'243',NULL,NULL,'181',NULL,'','KCH CHOCLATE WALNUT 250 G','KCH CHOCLATE WALNUT 250 G','19053100','250','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:31',NULL),(166,'243',NULL,NULL,'181A',NULL,'','KARACHI HALWA 400 G','KARACHI HALWA 400 G','04021020','400','2',NULL,'12','KARACHI BISCUITS','7','7','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:34',NULL),(167,'243',NULL,NULL,'181B',NULL,'','KARACHI HALWA 200 G','KARACHI HALWA 200 G','04021020','200','2',NULL,'12','KARACHI BISCUITS','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:37',NULL),(168,'243',NULL,NULL,'182',NULL,'','KARACHI OSMANIA BISC 400GM','KARACHI OSMANIA BISC 400GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:39',NULL),(169,'243',NULL,NULL,'182A',NULL,'','KCH CHOCOLAVA 250 G','KCH CHOCOLAVA 250 G','19053100','250','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:56',NULL),(170,'243',NULL,NULL,'182B',NULL,'','KCH CHOCOLAVA HAZELNUT COOKIES 250 G','KCH CHOCOLAVA HAZELNUT COOKIES 250 G','19053100','250','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:58:58',NULL),(171,'243',NULL,NULL,'182C',NULL,'','KCH ASSORTED CHOCOLAVA 250 G','KCH ASSORTED CHOCOLAVA 250 G','19053100','250','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:01',NULL),(172,'243',NULL,NULL,'182D',NULL,'','KCH BASEN LADOO 200 G','KCH BASEN LADOO 200 G','04021020','200','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:03',NULL),(173,'243',NULL,NULL,'182E',NULL,'','KCH BADAM PISTA BISCUITS 200 G','KCH BADAM PISTA BISCUITS 200 G','19053100','200','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:06',NULL),(174,'243',NULL,NULL,'182F',NULL,'','KCH CUMIN BISCUITS 200 G','KCH CUMIN BISCUITS 200 G','19053100','200','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:09',NULL),(175,'243',NULL,NULL,'182G',NULL,'','KCH CORN CHIVDA 150 G','KCH CORN CHIVDA 150 G','21069099','150','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:11',NULL),(176,'243',NULL,NULL,'183',NULL,'','KCH D.D RED (FR+CA) 400 G','KCH D.D RED (FR+CA) 400 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:14',NULL),(177,'243',NULL,NULL,'183A',NULL,'','KCH SHREWSBURY BISCUITS 400 G','KCH SHREWSBURY BISCUITS 400 G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:20',NULL),(178,'243',NULL,NULL,'184',NULL,'','KARACHI PINK DEL(FR+BP)400GM','KARACHI PINK DEL(FR+BP)400GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:22',NULL),(179,'243',NULL,NULL,'184A',NULL,'','DIVINE COLLECTION GIFT 800 G','DIVINE COLLECTION GIFT 800 G','19053100','800','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:25',NULL),(180,'243',NULL,NULL,'184B',NULL,'','JOYOUS COLLECTION GIFT 500 G','JOYOUS COLLECTION GIFT 500 G','19053100','500','2',NULL,'12','KARACHI BISCUITS','7','7','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:30',NULL),(181,'243',NULL,NULL,'184C',NULL,'','GOLDEN GLOW GIFT 1050 G','GOLDEN GLOW GIFT 1050 G','19053100','1050','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:33',NULL),(182,'243',NULL,NULL,'185',NULL,'','KCH D.D PINK (FR+KESAR) 400 G','KCH D.D PINK (FR+KESAR) 400 G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','30',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:38',NULL),(183,'243',NULL,NULL,'185A',NULL,'','KCH G-F MULTI NUTRITION COOKIES 140 G','KCH G-F MULTI NUTRITION COOKIES 140 G','19053100','140','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:44',NULL),(184,'243',NULL,NULL,'185B',NULL,'','KCH G-F CHOCOCHIP COOKIES 140 G','KCH G-F CHOCOCHIP COOKIES 140 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:46',NULL),(185,'243',NULL,NULL,'185C',NULL,'','KCH G-F MIXED NUTS COOKIES 140 G','KCH G-F MIXED NUTS COOKIES 140 G','19053100','140','2',NULL,'12','KARACHI BISCUITS','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:49',NULL),(186,'243',NULL,NULL,'186',NULL,'','BON BON COLLECTION GIFT 400 G','BON BON COLLECTION GIFT 400 G','18069010','400','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:52',NULL),(187,'243',NULL,NULL,'186A',NULL,'','COCOATINI CARAMEL 1 KG','COCOATINI CARAMEL 1 KG','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:54',NULL),(188,'243',NULL,NULL,'186B',NULL,'','COCOATINI COFFE & CREAM 1 KG','COCOATINI COFFE & CREAM 1 KG','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 10:59:57',NULL),(189,'243',NULL,NULL,'186C',NULL,'','COCOATINI COOKIES & CREAM 1 KG','COCOATINI COOKIES & CREAM 1 KG','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:00',NULL),(190,'243',NULL,NULL,'186D',NULL,'','COCOATINI ALMOND BRITTLE 204 G','COCOATINI ALMOND BRITTLE 204 G','18069010','204','2',NULL,'15','KARACHI CHOCLATE','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:04',NULL),(191,'243',NULL,NULL,'186E',NULL,'','COCOATINI SUPER CAR  600 G','COCOATINI SUPER CAR  600 G','18069010','600','2',NULL,'15','KARACHI CHOCLATE','7','7','18',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:08',NULL),(192,'243',NULL,NULL,'187',NULL,'','FIESTA COLLECTION GIFT 340 G','FIESTA COLLECTION GIFT 340 G','18069010','265','2',NULL,'15','KARACHI CHOCLATE','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:13',NULL),(193,'243',NULL,NULL,'187A',NULL,'','KCH FESTIVE FUSION GIFT  940 G','KCH FESTIVE FUSION GIFT  940 G','19053100','940','2',NULL,'12','KARACHI BISCUITS','7','7','4',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:26',NULL),(194,'243',NULL,NULL,'187B',NULL,'','TRUFFLE DELIGHT GIFT 400 G','TRUFFLE DELIGHT GIFT 400 G','18069010','400','2',NULL,'15','KARACHI CHOCLATE','7','7','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:29',NULL),(195,'243',NULL,NULL,'187C',NULL,'','SNACKY CHOCOLATE  GIFT 150 G','SNACKY CHOCOLATE  GIFT 150 G','18069010','150','2',NULL,'15','KARACHI CHOCLATE','7','7','38',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','38','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:32',NULL),(196,'243',NULL,NULL,'187D',NULL,'','SNACKY ASSORTMENT GIFT 375 G','SNACKY ASSORTMENT GIFT 375 G','18069010','375','2',NULL,'15','KARACHI CHOCLATE','7','7','13',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','13','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:35',NULL),(197,'243',NULL,NULL,'188A',NULL,'','COCOATINI FIESTA DELIGHT 300 G','COCOATINI FIESTA DELIGHT 300 G','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:38',NULL),(198,'243',NULL,NULL,'188B',NULL,'','SNACKY COLLECTION 450 G','SNACKY COLLECTION 450 G','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:43',NULL),(199,'243',NULL,NULL,'188C',NULL,'','COCOATINI SNACKY 225 G','COCOATINI SNACKY 225 G','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:47',NULL),(200,'243',NULL,NULL,'188D',NULL,'','COCATINI SNACKY WINDOW 500 G','COCATINI SNACKY WINDOW 500 G','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:00:53',NULL),(201,'243',NULL,NULL,'188E',NULL,'','SNACKY JAR 150 G (MRP 100/-)','SNACKY JAR 150 G (MRP 100/-)','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:01:03',NULL),(202,'243',NULL,NULL,'189',NULL,'','KAR.GOLD CLASS 1KG(RS.750)','KAR.GOLD CLASS 1KG(RS.750)','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','30',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:01:25',NULL),(203,'243',NULL,NULL,'189A',NULL,'','PANCHRATAN GIFT 900 G','PANCHRATAN GIFT 900 G','19053100','900','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:01:32',NULL),(204,'243',NULL,NULL,'189B',NULL,'','ROYAL SELECTION GIFT 900 G','ROYAL SELECTION GIFT 900 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:01:47',NULL),(205,'243',NULL,NULL,'189C',NULL,'','MEETHE PAL COMBO 400 G (MRP 160/-)','MEETHE PAL COMBO 400 G (MRP 160/-)','04021020','400','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:02',NULL),(206,'243',NULL,NULL,'189D',NULL,'','DOUBLE MITHAS 400 G(MRP 160/-)','DOUBLE MITHAS 400 G(MRP 160/-)','04021020','400','2',NULL,'12','KARACHI BISCUITS','7','7','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:10',NULL),(207,'243',NULL,NULL,'189E',NULL,'','RADIANT SELECTION  GIFT 400 G','RADIANT SELECTION  GIFT 400 G','19053100','400','2',NULL,'12','KARACHI BISCUITS','7','7','14',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','14','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:17',NULL),(208,'243',NULL,NULL,'190',NULL,'','CHOCOLATE JOY 800GM(RS.600)','CHOCOLATE JOY 800GM(RS.600)','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:23',NULL),(209,'243',NULL,NULL,'190A',NULL,'','MITHAS GIFT 500 G','MITHAS GIFT 500 G','04021020','500','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:28',NULL),(210,'243',NULL,NULL,'190B',NULL,'','GRANDEUR ASSORTMENT  GIFT 420 G','GRANDEUR ASSORTMENT  GIFT 420 G','19053100','420','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:33',NULL),(211,'243',NULL,NULL,'191',NULL,'','SUPREME JOY GIFT 800 G','SUPREME JOY GIFT 800 G','19053100','800','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:39',NULL),(212,'243',NULL,NULL,'192',NULL,'','KAR.FESTIVE JOY 750 GM(RS470)','KAR.FESTIVE JOY 750 GM(RS470)','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','8',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:02:55',NULL),(213,'243',NULL,NULL,'193',NULL,'','KAR.UMANG 650 GM (RS.410)','KAR.UMANG 650 GM (RS.410)','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:03',NULL),(214,'243',NULL,NULL,'194',NULL,'','KAR.BON BON TRUFFLES RS.250','KAR.BON BON TRUFFLES RS.250','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','15',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:09',NULL),(215,'243',NULL,NULL,'194A',NULL,'','COCOATINI ALMOND TRUFF 250 G','COCOATINI ALMOND TRUFF 250 G','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:14',NULL),(216,'243',NULL,NULL,'194B',NULL,'','COCOATINI COOKIE POP TRUFF 220','COCOATINI COOKIE POP TRUFF 220','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:20',NULL),(217,'243',NULL,NULL,'194C',NULL,'','COCOATINI HAZULNUT TRUFF 220 G','COCOATINI HAZULNUT TRUFF 220 G','18068010','1','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:25',NULL),(218,'243',NULL,NULL,'194D',NULL,'','COCOATINI ORANGE TRUFFLE 220 G','COCOATINI ORANGE TRUFFLE 220 G','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:33',NULL),(219,'243',NULL,NULL,'194E',NULL,'','COCOATINI STRAWBERY TRUF 220 G','COCOATINI STRAWBERY TRUF 220 G','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:41',NULL),(220,'243',NULL,NULL,'195',NULL,'','KCH TRIPLE DELITE (FR+CA+GP) 600 GM','KCH TRIPLE DELITE (FR+CA+GP) 600 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:03:49',NULL),(221,'243',NULL,NULL,'195A',NULL,'','KCH CLASSIC SOAN PAPDI 200 G','KCH CLASSIC SOAN PAPDI 200 G','21069099','200','2',NULL,'12','KARACHI BISCUITS','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:04:11',NULL),(222,'243',NULL,NULL,'195B',NULL,'','KCH PISTA SOAN PAPDI 200 G','KCH PISTA SOAN PAPDI 200 G','21069099','200','2',NULL,'12','KARACHI BISCUITS','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:04:18',NULL),(223,'243',NULL,NULL,'195C',NULL,'','KCH ORANGE SOAN PAPDI 200 G','KCH ORANGE SOAN PAPDI 200 G','21069099','200','2',NULL,'12','KARACHI BISCUITS','7','7','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:04:25',NULL),(224,'243',NULL,NULL,'195D',NULL,'','KCH CLASSIC SOAN PAPDI 300 G (MRP 130)','KCH CLASSIC SOAN PAPDI 300 G (MRP 130)','21069099','300','2',NULL,'12','KARACHI BISCUITS','7','7','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:04:34',NULL),(225,'243',NULL,NULL,'196',NULL,'','KAR.VEGAN FRUIT BISC.400GM','KAR.VEGAN FRUIT BISC.400GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:04:42',NULL),(226,'243',NULL,NULL,'197',NULL,'','KAR.VEGAN OSMANIA BISC.400 GM','KAR.VEGAN OSMANIA BISC.400 GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:04:52',NULL),(227,'243',NULL,NULL,'198',NULL,'','FESTIVE CELEBRATION 530 G','FESTIVE CELEBRATION 530 G','19053100','530','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:05:01',NULL),(228,'243',NULL,NULL,'198A',NULL,'','FESTIVE CELEBRATION 780 G','FESTIVE CELEBRATION 780 G','19053100','780','2',NULL,'12','KARACHI BISCUITS','7','7','8',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:05:10',NULL),(229,'243',NULL,NULL,'198B',NULL,'','SUNEHRE PAL 700 G','SUNEHRE PAL 700 G','21069099','700','2',NULL,'12','KARACHI BISCUITS','7','7','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:05:19',NULL),(230,'243',NULL,NULL,'198C',NULL,'','DELECATABLE DELIGTS 800 G','DELECATABLE DELIGTS 800 G','21069099','800','2',NULL,'12','KARACHI BISCUITS','7','7','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:05:29',NULL),(231,'243',NULL,NULL,'200',NULL,'','KAR.KESAR PISTA BISCUIT 300GM','KAR.KESAR PISTA BISCUIT 300GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:05:39',NULL),(232,'243',NULL,NULL,'201',NULL,'','COCOATINI ALMOND TRUFF 250 G','COCOATINI ALMOND TRUFF 250 G','18069010','230','2',NULL,'15','KARACHI CHOCLATE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:06:06',NULL),(233,'243',NULL,NULL,'202',NULL,'','COCOATINI HAZELNUT TRUFF 250 G','COCOATINI HAZELNUT TRUFF 250 G','18069010','230','2',NULL,'15','KARACHI CHOCLATE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:06:20',NULL),(234,'243',NULL,NULL,'203',NULL,'','COCOATINI STRAWBERRY TRUFF 250 G','COCOATINI STRAWBERRY TRUFF 250 G','18069010','230','2',NULL,'15','KARACHI CHOCLATE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:06:32',NULL),(235,'243',NULL,NULL,'204',NULL,'','COCOATINI ORANGE TRUFF 250 G','COCOATINI ORANGE TRUFF 250 G','18069010','230','2',NULL,'15','KARACHI CHOCLATE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:06:42',NULL),(236,'243',NULL,NULL,'204A',NULL,'','COCOATINI COOKIE POP TRUFF 250 G','COCOATINI COOKIE POP TRUFF 250 G','18069010','230','2',NULL,'15','KARACHI CHOCLATE','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:06:53',NULL),(237,'243',NULL,NULL,'205',NULL,'','KARACHI PISTACHIO BISC.300GM','KARACHI PISTACHIO BISC.300GM','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:05',NULL),(238,'243',NULL,NULL,'205A',NULL,'','VEGAN BLUEBERRY MILLET 300','VEGAN BLUEBERRY MILLET 300','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:19',NULL),(239,'243',NULL,NULL,'205B',NULL,'','VEGAN PISTACHIO MILLET 300 G','VEGAN PISTACHIO MILLET 300 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:25',NULL),(240,'243',NULL,NULL,'205C',NULL,'','SUGAR FREE ATTA OATS 300 G','SUGAR FREE ATTA OATS 300 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:30',NULL),(241,'243',NULL,NULL,'205D',NULL,'','SUGAR FREE CHOCO CHUNK 250 G','SUGAR FREE CHOCO CHUNK 250 G','19053100','1','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:36',NULL),(242,'243',NULL,NULL,'205E',NULL,'','SUGAR FREE CASHEW BSCUITS 250 G','SUGAR FREE CASHEW BSCUITS 250 G','19053100','250','2',NULL,'12','KARACHI BISCUITS','7','7','28',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','28','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:41',NULL),(243,'243',NULL,NULL,'206',NULL,'','KARACHI SNACKY\\\'S 450 G (30 PEC)','KARACHI SNACKY\\\'S 450 G (30 PEC)','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:47',NULL),(244,'243',NULL,NULL,'207',NULL,'','ROYAL INDULGENCE GIFT 300 G','ROYAL INDULGENCE GIFT 300 G','19053100','300','2',NULL,'12','KARACHI BISCUITS','7','7','14',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','14','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:53',NULL),(245,'243',NULL,NULL,'209',NULL,'','KAR.SNACKY\\\'S 150 GM','KAR.SNACKY\\\'S 150 GM','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','38',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','38','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:07:58',NULL),(246,'243',NULL,NULL,'209A',NULL,'','KCH SNACKY 75 G (5O/- RS)','KCH SNACKY 75 G (5O/- RS)','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','39',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','39','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:05',NULL),(247,'243',NULL,NULL,'209B',NULL,'','SNACKY HAZELNUT 75 G (75 RS)','SNACKY HAZELNUT 75 G (75 RS)','18069010','75','2',NULL,'15','KARACHI CHOCLATE','7','7','39',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','39','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:18',NULL),(248,'243',NULL,NULL,'210',NULL,'','SOLH CLASSIC COLD COFFEE 200 ML','SOLH CLASSIC COLD COFFEE 200 ML','22029930','200','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:25',NULL),(249,'243',NULL,NULL,'210A',NULL,'','SOLH FRAPPE COLD COFFEE 250 ML','SOLH FRAPPE COLD COFFEE 250 ML','22029930','250','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:33',NULL),(250,'243',NULL,NULL,'210B',NULL,'','SOLH MOCHA COLD COFFEE 250 ML','SOLH MOCHA COLD COFFEE 250 ML','22029930','250','2',NULL,'12','KARACHI BISCUITS','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:39',NULL),(251,'243',NULL,NULL,'211',NULL,'','KAR.SNACKY\\\'S RS.5 JAR','KAR.SNACKY\\\'S RS.5 JAR','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:44',NULL),(252,'243',NULL,NULL,'212',NULL,'','KAR.HAZELNUT BON BON CHO.RS.5','KAR.HAZELNUT BON BON CHO.RS.5','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:08:52',NULL),(253,'243',NULL,NULL,'213',NULL,'','KAR.STRAWBERRY BON BON CHORS.5','KAR.STRAWBERRY BON BON CHORS.5','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:01',NULL),(254,'243',NULL,NULL,'214',NULL,'','KAR.ALMOND BON BON CHOC RS.5','KAR.ALMOND BON BON CHOC RS.5','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:10',NULL),(255,'243',NULL,NULL,'215',NULL,'','KAR.ORANGE BONBON CHOCLATE 5','KAR.ORANGE BONBON CHOCLATE 5','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:17',NULL),(256,'243',NULL,NULL,'216',NULL,'','KAR.COOKIES & CREAM CHOCLATE','KAR.COOKIES & CREAM CHOCLATE','18069010','1','2',NULL,'12','KARACHI BISCUITS','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','KARACHI BISCUITS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:24',NULL),(257,'243',NULL,NULL,'216A',NULL,'','TRUFFLES ALMOND HANGER 550 G','TRUFFLES ALMOND HANGER 550 G','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:29',NULL),(258,'243',NULL,NULL,'216B',NULL,'','TRUFFLES HAZELNUT HANGER 550 G','TRUFFLES HAZELNUT HANGER 550 G','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:34',NULL),(259,'243',NULL,NULL,'216C',NULL,'','TRUFFLES STRAWBERRY HANGER 550 G','TRUFFLES STRAWBERRY HANGER 550 G','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:39',NULL),(260,'243',NULL,NULL,'216D',NULL,'','TRUFFLES ORANGE HANGER 550 G','TRUFFLES ORANGE HANGER 550 G','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:45',NULL),(261,'243',NULL,NULL,'216E',NULL,'','TRUFFLES COOKIES POP HANGER 550 G','TRUFFLES COOKIES POP HANGER 550 G','18069010','1','2',NULL,'15','KARACHI CHOCLATE','7','7','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','KARACHI CHOCLATE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:50',NULL),(262,'243',NULL,NULL,'217',NULL,'','ICY POPPS MIX FAMILY JAR','ICY POPPS MIX FAMILY JAR','21050000','1','2',NULL,'16','ICY POPS','7','7','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','ICY POPS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:09:58',NULL),(263,'243',NULL,NULL,'220',NULL,'','SNK MULTI GRAIN CHEESE CHIPS 300 G','SNK MULTI GRAIN CHEESE CHIPS 300 G','190532','300','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:05',NULL),(264,'243',NULL,NULL,'221',NULL,'','SNK MULTI GRAIN SWEET CHILLI CHIPS 300 G','SNK MULTI GRAIN SWEET CHILLI CHIPS 300 G','190532','300','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:13',NULL),(265,'243',NULL,NULL,'222',NULL,'','SNK CHOCO CHIP COOKIES COIN 150 G','SNK CHOCO CHIP COOKIES COIN 150 G','190532','150','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:24',NULL),(266,'243',NULL,NULL,'223',NULL,'','SNK BUTTER CASHEWNUT COOKIES COIN 150 G','SNK BUTTER CASHEWNUT COOKIES COIN 150 G','190532','150','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:33',NULL),(267,'243',NULL,NULL,'224',NULL,'','SNK COFFE COOKES COIN 150 G','SNK COFFE COOKES COIN 150 G','190532','150','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:40',NULL),(268,'243',NULL,NULL,'225',NULL,'','SNK OAT JAGGERY COOKIES COIN 150 G','SNK OAT JAGGERY COOKIES COIN 150 G','190532','150','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:46',NULL),(269,'243',NULL,NULL,'226',NULL,'','MZA DC BITTERSWEET  50 G','MZA DC BITTERSWEET  50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:10:55',NULL),(270,'243',NULL,NULL,'227',NULL,'','MZA DC  ALMOND 50 G','MZA DC  ALMOND 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:01',NULL),(271,'243',NULL,NULL,'228',NULL,'','MZA DC  CARDAMOM 50 G','MZA DC  CARDAMOM 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:06',NULL),(272,'243',NULL,NULL,'229',NULL,'','MZA DC  SALTED CARAMEL 50 G','MZA DC  SALTED CARAMEL 50 G','190532','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:12',NULL),(273,'243',NULL,NULL,'229A',NULL,'','LOUNGE PEACH SYRUP 1000 ML','LOUNGE PEACH SYRUP 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:19',NULL),(274,'243',NULL,NULL,'229B',NULL,'','LOUNGE HAZEL NUT SYRUP 1000 ML','LOUNGE HAZEL NUT SYRUP 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:26',NULL),(275,'243',NULL,NULL,'229C',NULL,'','LOUNGE STRAWBERRY SYRUP 1000 ML','LOUNGE STRAWBERRY SYRUP 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:32',NULL),(276,'243',NULL,NULL,'229D',NULL,'','LOUNGE GREEN APPLE SYRUP 1000 ML','LOUNGE GREEN APPLE SYRUP 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:38',NULL),(277,'243',NULL,NULL,'229E',NULL,'','LOUNGE MOJITO SHERBAT 1000 ML','LOUNGE MOJITO SHERBAT 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:45',NULL),(278,'243',NULL,NULL,'229F',NULL,'','LOUNGE VANILA SYRUP 1000 ML','LOUNGE VANILA SYRUP 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:11:53',NULL),(279,'243',NULL,NULL,'229G',NULL,'','LOUNGE BLUE CURACAO SYRUP 1000 ML','LOUNGE BLUE CURACAO SYRUP 1000 ML','210690','1000','2',NULL,'17','MAZAANA+SNACKERY','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:07',NULL),(280,'243',NULL,NULL,'230',NULL,'','MZA DC  TINGE OF SPICE 50 G','MZA DC  TINGE OF SPICE 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:13',NULL),(281,'243',NULL,NULL,'230A',NULL,'','LOUNGE BLUE CURACAO SYRUP 250 ML','LOUNGE BLUE CURACAO SYRUP 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:19',NULL),(282,'243',NULL,NULL,'230B',NULL,'','LOUNGE COCONUT FRUIT SHERBAT 250 ML','LOUNGE COCONUT FRUIT SHERBAT 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:27',NULL),(283,'243',NULL,NULL,'230C',NULL,'','LOUNGE MOJITO SHERBAT 250 ML','LOUNGE MOJITO SHERBAT 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:36',NULL),(284,'243',NULL,NULL,'230D',NULL,'','LOUNGE GREEN APPLE SYRUP 250 ML','LOUNGE GREEN APPLE SYRUP 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:49',NULL),(285,'243',NULL,NULL,'230E',NULL,'','LOUNGE TRIPLE SEC SYRUP 250 ML','LOUNGE TRIPLE SEC SYRUP 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:12:59',NULL),(286,'243',NULL,NULL,'230F',NULL,'','LOUNGE VANILA SYRUP 250 ML','LOUNGE VANILA SYRUP 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:06',NULL),(287,'243',NULL,NULL,'230G',NULL,'','LOUNGE WATER MELON SYRUP 250 ML','LOUNGE WATER MELON SYRUP 250 ML','210690','250','2',NULL,'17','MAZAANA+SNACKERY','7','7','6',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:16',NULL),(288,'243',NULL,NULL,'230H',NULL,'','MFP PRA KESAR SHRBAT 500 ML','MFP PRA KESAR SHRBAT 500 ML','210690','500','2',NULL,'17','MAZAANA+SNACKERY','7','7','12',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:27',NULL),(289,'243',NULL,NULL,'231',NULL,'','MZA EXTRA DARK CHOCOLATE 50 G','MZA EXTRA DARK CHOCOLATE 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:34',NULL),(290,'243',NULL,NULL,'231A',NULL,'','MZA  MC  ALMOND 50 G','MZA  MC  ALMOND 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:39',NULL),(291,'243',NULL,NULL,'231B',NULL,'','MZA  DC SUBTLE  50 G','MZA  DC SUBTLE  50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:45',NULL),(292,'243',NULL,NULL,'231C',NULL,'','MZA WC  KESAR BADAM PISTA 50 G','MZA WC  KESAR BADAM PISTA 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:51',NULL),(293,'243',NULL,NULL,'231D',NULL,'','MZA CHOCO ALMOND DATES  POUCH 100 G','MZA CHOCO ALMOND DATES  POUCH 100 G','180690','100','2',NULL,'17','MAZAANA+SNACKERY','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:13:59',NULL),(294,'243',NULL,NULL,'231E',NULL,'','MZA  CHOCOLATE PAAN POUCH 80 G','MZA  CHOCOLATE PAAN POUCH 80 G','180690','80','2',NULL,'17','MAZAANA+SNACKERY','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:06',NULL),(295,'243',NULL,NULL,'231F',NULL,'','MZA DC COATED FIG POUCH 100 G','MZA DC COATED FIG POUCH 100 G','180690','100','2',NULL,'17','MAZAANA+SNACKERY','7','7','24',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:12',NULL),(296,'243',NULL,NULL,'231G',NULL,'','MZA DC CARAMELIZED ALMOND CRUNCH 50 G','MZA DC CARAMELIZED ALMOND CRUNCH 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:20',NULL),(297,'243',NULL,NULL,'231H',NULL,'','MZA MILK CHOCOLATE 50 G','MZA MILK CHOCOLATE 50 G','180690','50','2',NULL,'17','MAZAANA+SNACKERY','7','7','36',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','MAZAANA+SNACKERY',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:26',NULL),(298,'243',NULL,NULL,'232',NULL,'','AMBIKA APPALAM (10 PEC)','AMBIKA APPALAM (10 PEC)','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','120',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:32',NULL),(299,'243',NULL,NULL,'233',NULL,'','AMBIKA APPALAM NO.1','AMBIKA APPALAM NO.1','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','60',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:37',NULL),(300,'243',NULL,NULL,'234',NULL,'','AMBIKA APPALAM NO.2','AMBIKA APPALAM NO.2','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','60',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:14:50',NULL),(301,'243',NULL,NULL,'235',NULL,'','AMBIKA APPALAM NO.3','AMBIKA APPALAM NO.3','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','60',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:15:07',NULL),(302,'243',NULL,NULL,'236',NULL,'','AMBIKA APPALAM NO.4','AMBIKA APPALAM NO.4','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','60',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:15:25',NULL),(303,'243',NULL,NULL,'237',NULL,'','AMBIKA APPALAM NO.5','AMBIKA APPALAM NO.5','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','60',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:15:40',NULL),(304,'243',NULL,NULL,'238',NULL,'','NANDI APPALAM 100 GM','NANDI APPALAM 100 GM','1905','1','2',NULL,'18','AMBIKA APPLAM','7','7','150',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','150','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:15:59',NULL),(305,'243',NULL,NULL,'239',NULL,'','AMBIKA SPL APPALAM 375 GM','AMBIKA SPL APPALAM 375 GM','19059040','1','2',NULL,'18','AMBIKA APPLAM','7','7','30',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','AMBIKA APPLAM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:16:07',NULL),(306,'243',NULL,NULL,'240',NULL,'','RAJ KOKUM SYRUP 1LTR','RAJ KOKUM SYRUP 1LTR','30049011','1','2',NULL,'19','RAJ KOKUM','7','7','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','RAJ KOKUM',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-06 11:16:23',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'243',NULL,NULL,'CHANDRADEEP','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(2,'243',NULL,NULL,'ROOH AFZA','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(3,'243',NULL,NULL,'ELEPHANT','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(4,'243',NULL,NULL,'CONCORD','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(5,'243',NULL,NULL,'JAHAGIRDAR','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(6,'243',NULL,NULL,'LG','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(7,'243',NULL,NULL,'JALANI','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(8,'243',NULL,NULL,'JYOTI','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(9,'243',NULL,NULL,'VAATAN COMPANY','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(10,'243',NULL,NULL,'MANIYAR','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(11,'243',NULL,NULL,'CHOKRA','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(12,'243',NULL,NULL,'KARACHI BISCUITS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(13,'243',NULL,NULL,'KARACHI GIFT BOX','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(14,'243',NULL,NULL,'BEYOND SNAX WAFER','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(15,'243',NULL,NULL,'KARACHI CHOCLATE','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(16,'243',NULL,NULL,'ICY POPS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(17,'243',NULL,NULL,'MAZAANA+SNACKERY','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(18,'243',NULL,NULL,'AMBIKA APPLAM','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(19,'243',NULL,NULL,'RAJ KOKUM','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(20,'243',NULL,NULL,'KALYAN BHEL','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(21,'243',NULL,NULL,'KELVERTS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(22,'243',NULL,NULL,'SARWAR','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(23,'243',NULL,NULL,'BB CHOCLATE','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(24,'243',NULL,NULL,'BLUE BIRD FOODS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(25,'243',NULL,NULL,'BLUE BIRD PASTA','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(26,'243',NULL,NULL,'AATASH','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(27,'243',NULL,NULL,'HINDALCO FRESHWRAP','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(28,'243',NULL,NULL,'SEGRETO NUTS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:39','2026-05-06 10:46:39'),(29,'243',NULL,NULL,'IMPRESSO','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(30,'243',NULL,NULL,'HARMOCIA','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(31,'243',NULL,NULL,'PRIYA PICKLE','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(32,'243',NULL,NULL,'PURO SALT','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(33,'243',NULL,NULL,'BLUE DIAMOND','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(34,'243',NULL,NULL,'KAILASH BHEL','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(35,'243',NULL,NULL,'BHAGIRATHI','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(36,'243',NULL,NULL,'FRESHEE','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(37,'243',NULL,NULL,'VEERAM INCENSE','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(38,'243',NULL,NULL,'CORNITOS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(39,'243',NULL,NULL,'VAIDYAS BISCUITS','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(40,'243',NULL,NULL,'SPICE STORY','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(41,'243',NULL,NULL,'WAI WAI NOODLES','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40'),(42,'243',NULL,NULL,'MANNA','1',NULL,NULL,NULL,NULL,NULL,'391','391',NULL,0,'2026-05-06 10:46:40','2026-05-06 10:46:40');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL DEFAULT 0,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int(11) NOT NULL DEFAULT 0,
  `CREATED_TS` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETED` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=497 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'243',NULL,NULL,'1','1672656017987','02-01-2023','1970-01-01','101','0','0','0','55','36.666','0','25','0','11.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:40',NULL),(2,'243',NULL,NULL,'1','1686741392772','null','1970-01-01','101','0','0','0','60','32.15','0','27','0','5.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:42',NULL),(3,'243',NULL,NULL,'1','1723275025070','null','1970-01-01','101','0','0','0','70','36.19','0','27','0','9.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:44',NULL),(4,'243',NULL,NULL,'1','1761307576048','null','1970-01-01','101','0','84','84','65','34.285','0','28.58','0','5.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:46',NULL),(5,'243',NULL,NULL,'2','230830174024','2026-05-06','1970-01-01','101A','0','0','0','35','20.952','0','16.08','0','4.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:47',NULL),(6,'243',NULL,NULL,'2','1731481388812','2026-05-06','1970-01-01','101A','0','13','13','40','23.809','0','16.97','0','6.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:49',NULL),(7,'243',NULL,NULL,'2','1761827842689','2026-05-06','1970-01-01','101A','0','0','0','37','21.142','0','16.97','0','4.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:51',NULL),(8,'243',NULL,NULL,'3','1672656018062','02-01-2023','1970-01-01','102','0','0','0','55','36.67','0','25','0','11.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:53',NULL),(9,'243',NULL,NULL,'3','1686741654670','null','1970-01-01','102','0','0','0','60','32.15','0','27','0','5.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:56',NULL),(10,'243',NULL,NULL,'3','7','null','1970-01-01','102','0','0','0','70','36.19','0','28.571','0','7.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:46:58',NULL),(11,'243',NULL,NULL,'3','1761307631793','null','1970-01-01','102','0','17','17','65','34.285','0','28.58','0','5.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:00',NULL),(12,'243',NULL,NULL,'4','230830174156','2026-05-06','1970-01-01','102A','0','0','0','35','19.64','0','16.08','0','3.56','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:03',NULL),(13,'243',NULL,NULL,'4','1731481432009','2026-05-06','1970-01-01','102A','0','0','0','40','23.81','0','16.97','0','6.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:05',NULL),(14,'243',NULL,NULL,'4','1764736904522','2026-05-06','1970-01-01','102A','0','8','8','37','21.904','0','16.97','0','4.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:06',NULL),(15,'243',NULL,NULL,'5','1672656018136','02-01-2023','1970-01-01','103','0','0','0','55','36.67','0','25','0','11.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:08',NULL),(16,'243',NULL,NULL,'5','1686741714465','null','1970-01-01','103','0','0','0','60','32.15','0','27','0','5.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:10',NULL),(17,'243',NULL,NULL,'5','1723275155644','null','1970-01-01','103','0','0','0','70','36.19','0','28.571','0','7.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:12',NULL),(18,'243',NULL,NULL,'5','1761307675213','null','1970-01-01','103','0','57','57','65','34.285','0','28.58','0','5.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:14',NULL),(19,'243',NULL,NULL,'6','1672656018210','02-01-2023','1970-01-01','104','0','0','0','55','36.67','0','25','0','11.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:16',NULL),(20,'243',NULL,NULL,'6','1686741780547','null','1970-01-01','104','0','0','0','60','32.15','0','27','0','5.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:18',NULL),(21,'243',NULL,NULL,'6','1727688194770','null','1970-01-01','104','0','0','0','70','36.19','0','28.57','0','7.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:20',NULL),(22,'243',NULL,NULL,'6','1761307721868','null','1970-01-01','104','0','75','75','65','34.285','0','28.58','0','5.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:22',NULL),(23,'243',NULL,NULL,'7','1672656018285','02-01-2023','1970-01-01','105','0','0','0','60','40','0','28','0','12.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:24',NULL),(24,'243',NULL,NULL,'7','1686741513285','null','1970-01-01','105','0','0','0','65','35.714','0','30','0','5.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:25',NULL),(25,'243',NULL,NULL,'7','1724073649436','null','1970-01-01','105','0','0','0','75','40','0','31.26','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:27',NULL),(26,'243',NULL,NULL,'7','1761308268255','null','1970-01-01','105','0','25','25','70','38.095','0','31.26','0','6.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:29',NULL),(27,'243',NULL,NULL,'8','1672656018349','02-01-2023','1970-01-01','106','0','0','0','60','40','0','28','0','12.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:31',NULL),(28,'243',NULL,NULL,'8','1686741591205','null','1970-01-01','106','0','0','0','65','35.71','0','30','0','5.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:33',NULL),(29,'243',NULL,NULL,'8','1724073710988','null','1970-01-01','106','0','0','0','75','40','0','31.26','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:35',NULL),(30,'243',NULL,NULL,'8','1761308477011','null','1970-01-01','106','0','42','42','70','38.095','0','31.26','0','6.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:37',NULL),(31,'243',NULL,NULL,'9','1672656018418','02-01-2023','1970-01-01','107','0','0','0','110','73.333','0','50','0','23.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:38',NULL),(32,'243',NULL,NULL,'9','1686741879357','null','1970-01-01','107','0','0','0','120','64.285','0','54','0','10.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:40',NULL),(33,'243',NULL,NULL,'9','1723275224169','null','1970-01-01','107','0','0','0','140','72.38','0','57.142','0','15.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:42',NULL),(34,'243',NULL,NULL,'9','1761828070549','null','1970-01-01','107','0','12','12','130','68.58','0','57.15','0','11.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:44',NULL),(35,'243',NULL,NULL,'10','1672656018493','02-01-2023','1970-01-01','108','0','0','0','110','73.33','0','50','0','23.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:46',NULL),(36,'243',NULL,NULL,'10','1686741925544','null','1970-01-01','108','0','0','0','120','64.285','0','54','0','10.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:48',NULL),(37,'243',NULL,NULL,'10','1723275284112','null','1970-01-01','108','0','0','0','140','72.38','0','57.142','0','15.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:50',NULL),(38,'243',NULL,NULL,'10','1769946562254','null','1970-01-01','1769946562253','0','0','0','130','68.58','0','57.142','0','11.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:52',NULL),(39,'243',NULL,NULL,'11','1672656018579','02-01-2023','1970-01-01','109','0','0','0','185','98.21','0','85','0','13.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:53',NULL),(40,'243',NULL,NULL,'11','1686742003268','null','1970-01-01','109','0','0','0','200','107.142','0','91.96','0','15.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:55',NULL),(41,'243',NULL,NULL,'11','2','null','1970-01-01','109','0','0','0','250','123.809','0','94.65','0','29.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:57',NULL),(42,'243',NULL,NULL,'11','1763122250915','null','1970-01-01','109','0','6','6','230','120.476','0','94.65','0','25.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:47:59',NULL),(43,'243',NULL,NULL,'12','1672656018651','02-01-2023','1970-01-01','110','0','0','0','185','98.21','0','85','0','13.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:01',NULL),(44,'243',NULL,NULL,'12','1686742134277','null','1970-01-01','110','0','0','0','200','125','0','92','0','33.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:03',NULL),(45,'243',NULL,NULL,'12','1728799545506','null','1970-01-01','110','0','12','12','250','123.809','0','94.65','0','29.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:05',NULL),(46,'243',NULL,NULL,'13','240405180948','2026-05-06','1970-01-01','110A','0','0','0','200','107.142','0','92','0','15.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:07',NULL),(47,'243',NULL,NULL,'13','1724073937199','2026-05-06','1970-01-01','110A','0','0','0','250','120.952','0','94.65','0','26.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:08',NULL),(48,'243',NULL,NULL,'14','1672656018726','02-01-2023','1970-01-01','111','0','0','0','450','267.86','0','225','0','42.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:10',NULL),(49,'243',NULL,NULL,'14','1694177163773','null','1970-01-01','111','0','3','3','750','401.78','0','330','0','71.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:12',NULL),(50,'243',NULL,NULL,'14','1728802331422','null','1970-01-01','111','0','4','4','800','410.713','0','357.142','0','53.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:14',NULL),(51,'243',NULL,NULL,'15','1672656018885','02-01-2023','1970-01-01','112','0','0','0','420','250','0','210','0','40.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:16',NULL),(52,'243',NULL,NULL,'15','1697630802283','null','1970-01-01','112','0','2','2','550','294.65','0','241.08','0','53.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:18',NULL),(53,'243',NULL,NULL,'15','1728802231982','null','1970-01-01','112','0','2','2','600','308.035','0','267.857','0','40.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:20',NULL),(54,'243',NULL,NULL,'16','231012183718','2026-05-06','1970-01-01','113','0','0','0','95','53.57','0','44.65','0','8.92','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:22',NULL),(55,'243',NULL,NULL,'16','1726565251461','2026-05-06','1970-01-01','113','0','-48','-48','120','68.58','0','57.15','0','11.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:24',NULL),(56,'243',NULL,NULL,'16','1761308852707','2026-05-06','1970-01-01','113','0','0','0','110','66.666','0','57.15','0','9.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:26',NULL),(57,'243',NULL,NULL,'17','231012184015','2026-05-06','1970-01-01','113A','0','0','0','170','93.75','0','78.58','0','15.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:28',NULL),(58,'243',NULL,NULL,'17','1728802175977','2026-05-06','1970-01-01','113A','0','0','0','200','114.285','0','89.285','0','25.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:30',NULL),(59,'243',NULL,NULL,'17','1761309030605','2026-05-06','1970-01-01','113A','0','0','0','185','123.809','0','104.76','0','19.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:32',NULL),(60,'243',NULL,NULL,'17','1773038277242','2026-05-06','1970-01-01','113A','0','0','0','210','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:33',NULL),(61,'243',NULL,NULL,'17','1773051239387','2026-05-06','1970-01-01','113A','0','143','143','210','125.712','0','104.76','0','20.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:35',NULL),(62,'243',NULL,NULL,'18','260410181817','2026-05-06','1970-01-01','113B','0','0','0','800','523.809','0','476.2','0','47.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:37',NULL),(63,'243',NULL,NULL,'19','231012184307','2026-05-06','1970-01-01','114','0','0','0','85','51.78','0','42.86','0','8.92','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:39',NULL),(64,'243',NULL,NULL,'19','53.571','2026-05-06','1970-01-01','114','0','0','0','100','62.5','0','53.571','0','8.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:41',NULL),(65,'243',NULL,NULL,'19','1734089730869','2026-05-06','1970-01-01','114','0','0','0','115','73.33','0','58.04','0','15.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:43',NULL),(66,'243',NULL,NULL,'19','1761308950606','2026-05-06','1970-01-01','114','0','0','0','110','76.19','0','61.91','0','14.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:45',NULL),(67,'243',NULL,NULL,'19','1773050890540','2026-05-06','1970-01-01','114','0','0','0','120','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:47',NULL),(68,'243',NULL,NULL,'19','1','2026-05-06','1970-01-01','114','0','37','37','120','74.292','0','61.91','0','12.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:49',NULL),(69,'243',NULL,NULL,'20','231012184558','2026-05-06','1970-01-01','114A','0','0','0','150','91.07','0','75.9','0','15.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:51',NULL),(70,'243',NULL,NULL,'20','1726565509963','2026-05-06','1970-01-01','114A','0','0','0','170','101.785','0','84.83','0','16.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:53',NULL),(71,'243',NULL,NULL,'20','1734089843877','2026-05-06','1970-01-01','114A','0','0','0','185','133.33','0','109.53','0','23.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:55',NULL),(72,'243',NULL,NULL,'20','1773051168888','2026-05-06','1970-01-01','114A','0','10','10','210','131.43','0','104.76','0','26.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:57',NULL),(73,'243',NULL,NULL,'21','250221090021','2026-05-06','1970-01-01','115','0','0','0','180','140.952','0','128.095','0','12.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:48:59',NULL),(74,'243',NULL,NULL,'21','1769509590446','2026-05-06','1970-01-01','115','0','-1','-1','165','140.952','0','133.33','0','7.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:01',NULL),(75,'243',NULL,NULL,'22','250725153904','2026-05-06','2026-05-06','115A','0','9','9','0','0','0','906','0','-906.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:03',NULL),(76,'243',NULL,NULL,'23','260203184355','2026-05-06','1970-01-01','115B','0','0','0','75','62.857','0','58.1','0','4.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:05',NULL),(77,'243',NULL,NULL,'24','1672656051195','02-01-2023','1970-01-01','116','0','0','0','36','26.54','0','21.6','0','4.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:07',NULL),(78,'243',NULL,NULL,'24','1674818065085','null','1970-01-01','116','0','0','0','37','26.54','0','21.6','0','4.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:09',NULL),(79,'243',NULL,NULL,'24','1724926635860','null','1970-01-01','116','0','0','0','38','28.228','0','24.2','0','4.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:11',NULL),(80,'243',NULL,NULL,'24','1731402232210','null','1970-01-01','116','0','-140','-140','41','31.61','0','26.8','0','4.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:13',NULL),(81,'243',NULL,NULL,'24','477','null','1970-01-01','116','0','369','369','47','34.914','0','30','0','4.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:15',NULL),(82,'243',NULL,NULL,'25','250813143423','2026-05-06','1970-01-01','116A','0','3','3','94','68.62','0','60','0','8.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:16',NULL),(83,'243',NULL,NULL,'26','1672656051289','02-01-2023','1970-01-01','117','0','0','0','37','27.15','0','23.5','0','3.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:18',NULL),(84,'243',NULL,NULL,'26','1672656051372','02-01-2023','1970-01-01','117','0','0','0','39','28.76','0','23.5','0','5.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:20',NULL),(85,'243',NULL,NULL,'26','1676200550986','null','1970-01-01','117','0','0','0','40','29.71','0','23.5','0','6.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:22',NULL),(86,'243',NULL,NULL,'26','1713347113662','null','1970-01-01','117','0','0','0','41','30.457','0','25','0','5.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:24',NULL),(87,'243',NULL,NULL,'26','1726561792403','null','1970-01-01','117','0','0','0','45','33.428','0','26.2','0','7.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:26',NULL),(88,'243',NULL,NULL,'26','1740133180756','null','1970-01-01','117','0','412','412','50','37.142','0','28.7','0','8.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:28',NULL),(89,'243',NULL,NULL,'27','230808153847','2026-05-06','1970-01-01','118','0','0','0','32','15.24','0','12','0','3.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:30',NULL),(90,'243',NULL,NULL,'27','1731402441606','2026-05-06','1970-01-01','118','0','0','0','35','16.666','0','13.95','0','2.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:32',NULL),(91,'243',NULL,NULL,'27','1742799628300','2026-05-06','1970-01-01','118','0','18','18','36','17.142','0','13.95','0','3.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:34',NULL),(92,'243',NULL,NULL,'28','1672656030167','02-01-2023','1970-01-01','119','0','-2','-2','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:36',NULL),(93,'243',NULL,NULL,'29','1672656051449','02-01-2023','1970-01-01','120','0','100','100','55','41.9','0','37.2','0','4.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:38',NULL),(94,'243',NULL,NULL,'29','1710496693568','null','1970-01-01','120','0','0','0','60','45.714','0','40.59','0','5.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:40',NULL),(95,'243',NULL,NULL,'29','1768034933344','null','1970-01-01','120','0','5','5','65','49.523','0','44.5','0','5.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:42',NULL),(96,'243',NULL,NULL,'30','1672656051532','02-01-2023','1970-01-01','121','0','0','0','110','83.8','0','74.4','0','9.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:44',NULL),(97,'243',NULL,NULL,'30','1708591944051','null','1970-01-01','121','0','0','0','120','91.428','0','81.16','0','10.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:46',NULL),(98,'243',NULL,NULL,'30','1758532850833','null','1970-01-01','121','0','2','2','130','99.047','0','88.57','0','10.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:48',NULL),(99,'243',NULL,NULL,'31','250218132203','2026-05-06','1970-01-01','122','0','10','10','60','47.619','0','38.52','0','9.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:50',NULL),(100,'243',NULL,NULL,'31','1759922664690','2026-05-06','1970-01-01','122','0','0','0','55','43.65','0','37.92','0','5.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:52',NULL),(101,'243',NULL,NULL,'32','250218132448','2026-05-06','1970-01-01','122A','0','-1','-1','70','55.555','0','44.94','0','10.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:54',NULL),(102,'243',NULL,NULL,'32','1759922746800','2026-05-06','1970-01-01','122A','0','0','0','65','51.587','0','44.82','0','6.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:56',NULL),(103,'243',NULL,NULL,'32','1765365228909','2026-05-06','1970-01-01','122A','0','0','0','75','59.523','0','51.71','0','7.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:49:58',NULL),(104,'243',NULL,NULL,'33','250218132622','2026-05-06','1970-01-01','122B','0','0','0','60','47.619','0','38.52','0','9.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:00',NULL),(105,'243',NULL,NULL,'34','250218132820','2026-05-06','1970-01-01','122C','0','0','0','85','67.46','0','54.57','0','12.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:02',NULL),(106,'243',NULL,NULL,'34','1759922803943','2026-05-06','1970-01-01','122C','0','0','0','80','63.492','0','55.16','0','8.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:05',NULL),(107,'243',NULL,NULL,'34','1767790789477','2026-05-06','1970-01-01','122C','0','31','31','90','71.4285','0','62.06','0','9.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:06',NULL),(108,'243',NULL,NULL,'35','250218133034','2026-05-06','1970-01-01','122D','0','0','0','85','67.46','0','57.49','0','9.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:08',NULL),(109,'243',NULL,NULL,'35','1759922867293','2026-05-06','1970-01-01','122D','0','0','0','80','63.492','0','55.16','0','8.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:11',NULL),(110,'243',NULL,NULL,'35','1765365314773','2026-05-06','1970-01-01','122D','0','12','12','90','71.428','0','62.06','0','9.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:13',NULL),(111,'243',NULL,NULL,'36','250218133231','2026-05-06','1970-01-01','122E','0','0','0','85','67.46','0','57.49','0','9.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:15',NULL),(112,'243',NULL,NULL,'36','1759923087857','2026-05-06','1970-01-01','122E','0','0','0','80','63.492','0','55.16','0','8.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:17',NULL),(113,'243',NULL,NULL,'36','1765365368075','2026-05-06','1970-01-01','122E','0','7','7','90','71.428','0','62.06','0','9.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:19',NULL),(114,'243',NULL,NULL,'37','250218133522','2026-05-06','1970-01-01','122F','0','0','0','85','67.46','0','57.49','0','9.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:21',NULL),(115,'243',NULL,NULL,'37','1759922943352','2026-05-06','1970-01-01','122F','0','0','0','80','63.492','0','55.16','0','8.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:23',NULL),(116,'243',NULL,NULL,'37','1765365277849','2026-05-06','1970-01-01','122F','0','1','1','90','71.428','0','62.06','0','9.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:25',NULL),(117,'243',NULL,NULL,'38','250218134009','2026-05-06','1970-01-01','122G','0','0','0','100','79.365','0','67.64','0','11.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:27',NULL),(118,'243',NULL,NULL,'38','1759923148048','2026-05-06','1970-01-01','122G','0','0','0','95','75.396','0','65.5','0','9.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:29',NULL),(119,'243',NULL,NULL,'38','1765365443335','2026-05-06','1970-01-01','122G','0','12','12','90','71.428','0','62.06','0','9.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:31',NULL),(120,'243',NULL,NULL,'39','250511165811','2026-05-06','1970-01-01','122H','0','0','0','60','47.619','0','43.29','0','4.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:33',NULL),(121,'243',NULL,NULL,'40','250715165141','2026-05-06','1970-01-01','123','0','0','0','50','33.333','0','30.438','0','2.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:35',NULL),(122,'243',NULL,NULL,'41','250715164617','2026-05-06','1970-01-01','123A','0','-43','-43','50','33.33','0','30.438','0','2.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:38',NULL),(123,'243',NULL,NULL,'42','250715164823','2026-05-06','1970-01-01','123B','0','-43','-43','50','33.33','0','30.438','0','2.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:40',NULL),(124,'243',NULL,NULL,'43','250715165007','2026-05-06','1970-01-01','123C','0','-48','-48','50','33.33','0','30.438','0','2.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:42',NULL),(125,'243',NULL,NULL,'44','250829113850','2026-05-06','1970-01-01','123O','0','-40','-40','50','33.33','0','30.438','0','2.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:44',NULL),(126,'243',NULL,NULL,'45','1672656051607','02-01-2023','1970-01-01','124','0','0','0','85','60.95','0','55.09','0','5.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:46',NULL),(127,'243',NULL,NULL,'45','1688804610838','null','1970-01-01','124','0','0','0','92','61.33','0','56.79','0','4.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:48',NULL),(128,'243',NULL,NULL,'45','1751544415365','null','1970-01-01','124','0','648','648','102','68','0','62.96','0','5.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:50',NULL),(129,'243',NULL,NULL,'46','231018180335','2026-05-06','1970-01-01','124A','0','0','0','25','16.67','0','15.43','0','1.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:53',NULL),(130,'243',NULL,NULL,'47','1672656051696','02-01-2023','1970-01-01','125','0','0','0','165','118.09','0','106.94','0','11.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:55',NULL),(131,'243',NULL,NULL,'47','1688804647866','null','1970-01-01','125','0','0','0','182','121.33','0','112.34','0','8.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:57',NULL),(132,'243',NULL,NULL,'47','1751544493469','null','1970-01-01','125','0','327','327','200','133.33','0','123.45','0','9.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:50:59',NULL),(133,'243',NULL,NULL,'48','1672656051779','02-01-2023','1970-01-01','126','0','0','0','328','233.33','0','212.59','0','20.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:01',NULL),(134,'243',NULL,NULL,'48','1688804708851','null','1970-01-01','126','0','0','0','356','237.33','0','219.75','0','17.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:03',NULL),(135,'243',NULL,NULL,'48','1757925743261','null','1970-01-01','126','0','57','57','375','250','0','231.48','0','18.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:06',NULL),(136,'243',NULL,NULL,'49','1672656051845','02-01-2023','1970-01-01','127','0','0','0','818','629.23','0','530.19','0','99.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:08',NULL),(137,'243',NULL,NULL,'49','1688804758640','null','1970-01-01','127','0','0','0','883','647.53','0','501.46','0','146.07','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:10',NULL),(138,'243',NULL,NULL,'49','1695283710214','null','1970-01-01','127','0','0','0','885','590','0','545.06','0','44.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:12',NULL),(139,'243',NULL,NULL,'49','1752051713586','null','1970-01-01','127','0','14','14','935','623.33','0','577.16','0','46.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:14',NULL),(140,'243',NULL,NULL,'50','1672656051912','02-01-2023','1970-01-01','128','0','0','0','165','126.93','0','106.94','0','19.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:16',NULL),(141,'243',NULL,NULL,'50','1688804799456','null','1970-01-01','128','0','0','0','180','120','0','111.11','0','8.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:18',NULL),(142,'243',NULL,NULL,'50','1751542006114','null','1970-01-01','128','0','316','316','195','130','0','120.37','0','9.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:20',NULL),(143,'243',NULL,NULL,'51','240211175015','2026-05-06','1970-01-01','128A','0','0','0','92','70.09','0','56.79','0','13.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:22',NULL),(144,'243',NULL,NULL,'52','260112134123','2026-05-06','1970-01-01','128B','0','-3','-3','550','321.428','0','300.24','0','21.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:25',NULL),(145,'243',NULL,NULL,'53','250422155537','2026-05-06','1970-01-01','129','0','-21','-21','30','18.543','0','18.263','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:27',NULL),(146,'243',NULL,NULL,'54','250422155809','2026-05-06','1970-01-01','129A','0','-23','-23','30','18.543','0','18.263','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:29',NULL),(147,'243',NULL,NULL,'55','250422161103','2026-05-06','1970-01-01','129B','0','-46','-46','30','18.543','0','18.263','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:31',NULL),(148,'243',NULL,NULL,'56','250422161312','2026-05-06','1970-01-01','129C','0','-6','-6','30','18.543','0','18.263','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:33',NULL),(149,'243',NULL,NULL,'57','250422161547','2026-05-06','1970-01-01','129D','0','-40','-40','30','18.543','0','18.263','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:35',NULL),(150,'243',NULL,NULL,'58','250311144643','2026-05-06','1970-01-01','130A','0','6','6','95','67.857','0','61.69','0','6.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:37',NULL),(151,'243',NULL,NULL,'59','250311144912','2026-05-06','1970-01-01','130B','0','0','0','190','135.714','0','123.38','0','12.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:40',NULL),(152,'243',NULL,NULL,'60','250329111509','2026-05-06','1970-01-01','131','0','19','19','50','30.906','0','34.615','0','-3.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:42',NULL),(153,'243',NULL,NULL,'61','250329110512','2026-05-06','1970-01-01','131A','0','0','0','230','164.29','0','153.54','0','10.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:44',NULL),(154,'243',NULL,NULL,'62','251101183336','2026-05-06','1970-01-01','131B','0','62','62','600','250','0','233.65','0','16.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:46',NULL),(155,'243',NULL,NULL,'63','250329113422','2026-05-06','1970-01-01','131C','0','29','29','50','30.906','0','30.44','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:48',NULL),(156,'243',NULL,NULL,'64','250329113915','2026-05-06','1970-01-01','131D','0','32','32','50','30.906','0','30.44','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:51',NULL),(157,'243',NULL,NULL,'65','250329114051','2026-05-06','1970-01-01','131E','0','52','52','50','30.906','0','30.44','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:53',NULL),(158,'243',NULL,NULL,'66','250329114609','2026-05-06','1970-01-01','131F','0','0','0','50','30.906','0','30.44','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:55',NULL),(159,'243',NULL,NULL,'67','250329115428','2026-05-06','1970-01-01','131G','0','0','0','50','30.906','0','30.44','0','0.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:51:58',NULL),(160,'243',NULL,NULL,'68','250329121015','2026-05-06','1970-01-01','131H','0','8','8','150','64.288','0','91.31','0','-27.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:00',NULL),(161,'243',NULL,NULL,'69','250329121156','2026-05-06','1970-01-01','131I','0','4','4','150','64.29','0','91.31','0','-27.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:02',NULL),(162,'243',NULL,NULL,'70','250329121403','2026-05-06','1970-01-01','131J','0','20','20','150','64.29','0','91.31','0','-27.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:04',NULL),(163,'243',NULL,NULL,'71','250329123401','2026-05-06','1970-01-01','131K','0','5','5','150','64.29','0','91.31','0','-27.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:07',NULL),(164,'243',NULL,NULL,'72','250329123545','2026-05-06','1970-01-01','131L','0','9','9','150','64.29','0','91.31','0','-27.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:09',NULL),(165,'243',NULL,NULL,'73','250329123727','2026-05-06','1970-01-01','131M','0','13','13','150','64.29','0','91.31','0','-27.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:11',NULL),(166,'243',NULL,NULL,'74','1672656051979','02-01-2023','1970-01-01','132','0','420','420','60','42.857','0','35.714','0','7.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:14',NULL),(167,'243',NULL,NULL,'75','1672656030354','02-01-2023','1970-01-01','133','0','425','425','85','61.864','0','55.7','0','6.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:16',NULL),(168,'243',NULL,NULL,'75','1776062360450','null','1970-01-01','133','0','0','0','90','66.101','0','60.7','0','5.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:18',NULL),(169,'243',NULL,NULL,'76','230208212351','2026-05-06','1970-01-01','134','0','0','0','110','72.03','0','64','0','8.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:20',NULL),(170,'243',NULL,NULL,'77','1672656030415','02-01-2023','1970-01-01','135','0','0','0','110','76.27','0','68.7','0','7.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:23',NULL),(171,'243',NULL,NULL,'78','1672656030481','02-01-2023','1970-01-01','136','0','0','0','115','80.5','0','68.33','0','12.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:25',NULL),(172,'243',NULL,NULL,'78','1686739775890','null','1970-01-01','136','0','24','24','125','84.745','0','68.33','0','16.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:27',NULL),(173,'243',NULL,NULL,'78','1777372000334','null','1970-01-01','136','0','0','0','140','88.983','0','76.666','0','12.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:29',NULL),(174,'243',NULL,NULL,'79','230218085745','2026-05-06','1970-01-01','137','0','0','0','80','55.932','0','50.7','0','5.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:31',NULL),(175,'243',NULL,NULL,'79','1772017057715','2026-05-06','1970-01-01','137','0','0','0','85','61.016','0','55.5','0','5.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:34',NULL),(176,'243',NULL,NULL,'80','240313213334','2026-05-06','1970-01-01','137A','0','16','16','100','59.322','0','55','0','4.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:36',NULL),(177,'243',NULL,NULL,'81','240313213543','2026-05-06','1970-01-01','137B','0','12','12','200','118.644','0','110','0','8.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:38',NULL),(178,'243',NULL,NULL,'82','240829124934','2026-05-06','1970-01-01','137C','0','1','1','900','550.847','0','425','0','125.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:40',NULL),(179,'243',NULL,NULL,'83','230607122534','2026-05-06','1970-01-01','138','0','352','352','10','7.203','0','6.55','0','0.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:43',NULL),(180,'243',NULL,NULL,'84','230607122804','2026-05-06','1970-01-01','138A','0','95','95','40','28.39','0','24.8','0','3.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:45',NULL),(181,'243',NULL,NULL,'85','230607123003','2026-05-06','1970-01-01','138B','0','0','0','75','55.08','0','48','0','7.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:47',NULL),(182,'243',NULL,NULL,'85','1774527054703','2026-05-06','1970-01-01','138B','0','25','25','80','57.627','0','48','0','9.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:49',NULL),(183,'243',NULL,NULL,'86','1672656030557','02-01-2023','1970-01-01','139','0','94','94','80','55.08','0','50.92','0','4.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:52',NULL),(184,'243',NULL,NULL,'86','1747646451995','null','1970-01-01','139','0','0','0','85','60.028','0','50.916','0','9.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:54',NULL),(185,'243',NULL,NULL,'86','1776062464669','null','1970-01-01','139','0','0','0','90','74.576','0','68.333','0','6.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:56',NULL),(186,'243',NULL,NULL,'86','1776347766937','null','1970-01-01','1776347766937','0','0','0','100','74.576','0','68.333','0','6.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:52:59',NULL),(187,'243',NULL,NULL,'87','1672656030616','02-01-2023','1970-01-01','140','0','45','45','80','55.08','0','50.92','0','4.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:01',NULL),(188,'243',NULL,NULL,'87','1776062596332','null','1970-01-01','140','0','0','0','100','74.576','0','68.333','0','6.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:03',NULL),(189,'243',NULL,NULL,'88','1672656030682','02-01-2023','1970-01-01','141','0','0','0','80','55.08','0','50.92','0','4.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:06',NULL),(190,'243',NULL,NULL,'88','1747720066887','null','1970-01-01','141','0','8','8','85','60.028','0','50.916','0','9.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:08',NULL),(191,'243',NULL,NULL,'88','1776062635704','null','1970-01-01','141','0','0','0','90','74.576','0','68.333','0','6.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:10',NULL),(192,'243',NULL,NULL,'88','1776347824489','null','1970-01-01','1776347824488','0','0','0','100','74.576','0','68.33','0','6.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:13',NULL),(193,'243',NULL,NULL,'89','1672656030740','02-01-2023','1970-01-01','142','0','18','18','80','55.08','0','50.92','0','4.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:15',NULL),(194,'243',NULL,NULL,'89','1776062665396','null','1970-01-01','142','0','0','0','90','74.576','0','68.333','0','6.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:17',NULL),(195,'243',NULL,NULL,'89','1776347852301','null','1970-01-01','1776347852301','0','0','0','100','74.576','0','68.33','0','6.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:20',NULL),(196,'243',NULL,NULL,'90','1672656030840','02-01-2023','1970-01-01','143','0','38','38','375','245.76','0','209.75','0','36.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:22',NULL),(197,'243',NULL,NULL,'90','1776062708636','null','1970-01-01','143','0','0','0','475','355.932','0','325','0','30.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:24',NULL),(198,'243',NULL,NULL,'91','1672656030899','02-01-2023','1970-01-01','144','0','25','25','375','245.76','0','209.75','0','36.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:27',NULL),(199,'243',NULL,NULL,'91','1776062745848','null','1970-01-01','144','0','0','0','475','355.932','0','325','0','30.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:29',NULL),(200,'243',NULL,NULL,'92','1672656030968','02-01-2023','1970-01-01','145','0','4','4','375','245.76','0','209.75','0','36.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:31',NULL),(201,'243',NULL,NULL,'92','1776062782553','null','1970-01-01','145','0','0','0','475','355.932','0','325','0','30.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:34',NULL),(202,'243',NULL,NULL,'93','1672656031031','02-01-2023','1970-01-01','146','0','14','14','375','245.76','0','209.75','0','36.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:36',NULL),(203,'243',NULL,NULL,'93','1776062858940','null','1970-01-01','146','0','0','0','475','355.932','0','325','0','30.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:38',NULL),(204,'243',NULL,NULL,'94','1672656031090','02-01-2023','1970-01-01','147','0','0','0','48','22.03','0','19.71','0','2.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:40',NULL),(205,'243',NULL,NULL,'94','1673249980185','null','1970-01-01','147','0','0','0','48','450','0','40','0','410.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:43',NULL),(206,'243',NULL,NULL,'94','1673347838356','null','1970-01-01','147','0','0','0','48','22.03','0','19.7','0','2.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:45',NULL),(207,'243',NULL,NULL,'94','1687519521297','null','1970-01-01','147','0','0','0','50','19.17','0','19.17','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:47',NULL),(208,'243',NULL,NULL,'94','1687519585277','null','1970-01-01','147','0','0','0','50','22.89','0','19.7','0','3.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:50',NULL),(209,'243',NULL,NULL,'94','1723009496600','null','1970-01-01','147','0','0','0','52','23.728','0','19.7','0','4.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:52',NULL),(210,'243',NULL,NULL,'94','1772017199217','null','1970-01-01','147','0','372','372','55','27.118','0','21.75','0','5.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:54',NULL),(211,'243',NULL,NULL,'95','1672656031141','02-01-2023','1970-01-01','148','0','0','0','95','50.85','0','43.5','0','7.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:57',NULL),(212,'243',NULL,NULL,'95','1690017466470','null','1970-01-01','148','0','0','0','100','52.54','0','45.5','0','7.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:53:59',NULL),(213,'243',NULL,NULL,'95','1735109131209','null','1970-01-01','148','0','0','0','110','55.0847','0','47.79','0','7.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:01',NULL),(214,'243',NULL,NULL,'95','1770624847898','null','1970-01-01','148','0','193','193','130','61.016','0','47.791','0','13.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:04',NULL),(215,'243',NULL,NULL,'96','1672656031198','02-01-2023','1970-01-01','149','0','0','0','175','93.22','0','84','0','9.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:06',NULL),(216,'243',NULL,NULL,'96','1690017535790','null','1970-01-01','149','0','0','0','200','97.45','0','87','0','10.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:08',NULL),(217,'243',NULL,NULL,'96','1727614441597','null','1970-01-01','149','0','0','0','210','101.694','0','91.333','0','10.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:11',NULL),(218,'243',NULL,NULL,'96','1772017281649','null','1970-01-01','149','0','115','115','250','118.644','0','91.33','0','27.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:13',NULL),(219,'243',NULL,NULL,'97','1672656031250','02-01-2023','1970-01-01','150','0','-4','-4','1030','474.576','0','407.25','0','67.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:15',NULL),(220,'243',NULL,NULL,'97','1774526771512','null','1970-01-01','150','0','12','12','1100','550.847','0','427.5','0','123.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:18',NULL),(221,'243',NULL,NULL,'98','1672656031314','02-01-2023','1970-01-01','150A','0','48','48','45','23.728','0','19.71','0','4.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:20',NULL),(222,'243',NULL,NULL,'99','1672656031365','02-01-2023','1970-01-01','150B','0','17','17','90','52.542','0','43.5','0','9.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:22',NULL),(223,'243',NULL,NULL,'100','1672656031425','02-01-2023','1970-01-01','150C','0','12','12','180','101.694','0','84','0','17.69','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:25',NULL),(224,'243',NULL,NULL,'101','1672656031481','02-01-2023','1970-01-01','150D','0','6','6','800','474.576','0','402','0','72.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:27',NULL),(225,'243',NULL,NULL,'102','1672656031540','02-01-2023','1970-01-01','151','0','0','0','28','18.64','0','16.5','0','2.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:30',NULL),(226,'243',NULL,NULL,'102','1695452733262','null','1970-01-01','151','0','0','0','28','18.64','0','16.5','0','2.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:32',NULL),(227,'243',NULL,NULL,'102','1698654223534','null','1970-01-01','151','0','36','36','30','18.65','0','16.5','0','2.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:35',NULL),(228,'243',NULL,NULL,'103','1672656031609','02-01-2023','1970-01-01','152','0','76','76','50','33.898','0','27.41','0','6.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:37',NULL),(229,'243',NULL,NULL,'104','1672656031665','02-01-2023','1970-01-01','153','0','0','0','80','33.9','0','25','0','8.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:39',NULL),(230,'243',NULL,NULL,'104','1693915430366','null','1970-01-01','153','0','0','0','100','46.61','0','34.375','0','12.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:42',NULL),(231,'243',NULL,NULL,'105','240226191842','2026-05-06','1970-01-01','153A','0','11','11','180','69.491','0','60.41','0','9.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:44',NULL),(232,'243',NULL,NULL,'106','241117181131','2026-05-06','1970-01-01','153B','0','14','14','55','25.423','0','22.611','0','2.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:46',NULL),(233,'243',NULL,NULL,'107','241114154412','2026-05-06','2026-05-06','153C','0','24','24','55','25.423','0','22.611','0','2.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:49',NULL),(234,'243',NULL,NULL,'108','260330180657','2026-05-06','1970-01-01','153D','0','30','30','110','46.61','0','40.666','0','5.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:51',NULL),(235,'243',NULL,NULL,'109','1672656031729','02-01-2023','1970-01-01','154','0','0','0','75','35.59','0','26','0','9.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:53',NULL),(236,'243',NULL,NULL,'109','1684150170219','null','1970-01-01','154','0','14','14','100','33.9','0','29.25','0','4.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:56',NULL),(237,'243',NULL,NULL,'110','230607123250','2026-05-06','1970-01-01','154A','0','5','5','550','228.81','0','200','0','28.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:54:58',NULL),(238,'243',NULL,NULL,'111','1672656031826','02-01-2023','1970-01-01','155','0','0','0','75','35.59','0','26','0','9.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:01',NULL),(239,'243',NULL,NULL,'111','1684150098380','null','1970-01-01','155','0','11','11','100','33.9','0','29.25','0','4.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:03',NULL),(240,'243',NULL,NULL,'112','230607123752','2026-05-06','1970-01-01','155A','0','3','3','550','228.81','0','200','0','28.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:05',NULL),(241,'243',NULL,NULL,'113','240929183842','2026-05-06','1970-01-01','155B','0','9','9','175','67.796','0','55.916','0','11.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:08',NULL),(242,'243',NULL,NULL,'114','241225124643','2026-05-06','1970-01-01','155C','0','2','2','800','271.186','0','156','0','115.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:10',NULL),(243,'243',NULL,NULL,'115','250311164306','2026-05-06','1970-01-01','155D','0','54','54','50','27.118','0','24.428','0','2.69','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:13',NULL),(244,'243',NULL,NULL,'116','1672656031893','02-01-2023','1970-01-01','156','0','0','0','65','31.25','0','26.25','0','5.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:15',NULL),(245,'243',NULL,NULL,'116','1727615384744','null','1970-01-01','156','0','17','17','95','38.135','0','31.541','0','6.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:18',NULL),(246,'243',NULL,NULL,'117','240527170322','2026-05-06','1970-01-01','156A','0','2','2','85','38.135','0','34','0','4.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:20',NULL),(247,'243',NULL,NULL,'118','240527170525','2026-05-06','1970-01-01','156B','0','9','9','180','67.796','0','60','0','7.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:23',NULL),(248,'243',NULL,NULL,'119','1672656031958','02-01-2023','1970-01-01','157','0','10','10','99','67.79','0','61.2','0','6.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:25',NULL),(249,'243',NULL,NULL,'120','1672656032043','02-01-2023','1970-01-01','157A','0','1','1','800','389.83','0','300','0','89.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:28',NULL),(250,'243',NULL,NULL,'121','1672656032100','02-01-2023','1970-01-01','158','0','0','0','99','67.79','0','61.2','0','6.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:30',NULL),(251,'243',NULL,NULL,'122','240527165327','2026-05-06','1970-01-01','158A','0','1','1','800','389.83','0','300','0','89.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:32',NULL),(252,'243',NULL,NULL,'123','1672656032159','02-01-2023','1970-01-01','159','0','4','4','180','93.22','0','66.66','0','26.56','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:35',NULL),(253,'243',NULL,NULL,'124','1672656032216','02-01-2023','1970-01-01','160','0','14','14','180','93.22','0','66.66','0','26.56','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:37',NULL),(254,'243',NULL,NULL,'125','1672656032290','02-01-2023','1970-01-01','161','0','708','708','15','5.08','0','4.5','0','0.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:40',NULL),(255,'243',NULL,NULL,'126','1672656032348','02-01-2023','1970-01-01','162','0','0','0','32','16.95','0','12','0','4.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:42',NULL),(256,'243',NULL,NULL,'126','1675872097122','null','1970-01-01','162','0','107','107','45','16.95','0','12','0','4.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:45',NULL),(257,'243',NULL,NULL,'127','1672656032406','02-01-2023','1970-01-01','163','0','153','153','30','12.71','0','9.8','0','2.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:47',NULL),(258,'243',NULL,NULL,'128','1672656016206','02-01-2023','1970-01-01','164','0','20','20','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:50',NULL),(259,'243',NULL,NULL,'129','1672656016294','02-01-2023','1970-01-01','165','0','45','45','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:53',NULL),(260,'243',NULL,NULL,'130','1672656016380','02-01-2023','1970-01-01','166','0','20','20','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:55',NULL),(261,'243',NULL,NULL,'131','1672656032465','02-01-2023','1970-01-01','167','0','144','144','10','5.084','0','4.6','0','0.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:55:58',NULL),(262,'243',NULL,NULL,'132','1672656032531','02-01-2023','1970-01-01','168','0','43','43','0','0','0','100','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:00',NULL),(263,'243',NULL,NULL,'133','250111121322','2026-05-06','1970-01-01','168A','0','16','16','0','0','0','100','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:03',NULL),(264,'243',NULL,NULL,'134','250111121432','2026-05-06','1970-01-01','168B','0','31','31','0','0','0','100','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:05',NULL),(265,'243',NULL,NULL,'135','250303142734','2026-05-06','2026-05-06','168C','0','0','0','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:08',NULL),(266,'243',NULL,NULL,'136','250303142814','2026-05-06','2026-05-06','168D','0','0','0','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:10',NULL),(267,'243',NULL,NULL,'137','1672656032591','02-01-2023','1970-01-01','169','0','181','181','5','3.81','0','3.04','0','0.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:13',NULL),(268,'243',NULL,NULL,'138','230729124628','2026-05-06','1970-01-01','1690616061559','0','0','0','61','45.39','0','41.26','0','4.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:15',NULL),(269,'243',NULL,NULL,'139','230729124945','2026-05-06','1970-01-01','1690616078232','0','0','0','61','45.39','0','41.26','0','4.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:18',NULL),(270,'243',NULL,NULL,'140','1672656032648','02-01-2023','1970-01-01','170','0','140','140','10','7.627','0','6.08','0','1.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:21',NULL),(271,'243',NULL,NULL,'141','240109162043','2026-05-06','1970-01-01','1704884767183','0','0','0','10','7.942','0','7.22','0','0.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:23',NULL),(272,'243',NULL,NULL,'142','1672656032723','02-01-2023','1970-01-01','171','0','326','326','5','3.81','0','3.23','0','0.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:25',NULL),(273,'243',NULL,NULL,'143','240418201301','2026-05-06','1970-01-01','1713451626002','0','0','0','85','60.169','0','54.23','0','5.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:28',NULL),(274,'243',NULL,NULL,'144','1672656032798','02-01-2023','1970-01-01','172','0','306','306','10','7.627','0','6.46','0','1.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:30',NULL),(275,'243',NULL,NULL,'145','1672656032856','02-01-2023','1970-01-01','173','0','310','310','10','7.2','0','6.7','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:33',NULL),(276,'243',NULL,NULL,'146','1672656032935','02-01-2023','1970-01-01','174','0','0','0','95','75.396','0','61.55','0','13.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:35',NULL),(277,'243',NULL,NULL,'146','1754380781343','null','1970-01-01','174','0','0','0','105','83.33','0','68.03','0','15.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:38',NULL),(278,'243',NULL,NULL,'146','1772608437729','null','1970-01-01','174','0','189','189','110','87.301','0','80.09','0','7.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:41',NULL),(279,'243',NULL,NULL,'147','240724145327','2026-05-06','1970-01-01','174A','0','0','0','85','67.46','0','55.07','0','12.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:43',NULL),(280,'243',NULL,NULL,'147','1753176769366','2026-05-06','1970-01-01','174A','0','0','0','95','75.396','0','61.55','0','13.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:46',NULL),(281,'243',NULL,NULL,'147','1760163220649','2026-05-06','1970-01-01','174A','0','0','0','80','63.492','0','51.83','0','11.66','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:48',NULL),(282,'243',NULL,NULL,'147','1760163471785','2026-05-06','1970-01-01','174A','0','0','0','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:51',NULL),(283,'243',NULL,NULL,'147','1772608827928','2026-05-06','1970-01-01','174A','0','48','48','100','79.365','0','72.81','0','6.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:54',NULL),(284,'243',NULL,NULL,'147','1777529141784','2026-05-06','1970-01-01','174A','0','0','0','105','83.33','0','76.45','0','6.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:56',NULL),(285,'243',NULL,NULL,'148','1672656032996','02-01-2023','1970-01-01','175','0','0','0','190','150.793','0','124.24','0','26.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:56:59',NULL),(286,'243',NULL,NULL,'148','1753773339753','null','1970-01-01','175','0','0','0','210','166.66','0','136.06','0','30.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:01',NULL),(287,'243',NULL,NULL,'148','1772104270267','null','1970-01-01','175','0','110','110','220','174.603','0','160.19','0','14.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:04',NULL),(288,'243',NULL,NULL,'149','251015174337','2026-05-06','1970-01-01','1760530524386','0','0','0','650','495.238','0','431.63','0','63.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:06',NULL),(289,'243',NULL,NULL,'150','1672656033055','02-01-2023','1970-01-01','177','0','1','1','105','83.33','0','68.03','0','15.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:09',NULL),(290,'243',NULL,NULL,'150','1716281700963','null','1970-01-01','177','0','0','0','115','91.269','0','74.5','0','16.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:12',NULL),(291,'243',NULL,NULL,'150','1772608630053','null','1970-01-01','177','0','85','85','120','95.238','0','87.37','0','7.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:14',NULL),(292,'243',NULL,NULL,'151','260401123134','2026-05-06','1970-01-01','1775031634791','0','0','0','20','15.238','0','13.85','0','1.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:17',NULL),(293,'243',NULL,NULL,'152','1672656033139','02-01-2023','1970-01-01','178','0','0','0','210','166.66','0','136.06','0','30.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:19',NULL),(294,'243',NULL,NULL,'152','1715778806139','null','1970-01-01','178','0','0','0','230','182.539','0','136.06','0','46.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:22',NULL),(295,'243',NULL,NULL,'152','1760517065624','null','1970-01-01','178','0','0','0','205','162.698','0','149.26','0','13.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:24',NULL),(296,'243',NULL,NULL,'152','1772609252249','null','1970-01-01','178','0','37','37','240','190.476','0','174.75','0','15.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:26',NULL),(297,'243',NULL,NULL,'153','240908175808','2026-05-06','1970-01-01','178A','0','0','0','150','105.932','0','97.19','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:29',NULL),(298,'243',NULL,NULL,'154','240908175954','2026-05-06','1970-01-01','178B','0','0','0','150','105.932','0','97.19','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:32',NULL),(299,'243',NULL,NULL,'155','241224152131','2026-05-06','1970-01-01','178C','0','0','0','150','105.932','0','97.19','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:34',NULL),(300,'243',NULL,NULL,'156','241224152523','2026-05-06','1970-01-01','178D','0','0','0','150','105.932','0','97.19','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:37',NULL),(301,'243',NULL,NULL,'157','241224152815','2026-05-06','1970-01-01','178E','0','0','0','150','105.932','0','97.19','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:39',NULL),(302,'243',NULL,NULL,'158','241224153022','2026-05-06','1970-01-01','178F','0','0','0','150','105.932','0','97.19','0','8.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:42',NULL),(303,'243',NULL,NULL,'159','1672656033204','02-01-2023','1970-01-01','179','0','0','0','100','79.365','0','64.79','0','14.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:44',NULL),(304,'243',NULL,NULL,'159','1715763570680','null','1970-01-01','179','0','0','0','120','95.238','0','77.75','0','17.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:47',NULL),(305,'243',NULL,NULL,'159','1760516980857','null','1970-01-01','179','0','84','84','110','87.301','0','80.09','0','7.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:49',NULL),(306,'243',NULL,NULL,'159','1776762238969','null','1970-01-01','179','0','0','0','130','103.174','0','94.66','0','8.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:52',NULL),(307,'243',NULL,NULL,'160','250218183349','2026-05-06','1970-01-01','179A','0','0','0','10','7.142','0','6.493','0','0.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:55',NULL),(308,'243',NULL,NULL,'161','250218183858','2026-05-06','1970-01-01','179B','0','0','0','35','25','0','22.72','0','2.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:57:57',NULL),(309,'243',NULL,NULL,'162','1672656033263','02-01-2023','1970-01-01','180','0','0','0','200','158.73','0','129.58','0','29.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:00',NULL),(310,'243',NULL,NULL,'162','1695283313851','null','1970-01-01','180','0','0','0','210','166.66','0','129.58','0','37.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:03',NULL),(311,'243',NULL,NULL,'162','1715763637066','null','1970-01-01','180','0','0','0','240','190.476','0','150.65','0','39.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:05',NULL),(312,'243',NULL,NULL,'162','1762600605806','null','1970-01-01','180','0','0','0','215','170.634','0','156.55','0','14.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:08',NULL),(313,'243',NULL,NULL,'162','1774944554359','null','1970-01-01','180','0','36','36','250','198.412','0','182.03','0','16.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:11',NULL),(314,'243',NULL,NULL,'163','1672656033332','02-01-2023','1970-01-01','180A','0','0','0','105','83.33','0','68.03','0','15.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:13',NULL),(315,'243',NULL,NULL,'163','1718706001743','null','1970-01-01','180A','0','5','5','120','95.238','0','77.75','0','17.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:16',NULL),(316,'243',NULL,NULL,'163','1756979626113','null','1970-01-01','180A','0','0','0','135','107.142','0','87.47','0','19.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:18',NULL),(317,'243',NULL,NULL,'163','1777528884849','null','1970-01-01','180A','0','0','0','130','103.174','0','94.66','0','8.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:21',NULL),(318,'243',NULL,NULL,'164','1672656033394','02-01-2023','1970-01-01','180B','0','0','0','210','166.66','0','136.06','0','30.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:23',NULL),(319,'243',NULL,NULL,'164','1717495093699','null','1970-01-01','180B','0','5','5','240','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:26',NULL),(320,'243',NULL,NULL,'164','27','null','1970-01-01','180B','0','0','0','270','214.285','0','174.93','0','39.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:29',NULL),(321,'243',NULL,NULL,'165','240226182455','2026-05-06','1970-01-01','181','0','0','0','270','190.677','0','167.94','0','22.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:31',NULL),(322,'243',NULL,NULL,'166','240409204254','2026-05-06','1970-01-01','181A','0','0','0','90','68.571','0','62.33','0','6.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:34',NULL),(323,'243',NULL,NULL,'167','240416143910','2026-05-06','1970-01-01','181B','0','0','0','50','38.095','0','34.63','0','3.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:37',NULL),(324,'243',NULL,NULL,'168','1672656033461','02-01-2023','1970-01-01','182','0','0','0','160','126.984','0','103.66','0','23.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:39',NULL),(325,'243',NULL,NULL,'168','170','null','1970-01-01','182','0','0','0','170','134.92','0','110.14','0','24.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:42',NULL),(326,'243',NULL,NULL,'168','1755692158149','null','1970-01-01','182','0','0','0','190','150.793','0','123.1','0','27.69','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:45',NULL),(327,'243',NULL,NULL,'168','1760517135009','null','1970-01-01','182','0','0','0','165','130.952','0','120.14','0','10.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:47',NULL),(328,'243',NULL,NULL,'168','1772609418363','null','1970-01-01','182','0','30','30','205','162.6984','0','149.26','0','13.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:50',NULL),(329,'243',NULL,NULL,'168','210','null','1970-01-01','182','0','0','0','210','166.66','0','152.91','0','13.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:53',NULL),(330,'243',NULL,NULL,'169','240605202927','2026-05-06','1970-01-01','182A','0','0','0','120','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:56',NULL),(331,'243',NULL,NULL,'170','240612100432','2026-05-06','1970-01-01','182B','0','0','0','120','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:58:58',NULL),(332,'243',NULL,NULL,'171','240612100614','2026-05-06','1970-01-01','182C','0','0','0','120','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:01',NULL),(333,'243',NULL,NULL,'172','260105185546','2026-05-06','1970-01-01','182D','0','0','0','150','114.285','0','105.82','0','8.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:03',NULL),(334,'243',NULL,NULL,'173','260105185737','2026-05-06','1970-01-01','182E','0','0','0','160','126.984','0','112.874','0','14.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:06',NULL),(335,'243',NULL,NULL,'174','260105185938','2026-05-06','1970-01-01','182F','0','0','0','90','71.428','0','66.137','0','5.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:09',NULL),(336,'243',NULL,NULL,'175','260105190116','2026-05-06','1970-01-01','182G','0','0','0','60','47.619','0','44.0917','0','3.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:11',NULL),(337,'243',NULL,NULL,'176','1672656033531','02-01-2023','1970-01-01','183','0','0','0','210','148.3','0','136.06','0','12.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:14',NULL),(338,'243',NULL,NULL,'176','1724828610213','null','1970-01-01','183','0','0','0','230','182.539','0','149.02','0','33.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:17',NULL),(339,'243',NULL,NULL,'177','240829124234','2026-05-06','1970-01-01','183A','0','0','0','290','204.802','0','187.89','0','16.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:20',NULL),(340,'243',NULL,NULL,'178','1672656033589','02-01-2023','1970-01-01','184','0','0','0','210','148.3','0','136.06','0','12.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:22',NULL),(341,'243',NULL,NULL,'179','241010203631','2026-05-06','1970-01-01','184A','0','0','0','450','317.796','0','265.9','0','51.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:25',NULL),(342,'243',NULL,NULL,'179','1759493123441','2026-05-06','1970-01-01','184A','0','0','0','499','380.19','0','331.36','0','48.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:28',NULL),(343,'243',NULL,NULL,'180','241010203937','2026-05-06','1970-01-01','184B','0','0','0','400','304.761','0','265.62','0','39.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:30',NULL),(344,'243',NULL,NULL,'181','241010204212','2026-05-06','1970-01-01','184C','0','0','0','700','494.35','0','413.62','0','80.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:33',NULL),(345,'243',NULL,NULL,'181','1759493349254','2026-05-06','1970-01-01','184C','0','0','0','650','495.238','0','431.63','0','63.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:36',NULL),(346,'243',NULL,NULL,'182','231017144517','2026-05-06','1970-01-01','185','0','0','0','230','162.42','0','149.02','0','13.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:38',NULL),(347,'243',NULL,NULL,'182','1730802028916','2026-05-06','1970-01-01','185','0','0','0','240','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:41',NULL),(348,'243',NULL,NULL,'183','250226165814','2026-05-06','1970-01-01','185A','0','0','0','120','95.238','0','77.75','0','17.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:44',NULL),(349,'243',NULL,NULL,'184','250226170025','2026-05-06','1970-01-01','185B','0','0','0','120','95.24','0','77.75','0','17.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:46',NULL),(350,'243',NULL,NULL,'185','250226170203','2026-05-06','2026-05-06','185C','0','0','0','120','95.24','0','77.75','0','17.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:49',NULL),(351,'243',NULL,NULL,'186','231019140132','2026-05-06','1970-01-01','186','0','1','1','210','160','0','123.69','0','36.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:52',NULL),(352,'243',NULL,NULL,'187','240715133547','2026-05-06','1970-01-01','186A','0','0','0','400','271.186','0','248.79','0','22.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:54',NULL),(353,'243',NULL,NULL,'188','240715133751','2026-05-06','1970-01-01','186B','0','0','0','400','271.186','0','248.79','0','22.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 10:59:57',NULL),(354,'243',NULL,NULL,'189','240715133945','2026-05-06','1970-01-01','186C','0','0','0','400','271.186','0','248.79','0','22.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:00',NULL),(355,'243',NULL,NULL,'190','240715134220','2026-05-06','1970-01-01','186D','0','0','0','480','305.08','0','279.89','0','25.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:04',NULL),(356,'243',NULL,NULL,'191','240715135355','2026-05-06','1970-01-01','186E','0','0','0','250','169.5','0','155.5','0','14.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:08',NULL),(357,'243',NULL,NULL,'192','231019140512','2026-05-06','1970-01-01','187','0','0','0','260','198.09','0','155.65','0','42.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:13',NULL),(358,'243',NULL,NULL,'192','1728389620699','2026-05-06','1970-01-01','187','0','0','0','250','190.476','0','147.72','0','42.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:17',NULL),(359,'243',NULL,NULL,'192','251003161733','2026-05-06','1970-01-01','187','0','0','0','275','209.523','0','182.61','0','26.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:22',NULL),(360,'243',NULL,NULL,'193','241021173453','2026-05-06','1970-01-01','187A','0','0','0','720','508.474','0','425.44','0','83.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:26',NULL),(361,'243',NULL,NULL,'194','250924182416','2026-05-06','1970-01-01','187B','0','2','2','350','266.66','0','217.7','0','48.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:29',NULL),(362,'243',NULL,NULL,'195','251003162135','2026-05-06','1970-01-01','187C','0','27','27','125','95.238','0','83','0','12.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:32',NULL),(363,'243',NULL,NULL,'196','251003162355','2026-05-06','1970-01-01','187D','0','3','3','300','228.571','0','199.21','0','29.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:35',NULL),(364,'243',NULL,NULL,'197','1672656033649','02-01-2023','1970-01-01','188A','0','0','0','225','158.89','0','139.95','0','18.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:38',NULL),(365,'243',NULL,NULL,'198','1672656033706','02-01-2023','1970-01-01','188B','0','0','0','350','247.17','0','217.69','0','29.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:43',NULL),(366,'243',NULL,NULL,'199','1672656033766','02-01-2023','1970-01-01','188C','0','0','0','300','211.86','0','186.6','0','25.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:47',NULL),(367,'243',NULL,NULL,'200','1672656033823','02-01-2023','1970-01-01','188D','0','0','0','250','169.5','0','155.5','0','14.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:00:53',NULL),(368,'243',NULL,NULL,'201','1672656033883','02-01-2023','1970-01-01','188E','0','0','0','85','60.02','0','52.87','0','7.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:03',NULL),(369,'243',NULL,NULL,'201','1733821683125','null','1970-01-01','188E','0','0','0','90','71.428','0','55.98','0','15.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:11',NULL),(370,'243',NULL,NULL,'201','1753177115638','null','1970-01-01','188E','0','8','8','100','79.365','0','64.79','0','14.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:18',NULL),(371,'243',NULL,NULL,'202','1672656033939','02-01-2023','1970-01-01','189','0','0','0','750','538.13','0','485.93','0','52.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:25',NULL),(372,'243',NULL,NULL,'203','1672656034039','02-01-2023','1970-01-01','189A','0','0','0','600','423.72','0','388.74','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:32',NULL),(373,'243',NULL,NULL,'203','1759493273021','null','1970-01-01','189A','0','0','0','575','438.095','0','381.83','0','56.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:39',NULL),(374,'243',NULL,NULL,'204','1672656034098','02-01-2023','1970-01-01','189B','0','0','0','500','353.1','0','323.95','0','29.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:47',NULL),(375,'243',NULL,NULL,'204','1759492998616','null','1970-01-01','189B','0','0','0','550','419.047','0','365.22','0','53.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:01:55',NULL),(376,'243',NULL,NULL,'205','251007121613','2026-05-06','1970-01-01','189C','0','41','41','160','121.904','0','106.25','0','15.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:02',NULL),(377,'243',NULL,NULL,'206','251007121826','2026-05-06','1970-01-01','189D','0','2','2','160','121.904','0','106.25','0','15.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:10',NULL),(378,'243',NULL,NULL,'207','251015174121','2026-05-06','1970-01-01','189E','0','0','0','399','304','0','264.95','0','39.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:17',NULL),(379,'243',NULL,NULL,'208','1672656034156','02-01-2023','1970-01-01','190','0','0','0','600','423.72','0','388.74','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:23',NULL),(380,'243',NULL,NULL,'209','251003163909','2026-05-06','1970-01-01','190A','0','0','0','290','220.952','0','192.57','0','28.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:28',NULL),(381,'243',NULL,NULL,'210','251003170608','2026-05-06','1970-01-01','190B','0','0','0','600','457.142','0','398.43','0','58.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:33',NULL),(382,'243',NULL,NULL,'211','1672656034222','02-01-2023','1970-01-01','191','0','0','0','490','346.05','0','317.47','0','28.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:39',NULL),(383,'243',NULL,NULL,'211','1759493202587','null','1970-01-01','191','0','0','0','499','380.19','0','331.36','0','48.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:46',NULL),(384,'243',NULL,NULL,'212','1672656034289','02-01-2023','1970-01-01','192','0','0','0','470','334.75','0','304.51','0','30.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:02:55',NULL),(385,'243',NULL,NULL,'213','1672656034366','02-01-2023','1970-01-01','193','0','0','0','410','292.37','0','265.64','0','26.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:03',NULL),(386,'243',NULL,NULL,'214','1672656034438','02-01-2023','1970-01-01','194','0','0','0','250','190.476','0','161.98','0','28.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:09',NULL),(387,'243',NULL,NULL,'215','1672656034497','02-01-2023','1970-01-01','194A','0','0','0','150','114.285','0','93.3','0','20.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:14',NULL),(388,'243',NULL,NULL,'216','1672656034556','02-01-2023','1970-01-01','194B','0','0','0','150','114.285','0','93.3','0','20.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:20',NULL),(389,'243',NULL,NULL,'217','1672656034614','02-01-2023','1970-01-01','194C','0','0','0','150','114.285','0','93.3','0','20.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:25',NULL),(390,'243',NULL,NULL,'218','1672656034673','02-01-2023','1970-01-01','194D','0','0','0','150','114.285','0','93.3','0','20.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:33',NULL),(391,'243',NULL,NULL,'219','1672656034735','02-01-2023','1970-01-01','194E','0','0','0','150','114.285','0','93.3','0','20.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:41',NULL),(392,'243',NULL,NULL,'220','1672656034799','02-01-2023','1970-01-01','195','0','0','0','300','211.86','0','194.37','0','17.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:49',NULL),(393,'243',NULL,NULL,'220','1724828704860','null','1970-01-01','195','0','0','0','330','261.904','0','213.8','0','48.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:03:55',NULL),(394,'243',NULL,NULL,'220','1760164085372','null','1970-01-01','195','0','0','0','295','234.126','0','214.8','0','19.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:02',NULL),(395,'243',NULL,NULL,'221','231103182052','2026-05-06','1970-01-01','195A','0','0','0','90','42.85','0','38.96','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:11',NULL),(396,'243',NULL,NULL,'222','240924210712','2026-05-06','1970-01-01','195B','0','0','0','90','42.85','0','38.96','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:18',NULL),(397,'243',NULL,NULL,'223','240924210832','2026-05-06','1970-01-01','195C','0','0','0','90','42.85','0','38.96','0','3.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:25',NULL),(398,'243',NULL,NULL,'224','260101150433','2026-05-06','1970-01-01','195D','0','2','2','130','61.904','0','56.277','0','5.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:34',NULL),(399,'243',NULL,NULL,'225','1672656034869','02-01-2023','1970-01-01','196','0','0','0','190','135.59','0','123.1','0','12.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:42',NULL),(400,'243',NULL,NULL,'226','1672656034931','02-01-2023','1970-01-01','197','0','0','0','180','128.4','0','116.62','0','11.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:04:52',NULL),(401,'243',NULL,NULL,'227','231102133022','2026-05-06','1970-01-01','198','0','0','0','425','300.14','0','275.36','0','24.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:01',NULL),(402,'243',NULL,NULL,'228','231102133227','2026-05-06','1970-01-01','198A','0','0','0','550','388.41','0','356.35','0','32.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:10',NULL),(403,'243',NULL,NULL,'229','231102134807','2026-05-06','1970-01-01','198B','0','0','0','360','267.85','0','245.74','0','22.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:20',NULL),(404,'243',NULL,NULL,'230','231102135656','2026-05-06','1970-01-01','198C','0','0','0','380','282.73','0','259.39','0','23.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:29',NULL),(405,'243',NULL,NULL,'231','1672656034992','02-01-2023','1970-01-01','200','0','0','0','245','194.44','0','178.39','0','16.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:39',NULL),(406,'243',NULL,NULL,'231','1760517031712','null','1970-01-01','200','0','0','0','225','178.571','0','163.83','0','14.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:49',NULL),(407,'243',NULL,NULL,'231','250','null','1970-01-01','200','0','25','25','250','198.412','0','182.03','0','16.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:05:58',NULL),(408,'243',NULL,NULL,'232','231212131806','2026-05-06','1970-01-01','201','0','0','0','125','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:06',NULL),(409,'243',NULL,NULL,'232','1746515877634','2026-05-06','1970-01-01','201','0','20','20','150','114.28','0','93.29','0','20.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:13',NULL),(410,'243',NULL,NULL,'233','231212132012','2026-05-06','1970-01-01','202','0','0','0','125','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:20',NULL),(411,'243',NULL,NULL,'233','1746515922289','2026-05-06','1970-01-01','202','0','39','39','150','114.28','0','93.29','0','20.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:26',NULL),(412,'243',NULL,NULL,'234','231212132141','2026-05-06','1970-01-01','203','0','0','0','125','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:32',NULL),(413,'243',NULL,NULL,'234','1746516008200','2026-05-06','1970-01-01','203','0','35','35','150','114.285','0','93.29','0','20.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:37',NULL),(414,'243',NULL,NULL,'235','231212132310','2026-05-06','1970-01-01','204','0','0','0','125','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:42',NULL),(415,'243',NULL,NULL,'235','1746515958308','2026-05-06','1970-01-01','204','0','17','17','150','114.285','0','93.29','0','20.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:48',NULL),(416,'243',NULL,NULL,'236','231212132435','2026-05-06','1970-01-01','204A','0','0','0','125','84.745','0','77.75','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:53',NULL),(417,'243',NULL,NULL,'236','1746516072200','2026-05-06','1970-01-01','204A','0','23','23','150','114.285','0','93.29','0','20.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:06:58',NULL),(418,'243',NULL,NULL,'237','1672656035064','02-01-2023','1970-01-01','205','0','20','20','270','214.285','0','161.48','0','52.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:05',NULL),(419,'243',NULL,NULL,'237','1753773750274','null','1970-01-01','205','0','0','0','300','238.095','0','194.37','0','43.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:13',NULL),(420,'243',NULL,NULL,'238','1672656035132','02-01-2023','1970-01-01','205A','0','0','0','280','197.74','0','167.46','0','30.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:19',NULL),(421,'243',NULL,NULL,'239','1672656035205','02-01-2023','1970-01-01','205B','0','0','0','280','197.74','0','167.46','0','30.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:25',NULL),(422,'243',NULL,NULL,'240','1672656035268','02-01-2023','1970-01-01','205C','0','0','0','270','190.67','0','161.48','0','29.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:30',NULL),(423,'243',NULL,NULL,'241','1672656035331','02-01-2023','1970-01-01','205D','0','0','0','185','130.64','0','110.64','0','20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:36',NULL),(424,'243',NULL,NULL,'242','231017144850','2026-05-06','1970-01-01','205E','0','0','0','200','141.24','0','124.4','0','16.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:41',NULL),(425,'243',NULL,NULL,'243','1672656035389','02-01-2023','1970-01-01','206','0','30','30','300','238.095','0','186.6','0','51.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:47',NULL),(426,'243',NULL,NULL,'244','1672656035447','02-01-2023','1970-01-01','207','0','0','0','299','227.809','0','198.55','0','29.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:53',NULL),(427,'243',NULL,NULL,'245','1672656035505','02-01-2023','1970-01-01','209','0','0','0','100','70.62','0','64.79','0','5.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:07:58',NULL),(428,'243',NULL,NULL,'246','1672656035566','02-01-2023','1970-01-01','209A','0','28','28','50','39.682','0','32.4','0','7.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:05',NULL),(429,'243',NULL,NULL,'246','1765886691588','null','1970-01-01','209A','0','0','0','45','35.714','0','32.4','0','3.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:13',NULL),(430,'243',NULL,NULL,'247','230905175819','2026-05-06','1970-01-01','209B','0','0','0','75','59.523','0','48.59','0','10.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:18',NULL),(431,'243',NULL,NULL,'248','240419144429','2026-05-06','1970-01-01','210','0','0','0','50','35.714','0','32.47','0','3.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:25',NULL),(432,'243',NULL,NULL,'249','240419144613','2026-05-06','1970-01-01','210A','0','0','0','50','35.714','0','32.47','0','3.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:33',NULL),(433,'243',NULL,NULL,'250','240419144802','2026-05-06','1970-01-01','210B','0','0','0','50','35.714','0','32.47','0','3.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:39',NULL),(434,'243',NULL,NULL,'251','1672656035641','02-01-2023','1970-01-01','211','0','0','0','200','135.59','0','124.4','0','11.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:44',NULL),(435,'243',NULL,NULL,'252','1672656035708','02-01-2023','1970-01-01','212','0','0','0','200','135.59','0','124.4','0','11.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:08:52',NULL),(436,'243',NULL,NULL,'253','1672656035775','02-01-2023','1970-01-01','213','0','0','0','200','135.59','0','124.4','0','11.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:01',NULL),(437,'243',NULL,NULL,'254','1672656035841','02-01-2023','1970-01-01','214','0','0','0','200','135.59','0','124.4','0','11.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:10',NULL),(438,'243',NULL,NULL,'255','1672656035908','02-01-2023','1970-01-01','215','0','0','0','200','135.59','0','124.4','0','11.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:17',NULL),(439,'243',NULL,NULL,'256','1672656035974','02-01-2023','1970-01-01','216','0','0','0','200','135.59','0','124.4','0','11.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:25',NULL),(440,'243',NULL,NULL,'257','1672656036033','02-01-2023','1970-01-01','216A','0','18','18','250','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:29',NULL),(441,'243',NULL,NULL,'258','1672656036089','02-01-2023','1970-01-01','216B','0','2','2','250','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:34',NULL),(442,'243',NULL,NULL,'259','1672656036147','02-01-2023','1970-01-01','216C','0','14','14','250','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:39',NULL),(443,'243',NULL,NULL,'260','1672656036206','02-01-2023','1970-01-01','216D','0','25','25','250','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:45',NULL),(444,'243',NULL,NULL,'261','1672656036264','02-01-2023','1970-01-01','216E','0','17','17','250','190.476','0','155.5','0','34.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:50',NULL),(445,'243',NULL,NULL,'262','260129195536','2026-05-06','1970-01-01','217','0','0','0','220','146.66','0','130.952','0','15.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:09:58',NULL),(446,'243',NULL,NULL,'263','241010191219','2026-05-06','1970-01-01','220','0','31','31','234','148.72','0','133.34','0','15.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:05',NULL),(447,'243',NULL,NULL,'264','241010191405','2026-05-06','1970-01-01','221','0','20','20','234','148.728','0','133.34','0','15.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:13',NULL),(448,'243',NULL,NULL,'265','241010192213','2026-05-06','1970-01-01','222','0','12','12','297','188.771','0','169.25','0','19.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:24',NULL),(449,'243',NULL,NULL,'266','241010192610','2026-05-06','1970-01-01','223','0','12','12','297','188.771','0','169.25','0','19.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:33',NULL),(450,'243',NULL,NULL,'267','241010192751','2026-05-06','1970-01-01','224','0','12','12','297','188.771','0','169.25','0','19.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:40',NULL),(451,'243',NULL,NULL,'268','241010192946','2026-05-06','1970-01-01','225','0','12','12','297','188.771','0','169.25','0','19.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:46',NULL),(452,'243',NULL,NULL,'269','241010193508','2026-05-06','1970-01-01','226','0','19','19','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:10:55',NULL),(453,'243',NULL,NULL,'270','241010193715','2026-05-06','1970-01-01','227','0','0','0','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:01',NULL),(454,'243',NULL,NULL,'271','241010193954','2026-05-06','1970-01-01','228','0','-1','-1','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:06',NULL),(455,'243',NULL,NULL,'272','241010194630','2026-05-06','1970-01-01','229','0','2','2','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:12',NULL),(456,'243',NULL,NULL,'273','250307081147','2026-05-06','1970-01-01','229A','0','-2','-2','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:19',NULL),(457,'243',NULL,NULL,'274','250307081341','2026-05-06','1970-01-01','229B','0','0','0','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:26',NULL),(458,'243',NULL,NULL,'275','250307081520','2026-05-06','1970-01-01','229C','0','0','0','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:32',NULL),(459,'243',NULL,NULL,'276','250307081651','2026-05-06','1970-01-01','229D','0','0','0','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:38',NULL),(460,'243',NULL,NULL,'277','250307081820','2026-05-06','1970-01-01','229E','0','0','0','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:45',NULL),(461,'243',NULL,NULL,'278','250307082059','2026-05-06','1970-01-01','229F','0','3','3','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:11:53',NULL),(462,'243',NULL,NULL,'279','250307082322','2026-05-06','2026-05-06','229G','0','-1','-1','630','400.423','0','359','0','41.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:07',NULL),(463,'243',NULL,NULL,'280','241010194820','2026-05-06','1970-01-01','230','0','0','0','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:13',NULL),(464,'243',NULL,NULL,'281','250307075503','2026-05-06','1970-01-01','230A','0','-2','-2','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:19',NULL),(465,'243',NULL,NULL,'282','250307075713','2026-05-06','1970-01-01','230B','0','0','0','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:27',NULL),(466,'243',NULL,NULL,'283','250307075858','2026-05-06','1970-01-01','230C','0','-3','-3','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:36',NULL),(467,'243',NULL,NULL,'284','250307080028','2026-05-06','1970-01-01','230D','0','0','0','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:49',NULL),(468,'243',NULL,NULL,'285','250307080206','2026-05-06','1970-01-01','230E','0','-1','-1','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:12:59',NULL),(469,'243',NULL,NULL,'286','250307080338','2026-05-06','1970-01-01','230F','0','0','0','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:06',NULL),(470,'243',NULL,NULL,'287','250307080519','2026-05-06','1970-01-01','230G','0','-4','-4','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:16',NULL),(471,'243',NULL,NULL,'288','250307080917','2026-05-06','1970-01-01','230H','0','0','0','450','286.016','0','256.44','0','29.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:27',NULL),(472,'243',NULL,NULL,'289','241010195021','2026-05-06','1970-01-01','231','0','-7','-7','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:34',NULL),(473,'243',NULL,NULL,'290','241010195256','2026-05-06','1970-01-01','231A','0','3','3','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:39',NULL),(474,'243',NULL,NULL,'291','241010195456','2026-05-06','1970-01-01','231B','0','24','24','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:45',NULL),(475,'243',NULL,NULL,'292','241010195722','2026-05-06','1970-01-01','231C','0','2','2','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:51',NULL),(476,'243',NULL,NULL,'293','241010195951','2026-05-06','1970-01-01','231D','0','2','2','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:13:59',NULL),(477,'243',NULL,NULL,'294','241010200247','2026-05-06','1970-01-01','231E','0','-1','-1','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:06',NULL),(478,'243',NULL,NULL,'295','241010200646','2026-05-06','1970-01-01','231F','0','3','3','252','160.169','0','143.6','0','16.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:12',NULL),(479,'243',NULL,NULL,'296','241010200902','2026-05-06','1970-01-01','231G','0','-1','-1','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:20',NULL),(480,'243',NULL,NULL,'297','241024193246','2026-05-06','1970-01-01','231H','0','0','0','198','125.847','0','112.83','0','13.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:26',NULL),(481,'243',NULL,NULL,'298','240808183435','2026-05-06','1970-01-01','232','0','230','230','10','8','0','7','0','1.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:32',NULL),(482,'243',NULL,NULL,'299','1672656016467','02-01-2023','1970-01-01','233','0','0','0','160','128','0','101.82','0','26.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:37',NULL),(483,'243',NULL,NULL,'299','1690035913893','null','1970-01-01','233','0','15','15','230','184','0','146.37','0','37.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:42',NULL),(484,'243',NULL,NULL,'300','1672656016536','02-01-2023','1970-01-01','234','0','-15','-15','140','112','0','89.09','0','22.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:50',NULL),(485,'243',NULL,NULL,'300','1693294433566','null','1970-01-01','234','0','68','68','200','160','0','127.28','0','32.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:14:59',NULL),(486,'243',NULL,NULL,'301','1672656016620','02-01-2023','1970-01-01','235','0','0','0','120','96','0','76.36','0','19.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:07',NULL),(487,'243',NULL,NULL,'301','1690035972683','null','1970-01-01','235','0','63','63','160','128','0','101.82','0','26.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:17',NULL),(488,'243',NULL,NULL,'302','1672656016697','02-01-2023','1970-01-01','236','0','0','0','100','80','0','63.64','0','16.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:25',NULL),(489,'243',NULL,NULL,'302','1690036029766','null','1970-01-01','236','0','2','2','130','104','0','82.73','0','21.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:33',NULL),(490,'243',NULL,NULL,'303','1672656016837','02-01-2023','1970-01-01','237','0','0','0','85','68','0','54.09','0','13.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:40',NULL),(491,'243',NULL,NULL,'303','1690036085917','null','1970-01-01','237','0','97','97','110','88','0','70','0','18.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:48',NULL),(492,'243',NULL,NULL,'304','1672656017071','02-01-2023','1970-01-01','238','0','0','0','30','25','0','18','0','7.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:15:59',NULL),(493,'243',NULL,NULL,'305','1672656017161','02-01-2023','1970-01-01','239','0','0','0','180','144','0','114.55','0','29.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:16:07',NULL),(494,'243',NULL,NULL,'305','1700134426768','null','1970-01-01','239','0','0','0','260','208','0','165.46','0','42.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:16:14',NULL),(495,'243',NULL,NULL,'306','1672656019106','02-01-2023','1970-01-01','240','0','0','0','180','128.57','0','105.73','0','22.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:16:23',NULL),(496,'243',NULL,NULL,'306','1686903823076','null','1970-01-01','240','0','0','0','160','114.28','0','93.98','0','20.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-06 11:16:31',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=497 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int(11) DEFAULT 0,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int(11) DEFAULT 0,
  `M_ROUND_OFF` int(11) DEFAULT 0,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int(11) NOT NULL,
  `LITE_ID` varchar(50) DEFAULT '',
  `WEB_ID` varchar(50) DEFAULT '',
  `PROD_ID` int(11) NOT NULL,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` varchar(50) DEFAULT NULL,
  `PUR_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT` varchar(25) DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) DEFAULT '0',
  `PUR_CESS` varchar(25) DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) DEFAULT '0',
  `PACK` varchar(25) DEFAULT '0',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(25) DEFAULT '0',
  `DISC_PERCENT` varchar(25) DEFAULT '0',
  `DISC_AMOUNT` varchar(25) DEFAULT '0',
  `RETURN_QTY` varchar(25) DEFAULT '0',
  `FREE` varchar(25) DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) DEFAULT '0',
  `AMT` varchar(25) DEFAULT '0',
  `TAX_AMT` varchar(25) DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) DEFAULT '0',
  `RETURN` varchar(25) DEFAULT '0',
  `SR_NO` varchar(50) DEFAULT '',
  `CESS_AMT` varchar(25) DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) DEFAULT '0',
  `UI_DISP_BAG` varchar(50) DEFAULT '',
  `WEIGHT` varchar(25) DEFAULT '0',
  `PRICE_PER` varchar(25) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT NULL,
  `TE_RATE` varchar(25) DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) DEFAULT '0',
  `MRP` varchar(25) DEFAULT '0',
  `DAMAGE` varchar(25) DEFAULT '0',
  `DAMAGE_AMT` varchar(25) DEFAULT '0',
  `REPLACE` varchar(25) DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) DEFAULT '0',
  `DMG_MRP` varchar(25) DEFAULT '0',
  `PUR_INSURANCE` varchar(25) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) DEFAULT '0',
  `CLOUD_SYNC` varchar(25) DEFAULT '0',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT current_timestamp(),
  `UPDATED_TS` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `FINAL_AMT` varchar(25) DEFAULT '0',
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `TCS_TAX` varchar(100) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT 0,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `BROKER_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `PUR_ID` int(11) DEFAULT 0,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=392 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (391,'243','0','emyPCHWV2p','temptemp','emyPCHWV2p','temptemp@yopmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','','391','391','',0,'2026-05-06 10:44:32','2026-05-06 10:44:32');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REMARKS` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int(11) DEFAULT 0,
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-05-06 10:44:27',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text DEFAULT NULL,
  `MAC_ID` int(11) DEFAULT 0,
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text DEFAULT NULL,
  `S_ADD2` text DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int(11) DEFAULT 0,
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'243',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(2,'243',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(3,'243',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(4,'243',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(5,'243',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(6,'243',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(7,'243',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(8,'243',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(9,'243',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(10,'243',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(11,'243',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(12,'243',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(13,'243',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(14,'243',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(15,'243',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(16,'243',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(17,'243',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(18,'243',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(19,'243',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(20,'243',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(21,'243',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(22,'243',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(23,'243',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(24,'243',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(25,'243',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(26,'243',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(27,'243',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(28,'243',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(29,'243',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(30,'243',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(31,'243',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(32,'243',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(33,'243',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(34,'243',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(35,'243',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(36,'243',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(37,'243',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(38,'243',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(39,'243',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(40,'243',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(41,'243',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(42,'243',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(43,'243',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(44,'243',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(45,'243',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(46,'243',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(47,'243',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(48,'243',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(49,'243',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(50,'243',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(51,'243',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(52,'243',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(53,'243',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(54,'243',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(55,'243',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(56,'243',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(57,'243',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(58,'243',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(59,'243',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(60,'243',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(61,'243',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(62,'243',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(63,'243',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(64,'243',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(65,'243',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(66,'243',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(67,'243',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(68,'243',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(69,'243',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(70,'243',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(71,'243',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(72,'243',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(73,'243',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(74,'243',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(75,'243',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(76,'243',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(77,'243',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(78,'243',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(79,'243',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(80,'243',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(81,'243',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(82,'243',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(83,'243',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(84,'243',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(85,'243',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(86,'243',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(87,'243',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(88,'243',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(89,'243',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(90,'243',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(91,'243',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(92,'243',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(93,'243',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(94,'243',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(95,'243',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(96,'243',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(97,'243',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29'),(98,'243',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-06 10:44:29','2026-05-06 10:44:29');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int(11) NOT NULL DEFAULT 0,
  `ADDRESS1` text DEFAULT NULL,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int(11) DEFAULT 0,
  `PG_ID` int(11) DEFAULT 0,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` int(11) DEFAULT 0,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `INV_ARR` text DEFAULT NULL,
  `INV_NO` text DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT NULL,
  `LITE_ID` varchar(50) DEFAULT NULL,
  `WEB_ID` varchar(50) DEFAULT NULL,
  `PROD_ID` varchar(20) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) DEFAULT NULL,
  `SALES_ID` varchar(20) DEFAULT NULL,
  `SALE_UNIT` varchar(20) DEFAULT NULL,
  `SALE_RATE` varchar(20) DEFAULT NULL,
  `PUR_RATE` varchar(20) DEFAULT NULL,
  `PROD_PACK` varchar(20) DEFAULT NULL,
  `PUR_VAT` varchar(20) DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_VAT` varchar(20) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) DEFAULT NULL,
  `SALES_CESS` varchar(20) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) DEFAULT NULL,
  `PACK` varchar(20) DEFAULT NULL,
  `BOX` varchar(20) DEFAULT NULL,
  `QTY` varchar(20) DEFAULT NULL,
  `DISC_PERCENT` varchar(20) DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) DEFAULT NULL,
  `RETURN_QTY` varchar(20) DEFAULT NULL,
  `FREE` varchar(20) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) DEFAULT NULL,
  `AMT` varchar(20) DEFAULT NULL,
  `PUR_AMT` varchar(20) DEFAULT NULL,
  `PROFIT` varchar(20) DEFAULT NULL,
  `TAX_AMT` varchar(20) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) DEFAULT NULL,
  `DAMAGE` varchar(20) DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) DEFAULT NULL,
  `REPLACE` varchar(25) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) DEFAULT NULL,
  `RETURN` varchar(25) DEFAULT NULL,
  `SR_NO` varchar(50) DEFAULT NULL,
  `CESS_AMT` varchar(20) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) DEFAULT NULL,
  `WEIGHT` varchar(20) DEFAULT NULL,
  `PUR_UNIT` varchar(20) DEFAULT NULL,
  `PRICE_PER` varchar(20) DEFAULT NULL,
  `TE_RATE` varchar(20) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) DEFAULT NULL,
  `DMG_MRP` varchar(20) DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) DEFAULT NULL,
  `INV_ARR` varchar(255) DEFAULT NULL,
  `INV_NO` varchar(100) DEFAULT NULL,
  `CREATED_BY` varchar(20) DEFAULT NULL,
  `UPDATED_BY` varchar(20) DEFAULT NULL,
  `SECURITY_KEY` varchar(100) DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(20) DEFAULT NULL,
  `SALES_MAN` varchar(100) DEFAULT NULL,
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(20) DEFAULT NULL,
  `PARTY_CODE` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(20) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) DEFAULT NULL,
  `BATCH_NO` varchar(50) DEFAULT NULL,
  `MFG_DATE` varchar(20) DEFAULT NULL,
  `EXP_DATE` varchar(20) DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int(11) DEFAULT 0,
  `AREA` int(11) DEFAULT 0,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int(11) DEFAULT 0,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int(11) DEFAULT 0,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint(4) NOT NULL DEFAULT 0,
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int(11) DEFAULT 0,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int(11) DEFAULT 0,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int(11) DEFAULT 0,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int(11) DEFAULT 0,
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int(11) DEFAULT 0,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int(11) DEFAULT 0,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int(11) DEFAULT 0,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int(11) NOT NULL DEFAULT 0,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int(11) DEFAULT 0,
  `PROD_BATCH_ID` int(11) DEFAULT 0,
  `SALES_ID` int(11) DEFAULT 0,
  `SALE_UNIT` int(11) DEFAULT 0,
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROD_PACK` int(11) NOT NULL DEFAULT 0,
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int(11) DEFAULT 0,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int(11) DEFAULT 0,
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `PROFIT` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int(11) DEFAULT 0,
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int(11) DEFAULT 0,
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int(11) DEFAULT 0,
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int(11) DEFAULT 0,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int(11) DEFAULT 0,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int(11) DEFAULT 0,
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SMAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYNC` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text DEFAULT NULL,
  `UPDATED_VALUE` text DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text DEFAULT NULL,
  `DIACM` text DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int(11) DEFAULT 0,
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int(11) DEFAULT 0,
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-05-06 10:44:27','2026-05-06 10:44:27');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNIT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UOM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT 0,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VAN` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WEB_ID` int(11) NOT NULL DEFAULT 0,
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int(11) DEFAULT 0,
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-05-06 10:44:32');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-23 11:02:21
