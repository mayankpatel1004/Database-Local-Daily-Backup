-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u797036281_cloudswiftsol
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT 'activities',
  `status_action` varchar(25) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `record_id` int(11) NOT NULL DEFAULT 0,
  `record_name` varchar(255) DEFAULT NULL,
  `record_column` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `note1` varchar(255) DEFAULT NULL,
  `note2` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`activity_id`),
  KEY `idx_record_id` (`record_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_passbook`
--

DROP TABLE IF EXISTS `bank_passbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_passbook` (
  `bank_passbook_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `transaction_ref` varchar(255) DEFAULT NULL,
  `transaction_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `debit_credit` enum('DEBIT','CREDIT') DEFAULT NULL,
  `current_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_holder` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`bank_passbook_id`),
  KEY `idx_transaction_date` (`transaction_date`),
  KEY `idx_bank_name` (`bank_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_passbook`
--

LOCK TABLES `bank_passbook` WRITE;
/*!40000 ALTER TABLE `bank_passbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_passbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cart_id_pk` int(11) DEFAULT 0,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `customer_pin` int(11) NOT NULL DEFAULT 0,
  `pos_customer` enum('Y','N') NOT NULL DEFAULT 'N',
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `guest_customer` enum('1','0') NOT NULL DEFAULT '0' COMMENT '1=registration during guest order',
  `access_token` varchar(255) DEFAULT NULL,
  `security_question_id` int(11) NOT NULL DEFAULT 0,
  `security_answer` varchar(191) DEFAULT NULL,
  `user_address1` varchar(191) DEFAULT NULL,
  `user_address2` varchar(191) DEFAULT NULL,
  `user_city` varchar(191) DEFAULT NULL,
  `user_state` varchar(191) DEFAULT NULL,
  `user_zipcode` varchar(191) DEFAULT NULL,
  `user_country` varchar(191) DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `display_on_listing` enum('Y','N') NOT NULL DEFAULT 'Y',
  `show_action_checkbox` enum('Y','N') NOT NULL DEFAULT 'Y',
  `web_token` varchar(255) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `item_type` varchar(25) NOT NULL DEFAULT 'users',
  `wallet_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `blocked` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_cart`
--

DROP TABLE IF EXISTS `ec_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_cart` (
  `cart_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `cart_sub_id` int(11) NOT NULL DEFAULT 0,
  `session_id` varchar(255) DEFAULT NULL,
  `is_customer` enum('Y','N') NOT NULL DEFAULT 'N',
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `birth_date` varchar(255) DEFAULT NULL,
  `order_status` varchar(255) DEFAULT NULL,
  `billing_first_name` varchar(255) DEFAULT NULL,
  `billing_last_name` varchar(255) DEFAULT NULL,
  `billing_address_1` varchar(255) DEFAULT NULL,
  `billing_address_2` varchar(255) DEFAULT NULL,
  `billing_city` varchar(255) DEFAULT NULL,
  `billing_state_id` int(11) NOT NULL DEFAULT 0,
  `billing_state` varchar(255) DEFAULT NULL,
  `billing_country_id` int(11) NOT NULL DEFAULT 0,
  `billing_country` varchar(255) DEFAULT NULL,
  `billing_zipcode` varchar(255) DEFAULT NULL,
  `billing_contact` varchar(255) DEFAULT NULL,
  `billing_email` varchar(255) DEFAULT NULL,
  `shipping_first_name` varchar(255) DEFAULT NULL,
  `shipping_last_name` varchar(255) DEFAULT NULL,
  `shipping_address_1` varchar(255) DEFAULT NULL,
  `shipping_address_2` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(255) DEFAULT NULL,
  `shipping_state_id` int(11) NOT NULL DEFAULT 0,
  `shipping_state` varchar(255) DEFAULT NULL,
  `shipping_country` varchar(255) DEFAULT NULL,
  `shipping_country_id` int(11) NOT NULL DEFAULT 0,
  `shipping_zipcode` varchar(255) DEFAULT NULL,
  `shipping_contact` varchar(255) DEFAULT NULL,
  `shipping_email` varchar(255) DEFAULT NULL,
  `coupon_code` varchar(255) DEFAULT NULL,
  `coupon_type` varchar(255) DEFAULT NULL,
  `item_coupon_type` varchar(255) DEFAULT NULL,
  `currancy` varchar(10) DEFAULT NULL,
  `cashback_amount_applied` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_amount_applied` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cashback_wallet_amount_used` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_ordered_quantity` int(11) NOT NULL DEFAULT 0,
  `total_items_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_items_tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_items_shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_pos_order` enum('Y','N') NOT NULL DEFAULT 'N',
  `payment_type` varchar(255) DEFAULT NULL,
  `shipping_type` varchar(255) DEFAULT NULL,
  `shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_notes` text DEFAULT NULL,
  `device` varchar(255) DEFAULT '1.0',
  `device_id` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `browser_name` varchar(255) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `browser_version` varchar(100) DEFAULT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `browser_pattern` varchar(255) DEFAULT NULL,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expire_at` datetime DEFAULT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_cart`
--

LOCK TABLES `ec_cart` WRITE;
/*!40000 ALTER TABLE `ec_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_cart_product`
--

DROP TABLE IF EXISTS `ec_cart_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_cart_product` (
  `cart_product_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL DEFAULT 0,
  `cart_sub_id` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `item_name` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_code` varchar(255) DEFAULT NULL,
  `ordered_quantity` int(11) NOT NULL DEFAULT 0,
  `product_attribute_1` varchar(255) DEFAULT NULL,
  `product_attribute_2` varchar(255) DEFAULT NULL,
  `product_attribute_3` varchar(255) DEFAULT NULL,
  `product_option_1` varchar(255) DEFAULT NULL,
  `product_option_2` varchar(255) DEFAULT NULL,
  `product_option_3` varchar(255) DEFAULT NULL,
  `product_option_4` varchar(255) DEFAULT NULL,
  `product_option_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `product_option_price_display` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(255) DEFAULT NULL,
  `is_taxable` enum('Y','N') NOT NULL DEFAULT 'Y',
  `item_tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_default_price` enum('Y','N') NOT NULL DEFAULT 'Y',
  `product_quantity` int(11) NOT NULL DEFAULT 0,
  `special_price_from_date` date DEFAULT NULL,
  `special_price_to_date` date DEFAULT NULL,
  `item_price_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_tax_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `final_item_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cart_product_id`),
  KEY `idx_cart_id` (`cart_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_cart_product`
--

LOCK TABLES `ec_cart_product` WRITE;
/*!40000 ALTER TABLE `ec_cart_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_cart_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_cashback_credit_transaction`
--

DROP TABLE IF EXISTS `ec_cashback_credit_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_cashback_credit_transaction` (
  `cashbackcredit_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `order_id` int(11) DEFAULT 0,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `cashback_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cashbackcredit_transaction_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_cashback_credit_transaction`
--

LOCK TABLES `ec_cashback_credit_transaction` WRITE;
/*!40000 ALTER TABLE `ec_cashback_credit_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_cashback_credit_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_cashback_transaction`
--

DROP TABLE IF EXISTS `ec_cashback_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_cashback_transaction` (
  `cashback_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `currency` varchar(10) DEFAULT NULL,
  `cashback_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `transaction_id` varchar(255) DEFAULT NULL,
  `coupon_code` varchar(255) DEFAULT NULL,
  `coupon_type` varchar(255) DEFAULT NULL,
  `item_coupon_type` varchar(255) DEFAULT NULL,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cashback_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_cashback_transaction`
--

LOCK TABLES `ec_cashback_transaction` WRITE;
/*!40000 ALTER TABLE `ec_cashback_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_cashback_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_closeday`
--

DROP TABLE IF EXISTS `ec_closeday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_closeday` (
  `closeday_id` int(11) NOT NULL AUTO_INCREMENT,
  `opening_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `closing_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `closing_time` datetime DEFAULT NULL,
  `closed_by` int(11) DEFAULT NULL,
  `closed_by_name` varchar(255) DEFAULT NULL,
  `closing_notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`closeday_id`),
  KEY `idx_closed_by` (`closed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_closeday`
--

LOCK TABLES `ec_closeday` WRITE;
/*!40000 ALTER TABLE `ec_closeday` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_closeday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_coupon`
--

DROP TABLE IF EXISTS `ec_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_coupon` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(255) DEFAULT 'discount',
  `coupon_code_type` varchar(255) NOT NULL DEFAULT 'alluser',
  `specific_user_id` int(11) NOT NULL DEFAULT 0,
  `coupon_title` varchar(255) DEFAULT NULL,
  `coupon_alias` varchar(255) DEFAULT NULL,
  `coupon_description` text DEFAULT NULL,
  `coupon_terms_conditions` text DEFAULT NULL,
  `order_calculation_required` enum('Y','N') NOT NULL DEFAULT 'N',
  `minimum_order_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_item_type` varchar(255) DEFAULT 'discount',
  `coupon_item_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_code` varchar(255) DEFAULT NULL,
  `amount_type` varchar(255) DEFAULT 'Fixed',
  `currency` varchar(20) DEFAULT '$',
  `coupon_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_amount_maximum` decimal(10,2) NOT NULL DEFAULT 0.00,
  `user_per_customer` int(11) DEFAULT 1,
  `created_user_id` int(11) NOT NULL DEFAULT 0,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `site_id` tinyint(4) DEFAULT NULL,
  `item_type_alias` varchar(255) DEFAULT NULL,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_user_id` int(11) DEFAULT NULL,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`coupon_id`),
  UNIQUE KEY `coupon_code` (`coupon_code`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_start_date` (`start_date`),
  KEY `idx_end_date` (`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_coupon`
--

LOCK TABLES `ec_coupon` WRITE;
/*!40000 ALTER TABLE `ec_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_order`
--

DROP TABLE IF EXISTS `ec_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_order` (
  `order_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `order_id_unique` varchar(255) DEFAULT NULL,
  `cart_id` int(11) NOT NULL DEFAULT 0,
  `cart_customer_id` varchar(255) DEFAULT NULL,
  `cart_sub_id` int(11) NOT NULL DEFAULT 0,
  `session_id` varchar(255) DEFAULT NULL,
  `is_customer` enum('Y','N') NOT NULL DEFAULT 'N',
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `order_status` varchar(255) DEFAULT NULL,
  `cancelled_by` int(11) DEFAULT NULL,
  `cancelled_by_name` varchar(255) DEFAULT NULL,
  `cancelled_reason` varchar(255) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `billing_first_name` varchar(255) DEFAULT NULL,
  `billing_last_name` varchar(255) DEFAULT NULL,
  `billing_address_1` varchar(255) DEFAULT NULL,
  `billing_address_2` varchar(255) DEFAULT NULL,
  `billing_city` varchar(255) DEFAULT NULL,
  `billing_state_id` int(11) NOT NULL DEFAULT 0,
  `billing_state` varchar(255) DEFAULT NULL,
  `billing_country_id` int(11) NOT NULL DEFAULT 0,
  `billing_country` varchar(255) DEFAULT NULL,
  `billing_zipcode` varchar(255) DEFAULT NULL,
  `billing_contact` varchar(255) DEFAULT NULL,
  `billing_email` varchar(255) DEFAULT NULL,
  `shipping_first_name` varchar(255) DEFAULT NULL,
  `shipping_last_name` varchar(255) DEFAULT NULL,
  `shipping_address_1` varchar(255) DEFAULT NULL,
  `shipping_address_2` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(255) DEFAULT NULL,
  `shipping_state_id` int(11) NOT NULL DEFAULT 0,
  `shipping_state` varchar(255) DEFAULT NULL,
  `shipping_country` varchar(255) DEFAULT NULL,
  `shipping_country_id` int(11) NOT NULL DEFAULT 0,
  `shipping_zipcode` varchar(255) DEFAULT NULL,
  `shipping_contact` varchar(255) DEFAULT NULL,
  `shipping_email` varchar(255) DEFAULT NULL,
  `coupon_code` varchar(255) DEFAULT NULL,
  `coupon_type` varchar(255) DEFAULT NULL,
  `item_coupon_type` varchar(255) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `cashback_amount_applied` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_amount_applied` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cashback_wallet_amount_used` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_ordered_quantity` int(11) NOT NULL DEFAULT 0,
  `total_items_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_items_tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_items_shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_pos_order` enum('Y','N') NOT NULL DEFAULT 'N',
  `payment_type` varchar(255) DEFAULT NULL,
  `shipping_type` varchar(255) DEFAULT NULL,
  `shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_notes` text DEFAULT NULL,
  `device` varchar(255) DEFAULT '1.0',
  `device_id` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `browser_name` varchar(255) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `browser_version` varchar(100) DEFAULT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `browser_pattern` varchar(255) DEFAULT NULL,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `sync_to_live` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expire_at` datetime DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `cashback_credited` enum('Y','N') NOT NULL DEFAULT 'N',
  `cashback_credited_user_id` int(11) NOT NULL DEFAULT 0,
  `cashback_credited_date` datetime DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_id_unique` (`order_id_unique`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_order_status` (`order_status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_payment_status` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_order`
--

LOCK TABLES `ec_order` WRITE;
/*!40000 ALTER TABLE `ec_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_order_payment_details`
--

DROP TABLE IF EXISTS `ec_order_payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_order_payment_details` (
  `order_payment_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `order_status` varchar(255) DEFAULT NULL,
  `order_key` varchar(255) DEFAULT NULL,
  `order_value` text DEFAULT NULL,
  `payment_gateway_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`order_payment_details_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_order_payment_details`
--

LOCK TABLES `ec_order_payment_details` WRITE;
/*!40000 ALTER TABLE `ec_order_payment_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_order_payment_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_order_products`
--

DROP TABLE IF EXISTS `ec_order_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_order_products` (
  `order_product_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL DEFAULT 0,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `order_status` varchar(255) DEFAULT NULL,
  `cart_sub_id` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `item_name` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_code` varchar(255) DEFAULT NULL,
  `ordered_quantity` int(11) NOT NULL DEFAULT 0,
  `product_attribute_1` varchar(255) DEFAULT NULL,
  `product_attribute_2` varchar(255) DEFAULT NULL,
  `product_attribute_3` varchar(255) DEFAULT NULL,
  `product_option_1` varchar(255) DEFAULT NULL,
  `product_option_2` varchar(255) DEFAULT NULL,
  `product_option_3` varchar(255) DEFAULT NULL,
  `product_option_4` varchar(255) DEFAULT NULL,
  `product_option_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `product_option_price_display` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(255) DEFAULT NULL,
  `is_taxable` enum('Y','N') NOT NULL DEFAULT 'Y',
  `item_tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_default_price` enum('Y','N') NOT NULL DEFAULT 'Y',
  `item_price_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_tax_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `final_item_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `review_added` enum('Y','N') NOT NULL DEFAULT 'N',
  `review_request_counter` tinyint(4) NOT NULL DEFAULT 0,
  `request_exchange_refund` enum('Y','N') NOT NULL DEFAULT 'N',
  `exchange_refund_type` varchar(255) DEFAULT NULL COMMENT 'Refund or Exchange',
  `request_exchange_refund_approved` enum('Y','N') NOT NULL DEFAULT 'N',
  `request_exchange_refund_approved_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`order_product_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_product_price_id` (`product_price_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_order_products`
--

LOCK TABLES `ec_order_products` WRITE;
/*!40000 ALTER TABLE `ec_order_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_order_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_order_products_return`
--

DROP TABLE IF EXISTS `ec_order_products_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_order_products_return` (
  `products_return_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_final_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `order_status` varchar(255) DEFAULT NULL,
  `order_product_id` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_contact` varchar(255) DEFAULT NULL,
  `exchange_refund` varchar(255) DEFAULT NULL,
  `exchange_refund_reason` varchar(255) DEFAULT NULL,
  `exchange_refund_description` text DEFAULT NULL,
  `admin_approved` enum('Y','N') NOT NULL DEFAULT 'N',
  `admin_notes` text DEFAULT NULL,
  `admin_approve_date` datetime DEFAULT NULL,
  `photo_1` varchar(255) DEFAULT NULL,
  `photo_2` varchar(255) DEFAULT NULL,
  `photo_3` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`products_return_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_order_products_return`
--

LOCK TABLES `ec_order_products_return` WRITE;
/*!40000 ALTER TABLE `ec_order_products_return` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_order_products_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_order_products_return_logs`
--

DROP TABLE IF EXISTS `ec_order_products_return_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_order_products_return_logs` (
  `products_return_id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_refund_primary_key` int(11) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_final_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `order_status` varchar(255) DEFAULT NULL,
  `order_product_id` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_contact` varchar(255) DEFAULT NULL,
  `exchange_refund` varchar(255) DEFAULT NULL,
  `exchange_refund_reason` varchar(255) DEFAULT NULL,
  `exchange_refund_description` text DEFAULT NULL,
  `admin_approved` enum('Y','N') NOT NULL DEFAULT 'N',
  `admin_notes` text DEFAULT NULL,
  `admin_approve_date` datetime DEFAULT NULL,
  `photo_1` varchar(255) DEFAULT NULL,
  `photo_2` varchar(255) DEFAULT NULL,
  `photo_3` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`products_return_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_order_products_return_logs`
--

LOCK TABLES `ec_order_products_return_logs` WRITE;
/*!40000 ALTER TABLE `ec_order_products_return_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_order_products_return_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_order_status`
--

DROP TABLE IF EXISTS `ec_order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_order_status` (
  `order_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_status` varchar(255) DEFAULT NULL COMMENT 'current_original_order_status',
  `updated_status` varchar(255) DEFAULT NULL,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `updated_by_name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`order_status_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_updated_status` (`updated_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_order_status`
--

LOCK TABLES `ec_order_status` WRITE;
/*!40000 ALTER TABLE `ec_order_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_order_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_product_price`
--

DROP TABLE IF EXISTS `ec_product_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_product_price` (
  `product_price_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `product_attribute_1` varchar(255) DEFAULT NULL,
  `product_attribute_2` varchar(255) DEFAULT NULL,
  `product_attribute_3` varchar(255) DEFAULT NULL,
  `product_option_1` varchar(255) DEFAULT NULL,
  `product_option_2` varchar(255) DEFAULT NULL,
  `product_option_3` varchar(255) DEFAULT NULL,
  `product_option_4` int(11) NOT NULL DEFAULT 0,
  `product_option_price` decimal(10,2) DEFAULT NULL,
  `product_option_price_display` decimal(10,2) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `item_tax_amount` decimal(10,2) DEFAULT 0.00,
  `min_quantity_notification` tinyint(4) NOT NULL DEFAULT 0,
  `item_shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_default_price` enum('Y','N') NOT NULL DEFAULT 'N',
  `product_quantity` int(11) NOT NULL DEFAULT 0,
  `special_price_from_date` date DEFAULT NULL,
  `special_price_to_date` date DEFAULT NULL,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_price_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_product_price`
--

LOCK TABLES `ec_product_price` WRITE;
/*!40000 ALTER TABLE `ec_product_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_product_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_product_price_log`
--

DROP TABLE IF EXISTS `ec_product_price_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_product_price_log` (
  `product_price_log_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `product_option_price` decimal(10,2) DEFAULT NULL,
  `product_option_price_old` decimal(10,2) NOT NULL DEFAULT 0.00,
  `product_option_price_display` decimal(10,2) DEFAULT NULL,
  `product_option_price_display_old` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_tax_amount` decimal(10,2) DEFAULT 0.00,
  `item_tax_amount_old` int(11) NOT NULL DEFAULT 0,
  `item_shipping_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_shipping_amount_old` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_default_price` enum('Y','N') NOT NULL DEFAULT 'N',
  `product_quantity` int(11) NOT NULL DEFAULT 0,
  `product_quantity_old` int(11) NOT NULL DEFAULT 0,
  `login_id` int(11) NOT NULL DEFAULT 0,
  `login_name` varchar(255) DEFAULT NULL,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`product_price_log_id`),
  KEY `idx_product_price_id` (`product_price_id`),
  KEY `idx_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_product_price_log`
--

LOCK TABLES `ec_product_price_log` WRITE;
/*!40000 ALTER TABLE `ec_product_price_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_product_price_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_product_reviews`
--

DROP TABLE IF EXISTS `ec_product_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_product_reviews` (
  `product_review_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_alias` varchar(255) DEFAULT NULL,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `ratings` decimal(10,2) NOT NULL DEFAULT 0.00,
  `review_text` text DEFAULT NULL,
  `display_status` enum('Y','N','P') NOT NULL DEFAULT 'P',
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `deleted_date` date DEFAULT NULL,
  `deleted_user_id` int(11) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_review_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_product_reviews`
--

LOCK TABLES `ec_product_reviews` WRITE;
/*!40000 ALTER TABLE `ec_product_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_product_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_product_specifications`
--

DROP TABLE IF EXISTS `ec_product_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_product_specifications` (
  `product_specification_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_alias` varchar(255) DEFAULT NULL,
  `specification_title` varchar(255) DEFAULT NULL,
  `specification_value` varchar(255) DEFAULT NULL,
  `specification_type` varchar(255) DEFAULT NULL,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_specification_id`),
  KEY `idx_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_product_specifications`
--

LOCK TABLES `ec_product_specifications` WRITE;
/*!40000 ALTER TABLE `ec_product_specifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_product_specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_products`
--

DROP TABLE IF EXISTS `ec_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_products` (
  `item_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `pos_user` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_code` varchar(255) DEFAULT NULL,
  `parent_item_id` int(11) NOT NULL DEFAULT 0,
  `item_type_alias` varchar(255) DEFAULT NULL,
  `item_section_alias` varchar(255) DEFAULT NULL,
  `item_category_alias` varchar(255) DEFAULT NULL,
  `item_tags_alias` varchar(255) DEFAULT NULL,
  `item_format_alias` varchar(255) DEFAULT NULL,
  `item_template_name` varchar(255) DEFAULT NULL,
  `item_weight` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_download_product` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_free_product` enum('Y','N') NOT NULL DEFAULT 'N',
  `in_stock` enum('Y','N') NOT NULL DEFAULT 'Y',
  `currency` varchar(20) DEFAULT NULL,
  `item_shipping_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `item_description` text DEFAULT NULL,
  `item_short_description` varchar(1024) DEFAULT NULL,
  `item_terms_conditions` varchar(1024) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `publish_end_date` date DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  `file2` varchar(255) DEFAULT NULL,
  `file3` varchar(255) DEFAULT NULL,
  `total_visit` int(11) DEFAULT 0,
  `internal_link` varchar(255) DEFAULT NULL,
  `external_link` varchar(255) DEFAULT NULL,
  `is_featured` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_home` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT 'Home Recommands',
  `is_sidebar` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_returnable` enum('Y','N') NOT NULL DEFAULT 'Y',
  `top_ranked` enum('Y','N') NOT NULL DEFAULT 'N',
  `highest_rated` enum('Y','N') NOT NULL DEFAULT 'N',
  `most_viewed` enum('Y','N') NOT NULL DEFAULT 'N',
  `related_products` varchar(255) DEFAULT NULL,
  `total_sold` int(11) NOT NULL DEFAULT 0,
  `is_taxable` enum('Y','N') NOT NULL DEFAULT 'N',
  `pos_online` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1=pos,2=online,0=both',
  `item_css_class` varchar(255) DEFAULT NULL,
  `display_on_sitemap` enum('Y','N') NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `site_id` int(11) NOT NULL DEFAULT 0,
  `deleted_user_id` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_reviews` int(11) NOT NULL DEFAULT 0,
  `avg_ratings` decimal(10,2) NOT NULL DEFAULT 0.00,
  `has_options` enum('Y','N') NOT NULL DEFAULT 'N',
  `total_visitors` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_alias` (`item_alias`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_item_type_alias` (`item_type_alias`),
  KEY `idx_item_code` (`item_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_products`
--

LOCK TABLES `ec_products` WRITE;
/*!40000 ALTER TABLE `ec_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_search_terms`
--

DROP TABLE IF EXISTS `ec_search_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_search_terms` (
  `search_terms_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) DEFAULT NULL,
  `search_count` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`search_terms_id`),
  UNIQUE KEY `keyword` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_search_terms`
--

LOCK TABLES `ec_search_terms` WRITE;
/*!40000 ALTER TABLE `ec_search_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_search_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_search_terms_logs`
--

DROP TABLE IF EXISTS `ec_search_terms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_search_terms_logs` (
  `search_terms_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) DEFAULT NULL,
  `search_count` int(11) NOT NULL DEFAULT 0,
  `is_web` enum('N','Y') NOT NULL DEFAULT 'N',
  `ip_address` varchar(45) DEFAULT NULL,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `browser` varchar(1024) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`search_terms_id`),
  KEY `idx_keyword` (`keyword`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_search_terms_logs`
--

LOCK TABLES `ec_search_terms_logs` WRITE;
/*!40000 ALTER TABLE `ec_search_terms_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_search_terms_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec_wishlist`
--

DROP TABLE IF EXISTS `ec_wishlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec_wishlist` (
  `wishlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `site_id` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`wishlist_id`),
  UNIQUE KEY `customer_item_unique` (`customer_id`,`item_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec_wishlist`
--

LOCK TABLES `ec_wishlist` WRITE;
/*!40000 ALTER TABLE `ec_wishlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `ec_wishlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_sending_logs`
--

DROP TABLE IF EXISTS `email_sending_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_sending_logs` (
  `email_sending_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_to` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'allemails',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`email_sending_log_id`),
  KEY `idx_email_to` (`email_to`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_sending_logs`
--

LOCK TABLES `email_sending_logs` WRITE;
/*!40000 ALTER TABLE `email_sending_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_sending_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `forms_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(255) DEFAULT 'contact',
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `file1` varchar(255) DEFAULT NULL,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N','P') NOT NULL DEFAULT 'P',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`forms_id`),
  KEY `idx_email_address` (`email_address`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `get_token`
--

DROP TABLE IF EXISTS `get_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `get_token` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `generated_token` varchar(1024) DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `device_brand` varchar(255) DEFAULT NULL,
  `app_version` varchar(25) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`token_id`),
  UNIQUE KEY `generated_token` (`generated_token`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `get_token`
--

LOCK TABLES `get_token` WRITE;
/*!40000 ALTER TABLE `get_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `get_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_date` date NOT NULL,
  `holiday_name` varchar(255) DEFAULT NULL,
  `holiday_description` text DEFAULT NULL,
  `holiday_religion` enum('H','M','C','O') DEFAULT 'C' COMMENT 'H-M-C = Hindu,Muslim,Christian',
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`holiday_id`),
  UNIQUE KEY `holiday_date` (`holiday_date`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday`
--

LOCK TABLES `holiday` WRITE;
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_dispatched`
--

DROP TABLE IF EXISTS `inv_dispatched`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inv_dispatched` (
  `dispatched_id` int(11) NOT NULL AUTO_INCREMENT,
  `inventory_id` int(11) NOT NULL,
  `item_size` int(11) NOT NULL,
  `total_items` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_partial` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_unit` varchar(255) DEFAULT NULL,
  `taken_by` int(11) NOT NULL DEFAULT 0,
  `taken_by_name` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`dispatched_id`),
  KEY `idx_inventory_id` (`inventory_id`),
  KEY `idx_taken_by` (`taken_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_dispatched`
--

LOCK TABLES `inv_dispatched` WRITE;
/*!40000 ALTER TABLE `inv_dispatched` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_dispatched` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_inventories`
--

DROP TABLE IF EXISTS `inv_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inv_inventories` (
  `inventory_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_title` varchar(255) DEFAULT NULL,
  `items_alias` varchar(255) DEFAULT NULL,
  `item_size` int(11) NOT NULL DEFAULT 0 COMMENT 'Size = How much litre,meter,number',
  `total_item_size` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_unit` varchar(255) DEFAULT NULL,
  `total_item` decimal(10,2) NOT NULL DEFAULT 0.00,
  `overall_item_total` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'When same item arrive multiple times',
  `item_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_price_with_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_partial` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_description` text DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `bill_picture` varchar(255) DEFAULT NULL,
  `po_number` varchar(255) DEFAULT NULL,
  `gst_number` varchar(255) DEFAULT NULL,
  `is_consumable` enum('Y','N') NOT NULL DEFAULT 'N',
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`inventory_id`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_item_title` (`item_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_inventories`
--

LOCK TABLES `inv_inventories` WRITE;
/*!40000 ALTER TABLE `inv_inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_inventories_activities`
--

DROP TABLE IF EXISTS `inv_inventories_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inv_inventories_activities` (
  `inventories_activities_id` int(11) NOT NULL AUTO_INCREMENT,
  `inventory_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `item_size` int(11) NOT NULL DEFAULT 0 COMMENT 'Size = How much litre,meter,number',
  `total_item_size` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_items` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Total Items added or substract',
  `total_items_before_entry` int(11) NOT NULL DEFAULT 0,
  `total_price_with_qty` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_partial` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_unit` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `po_number` varchar(255) DEFAULT NULL,
  `bill_picture` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `taken_by` int(11) NOT NULL DEFAULT 0,
  `taken_by_name` varchar(255) DEFAULT NULL COMMENT 'Taken By / Return By',
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`inventories_activities_id`),
  KEY `idx_inventory_id` (`inventory_id`),
  KEY `idx_operation` (`operation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_inventories_activities`
--

LOCK TABLES `inv_inventories_activities` WRITE;
/*!40000 ALTER TABLE `inv_inventories_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_inventories_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_comments`
--

DROP TABLE IF EXISTS `item_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_comments` (
  `item_comments_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_alias` varchar(255) NOT NULL,
  `item_title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Items Creator ID',
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `display_status` enum('Y','N','P') NOT NULL DEFAULT 'N' COMMENT 'P=Pending',
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `deleted_date` datetime DEFAULT NULL,
  `deleted_user_id` int(11) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`item_comments_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_comments`
--

LOCK TABLES `item_comments` WRITE;
/*!40000 ALTER TABLE `item_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_logs`
--

DROP TABLE IF EXISTS `item_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_logs` (
  `item_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') DEFAULT 'N',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_log_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_logs`
--

LOCK TABLES `item_logs` WRITE;
/*!40000 ALTER TABLE `item_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_meta`
--

DROP TABLE IF EXISTS `item_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_meta` (
  `item_meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` text DEFAULT NULL,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_meta_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_meta`
--

LOCK TABLES `item_meta` WRITE;
/*!40000 ALTER TABLE `item_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_section`
--

DROP TABLE IF EXISTS `item_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_section` (
  `item_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_section_parent_id` int(11) NOT NULL DEFAULT 0,
  `section_title` varchar(255) DEFAULT NULL,
  `section_alias` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `attachment1` varchar(255) DEFAULT NULL,
  `attachment2` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `display_order` int(11) DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `robots` varchar(50) DEFAULT 'NOINDEX, NOFOLLOW',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `device` varchar(100) DEFAULT NULL,
  `deviceId` varchar(100) DEFAULT NULL,
  `deviceType` varchar(100) DEFAULT NULL,
  `appVersion` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_section_id`),
  KEY `idx_section_alias` (`section_alias`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_section`
--

LOCK TABLES `item_section` WRITE;
/*!40000 ALTER TABLE `item_section` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_parent` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) DEFAULT NULL,
  `item_category` varchar(255) DEFAULT NULL,
  `item_description` longtext DEFAULT NULL,
  `item_shortdescription` text DEFAULT NULL,
  `guest_item` enum('Y','N') NOT NULL DEFAULT 'N',
  `snippets_code` text DEFAULT NULL,
  `meta_title_length` int(100) DEFAULT NULL,
  `meta_description_length` int(200) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `charges` decimal(10,2) DEFAULT NULL,
  `debit_credit` varchar(255) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  `file2` varchar(255) DEFAULT NULL,
  `file3` varchar(255) DEFAULT NULL,
  `external_url` varchar(255) DEFAULT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT 'index',
  `robots` varchar(50) DEFAULT 'NOINDEX, NOFOLLOW',
  `published_at` date DEFAULT NULL,
  `published_end_at` date DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `html_sitemap` enum('Y','N') NOT NULL DEFAULT 'N',
  `html_sitemap_order` int(11) NOT NULL DEFAULT 0,
  `admin_module` enum('Y','N') NOT NULL DEFAULT 'N',
  `custom_view` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `device` varchar(100) DEFAULT NULL,
  `deviceId` varchar(100) DEFAULT NULL,
  `deviceType` varchar(100) DEFAULT NULL,
  `appVersion` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`item_id`),
  KEY `idx_item_type` (`item_type`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_item_alias` (`item_alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `lat` varchar(255) DEFAULT NULL,
  `lng` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `region_name` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `timezone` varchar(255) DEFAULT NULL,
  `frontend_backend` varchar(30) DEFAULT 'backend',
  `platform` varchar(255) DEFAULT NULL,
  `browser_name` varchar(255) DEFAULT NULL,
  `browser_version` varchar(255) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_logs`
--

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `remarks` varchar(1024) DEFAULT NULL,
  `ipaddress` varchar(45) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `country_code` varchar(4) DEFAULT NULL,
  `lat` varchar(30) DEFAULT NULL,
  `lng` varchar(30) DEFAULT NULL,
  `organization` varchar(50) DEFAULT NULL,
  `region` varchar(30) DEFAULT NULL,
  `region_name` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT NULL,
  `useragent` varchar(255) DEFAULT NULL,
  `browsername` varchar(255) DEFAULT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_created_date` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `media_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT 'default',
  `media_extension` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`media_id`),
  KEY `idx_type` (`type`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_report_problem`
--

DROP TABLE IF EXISTS `product_report_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_report_problem` (
  `problem_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_price_id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `item_title` varchar(255) DEFAULT NULL,
  `problem_type` varchar(100) DEFAULT NULL,
  `product_quantity` int(11) NOT NULL DEFAULT 0,
  `reason` text DEFAULT NULL,
  `reduce_product_qty` enum('Y','N','P') NOT NULL DEFAULT 'P',
  `login_id` int(11) NOT NULL DEFAULT 0,
  `login_name` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`problem_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_product_price_id` (`product_price_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_report_problem`
--

LOCK TABLES `product_report_problem` WRITE;
/*!40000 ALTER TABLE `product_report_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_report_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_title` varchar(255) DEFAULT NULL,
  `item_alias` varchar(255) DEFAULT NULL,
  `item_type` varchar(255) NOT NULL DEFAULT 'role',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `display_on_listing` enum('Y','N') NOT NULL DEFAULT 'Y',
  `show_action_checkbox` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_title` (`role_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_access`
--

DROP TABLE IF EXISTS `role_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_access` (
  `role_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT 0,
  `module_id` int(11) DEFAULT 0,
  `grant_add` enum('Y','N') NOT NULL DEFAULT 'N',
  `grant_edit` enum('Y','N') NOT NULL DEFAULT 'N',
  `grant_delete` enum('Y','N') NOT NULL DEFAULT 'N',
  `grant_view` enum('Y','N') NOT NULL DEFAULT 'N',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_access_id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_access`
--

LOCK TABLES `role_access` WRITE;
/*!40000 ALTER TABLE `role_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(5) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `notified` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`),
  KEY `idx_month_year` (`month`,`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_title` varchar(1024) DEFAULT NULL,
  `config_name` varchar(1024) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `input_type` varchar(15) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 100,
  `maxlength` int(11) NOT NULL DEFAULT 100,
  `input_type_title` varchar(100) DEFAULT NULL,
  `class` varchar(100) DEFAULT 'textbox',
  `required` enum('Y','N','O') DEFAULT 'O',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `comments` varchar(255) DEFAULT NULL,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `additional` varchar(100) DEFAULT NULL,
  `display_on_dashboard` enum('Y','N') NOT NULL DEFAULT 'N',
  `display_on_third_party` enum('Y','N') NOT NULL DEFAULT 'N',
  `site_config_parent_id` tinyint(4) NOT NULL DEFAULT 0,
  `site_id` tinyint(4) NOT NULL DEFAULT 0,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `root_user_only` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `config_name` (`config_name`(255)),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config_parent`
--

DROP TABLE IF EXISTS `site_config_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config_parent` (
  `site_config_parent_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_config_title` varchar(191) NOT NULL,
  `display_order` int(11) NOT NULL,
  `display_status` enum('Y','N') NOT NULL,
  `class` varchar(191) NOT NULL,
  `site_id` int(11) NOT NULL,
  `deleted_status` enum('Y','N') NOT NULL,
  `root_user_only` enum('Y','N') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`site_config_parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config_parent`
--

LOCK TABLES `site_config_parent` WRITE;
/*!40000 ALTER TABLE `site_config_parent` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_config_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_request`
--

DROP TABLE IF EXISTS `site_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_request` (
  `site_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `request` longtext DEFAULT NULL,
  `request_url` varchar(1024) DEFAULT NULL,
  `response` longtext DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `comment1` text DEFAULT NULL,
  `comment2` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`site_request_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_request`
--

LOCK TABLES `site_request` WRITE;
/*!40000 ALTER TABLE `site_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriber`
--

DROP TABLE IF EXISTS `subscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriber` (
  `subscriber_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email_address` varchar(255) NOT NULL,
  `item_type` varchar(60) NOT NULL DEFAULT 'newsletter',
  `contact` varchar(20) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `cellphone1` varchar(15) DEFAULT NULL,
  `cellphone2` varchar(15) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `last_email_sent` datetime DEFAULT NULL,
  `unsubscribe` enum('Y','N') NOT NULL DEFAULT 'N',
  `unsubscribe_date` datetime DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`subscriber_id`),
  UNIQUE KEY `email_address` (`email_address`),
  KEY `idx_display_status` (`display_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriber`
--

LOCK TABLES `subscriber` WRITE;
/*!40000 ALTER TABLE `subscriber` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriber_email_logs`
--

DROP TABLE IF EXISTS `subscriber_email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriber_email_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_to` varchar(255) DEFAULT NULL,
  `subject` varchar(1024) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_to` (`email_to`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriber_email_logs`
--

LOCK TABLES `subscriber_email_logs` WRITE;
/*!40000 ALTER TABLE `subscriber_email_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriber_email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `summary`
--

DROP TABLE IF EXISTS `summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `summary` (
  `summary_id` int(11) NOT NULL AUTO_INCREMENT,
  `summary_type` varchar(255) DEFAULT NULL,
  `summary_title` varchar(255) DEFAULT NULL,
  `summary_value` varchar(255) DEFAULT NULL,
  `summary_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`summary_id`),
  KEY `idx_summary_type` (`summary_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `summary`
--

LOCK TABLES `summary` WRITE;
/*!40000 ALTER TABLE `summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) NOT NULL DEFAULT 'projects',
  `task_status` varchar(25) DEFAULT NULL,
  `task_priority` varchar(25) DEFAULT NULL,
  `task_name` varchar(1024) DEFAULT NULL,
  `task_description` text DEFAULT NULL,
  `assign_to` int(11) NOT NULL DEFAULT 0,
  `assign_by` int(11) NOT NULL DEFAULT 0,
  `milestone` varchar(255) DEFAULT NULL,
  `estimate_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `device` varchar(100) DEFAULT NULL,
  `deviceId` varchar(100) DEFAULT NULL,
  `deviceType` varchar(100) DEFAULT NULL,
  `appVersion` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`task_id`),
  KEY `idx_project_id` (`project_id`),
  KEY `idx_assign_to` (`assign_to`),
  KEY `idx_task_status` (`task_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_activity`
--

DROP TABLE IF EXISTS `task_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_activity` (
  `task_activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL DEFAULT 0,
  `task_name` varchar(255) DEFAULT NULL,
  `task_action` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`task_activity_id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_activity`
--

LOCK TABLES `task_activity` WRITE;
/*!40000 ALTER TABLE `task_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_comments`
--

DROP TABLE IF EXISTS `task_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_comments` (
  `task_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL DEFAULT 0,
  `task_name` varchar(255) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `commented_by` int(11) NOT NULL DEFAULT 0,
  `commented_by_name` varchar(255) DEFAULT NULL,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(225) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`task_comment_id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_commented_by` (`commented_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_comments`
--

LOCK TABLES `task_comments` WRITE;
/*!40000 ALTER TABLE `task_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timecard`
--

DROP TABLE IF EXISTS `timecard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timecard` (
  `timecard_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `task_id` int(11) NOT NULL DEFAULT 0,
  `task_name` varchar(255) DEFAULT NULL,
  `task_comment` text DEFAULT NULL,
  `hours` decimal(10,2) DEFAULT 0.00,
  `is_weekend` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_publicholiday` enum('Y','N') NOT NULL DEFAULT 'N',
  `adjustment_day` enum('Y','N') NOT NULL DEFAULT 'Y',
  `adjustment_day_notes` text DEFAULT NULL,
  `timecard_date` date DEFAULT NULL,
  `festival_name` varchar(255) DEFAULT NULL,
  `working_day_status` varchar(255) DEFAULT NULL,
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `device` varchar(100) DEFAULT NULL,
  `deviceId` varchar(100) DEFAULT NULL,
  `deviceType` varchar(100) DEFAULT NULL,
  `appVersion` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`timecard_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_timecard_date` (`timecard_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timecard`
--

LOCK TABLES `timecard` WRITE;
/*!40000 ALTER TABLE `timecard` DISABLE KEYS */;
/*!40000 ALTER TABLE `timecard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timecard_ot`
--

DROP TABLE IF EXISTS `timecard_ot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timecard_ot` (
  `ot_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `month` int(11) NOT NULL DEFAULT 0,
  `year` int(11) NOT NULL DEFAULT 0,
  `total_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ot_date` datetime DEFAULT NULL,
  `ot_day` varchar(20) DEFAULT NULL,
  `ot_type` varchar(20) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ot_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_month_year` (`month`,`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timecard_ot`
--

LOCK TABLES `timecard_ot` WRITE;
/*!40000 ALTER TABLE `timecard_ot` DISABLE KEYS */;
/*!40000 ALTER TABLE `timecard_ot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_pin` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `access_token` varchar(255) DEFAULT NULL,
  `security_question_id` int(11) NOT NULL DEFAULT 0,
  `security_answer` varchar(191) DEFAULT NULL,
  `user_address1` varchar(191) DEFAULT NULL,
  `user_address2` varchar(191) DEFAULT NULL,
  `user_city` varchar(191) DEFAULT NULL,
  `user_state` varchar(191) DEFAULT NULL,
  `user_zipcode` varchar(191) DEFAULT NULL,
  `user_country` varchar(191) DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `display_on_listing` enum('Y','N') NOT NULL DEFAULT 'Y',
  `show_action_checkbox` enum('Y','N') NOT NULL DEFAULT 'Y',
  `api_token` varchar(255) DEFAULT NULL,
  `item_type` varchar(25) NOT NULL DEFAULT 'users',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `fail_attempt` tinyint(4) NOT NULL DEFAULT 0,
  `blocked` enum('Y','N') NOT NULL DEFAULT 'N',
  `cart_id_pk` int(11) NOT NULL DEFAULT 0,
  `device` varchar(255) DEFAULT 'website',
  `device_id` varchar(255) DEFAULT 'windows',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `deleted_by_name` varchar(255) DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deviceId` varchar(255) DEFAULT NULL,
  `deviceType` varchar(255) DEFAULT NULL,
  `appVersion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_registration`
--

DROP TABLE IF EXISTS `website_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_registration` (
  `website_registration_id` int(11) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(255) DEFAULT NULL,
  `website_url` varchar(255) DEFAULT NULL,
  `registered_date` date DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `expired_notification_date` date DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `client_email` varchar(255) DEFAULT NULL,
  `client_contact` varchar(255) DEFAULT NULL,
  `client_registration_date` date DEFAULT NULL,
  `domain_registration_on` varchar(255) DEFAULT NULL,
  `our_domain_registration` enum('Y','N') NOT NULL DEFAULT 'N',
  `hosted_on` varchar(255) DEFAULT NULL,
  `our_hosting_registration` enum('Y','N') NOT NULL DEFAULT 'N',
  `cloudflare_registered` enum('Y','N') NOT NULL DEFAULT 'N',
  `description` text DEFAULT NULL,
  `display_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted_status` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`website_registration_id`),
  KEY `idx_display_status` (`display_status`),
  KEY `idx_expired_date` (`expired_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_registration`
--

LOCK TABLES `website_registration` WRITE;
/*!40000 ALTER TABLE `website_registration` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_revenue`
--

DROP TABLE IF EXISTS `work_revenue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_revenue` (
  `revenue_id` int(11) NOT NULL AUTO_INCREMENT,
  `financial_year` varchar(255) DEFAULT NULL,
  `total_work_income` decimal(10,2) DEFAULT NULL,
  `paid_to_others` decimal(10,2) DEFAULT NULL,
  `paid_to_others_notes` text DEFAULT NULL,
  `total_income_received` decimal(10,2) DEFAULT NULL,
  `total_income_pending` decimal(10,2) DEFAULT NULL COMMENT 'To Be received next FY',
  `previous_pending_income` decimal(10,2) DEFAULT NULL COMMENT 'Previous FY received Income',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`revenue_id`),
  UNIQUE KEY `financial_year` (`financial_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_revenue`
--

LOCK TABLES `work_revenue` WRITE;
/*!40000 ALTER TABLE `work_revenue` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_revenue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_day`
--

DROP TABLE IF EXISTS `working_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `working_day` (
  `working_day_id` int(11) NOT NULL AUTO_INCREMENT,
  `day_type` varchar(255) DEFAULT NULL COMMENT 'Working,Weekend,Festival,Others',
  `working_date` date DEFAULT NULL,
  `week_day` varchar(30) DEFAULT NULL,
  `festival_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`working_day_id`),
  UNIQUE KEY `working_date` (`working_date`),
  KEY `idx_day_type` (`day_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_day`
--

LOCK TABLES `working_day` WRITE;
/*!40000 ALTER TABLE `working_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_day` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-28 16:51:27
